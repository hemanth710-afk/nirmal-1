"""
Attention primitives for Nirmal-1:
- NirmalRMSNorm: Root Mean Square Layer Normalization.
- NirmalRotaryEmbedding: 1D Rotary Position Embeddings (RoPE).
- NirmalCausalAttention: Grouped Query Attention (GQA) with causal masking and KV cache.
"""

import math
from typing import Optional, Tuple
import torch
import torch.nn as nn
import torch.nn.functional as F

from nirmal.configuration_nirmal import NirmalConfig


class NirmalRMSNorm(nn.Module):
    """Root Mean Square Layer Normalization (RMSNorm)."""

    def __init__(self, hidden_size: int, eps: float = 1e-6):
        super().__init__()
        self.eps = eps
        self.weight = nn.Parameter(torch.ones(hidden_size))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        input_dtype = x.dtype
        variance = x.to(torch.float32).pow(2).mean(-1, keepdim=True)
        x_normed = x * torch.rsqrt(variance + self.eps)
        return x_normed.to(input_dtype) * self.weight


class NirmalRotaryEmbedding(nn.Module):
    """Rotary Position Embedding (RoPE) for relative sequence position encoding."""

    def __init__(self, dim: int, max_position_embeddings: int = 8192, base: float = 10000.0):
        super().__init__()
        self.dim = dim
        self.max_position_embeddings = max_position_embeddings
        self.base = base

        # Precompute inverse frequencies: dim must be even
        inv_freq = 1.0 / (self.base ** (torch.arange(0, self.dim, 2).float() / self.dim))
        self.register_buffer("inv_freq", inv_freq, persistent=False)
        self._set_cos_sin_cache(max_position_embeddings)

    def _set_cos_sin_cache(self, seq_len: int, device: Optional[torch.device] = None, dtype: torch.dtype = torch.float32) -> None:
        self.max_seq_len_cached = max(seq_len, getattr(self, "max_seq_len_cached", 0))
        target_device = device if device is not None else self.inv_freq.device
        t = torch.arange(self.max_seq_len_cached, device=target_device, dtype=self.inv_freq.dtype)
        freqs = torch.outer(t, self.inv_freq)
        emb = torch.cat((freqs, freqs), dim=-1)
        self.register_buffer("cos_cached", emb.cos().to(dtype), persistent=False)
        self.register_buffer("sin_cached", emb.sin().to(dtype), persistent=False)

    def forward(self, x: torch.Tensor, seq_len: int) -> Tuple[torch.Tensor, torch.Tensor]:
        """Returns cos and sin slices matching seq_len."""
        if seq_len > self.max_seq_len_cached:
            self._set_cos_sin_cache(seq_len=seq_len, device=x.device, dtype=x.dtype)
        return (
            self.cos_cached[:seq_len].to(device=x.device, dtype=x.dtype),
            self.sin_cached[:seq_len].to(device=x.device, dtype=x.dtype),
        )


def rotate_half(x: torch.Tensor) -> torch.Tensor:
    """Rotates half the hidden dimensions of the input."""
    x1 = x[..., : x.shape[-1] // 2]
    x2 = x[..., x.shape[-1] // 2 :]
    return torch.cat((-x2, x1), dim=-1)


def apply_rotary_pos_emb(
    q: torch.Tensor,
    k: torch.Tensor,
    cos: torch.Tensor,
    sin: torch.Tensor,
    position_ids: Optional[torch.Tensor] = None,
) -> Tuple[torch.Tensor, torch.Tensor]:
    """Applies Rotary Position Embedding to query and key tensors.

    q, k shape: (batch_size, num_heads, seq_len, head_dim)
    cos, sin shape: (seq_len, head_dim) or (max_pos, head_dim)
    """
    if position_ids is None:
        # cos, sin shape: (seq_len, head_dim) -> reshape to (1, 1, seq_len, head_dim)
        cos = cos.unsqueeze(0).unsqueeze(0)
        sin = sin.unsqueeze(0).unsqueeze(0)
    else:
        # position_ids shape: (batch_size, seq_len)
        cos = cos[position_ids].unsqueeze(1)  # (batch_size, 1, seq_len, head_dim)
        sin = sin[position_ids].unsqueeze(1)

    q_embed = (q * cos) + (rotate_half(q) * sin)
    k_embed = (k * cos) + (rotate_half(k) * sin)
    return q_embed, k_embed


def repeat_kv(hidden_states: torch.Tensor, n_rep: int) -> torch.Tensor:
    """Repeat key/value heads along head dimension for GQA.

    Input shape: (batch, num_key_value_heads, seq_len, head_dim)
    Output shape: (batch, num_attention_heads, seq_len, head_dim)
    """
    if n_rep == 1:
        return hidden_states
    batch, num_key_value_heads, seq_len, head_dim = hidden_states.shape
    hidden_states = hidden_states[:, :, None, :, :].expand(
        batch, num_key_value_heads, n_rep, seq_len, head_dim
    )
    return hidden_states.reshape(batch, num_key_value_heads * n_rep, seq_len, head_dim)


class NirmalCausalAttention(nn.Module):
    """Grouped Query Attention (GQA) with causal masking and KV cache."""

    def __init__(self, config: NirmalConfig, layer_idx: Optional[int] = None):
        super().__init__()
        self.config = config
        self.layer_idx = layer_idx
        self.hidden_size = config.hidden_size
        self.num_heads = config.num_attention_heads
        self.head_dim = config.head_dim
        self.num_key_value_heads = config.num_key_value_heads
        self.num_key_value_groups = self.num_heads // self.num_key_value_heads

        self.q_proj = nn.Linear(self.hidden_size, self.num_heads * self.head_dim, bias=config.use_bias)
        self.k_proj = nn.Linear(self.hidden_size, self.num_key_value_heads * self.head_dim, bias=config.use_bias)
        self.v_proj = nn.Linear(self.hidden_size, self.num_key_value_heads * self.head_dim, bias=config.use_bias)
        self.o_proj = nn.Linear(self.num_heads * self.head_dim, self.hidden_size, bias=config.use_bias)

        self.rotary_emb = NirmalRotaryEmbedding(
            dim=self.head_dim,
            max_position_embeddings=config.context_length,
            base=config.rope_theta,
        )
        self.dropout = nn.Dropout(config.attention_dropout)

    def forward(
        self,
        hidden_states: torch.Tensor,
        attention_mask: Optional[torch.Tensor] = None,
        position_ids: Optional[torch.Tensor] = None,
        past_key_value: Optional[Tuple[torch.Tensor, torch.Tensor]] = None,
        use_cache: bool = False,
    ) -> Tuple[torch.Tensor, Optional[Tuple[torch.Tensor, torch.Tensor]]]:
        """Forward pass of GQA attention with causal masking."""
        batch_size, seq_len, _ = hidden_states.shape

        # Linear projections
        query_states = self.q_proj(hidden_states)
        key_states = self.k_proj(hidden_states)
        value_states = self.v_proj(hidden_states)

        # Reshape to (batch, heads, seq_len, head_dim)
        query_states = query_states.view(batch_size, seq_len, self.num_heads, self.head_dim).transpose(1, 2)
        key_states = key_states.view(batch_size, seq_len, self.num_key_value_heads, self.head_dim).transpose(1, 2)
        value_states = value_states.view(batch_size, seq_len, self.num_key_value_heads, self.head_dim).transpose(1, 2)

        kv_seq_len = key_states.shape[-2]
        past_len = past_key_value[0].shape[-2] if past_key_value is not None else 0
        total_kv_len = kv_seq_len + past_len

        # Determine RoPE cache requirement
        req_pos_len = total_kv_len
        if position_ids is not None:
            max_pos = int(position_ids.max().item()) + 1
            req_pos_len = max(req_pos_len, max_pos)

        cos, sin = self.rotary_emb(value_states, seq_len=req_pos_len)

        if position_ids is not None:
            query_states, key_states = apply_rotary_pos_emb(
                query_states, key_states, cos, sin, position_ids=position_ids
            )
        elif past_key_value is not None:
            cos_slice = cos[past_len : past_len + seq_len]
            sin_slice = sin[past_len : past_len + seq_len]
            query_states, key_states = apply_rotary_pos_emb(query_states, key_states, cos_slice, sin_slice)
        else:
            cos_slice = cos[:seq_len]
            sin_slice = sin[:seq_len]
            query_states, key_states = apply_rotary_pos_emb(query_states, key_states, cos_slice, sin_slice)

        if past_key_value is not None:
            key_states = torch.cat([past_key_value[0], key_states], dim=2)
            value_states = torch.cat([past_key_value[1], value_states], dim=2)

        present_key_value = (key_states, value_states) if use_cache else None

        # Repeat key/value heads for GQA
        key_states = repeat_kv(key_states, self.num_key_value_groups)
        value_states = repeat_kv(value_states, self.num_key_value_groups)

        # Scaled dot-product attention
        scale = 1.0 / math.sqrt(self.head_dim)
        attn_weights = torch.matmul(query_states, key_states.transpose(2, 3)) * scale

        # Prepare 4D attention mask combining causal and custom masks
        total_key_len = key_states.shape[-2]
        causal_mask = None
        if seq_len > 1:
            causal_mask = torch.triu(
                torch.full((seq_len, total_key_len), float("-inf"), device=hidden_states.device, dtype=hidden_states.dtype),
                diagonal=total_key_len - seq_len + 1,
            )

        if attention_mask is not None:
            # Format custom mask to 4D additive
            if attention_mask.dim() == 2:
                # (batch, seq_len) -> (batch, 1, 1, total_key_len)
                # Expand 1 for valid token, 0 for pad into 0.0 for valid, -inf for pad
                expanded_mask = torch.zeros(
                    batch_size, 1, 1, total_key_len, device=hidden_states.device, dtype=hidden_states.dtype
                )
                if attention_mask.shape[-1] == total_key_len:
                    padding_zero_mask = (attention_mask == 0).unsqueeze(1).unsqueeze(2)
                    expanded_mask = expanded_mask.masked_fill(padding_zero_mask, float("-inf"))
                attention_mask = expanded_mask

            attn_weights = attn_weights + attention_mask

        if causal_mask is not None:
            attn_weights = attn_weights + causal_mask

        attn_weights = F.softmax(attn_weights, dim=-1, dtype=torch.float32).to(query_states.dtype)
        attn_weights = self.dropout(attn_weights)

        attn_output = torch.matmul(attn_weights, value_states)
        attn_output = attn_output.transpose(1, 2).contiguous()
        attn_output = attn_output.reshape(batch_size, seq_len, self.hidden_size)
        attn_output = self.o_proj(attn_output)

        return attn_output, present_key_value
