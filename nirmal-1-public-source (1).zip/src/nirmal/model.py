"""
Nirmal-1 Core Neural Model Architecture:
- NirmalHybridCache: Dynamic state container for both GQA KV pairs and DeltaNet recurrent matrices.
- NirmalDecoderLayer: Hybrid transformer block interleaving DeltaNet/GQA token mixing and MoE/SwiGLU channel mixing.
- NirmalModel: Transformer backbone (embeddings, stacked layers, final RMSNorm).
- NirmalForCausalLM: Complete causal language model with LM head and composite training loss.
"""

from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple, Union
import torch
import torch.nn as nn
import torch.nn.functional as F

from nirmal.configuration_nirmal import NirmalConfig
from nirmal.attention import NirmalRMSNorm, NirmalCausalAttention
from nirmal.delta_net import NirmalDeltaNet
from nirmal.moe import NirmalSparseMoE, NirmalSwiGLU


class NirmalHybridCache:
    """Manages cache states for both full attention layers (KV pairs) and DeltaNet layers (recurrent matrices)."""

    def __init__(self) -> None:
        # Map layer_idx -> Tuple[torch.Tensor, torch.Tensor] for GQA
        self.kv_cache: Dict[int, Tuple[torch.Tensor, torch.Tensor]] = {}
        # Map layer_idx -> torch.Tensor for DeltaNet recurrent state
        self.delta_states: Dict[int, torch.Tensor] = {}
        self.seen_tokens: int = 0

    def get_kv(self, layer_idx: int) -> Optional[Tuple[torch.Tensor, torch.Tensor]]:
        return self.kv_cache.get(layer_idx)

    def set_kv(self, layer_idx: int, kv: Tuple[torch.Tensor, torch.Tensor]) -> None:
        self.kv_cache[layer_idx] = kv
        self.seen_tokens = max(self.seen_tokens, kv[0].shape[-2])

    def get_delta_state(self, layer_idx: int) -> Optional[torch.Tensor]:
        return self.delta_states.get(layer_idx)

    def set_delta_state(self, layer_idx: int, state: torch.Tensor) -> None:
        self.delta_states[layer_idx] = state

    def increment_seen_tokens(self, delta: int) -> None:
        self.seen_tokens += delta

    def get_seq_length(self, layer_idx: Optional[int] = None) -> int:
        """Returns sequence length. If layer_idx has KV cache, returns KV length; otherwise seen tokens."""
        if layer_idx is not None and layer_idx in self.kv_cache:
            return self.kv_cache[layer_idx][0].shape[-2]
        return self.seen_tokens

    def reset(self) -> None:
        self.kv_cache.clear()
        self.delta_states.clear()
        self.seen_tokens = 0


@dataclass
class NirmalCausalLMOutput:
    """Output container for NirmalForCausalLM."""
    loss: Optional[torch.Tensor] = None
    logits: Optional[torch.Tensor] = None
    router_loss: Optional[torch.Tensor] = None
    past_key_values: Optional[NirmalHybridCache] = None
    hidden_states: Optional[torch.Tensor] = None


class NirmalDecoderLayer(nn.Module):
    """Decoder layer combining a token mixer (DeltaNet or GQA) with a channel mixer (MoE or SwiGLU)."""

    def __init__(self, config: NirmalConfig, layer_idx: int):
        super().__init__()
        self.config = config
        self.layer_idx = layer_idx
        self.layer_type = config.layer_types[layer_idx]

        self.input_layernorm = NirmalRMSNorm(config.hidden_size, eps=config.rms_norm_eps)

        # Token mixer: DeltaNet or Causal Attention
        if self.layer_type == "causal_attention":
            self.token_mixer = NirmalCausalAttention(config, layer_idx=layer_idx)
        elif self.layer_type == "delta_net":
            self.token_mixer = NirmalDeltaNet(config, layer_idx=layer_idx)
        else:
            raise ValueError(f"Unsupported layer type: {self.layer_type}")

        self.post_attention_layernorm = NirmalRMSNorm(config.hidden_size, eps=config.rms_norm_eps)

        # Channel mixer: Sparse MoE or dense SwiGLU
        is_moe = (config.moe_layer_interval > 0) and ((layer_idx + 1) % config.moe_layer_interval == 0)
        if is_moe and config.num_experts > 1:
            self.channel_mixer = NirmalSparseMoE(config)
            self.is_moe = True
        else:
            self.channel_mixer = NirmalSwiGLU(
                hidden_size=config.hidden_size,
                intermediate_size=config.intermediate_size,
                use_bias=config.use_bias,
            )
            self.is_moe = False

    def forward(
        self,
        hidden_states: torch.Tensor,
        attention_mask: Optional[torch.Tensor] = None,
        position_ids: Optional[torch.Tensor] = None,
        cache: Optional[NirmalHybridCache] = None,
        use_cache: bool = False,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """Forward pass for decoder layer.

        Returns:
            Tuple of:
                - hidden_states: (batch, seq_len, hidden_size)
                - router_loss: Scalar auxiliary loss
        """
        residual = hidden_states
        normed_states = self.input_layernorm(hidden_states)

        # 1. Token Mixing (DeltaNet or GQA)
        if self.layer_type == "causal_attention":
            past_kv = cache.get_kv(self.layer_idx) if cache is not None else None
            mixer_out, present_kv = self.token_mixer(
                normed_states,
                attention_mask=attention_mask,
                position_ids=position_ids,
                past_key_value=past_kv,
                use_cache=use_cache,
            )
            if use_cache and cache is not None and present_kv is not None:
                cache.set_kv(self.layer_idx, present_kv)
        else:
            # DeltaNet
            past_delta = cache.get_delta_state(self.layer_idx) if cache is not None else None
            mixer_out, present_delta = self.token_mixer(
                normed_states,
                attention_mask=attention_mask,
                position_ids=position_ids,
                state=past_delta,
                use_cache=use_cache,
            )
            if use_cache and cache is not None and present_delta is not None:
                cache.set_delta_state(self.layer_idx, present_delta)

        hidden_states = residual + mixer_out

        # 2. Channel Mixing (MoE or SwiGLU)
        residual = hidden_states
        normed_states = self.post_attention_layernorm(hidden_states)

        if self.is_moe:
            feed_forward_out, router_loss = self.channel_mixer(normed_states)
        else:
            feed_forward_out = self.channel_mixer(normed_states)
            router_loss = torch.tensor(0.0, device=hidden_states.device, dtype=hidden_states.dtype)

        hidden_states = residual + feed_forward_out
        return hidden_states, router_loss


class NirmalModel(nn.Module):
    """Nirmal-1 Transformer Backbone."""

    def __init__(self, config: NirmalConfig):
        super().__init__()
        self.config = config
        self.embed_tokens = nn.Embedding(config.vocab_size, config.hidden_size)
        self.layers = nn.ModuleList([
            NirmalDecoderLayer(config, layer_idx=i) for i in range(config.num_hidden_layers)
        ])
        self.norm = NirmalRMSNorm(config.hidden_size, eps=config.rms_norm_eps)

        self._init_weights()

    def _init_weights(self) -> None:
        for module in self.modules():
            if isinstance(module, nn.Linear):
                nn.init.normal_(module.weight, mean=0.0, std=self.config.initializer_range)
                if module.bias is not None:
                    nn.init.zeros_(module.bias)
            elif isinstance(module, nn.Embedding):
                nn.init.normal_(module.weight, mean=0.0, std=self.config.initializer_range)

    def forward(
        self,
        input_ids: torch.Tensor,
        attention_mask: Optional[torch.Tensor] = None,
        position_ids: Optional[torch.Tensor] = None,
        cache: Optional[NirmalHybridCache] = None,
        use_cache: bool = False,
    ) -> Tuple[torch.Tensor, torch.Tensor, Optional[NirmalHybridCache]]:
        batch_size, seq_len = input_ids.shape

        if use_cache and cache is None:
            cache = NirmalHybridCache()

        hidden_states = self.embed_tokens(input_ids)
        total_router_loss = torch.tensor(0.0, device=input_ids.device)

        for layer in self.layers:
            hidden_states, layer_router_loss = layer(
                hidden_states,
                attention_mask=attention_mask,
                position_ids=position_ids,
                cache=cache,
                use_cache=use_cache,
            )
            total_router_loss = total_router_loss + layer_router_loss

        hidden_states = self.norm(hidden_states)

        if use_cache and cache is not None:
            cache.seen_tokens = max(cache.seen_tokens, cache.seen_tokens + (seq_len if not cache.kv_cache else 0))

        return hidden_states, total_router_loss, (cache if use_cache else None)


class NirmalForCausalLM(nn.Module):
    """Nirmal-1 Causal Language Model with LM Head and unified training loss."""

    def __init__(self, config: NirmalConfig):
        super().__init__()
        self.config = config
        self.model = NirmalModel(config)
        self.lm_head = nn.Linear(config.hidden_size, config.vocab_size, bias=False)

        if config.tie_word_embeddings:
            self.lm_head.weight = self.model.embed_tokens.weight

    def forward(
        self,
        input_ids: torch.Tensor,
        attention_mask: Optional[torch.Tensor] = None,
        position_ids: Optional[torch.Tensor] = None,
        labels: Optional[torch.Tensor] = None,
        cache: Optional[NirmalHybridCache] = None,
        use_cache: bool = False,
    ) -> NirmalCausalLMOutput:
        hidden_states, router_loss, past_cache = self.model(
            input_ids=input_ids,
            attention_mask=attention_mask,
            position_ids=position_ids,
            cache=cache,
            use_cache=use_cache,
        )

        logits = self.lm_head(hidden_states)

        loss = None
        if labels is not None:
            # Shift tokens for next-token prediction
            shift_logits = logits[..., :-1, :].contiguous()
            shift_labels = labels[..., 1:].contiguous()

            # Flatten cross-entropy
            lm_loss = F.cross_entropy(
                shift_logits.view(-1, self.config.vocab_size),
                shift_labels.view(-1),
                ignore_index=-100,
            )
            loss = lm_loss + router_loss

        return NirmalCausalLMOutput(
            loss=loss,
            logits=logits,
            router_loss=router_loss,
            past_key_values=past_cache,
            hidden_states=hidden_states,
        )

    def count_parameters(self) -> Dict[str, int]:
        """Return total and trainable parameter counts."""
        total = sum(p.numel() for p in self.parameters())
        trainable = sum(p.numel() for p in self.parameters() if p.requires_grad)
        return {"total": total, "trainable": trainable}
