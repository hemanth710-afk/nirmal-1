"""
Sparse Mixture of Experts (MoE) implementation for Nirmal-1.
Includes SwiGLU expert feed-forward network, Top-K router with auxiliary load-balancing
loss and router z-loss, and vectorized sparse MoE block.
"""

from typing import Optional, Tuple
import torch
import torch.nn as nn
import torch.nn.functional as F

from nirmal.configuration_nirmal import NirmalConfig


class NirmalSwiGLU(nn.Module):
    """SwiGLU Feed-Forward Network: SwiGLU(x) = (SiLU(x @ W_gate) * (x @ W_up)) @ W_down."""

    def __init__(self, hidden_size: int, intermediate_size: int, use_bias: bool = False):
        super().__init__()
        self.gate_proj = nn.Linear(hidden_size, intermediate_size, bias=use_bias)
        self.up_proj = nn.Linear(hidden_size, intermediate_size, bias=use_bias)
        self.down_proj = nn.Linear(intermediate_size, hidden_size, bias=use_bias)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.down_proj(F.silu(self.gate_proj(x)) * self.up_proj(x))


class NirmalTopKRouter(nn.Module):
    """Top-K Router with softmax gating, auxiliary load-balancing loss, and router z-loss."""

    def __init__(
        self,
        hidden_size: int,
        num_experts: int,
        top_k: int = 2,
        aux_loss_coef: float = 0.01,
        z_loss_coef: float = 0.001,
    ):
        super().__init__()
        self.hidden_size = hidden_size
        self.num_experts = num_experts
        self.top_k = top_k
        self.aux_loss_coef = aux_loss_coef
        self.z_loss_coef = z_loss_coef
        self.weight = nn.Parameter(torch.empty(num_experts, hidden_size))
        nn.init.normal_(self.weight, std=0.02)

    def forward(
        self, hidden_states: torch.Tensor
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        """Compute routing weights, selected expert indices, and router auxiliary loss.

        Args:
            hidden_states: (batch_size, seq_len, hidden_size)

        Returns:
            Tuple of:
                - routing_weights: (batch_size, seq_len, top_k)
                - selected_experts: (batch_size, seq_len, top_k)
                - router_loss: Scalar auxiliary loss tensor
        """
        batch_size, seq_len, _ = hidden_states.shape
        flat_hidden = hidden_states.view(-1, self.hidden_size)  # (N, hidden_size)

        # Compute raw routing logits: (N, num_experts)
        router_logits = F.linear(flat_hidden, self.weight)

        # 1. Router z-loss: penalizes large logit magnitudes for numerical stability
        log_z = torch.logsumexp(router_logits, dim=-1)  # (N,)
        z_loss = torch.mean(log_z ** 2) * self.z_loss_coef

        # 2. Select top-k experts per token
        topk_logits, selected_experts = torch.topk(router_logits, self.top_k, dim=-1)

        # Softmax normalize over the top-k selected experts
        routing_weights = F.softmax(topk_logits, dim=-1, dtype=torch.float32).to(hidden_states.dtype)

        # 3. Auxiliary load-balancing loss (Switch / Mixtral formulation)
        # Probabilities across all experts
        full_probs = F.softmax(router_logits, dim=-1)  # (N, num_experts)
        # Mean probability per expert across all tokens: P_i
        mean_prob = full_probs.mean(dim=0)  # (num_experts,)

        # Fraction of tokens dispatched to each expert: f_i
        # Token is dispatched to expert i if expert i is in its top-k
        expert_mask = F.one_hot(selected_experts, num_classes=self.num_experts).sum(dim=1)  # (N, num_experts)
        tokens_per_expert = expert_mask.float().mean(dim=0)  # (num_experts,)

        aux_loss = self.aux_loss_coef * self.num_experts * torch.sum(tokens_per_expert * mean_prob)
        total_router_loss = aux_loss + z_loss

        routing_weights = routing_weights.view(batch_size, seq_len, self.top_k)
        selected_experts = selected_experts.view(batch_size, seq_len, self.top_k)

        return routing_weights, selected_experts, total_router_loss


class NirmalSparseMoE(nn.Module):
    """Sparse Mixture of Experts module dispatching tokens across SwiGLU expert networks."""

    def __init__(self, config: NirmalConfig):
        super().__init__()
        self.config = config
        self.num_experts = config.num_experts
        self.top_k = config.num_experts_per_tok
        self.hidden_size = config.hidden_size

        self.router = NirmalTopKRouter(
            hidden_size=config.hidden_size,
            num_experts=config.num_experts,
            top_k=config.num_experts_per_tok,
            aux_loss_coef=config.router_aux_loss_coef,
            z_loss_coef=config.router_z_loss_coef,
        )

        self.experts = nn.ModuleList([
            NirmalSwiGLU(
                hidden_size=config.hidden_size,
                intermediate_size=config.intermediate_size,
                use_bias=config.use_bias,
            )
            for _ in range(config.num_experts)
        ])

    def forward(self, hidden_states: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        """Forward pass dispatching tokens to top-k experts.

        Args:
            hidden_states: (batch_size, seq_len, hidden_size)

        Returns:
            Tuple of:
                - output: (batch_size, seq_len, hidden_size)
                - router_loss: Scalar auxiliary loss tensor
        """
        batch_size, seq_len, hidden_size = hidden_states.shape
        flat_x = hidden_states.view(-1, hidden_size)  # (N, D)

        routing_weights, selected_experts, router_loss = self.router(hidden_states)

        flat_weights = routing_weights.view(-1, self.top_k)  # (N, K)
        flat_indices = selected_experts.view(-1, self.top_k)  # (N, K)

        final_output = torch.zeros_like(flat_x)

        # Group tokens by active expert to execute forward passes efficiently
        for expert_idx in range(self.num_experts):
            # Mask of tokens where expert_idx was selected: (N, K)
            mask = (flat_indices == expert_idx)
            if not mask.any():
                continue

            # Token row indices and k-slot indices
            token_idx, k_slot = torch.where(mask)
            expert_in = flat_x[token_idx]
            expert_out = self.experts[expert_idx](expert_in)

            weights = flat_weights[token_idx, k_slot].unsqueeze(-1)
            final_output.index_add_(0, token_idx, expert_out * weights)

        final_output = final_output.view(batch_size, seq_len, hidden_size)
        return final_output, router_loss
