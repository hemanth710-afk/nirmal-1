"""
Configuration module for the Nirmal-1 model architecture.
Provides NirmalConfig with comprehensive parameter validation and serialization.
"""

from dataclasses import dataclass, field, asdict
import json
from pathlib import Path
from typing import Any, Dict, List, Optional, Union


@dataclass
class NirmalConfig:
    """Configuration class for the Nirmal-1 hybrid neural architecture.

    Parameters:
        vocab_size: Size of vocabulary. Default: 32000.
        hidden_size: Dimensionality of encoder/decoder hidden layers. Default: 512.
        num_hidden_layers: Number of decoder layers. Default: 12.
        num_attention_heads: Number of query attention heads. Default: 8.
        num_key_value_heads: Number of key/value heads for GQA. Default: 2.
        head_dim: Dimensionality of each attention head. Default: 64.
        context_length: Maximum sequence context length. Default: 8192.
        intermediate_size: Dimension of the feed-forward intermediate layer. Default: 1408.
        full_attention_interval: Interval for GQA layers in the hybrid stack. Default: 4.
        layer_types: Explicit list of layer types ('delta_net' or 'causal_attention').
        num_experts: Number of routed experts in Sparse MoE. Default: 8.
        num_experts_per_tok: Number of active experts selected per token (top-k). Default: 2.
        router_aux_loss_coef: Weight for router load-balancing auxiliary loss. Default: 0.01.
        router_z_loss_coef: Weight for router logits z-loss stability penalty. Default: 0.001.
        moe_layer_interval: Interval of layers containing MoE blocks. Default: 1 (all layers).
        rms_norm_eps: Epsilon parameter for RMSNorm stabilization. Default: 1e-6.
        rope_theta: Base frequency for Rotary Position Embeddings. Default: 10000.0.
        initializer_range: Standard deviation for weight initialization. Default: 0.02.
        tie_word_embeddings: Whether to tie input embeddings to output LM head. Default: False.
        use_bias: Whether linear projections include additive bias terms. Default: False.
        attention_dropout: Dropout probability for attention weights. Default: 0.0.
        hidden_dropout: Dropout probability for residual connections. Default: 0.0.
        delta_net_qk_norm: Whether to apply L2 normalization to keys in DeltaNet. Default: True.
    """

    vocab_size: int = 32000
    hidden_size: int = 512
    num_hidden_layers: int = 12
    num_attention_heads: int = 8
    num_key_value_heads: int = 2
    head_dim: int = 64
    context_length: int = 8192
    intermediate_size: Optional[int] = 1408
    full_attention_interval: int = 4
    layer_types: Optional[List[str]] = None
    num_experts: int = 8
    num_experts_per_tok: int = 2
    router_aux_loss_coef: float = 0.01
    router_z_loss_coef: float = 0.001
    moe_layer_interval: int = 1
    rms_norm_eps: float = 1e-6
    rope_theta: float = 10000.0
    initializer_range: float = 0.02
    tie_word_embeddings: bool = False
    use_bias: bool = False
    attention_dropout: float = 0.0
    hidden_dropout: float = 0.0
    delta_net_qk_norm: bool = True

    def __post_init__(self) -> None:
        """Validate configuration parameters and auto-resolve derived fields."""
        if self.intermediate_size is None:
            # Standard SwiGLU 8/3 expansion scaled to multiple of 64
            self.intermediate_size = int(2 * self.hidden_size * 4 / 3)
            self.intermediate_size = ((self.intermediate_size + 63) // 64) * 64

        # Validate layer types
        if self.layer_types is None:
            resolved_types = []
            for i in range(self.num_hidden_layers):
                # 1-indexed interval check: periodic layers use full causal attention
                if self.full_attention_interval > 0 and (i + 1) % self.full_attention_interval == 0:
                    resolved_types.append("causal_attention")
                else:
                    resolved_types.append("delta_net")
            self.layer_types = resolved_types

        self.validate()

    def validate(self) -> None:
        """Perform comprehensive dimension and parameter validation checks."""
        if self.vocab_size <= 0:
            raise ValueError(f"vocab_size must be positive, got {self.vocab_size}")
        if self.hidden_size <= 0:
            raise ValueError(f"hidden_size must be positive, got {self.hidden_size}")
        if self.num_hidden_layers <= 0:
            raise ValueError(f"num_hidden_layers must be positive, got {self.num_hidden_layers}")
        if self.num_attention_heads <= 0:
            raise ValueError(f"num_attention_heads must be positive, got {self.num_attention_heads}")
        if self.num_key_value_heads <= 0:
            raise ValueError(f"num_key_value_heads must be positive, got {self.num_key_value_heads}")
        if self.head_dim <= 0:
            raise ValueError(f"head_dim must be positive, got {self.head_dim}")

        expected_hidden = self.num_attention_heads * self.head_dim
        if self.hidden_size != expected_hidden:
            raise ValueError(
                f"hidden_size ({self.hidden_size}) must equal num_attention_heads ({self.num_attention_heads}) "
                f"* head_dim ({self.head_dim}) = {expected_hidden}"
            )

        if self.num_attention_heads % self.num_key_value_heads != 0:
            raise ValueError(
                f"num_attention_heads ({self.num_attention_heads}) must be divisible by "
                f"num_key_value_heads ({self.num_key_value_heads})"
            )

        if self.num_experts < 1:
            raise ValueError(f"num_experts must be >= 1, got {self.num_experts}")
        if self.num_experts_per_tok < 1 or self.num_experts_per_tok > self.num_experts:
            raise ValueError(
                f"num_experts_per_tok ({self.num_experts_per_tok}) must be in [1, num_experts ({self.num_experts})]"
            )

        if len(self.layer_types) != self.num_hidden_layers:
            raise ValueError(
                f"layer_types length ({len(self.layer_types)}) must equal "
                f"num_hidden_layers ({self.num_hidden_layers})"
            )

        valid_types = {"delta_net", "causal_attention"}
        for idx, lt in enumerate(self.layer_types):
            if lt not in valid_types:
                raise ValueError(
                    f"Unknown layer type '{lt}' at index {idx}. Must be one of {valid_types}"
                )

        if self.context_length <= 0:
            raise ValueError(f"context_length must be positive, got {self.context_length}")
        if self.rms_norm_eps <= 0:
            raise ValueError(f"rms_norm_eps must be positive, got {self.rms_norm_eps}")

    def to_dict(self) -> Dict[str, Any]:
        """Convert configuration to dictionary."""
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "NirmalConfig":
        """Construct configuration from dictionary."""
        return cls(**data)

    def to_json_string(self) -> str:
        """Convert configuration to formatted JSON string."""
        return json.dumps(self.to_dict(), indent=2, sort_keys=True)

    @classmethod
    def from_json_string(cls, json_str: str) -> "NirmalConfig":
        """Construct configuration from JSON string."""
        return cls.from_dict(json.loads(json_str))

    def to_json_file(self, file_path: Union[str, Path]) -> None:
        """Save configuration to a JSON file."""
        Path(file_path).write_text(self.to_json_string(), encoding="utf-8")

    @classmethod
    def from_json_file(cls, file_path: Union[str, Path]) -> "NirmalConfig":
        """Load configuration from a JSON file."""
        content = Path(file_path).read_text(encoding="utf-8")
        return cls.from_json_string(content)
