"""
DeltaNet: Linear attention with Delta-rule associative memory recurrence.

Mathematical formulation:
    k_hat = normalize(k, p=2, dim=-1)
    beta = sigmoid(beta_proj(x))
    error = v - S_{t-1} @ k_hat
    S_t = S_{t-1} + beta * (error @ k_hat.T)
    output = S_t @ q
"""

from typing import Any, Optional, Tuple
import torch
import torch.nn as nn
import torch.nn.functional as F

from nirmal.configuration_nirmal import NirmalConfig
from nirmal.attention import NirmalRMSNorm


class NirmalDeltaNet(nn.Module):
    """DeltaNet linear attention layer with associative memory recurrence."""

    def __init__(self, config: NirmalConfig, layer_idx: Optional[int] = None):
        super().__init__()
        self.config = config
        self.layer_idx = layer_idx
        self.hidden_size = config.hidden_size
        self.num_heads = config.num_attention_heads
        self.head_dim = config.head_dim
        self.use_qk_norm = config.delta_net_qk_norm

        # Projections for Q, K, V, Beta (learning rate/decay), and G (output gate)
        self.q_proj = nn.Linear(self.hidden_size, self.hidden_size, bias=config.use_bias)
        self.k_proj = nn.Linear(self.hidden_size, self.hidden_size, bias=config.use_bias)
        self.v_proj = nn.Linear(self.hidden_size, self.hidden_size, bias=config.use_bias)
        self.beta_proj = nn.Linear(self.hidden_size, self.num_heads, bias=True)
        self.g_proj = nn.Linear(self.hidden_size, self.hidden_size, bias=config.use_bias)

        self.norm = NirmalRMSNorm(self.head_dim, eps=config.rms_norm_eps)
        self.out_proj = nn.Linear(self.hidden_size, self.hidden_size, bias=config.use_bias)

    def forward(
        self,
        hidden_states: torch.Tensor,
        attention_mask: Optional[torch.Tensor] = None,
        position_ids: Optional[torch.Tensor] = None,
        state: Optional[torch.Tensor] = None,
        use_cache: bool = False,
        **kwargs: Any,
    ) -> Tuple[torch.Tensor, Optional[torch.Tensor]]:
        """Forward pass for DeltaNet with attention mask and state support.

        Args:
            hidden_states: Input tensor of shape (batch, seq_len, hidden_size)
            attention_mask: Optional padding mask (batch, seq_len)
            position_ids: Optional position ids (for API consistency with attention)
            state: Optional previous recurrent state S_{t-1} of shape
                   (batch, num_heads, head_dim, head_dim)
            use_cache: Whether to return the updated recurrent state

        Returns:
            Tuple of:
                - output tensor: (batch, seq_len, hidden_size)
                - next_state: (batch, num_heads, head_dim, head_dim) if use_cache else None
        """
        batch_size, seq_len, _ = hidden_states.shape

        if seq_len == 0:
            empty_out = torch.zeros_like(hidden_states)
            return empty_out, state

        q = self.q_proj(hidden_states)
        k = self.k_proj(hidden_states)
        v = self.v_proj(hidden_states)
        g = F.silu(self.g_proj(hidden_states))  # Output gating
        beta = torch.sigmoid(self.beta_proj(hidden_states))  # (batch, seq_len, num_heads)

        # Reshape to (batch, seq_len, num_heads, head_dim)
        q = q.view(batch_size, seq_len, self.num_heads, self.head_dim)
        k = k.view(batch_size, seq_len, self.num_heads, self.head_dim)
        v = v.view(batch_size, seq_len, self.num_heads, self.head_dim)

        if self.use_qk_norm:
            k = F.normalize(k, p=2, dim=-1, eps=1e-6)

        # Parse padding mask if provided
        step_mask = None
        if attention_mask is not None:
            if attention_mask.dim() == 2:
                step_mask = (attention_mask != 0).float()  # (batch, seq_len)
            elif attention_mask.dim() == 4:
                # (batch, 1, seq_len, seq_len) -> extract diagonal
                step_mask = (attention_mask[:, 0, :, -1] != float("-inf")).float()

        # Initialize recurrent state if not provided
        if state is None:
            current_state = torch.zeros(
                batch_size,
                self.num_heads,
                self.head_dim,
                self.head_dim,
                device=hidden_states.device,
                dtype=hidden_states.dtype,
            )
        else:
            current_state = state.clone()

        # Sequential scan over time dimension
        outputs = []
        for t in range(seq_len):
            q_t = q[:, t]       # (batch, num_heads, head_dim)
            k_t = k[:, t]       # (batch, num_heads, head_dim)
            v_t = v[:, t]       # (batch, num_heads, head_dim)
            beta_t = beta[:, t].unsqueeze(-1).unsqueeze(-1)  # (batch, num_heads, 1, 1)

            # Mask gate for padding tokens
            if step_mask is not None:
                token_valid = step_mask[:, t].view(batch_size, 1, 1, 1)
                beta_t = beta_t * token_valid

            k_col = k_t.unsqueeze(-1)  # (batch, num_heads, head_dim, 1)
            k_row = k_t.unsqueeze(-2)  # (batch, num_heads, 1, head_dim)
            v_col = v_t.unsqueeze(-1)  # (batch, num_heads, head_dim, 1)

            # Associative recall from previous state: S_{t-1} @ k_t
            pred_v = torch.matmul(current_state, k_col)  # (batch, num_heads, head_dim, 1)
            delta_v = v_col - pred_v

            # Delta-rule rank-1 outer product update:
            update = torch.matmul(delta_v, k_row)
            current_state = current_state + beta_t * update

            # Query retrieval: S_t @ q_t
            q_col = q_t.unsqueeze(-1)
            out_t = torch.matmul(current_state, q_col).squeeze(-1)  # (batch, num_heads, head_dim)

            if step_mask is not None:
                out_t = out_t * step_mask[:, t].view(batch_size, 1, 1)

            outputs.append(out_t)

        out = torch.stack(outputs, dim=1)  # (batch, seq_len, num_heads, head_dim)

        # Head normalization
        out = self.norm(out)
        out = out.reshape(batch_size, seq_len, self.hidden_size)

        # Output gating & projection
        out = out * g
        out = self.out_proj(out)

        next_state = current_state if use_cache else None
        return out, next_state
