"""
Learning & Adaptation Subsystem for Nirmal-1:
- Experience: Dataclass recording complete interaction trajectories.
- EpisodicBuffer: Experience replay buffer for offline/online policy updates and curriculum tuning.
- ExperienceCollector: Real-time telemetry collector for agent rollouts.
"""

from collections import deque
from dataclasses import dataclass, field, asdict
import json
import random
import time
from typing import Any, Deque, Dict, List, Optional


@dataclass
class Experience:
    """A complete structured interaction trajectory from goal presentation to environmental outcome."""
    task_id: str = ""
    goal: str = ""
    task_family: str = "general"
    context: str = ""
    retrieved_memory: List[str] = field(default_factory=list)
    proposed_plan: Dict[str, Any] = field(default_factory=dict)
    actions: List[Dict[str, Any]] = field(default_factory=list)
    observations: List[str] = field(default_factory=list)
    verification_result: Optional[Dict[str, Any]] = None
    reward: float = 0.0
    success: bool = False
    failure_reason: Optional[str] = None
    strategy_used: Optional[str] = None
    timestamp: float = field(default_factory=time.time)
    episode_index: int = 0
    feedback: str = ""
    metadata: Dict[str, Any] = field(default_factory=dict)
    trajectory_id: str = ""

    def __post_init__(self) -> None:
        if not self.task_id and self.trajectory_id:
            self.task_id = self.trajectory_id
        elif not self.trajectory_id and self.task_id:
            self.trajectory_id = self.task_id

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Experience":
        return cls(**data)

    def to_json(self) -> str:
        return json.dumps(self.to_dict())

    @classmethod
    def from_json(cls, json_str: str) -> "Experience":
        return cls.from_dict(json.loads(json_str))


class EpisodicBuffer:
    """Experience replay memory store with O(1) bounded capacity eviction."""

    def __init__(self, max_capacity: int = 10000):
        self.max_capacity = max_capacity
        self.buffer: Deque[Experience] = deque(maxlen=max_capacity)

    def add(self, experience: Experience) -> None:
        """Append an experience trajectory, automatically evicting oldest at capacity."""
        self.buffer.append(experience)

    def record(self, trajectory: Experience) -> None:
        """Conforms to AGI_SPEC.md interface."""
        self.add(trajectory)

    def sample(self, batch_size: int) -> List[Experience]:
        """Uniformly sample a batch of experiences."""
        sample_size = min(batch_size, len(self.buffer))
        return random.sample(list(self.buffer), sample_size)

    def sample_batch(self, batch_size: int) -> List[Experience]:
        """Conforms to AGI_SPEC.md interface."""
        return self.sample(batch_size)

    def get_successful_experiences(self) -> List[Experience]:
        """Return all trajectories that achieved success = True."""
        return [exp for exp in self.buffer if exp.success]

    def query(
        self,
        task_family: Optional[str] = None,
        success: Optional[bool] = None,
        top_k: int = 10,
    ) -> List[Experience]:
        """Query experiences filtered by family and success status, ordered most recent first."""
        results = []
        for exp in reversed(self.buffer):
            if task_family is not None and exp.task_family != task_family:
                continue
            if success is not None and exp.success != success:
                continue
            results.append(exp)
            if len(results) >= top_k:
                break
        return results

    def clear(self) -> None:
        self.buffer.clear()

    def __len__(self) -> int:
        return len(self.buffer)


class ExperienceCollector:
    """Stateful collector recording a current rollout before storing in EpisodicBuffer."""

    def __init__(self, buffer: EpisodicBuffer):
        self.buffer = buffer
        self.current_trajectory: Optional[Experience] = None

    def start_trajectory(self, trajectory_id: str, goal: str) -> None:
        self.current_trajectory = Experience(trajectory_id=trajectory_id, goal=goal)

    def record_step(self, action: Dict[str, Any], observation: str) -> None:
        if self.current_trajectory is not None:
            self.current_trajectory.actions.append(action)
            self.current_trajectory.observations.append(observation)

    def finalize_trajectory(self, success: bool, reward: float, feedback: str = "") -> Optional[Experience]:
        if self.current_trajectory is None:
            return None

        self.current_trajectory.success = success
        self.current_trajectory.reward = reward
        self.current_trajectory.feedback = feedback

        completed_exp = self.current_trajectory
        self.buffer.add(completed_exp)
        self.current_trajectory = None
        return completed_exp
