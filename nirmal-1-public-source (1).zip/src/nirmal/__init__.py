"""
Nirmal-1: Modular AGI Research Architecture & Hybrid Neural Sequence Model.
"""

from nirmal.configuration_nirmal import NirmalConfig
from nirmal.attention import NirmalRMSNorm, NirmalRotaryEmbedding, NirmalCausalAttention
from nirmal.delta_net import NirmalDeltaNet
from nirmal.moe import NirmalTopKRouter, NirmalSwiGLU, NirmalSparseMoE
from nirmal.model import (
    NirmalModel,
    NirmalForCausalLM,
    NirmalCausalLMOutput,
    NirmalDecoderLayer,
    NirmalHybridCache,
)
from nirmal.generation import NirmalGenerator
from nirmal.memory import (
    WorkingMemory,
    PersistentMemory,
    InMemoryVectorStore,
    RetrievalEngine,
    MemoryRecord,
)
from nirmal.reasoning import (
    ReasoningEngine,
    ReasoningTrace,
    ReasoningStep,
    StepType,
    VerificationResult,
)
from nirmal.planning import (
    Planner,
    TaskGraph,
    PlanNode,
    PlanStatus,
)
from nirmal.learning import (
    Experience,
    EpisodicBuffer,
    ExperienceCollector,
)
from nirmal.tools import (
    Tool,
    ToolResult,
    ToolRegistry,
    CalculatorTool,
)
from nirmal.agent import (
    CognitiveController,
    ControllerState,
    ControllerResult,
    Goal,
    WorldState,
    DeterministicVerifier,
)

__version__ = "0.1.0"

__all__ = [
    "NirmalConfig",
    "NirmalRMSNorm",
    "NirmalRotaryEmbedding",
    "NirmalCausalAttention",
    "NirmalDeltaNet",
    "NirmalTopKRouter",
    "NirmalSwiGLU",
    "NirmalSparseMoE",
    "NirmalModel",
    "NirmalForCausalLM",
    "NirmalCausalLMOutput",
    "NirmalDecoderLayer",
    "NirmalHybridCache",
    "NirmalGenerator",
    "WorkingMemory",
    "PersistentMemory",
    "InMemoryVectorStore",
    "RetrievalEngine",
    "MemoryRecord",
    "ReasoningEngine",
    "ReasoningTrace",
    "ReasoningStep",
    "StepType",
    "VerificationResult",
    "Planner",
    "TaskGraph",
    "PlanNode",
    "PlanStatus",
    "Experience",
    "EpisodicBuffer",
    "ExperienceCollector",
    "Tool",
    "ToolResult",
    "ToolRegistry",
    "CalculatorTool",
    "CognitiveController",
    "ControllerState",
    "ControllerResult",
    "Goal",
    "WorldState",
    "DeterministicVerifier",
]
