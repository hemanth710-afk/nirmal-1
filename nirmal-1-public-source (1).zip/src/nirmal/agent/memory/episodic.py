"""
Episodic Memory Subsystem for Nirmal-1.
Records and indexes specific past interaction trajectories and outcomes.
"""

from collections import deque
from dataclasses import dataclass, field, asdict
import time
from typing import Any, Deque, Dict, List, Optional


@dataclass
class Episode:
    """A complete record of an agent's cognitive episode."""
    episode_id: str
    goal: str
    context: str = ""
    retrieved_memories: List[str] = field(default_factory=list)
    reasoning_summary: str = ""
    plan: Optional[Dict[str, Any]] = None
    actions: List[Dict[str, Any]] = field(default_factory=list)
    observations: List[str] = field(default_factory=list)
    verification_results: List[Dict[str, Any]] = field(default_factory=list)
    outcome: Any = None
    success: bool = False
    reward: float = 0.0
    timestamp: float = field(default_factory=time.time)
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Episode":
        return cls(**data)


class EpisodicMemory:
    """Stores and retrieves specific past interaction episodes with bounded capacity."""

    def __init__(self, max_episodes: int = 1000):
        self.max_episodes = max_episodes
        self.episodes: Deque[Episode] = deque(maxlen=max_episodes)
        self._id_index: Dict[str, Episode] = {}

    def store_episode(self, episode: Episode) -> None:
        """Store a completed episode."""
        if len(self.episodes) == self.max_episodes and self.episodes:
            oldest = self.episodes[0]
            self._id_index.pop(oldest.episode_id, None)

        self.episodes.append(episode)
        self._id_index[episode.episode_id] = episode

    def get_episode(self, episode_id: str) -> Optional[Episode]:
        """Fetch episode by unique identifier."""
        return self._id_index.get(episode_id)

    def query_episodes(self, query_goal: str, top_k: int = 3) -> List[Episode]:
        """Keyword/substring search over past goals."""
        terms = query_goal.lower().split()
        scored = []
        for ep in self.episodes:
            score = sum(1 for term in terms if term in ep.goal.lower())
            if score > 0:
                scored.append((score, ep))

        scored.sort(key=lambda x: x[0], reverse=True)
        return [ep for _, ep in scored[:top_k]]

    def retrieve_similar(self, query_goal: str, top_k: int = 3) -> List[Episode]:
        """Convenience retrieval alias."""
        return self.query_episodes(query_goal=query_goal, top_k=top_k)

    def get_successful_episodes(self) -> List[Episode]:
        """Filter episodes that succeeded."""
        return [ep for ep in self.episodes if ep.success]

    def clear(self) -> None:
        self.episodes.clear()
        self._id_index.clear()

    def __len__(self) -> int:
        return len(self.episodes)
