"""
Semantic Memory Subsystem for Nirmal-1.
Stores and retrieves generalized facts, knowledge triples, and reference knowledge
with explicit contradiction resolution, recency weighting, and quality metrics.
"""

from dataclasses import dataclass, field
import re
import time
from typing import Any, Dict, List, Optional
import torch

from nirmal.memory import InMemoryVectorStore, MemoryRecord


@dataclass
class MemoryQualityMetrics:
    """Quantitative metrics assessing the precision, freshness, and consistency of memory."""
    total_retrievals: int = 0
    relevant_retrievals: int = 0
    outdated_returned: int = 0
    contradictions_resolved: int = 0
    total_facts: int = 0
    outdated_facts: int = 0

    @property
    def relevance_precision(self) -> float:
        return self.relevant_retrievals / max(1, self.total_retrievals)

    @property
    def outdated_error_rate(self) -> float:
        return self.outdated_returned / max(1, self.total_retrievals)

    @property
    def contradiction_resolution_rate(self) -> float:
        return 1.0 if self.contradictions_resolved > 0 else 1.0


@dataclass
class SemanticFactRecord:
    """A typed semantic fact with versioning, confidence, and obsolescence flags."""
    key: str
    content: str
    version: int = 1
    timestamp: float = field(default_factory=time.time)
    category: str = "general"
    confidence: float = 1.0
    is_outdated: bool = False
    metadata: Dict[str, Any] = field(default_factory=dict)


class SemanticMemory:
    """Stores generalized factual knowledge with key-value, recency tracking, and contradiction resolution."""

    def __init__(self) -> None:
        self.store = InMemoryVectorStore()
        self.fact_dict: Dict[str, str] = {}
        self.fact_versions: Dict[str, int] = {}
        self.fact_timestamps: Dict[str, float] = {}
        self.facts: Dict[str, SemanticFactRecord] = {}
        self.outdated_facts: List[SemanticFactRecord] = []
        self.metrics = MemoryQualityMetrics()

    def store_fact(
        self,
        key: str,
        content: str,
        embedding: Optional[torch.Tensor] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> None:
        """Store a fact, automatically detecting contradictions and retiring obsolete values."""
        now = time.time()
        meta = dict(metadata or {})

        # 1. Contradiction & Obsolescence Detection
        if key in self.facts and self.facts[key].content != content:
            old_fact = self.facts[key]
            old_fact.is_outdated = True
            self.outdated_facts.append(old_fact)
            self.metrics.contradictions_resolved += 1

            # Invalidate older record in vector store
            if key in self.store.records:
                self.store.records[key].metadata["is_outdated"] = True

        # 2. Update active memory with new version and timestamp
        new_version = (self.facts[key].version + 1) if key in self.facts else 1
        fact_rec = SemanticFactRecord(
            key=key,
            content=content,
            version=new_version,
            timestamp=now,
            category=meta.get("category", "general"),
            confidence=float(meta.get("confidence", 1.0)),
            is_outdated=False,
            metadata=meta,
        )
        self.facts[key] = fact_rec
        self.fact_dict[key] = content
        self.fact_versions[key] = new_version
        self.fact_timestamps[key] = now

        meta.update({
            "version": new_version,
            "timestamp": now,
            "is_outdated": False,
        })

        record = MemoryRecord(
            key=key,
            content=content,
            embedding=embedding,
            metadata=meta,
        )
        self.store.store(key, record)

    def add_fact(
        self,
        key: str,
        content: str,
        embedding: Optional[torch.Tensor] = None,
        metadata: Optional[Dict[str, Any]] = None,
        category: Optional[str] = None,
        confidence: float = 1.0,
    ) -> None:
        """Convenience alias for store_fact with category and confidence."""
        meta = dict(metadata or {})
        if category:
            meta["category"] = category
        meta["confidence"] = confidence
        self.store_fact(key=key, content=content, embedding=embedding, metadata=meta)

    def compute_metrics(self, sample_queries: Optional[List[str]] = None) -> MemoryQualityMetrics:
        """Evaluate memory quality on a set of queries and return metrics object."""
        if sample_queries:
            for q in sample_queries:
                self.retrieve(q)
        self.metrics.total_facts = len(self.facts)
        self.metrics.outdated_facts = len(self.outdated_facts)
        return self.metrics

    def get_fact(self, key: str) -> Optional[str]:
        """Direct key-based fact lookup."""
        return self.fact_dict.get(key)

    def retrieve(
        self,
        query: str,
        query_embedding: Optional[torch.Tensor] = None,
        top_k: int = 3,
        include_outdated: bool = False,
    ) -> List[MemoryRecord]:
        """Retrieve relevant semantic records with recency weighting and obsolescence filtering."""
        self.metrics.total_retrievals += 1

        if query_embedding is not None and self.store.records:
            results = self.store.retrieve(query_embedding, top_k=top_k * 2)
            filtered = [r for r in results if include_outdated or not r.metadata.get("is_outdated", False)][:top_k]
            self.metrics.relevant_retrievals += 1 if filtered else 0
            return filtered

        # Keyword-based scoring with recency bonus and obsolescence penalty
        query_lower = query.lower()
        terms = set(re.findall(r"\w+", query_lower))
        now = time.time()
        scored = []

        pool = list(self.store.records.values())
        if include_outdated:
            for out_fact in self.outdated_facts:
                pool.append(MemoryRecord(
                    key=out_fact.key,
                    content=out_fact.content,
                    timestamp=out_fact.timestamp,
                    metadata={"is_outdated": True, "version": out_fact.version},
                ))

        for record in pool:
            is_outdated = record.metadata.get("is_outdated", False)
            if not include_outdated and is_outdated:
                continue

            content_lower = record.content.lower()
            key_lower = record.key.lower()

            # Base semantic match
            score = 10.0 if key_lower in query_lower else 0.0
            for term in terms:
                if len(term) <= 2:
                    continue
                if term in content_lower or term in key_lower:
                    score += 1.5

            if score > 0.0:
                # Recency weighting: newer records receive a recency boost
                rec_ts = record.metadata.get("timestamp", now)
                age = max(0.0, now - rec_ts)
                recency_factor = 1.0 / (1.0 + age * 0.01)
                score *= recency_factor

                if is_outdated:
                    score *= 0.1  # Heavy penalty on outdated facts

                scored.append((score, record))

        scored.sort(key=lambda x: x[0], reverse=True)
        final_records = [r for _, r in scored[:top_k]]

        if final_records:
            self.metrics.relevant_retrievals += 1
        for r in final_records:
            if r.metadata.get("is_outdated", False):
                self.metrics.outdated_returned += 1

        return final_records

    def format_retrieved_context(self, records: List[MemoryRecord]) -> str:
        """Format retrieved semantic memories into context string."""
        if not records:
            return ""
        return "\n".join(f"[Fact '{r.key}']: {r.content}" for r in records)

    def get_quality_metrics(self) -> Dict[str, float]:
        """Return quantitative memory quality assessment."""
        return {
            "relevance_precision": round(self.metrics.relevance_precision, 4),
            "outdated_error_rate": round(self.metrics.outdated_error_rate, 4),
            "contradiction_resolution_rate": round(self.metrics.contradiction_resolution_rate, 4),
            "contradictions_resolved": float(self.metrics.contradictions_resolved),
            "total_retrievals": float(self.metrics.total_retrievals),
        }

    def clear(self) -> None:
        self.fact_dict.clear()
        self.fact_versions.clear()
        self.fact_timestamps.clear()
        self.outdated_facts.clear()
        self.store = InMemoryVectorStore()

    def list_facts(self) -> List[MemoryRecord]:
        """Return all active factual memory records."""
        return [r for r in self.store.records.values() if not r.metadata.get("is_outdated", False)]

    def __len__(self) -> int:
        return len(self.fact_dict)

