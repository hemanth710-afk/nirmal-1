"""
Memory Subsystem for Nirmal-1 Agent:
- EpisodicMemory: Records specific past interaction trajectories and outcomes.
- SemanticMemory: Stores generalized facts, knowledge triples, and reference documents.
- ProceduralMemory: Stores reusable action sequences and task templates.
- WorkingMemory: Maintains current episode context and scratchpad state.
"""

from nirmal.memory import WorkingMemory
from nirmal.agent.memory.episodic import EpisodicMemory, Episode
from nirmal.agent.memory.semantic import SemanticMemory
from nirmal.agent.memory.procedural import ProceduralMemory, ProcedureTemplate

__all__ = [
    "WorkingMemory",
    "EpisodicMemory",
    "Episode",
    "SemanticMemory",
    "ProceduralMemory",
    "ProcedureTemplate",
]
