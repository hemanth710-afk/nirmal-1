"""
Procedural Memory Subsystem for Nirmal-1.
Stores, indexes, and adapts reusable action sequences, skill definitions,
and parameterized strategy templates with dynamic empirical reliability tracking.
"""

from dataclasses import dataclass, field
import re
import time
from typing import Any, Dict, List, Optional


@dataclass
class ProcedureTemplate:
    """A reusable procedural skill template for decomposing specific task types."""
    name: str
    description: str
    trigger_patterns: List[str] = field(default_factory=list)
    steps: List[Dict[str, Any]] = field(default_factory=list)
    success_count: int = 0
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class Strategy(ProcedureTemplate):
    """An adaptive procedural strategy with explicit applicability preconditions,
    counterfactual avoidance constraints, parameter templates, and empirical reliability tracking.
    """
    strategy_id: Optional[str] = None
    task_family: str = "general"
    when_applies: List[str] = field(default_factory=list)
    expected_outcome: Optional[str] = None
    verification_condition: Optional[str] = None
    conditions: Dict[str, Any] = field(default_factory=dict)
    avoid_conditions: Dict[str, Any] = field(default_factory=dict)
    action_credits: Dict[str, float] = field(default_factory=dict)
    action_costs: Dict[str, float] = field(default_factory=dict)
    counterfactual_rejections: int = 0
    total_trials: int = 0
    failure_count: int = 0
    reliability: float = 0.5  # Laplace uninformative prior (1 success / 2 trials)
    success_rate: Optional[float] = None
    last_updated: float = field(default_factory=time.time)

    def __post_init__(self) -> None:
        if self.strategy_id is None:
            self.strategy_id = self.name
        elif not self.name:
            self.name = self.strategy_id
        if self.success_rate is not None:
            self.reliability = float(self.success_rate)
        if not self.when_applies and self.trigger_patterns:
            self.when_applies = list(self.trigger_patterns)
        elif not self.trigger_patterns and self.when_applies:
            self.trigger_patterns = list(self.when_applies)
        elif not self.when_applies and not self.trigger_patterns:
            words = []
            if self.description:
                words.extend([w.lower() for w in re.findall(r"\w+", self.description) if len(w) > 2])
            if self.name:
                words.extend([w.lower() for w in re.findall(r"\w+", self.name) if len(w) > 2])
            self.when_applies = list(set(words))
            self.trigger_patterns = list(self.when_applies)
        if self.total_trials > 0:
            self._recalculate_reliability()

    def _recalculate_reliability(self) -> None:
        """Laplace-smoothed Bayesian reliability: (success + 1) / (trials + 2)."""
        self.reliability = (self.success_count + 1.0) / (self.total_trials + 2.0)

    def record_outcome(self, success: bool) -> None:
        """Update historical statistics and adapt reliability dynamically."""
        self.total_trials += 1
        if success:
            self.success_count += 1
        else:
            self.failure_count += 1
        self._recalculate_reliability()
        self.last_updated = time.time()

    def record_action_credit(self, action_id: str, credit: float) -> None:
        """Record localized credit attribution for a specific step in the strategy."""
        old_credit = self.action_credits.get(action_id, 0.0)
        self.action_credits[action_id] = round(0.7 * old_credit + 0.3 * credit, 4)



class ProceduralMemory:
    """Manages reusable plans, templates, and successful action sequences with adaptive selection."""

    def __init__(self) -> None:
        self.procedures: Dict[str, Strategy] = {}
        self._register_default_procedures()

    def _register_default_procedures(self) -> None:
        """Seed common default procedural templates as baseline strategies."""
        # 1. Multi-step arithmetic evaluation
        self.register_strategy(
            Strategy(
                name="arithmetic_eval",
                task_family="arithmetic",
                description="Evaluate a mathematical expression using the calculator tool.",
                trigger_patterns=["calculate", "compute", "arithmetic", "evaluate", "math"],
                when_applies=["calculate", "compute", "arithmetic", "evaluate", "math"],
                steps=[
                    {
                        "id": "step_calc",
                        "description": "Compute expression with calculator",
                        "tool_name": "calculator",
                        "tool_args": {"expression": "{expression}"},
                    }
                ],
                verification_condition="Numeric result matches arithmetic expectation",
            )
        )
        # 2. Fact retrieval and answer
        self.register_strategy(
            Strategy(
                name="memory_lookup",
                task_family="knowledge",
                description="Retrieve fact from memory and output answer.",
                trigger_patterns=["what is", "lookup", "recall", "retrieve", "fact"],
                when_applies=["what is", "lookup", "recall", "retrieve", "fact"],
                steps=[
                    {
                        "id": "step_retrieve",
                        "description": "Search semantic memory for relevant fact",
                        "tool_name": "string_util",
                        "tool_args": {"operation": "echo", "text": "{query}"},
                    }
                ],
                verification_condition="Output equals stored fact string",
            )
        )

    def register_strategy(self, strategy: Strategy) -> None:
        """Add or update an adaptive strategy."""
        self.procedures[strategy.name] = strategy

    def register_procedure(self, template: ProcedureTemplate) -> None:
        """Add or update a procedural template, upgrading to Strategy if necessary."""
        if isinstance(template, Strategy):
            self.register_strategy(template)
        else:
            strategy = Strategy(
                name=template.name,
                description=template.description,
                trigger_patterns=template.trigger_patterns,
                steps=template.steps,
                success_count=template.success_count,
                total_trials=template.success_count,
                metadata=template.metadata,
            )
            self.register_strategy(strategy)

    def get_procedure(self, name: str) -> Optional[Strategy]:
        """Fetch procedure or strategy by name."""
        return self.procedures.get(name)

    def get_strategy(self, name: str) -> Optional[Strategy]:
        """Fetch strategy by name."""
        return self.get_procedure(name)

    def select_strategy(
        self,
        goal_description: str,
        context: Optional[str] = None,
        task_family: Optional[str] = None,
        enable_strategy_selection: bool = True,
        conditions: Optional[Dict[str, Any]] = None,
    ) -> Optional[Strategy]:
        """Adaptively select best matching strategy using context, similarity, reliability, and conditions."""
        goal_lower = goal_description.lower()
        context_lower = (context or "").lower()

        candidates: List[tuple[float, Strategy]] = []

        for proc in self.procedures.values():
            # Skip strategies from conflicting specific task families
            if (
                task_family
                and proc.task_family
                and task_family != "general"
                and proc.task_family != "general"
                and proc.task_family != task_family
            ):
                continue

            # 1. Counterfactual Avoidance Check
            if conditions and proc.avoid_conditions:
                is_avoided = False
                for avoid_k, avoid_v in proc.avoid_conditions.items():
                    if conditions.get(avoid_k) == avoid_v:
                        is_avoided = True
                        break
                if is_avoided:
                    proc.counterfactual_rejections += 1
                    if enable_strategy_selection:
                        continue  # Reject contraindicated strategy under condition C
                    else:
                        candidates.append((-50.0, proc))
                        continue

            # 2. Condition Precondition Alignment & Conflict Resolution
            condition_score = 0.0
            condition_conflict = False
            if conditions and proc.conditions:
                for cond_k, cond_v in proc.conditions.items():
                    if cond_k in conditions:
                        actual_v = conditions[cond_k]
                        if actual_v == cond_v:
                            condition_score += 4.0  # Positive precondition satisfied
                        else:
                            condition_conflict = True
                            condition_score -= 10.0  # Conflicting condition (e.g. NOT-P or Q)
                    else:
                        condition_score -= 2.0  # Required condition missing from active context

            if condition_conflict and enable_strategy_selection:
                continue

            # 3. Check trigger pattern match and lexical overlap
            match_score = 0.0
            search_triggers = list(proc.when_applies)
            if proc.description:
                search_triggers.append(proc.description.lower())
            if proc.name:
                search_triggers.append(proc.name.lower())

            for trigger in search_triggers:
                t_lower = trigger.lower()
                if t_lower in goal_lower or goal_lower in t_lower:
                    match_score = max(match_score, 1.0)
                elif context_lower and (t_lower in context_lower or context_lower in t_lower):
                    match_score = max(match_score, 0.5)

            # Word-level token overlap between goal and strategy description/name
            goal_tokens = set(re.findall(r"\w+", goal_lower))
            strat_text = f"{proc.name} {proc.description}".lower()
            strat_tokens = set(re.findall(r"\w+", strat_text))
            overlap = goal_tokens.intersection(strat_tokens)
            overlap_meaningful = [w for w in overlap if len(w) > 2 and w not in ("and", "the", "for", "with", "via")]
            if overlap_meaningful:
                overlap_ratio = len(overlap_meaningful) / max(1, len(goal_tokens))
                match_score = max(match_score, overlap_ratio)

            # If condition matched strongly, allow match even if text is novel
            if match_score == 0.0 and condition_score <= 0.0:
                continue

            if not enable_strategy_selection:
                # Ablation mode: unweighted first match
                candidates.append((match_score + condition_score, proc))
                continue

            # 4. Composite adaptive scoring
            family_bonus = 1.0 if (task_family and proc.task_family == task_family) else 0.0

            # Action credit weighting
            credit_bonus = 0.0
            if proc.action_credits:
                avg_credit = sum(proc.action_credits.values()) / max(1, len(proc.action_credits))
                credit_bonus = avg_credit * 2.0

            # Cost penalty
            cost_penalty = 0.0
            if proc.action_costs:
                total_cost = sum(proc.action_costs.values())
                cost_penalty = min(3.0, total_cost * 0.1)

            composite_score = (
                (match_score * 2.0)
                + condition_score
                + family_bonus
                + (proc.reliability * 3.0)
                + credit_bonus
                - cost_penalty
            )

            # Penalize highly unreliable strategies (repeated failures)
            if proc.total_trials >= 2 and proc.reliability < 0.35:
                composite_score -= 5.0

            candidates.append((composite_score, proc))

        if not candidates:
            return None

        # Sort by composite score descending
        candidates.sort(key=lambda c: c[0], reverse=True)
        best_score, best_strategy = candidates[0]

        # In adaptive mode, if even the best candidate is heavily penalized, reject
        if enable_strategy_selection and best_score < 0.0:
            return None

        return best_strategy


    def find_matching_procedure(self, goal_description: str) -> Optional[Strategy]:
        """Find matching procedural template (maintains backward compatibility)."""
        return self.select_strategy(goal_description=goal_description, enable_strategy_selection=True)

    def record_success(self, name: str) -> None:
        """Reinforce procedure or strategy after a verified successful execution."""
        proc = self.get_procedure(name)
        if proc is not None:
            proc.record_outcome(True)

    def record_failure(self, name: str) -> None:
        """Penalize procedure or strategy after an execution or verification failure."""
        proc = self.get_procedure(name)
        if proc is not None:
            proc.record_outcome(False)

    def compose_strategies(
        self,
        goal_description: str,
        task_family: Optional[str] = None,
        subskills: Optional[List[str]] = None,
    ) -> Optional[Strategy]:
        """Dynamically compose learned subskills (X, Y, Z) into a multi-stage procedural strategy.

        Returns None if the goal is not compound, or if any required constituent
        subskills have not been acquired in ProceduralMemory.
        """
        goal_lower = goal_description.lower()
        family_lower = (task_family or "").lower()

        # Check if goal indicates composition
        if not ("compose" in goal_lower or "composition" in family_lower or (subskills and len(subskills) >= 2)):
            return None

        # Determine required subskills
        needed_skills: List[str] = []
        if subskills and len(subskills) >= 2:
            needed_skills = [s.upper() for s in subskills]
        elif "xyz" in family_lower or ("transform" in goal_lower and ("route" in goal_lower or "service" in goal_lower) and ("length" in goal_lower or "checksum" in goal_lower)):
            needed_skills = ["X", "Y", "Z"]
        elif "xy" in family_lower or ("transform" in goal_lower and ("route" in goal_lower or "service" in goal_lower)):
            needed_skills = ["X", "Y"]
        elif "compose" in goal_lower or "composition" in family_lower:
            if "length" in goal_lower or "checksum" in goal_lower:
                needed_skills = ["X", "Y", "Z"]
            else:
                needed_skills = ["X", "Y"]
        else:
            return None

        if len(needed_skills) < 2:
            return None


        # Check availability of constituent subskills in procedural memory
        matched_strategies: List[Strategy] = []
        for skill in needed_skills:
            found = None
            for strat in self.procedures.values():
                strat_family = strat.task_family.lower()
                strat_name = strat.name.lower()
                strat_triggers = [t.lower() for t in strat.trigger_patterns]

                if skill == "X" and (strat_family in ("skill_transformation", "encoding_pipeline") or "transform" in strat_name or any("transform" in t for t in strat_triggers)):
                    found = strat
                    break
                elif skill == "Y" and (strat_family in ("skill_routing", "resource_discovery") or "routing" in strat_name or any("route" in t for t in strat_triggers)):
                    found = strat
                    break
                elif skill == "Z" and (strat_family in ("skill_checksum",) or "checksum" in strat_name or any("length" in t or "checksum" in t for t in strat_triggers)):
                    found = strat
                    break

            if found is None:
                # Missing required constituent subskill
                return None
            matched_strategies.append(found)

        # Synthesize compound DAG action sequence
        comp_steps: List[Dict[str, Any]] = [
            {
                "id": "step_1",
                "description": "Transform key name with operation",
                "tool_name": "string_util",
                "tool_args": {"operation": "{op1}", "text": "{stem}"},
                "dependencies": [],
            },
            {
                "id": "step_2",
                "description": "Read service mapping for transformed key",
                "tool_name": "mock_env",
                "tool_args": {"action": "read", "key": "svc_{step_1}"},
                "dependencies": ["step_1"],
            },
            {
                "id": "step_3",
                "description": "Read port mapping for discovered node",
                "tool_name": "mock_env",
                "tool_args": {"action": "read", "key": "{step_2}_port"},
                "dependencies": ["step_2"],
            },
            {
                "id": "step_4",
                "description": "Persist active route to environment",
                "tool_name": "mock_env",
                "tool_args": {"action": "write", "key": "active_route", "value": "{step_2}:{step_3}"},
                "dependencies": ["step_2", "step_3"],
            },
        ]

        if "Z" in needed_skills:
            comp_steps.append({
                "id": "step_5",
                "description": "Compute checksum / length of resolved endpoint",
                "tool_name": "string_util",
                "tool_args": {"operation": "length", "text": "{step_2}:{step_3}"},
                "dependencies": ["step_4"],
            })
        else:
            comp_steps.append({
                "id": "step_5",
                "description": "Output finalized route",
                "tool_name": "string_util",
                "tool_args": {"operation": "echo", "text": "{step_2}:{step_3}"},
                "dependencies": ["step_4"],
            })

        min_rel = min(s.reliability for s in matched_strategies) if matched_strategies else 0.5
        comp_name = f"composed_{'_'.join(needed_skills).lower()}"

        return Strategy(
            name=comp_name,
            task_family=task_family or f"composition_{''.join(needed_skills).lower()}",
            description=f"Dynamically composed strategy combining subskills {', '.join(needed_skills)}",
            trigger_patterns=["compose", "composition"],
            when_applies=["compose", "composition"],
            steps=comp_steps,
            total_trials=1,
            success_count=1,
            reliability=min_rel,
        )

    def list_procedures(self) -> List[str]:
        return list(self.procedures.keys())

    def list_strategies(self) -> List[Strategy]:
        return list(self.procedures.values())

