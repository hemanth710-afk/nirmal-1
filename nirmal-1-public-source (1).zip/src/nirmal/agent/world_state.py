"""
WorldState: Explicit, serializable state representation for the Nirmal-1 Cognitive Agent.
Tracks grounded facts, active goals, plan execution state, observations, and action provenance.
"""

from dataclasses import dataclass, field, asdict
import json
import time
from typing import Any, Dict, List, Optional, Tuple


@dataclass
class Observation:
    """An environmental or tool observation record."""
    source: str
    content: Any
    timestamp: float = field(default_factory=time.time)
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Observation":
        return cls(**data)


@dataclass
class Action:
    """An action dispatched to a tool or environment."""
    action_id: str
    tool_name: str
    arguments: Dict[str, Any]
    expected_outcome: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Action":
        return cls(**data)


@dataclass
class ActionResult:
    """Outcome of an executed Action."""
    action_id: str
    success: bool
    output: Any = None
    error: Optional[str] = None
    execution_time: float = 0.0
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ActionResult":
        return cls(**data)


@dataclass
class Fact:
    """A grounded piece of knowledge with explicit provenance and confidence."""
    key: str
    value: Any
    source: str
    confidence: float = 1.0
    timestamp: float = field(default_factory=time.time)


class WorldState:
    """Explicit structured state maintaining agent knowledge, plans, and observations."""

    def __init__(self, goal_description: Optional[str] = None):
        self.goal: Optional[str] = goal_description
        self.facts: Dict[str, Fact] = {}
        self.observations: List[Observation] = []
        self.action_history: List[Tuple[Action, ActionResult]] = []
        self.status: str = "active"  # "active", "completed", "failed"
        self.confidence: float = 1.0
        self.metadata: Dict[str, Any] = {}

    def update_fact(self, key: str, value: Any, source: str = "agent", confidence: float = 1.0) -> None:
        """Add or update a verified fact with provenance."""
        self.facts[key] = Fact(
            key=key,
            value=value,
            source=source,
            confidence=confidence,
            timestamp=time.time(),
        )

    def get_fact(self, key: str, default: Any = None) -> Any:
        """Retrieve the value of a stored fact."""
        fact = self.facts.get(key)
        return fact.value if fact is not None else default

    def add_observation(self, observation: Observation) -> None:
        """Append an incoming observation."""
        self.observations.append(observation)

    def record_action(self, action: Action, result: ActionResult) -> None:
        """Log an executed action and its corresponding result."""
        self.action_history.append((action, result))

    def to_dict(self) -> Dict[str, Any]:
        """Serialize WorldState into a standard dictionary."""
        return {
            "goal": self.goal,
            "status": self.status,
            "confidence": self.confidence,
            "metadata": self.metadata,
            "facts": {
                k: {
                    "key": f.key,
                    "value": f.value,
                    "source": f.source,
                    "confidence": f.confidence,
                    "timestamp": f.timestamp,
                }
                for k, f in self.facts.items()
            },
            "observations": [obs.to_dict() for obs in self.observations],
            "action_history": [
                {"action": act.to_dict(), "result": res.to_dict()}
                for act, res in self.action_history
            ],
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "WorldState":
        """Reconstruct WorldState from a dictionary."""
        state = cls(goal_description=data.get("goal"))
        state.status = data.get("status", "active")
        state.confidence = data.get("confidence", 1.0)
        state.metadata = data.get("metadata", {})

        for k, f_data in data.get("facts", {}).items():
            state.facts[k] = Fact(
                key=f_data["key"],
                value=f_data["value"],
                source=f_data.get("source", "unknown"),
                confidence=f_data.get("confidence", 1.0),
                timestamp=f_data.get("timestamp", time.time()),
            )

        for obs_data in data.get("observations", []):
            state.observations.append(Observation.from_dict(obs_data))

        for item in data.get("action_history", []):
            act = Action.from_dict(item["action"])
            res = ActionResult.from_dict(item["result"])
            state.action_history.append((act, res))

        return state

    def to_json(self) -> str:
        """Serialize WorldState to JSON string."""
        return json.dumps(self.to_dict(), indent=2)

    @classmethod
    def from_json(cls, json_str: str) -> "WorldState":
        """Deserialize WorldState from JSON string."""
        return cls.from_dict(json.loads(json_str))
