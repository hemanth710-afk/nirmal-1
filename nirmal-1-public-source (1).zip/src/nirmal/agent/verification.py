"""
Deterministic Programmatic Verification Subsystem for Nirmal-1.
Rejects model self-confidence as proof of correctness; enforces objective,
reproducible, and inspectable verification checks.
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
import math
import re
from typing import Any, Callable, Dict, Optional, Union


@dataclass
class VerificationResult:
    """Outcome of verifying an expected state against an actual observation."""
    is_valid: bool
    score: float = 1.0
    message: str = ""
    details: Dict[str, Any] = field(default_factory=dict)


class Verifier(ABC):
    """Abstract interface for result verification."""

    @abstractmethod
    def verify(self, expected: Any, actual: Any, context: Optional[Dict[str, Any]] = None) -> VerificationResult:
        """Verify actual outcome against expected criteria."""
        pass


class DeterministicVerifier(Verifier):
    """Programmatic verifier performing deterministic comparisons."""

    def __init__(self, numeric_tolerance: float = 1e-5):
        self.numeric_tolerance = numeric_tolerance

    def verify(self, expected: Any, actual: Any, context: Optional[Dict[str, Any]] = None) -> VerificationResult:
        """Deterministically compare expected vs actual outcome."""
        context = context or {}
        check_type = context.get("check_type", "auto")

        # 1. Custom Callable Predicate
        if callable(expected):
            try:
                passed = bool(expected(actual))
                return VerificationResult(
                    is_valid=passed,
                    score=1.0 if passed else 0.0,
                    message="Predicate passed." if passed else "Predicate check failed.",
                )
            except Exception as e:
                return VerificationResult(is_valid=False, score=0.0, message=f"Predicate exception: {str(e)}")

        # 2. None check (expected is unconstrained or None)
        if expected is None:
            # If no specific expectation, verify that actual is non-error and non-empty
            valid = actual is not None and actual != ""
            return VerificationResult(
                is_valid=valid,
                score=1.0 if valid else 0.0,
                message="Actual value exists and is non-empty." if valid else "Actual value is empty/None.",
            )

        # 3. Numeric Comparison (including numeric-convertible values/strings)
        try:
            is_exp_num = isinstance(expected, (int, float)) or (isinstance(expected, str) and not isinstance(expected, bool) and expected.replace(".", "", 1).replace("-", "", 1).isdigit())
            is_act_num = isinstance(actual, (int, float)) or (isinstance(actual, str) and not isinstance(actual, bool) and actual.replace(".", "", 1).replace("-", "", 1).isdigit())
            if is_exp_num and is_act_num:
                exp_f = float(expected)
                act_f = float(actual)
                diff = abs(exp_f - act_f)
                passed = diff <= self.numeric_tolerance
                if passed:
                    return VerificationResult(
                        is_valid=True,
                        score=1.0,
                        message=f"Numeric match (diff={diff:.6f} <= {self.numeric_tolerance})",
                        details={"diff": diff, "expected": expected, "actual": actual},
                    )
                elif isinstance(expected, (int, float)) and isinstance(actual, (int, float)):
                    return VerificationResult(
                        is_valid=False,
                        score=0.0,
                        message=f"Numeric mismatch: expected {expected}, got {actual}",
                        details={"diff": diff, "expected": expected, "actual": actual},
                    )
        except (ValueError, TypeError):
            pass

        # 4. String comparison (exact, case-insensitive, or substring)
        if isinstance(expected, str) and isinstance(actual, str):
            if check_type == "substring" or (check_type == "auto" and len(expected) < len(actual) and "\n" in actual):
                passed = expected.strip().lower() in actual.strip().lower()
                return VerificationResult(
                    is_valid=passed,
                    score=1.0 if passed else 0.0,
                    message="Substring found." if passed else f"Expected substring '{expected}' not found in '{actual[:100]}...'",
                )
            elif check_type == "regex":
                passed = bool(re.search(expected, actual))
                return VerificationResult(
                    is_valid=passed,
                    score=1.0 if passed else 0.0,
                    message="Regex pattern matched." if passed else f"Pattern '{expected}' did not match.",
                )
            else:
                passed = (expected.strip() == actual.strip()) or (expected.strip().lower() == actual.strip().lower())
                return VerificationResult(
                    is_valid=passed,
                    score=1.0 if passed else 0.0,
                    message="String match verified." if passed else f"String mismatch: expected '{expected}', got '{actual}'",
                )

        # 5. Fallback Exact Equality
        passed = expected == actual
        return VerificationResult(
            is_valid=passed,
            score=1.0 if passed else 0.0,
            message="Exact equality verified." if passed else f"Equality failed: expected {expected} ({type(expected)}), got {actual} ({type(actual)})",
        )
