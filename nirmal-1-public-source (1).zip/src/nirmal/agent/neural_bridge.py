"""
Neural-Cognitive Integration Bridge for Nirmal-1 V5.
Provides concrete neural computation connecting the hybrid core model (DeltaNet + GQA + MoE)
to all seven cognitive subsystems:
1. Perception / Dense Embedding
2. Working & Semantic Memory Dense Retrieval
3. Forward State Transition Prediction (Neural World Model)
4. Structured Reasoning Proposal & Perplexity Scoring
5. Plan Step Viability Scoring
6. Learned Semantic Verification Scoring
7. Step-Credit-Weighted Experience Learning
"""

import math
import re
from typing import Any, Dict, List, Optional, Tuple, Union
import torch
import torch.nn.functional as F

from nirmal.configuration_nirmal import NirmalConfig
from nirmal.model import NirmalForCausalLM
from nirmal.generation import NirmalGenerator
from training.dataset import CharTokenizer


class NeuralBridge:
    """
    Connects NirmalForCausalLM to cognitive agent modules, performing concrete
    neural representation extraction, likelihood scoring, and generation.
    """

    def __init__(
        self,
        model: Optional[NirmalForCausalLM] = None,
        tokenizer: Optional[CharTokenizer] = None,
        device: Optional[torch.device] = None,
        kill_switch_mode: Optional[str] = None,
    ):
        self.device = device or torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.tokenizer = tokenizer if tokenizer is not None else CharTokenizer()
        self.kill_switch_mode = kill_switch_mode

        if model is None:
            # Default Tiny configuration for lightweight neural inference
            config = NirmalConfig(
                vocab_size=self.tokenizer.vocab_size,
                hidden_size=64,
                num_hidden_layers=2,
                num_attention_heads=2,
                num_key_value_heads=1,
                head_dim=32,
                context_length=256,
                num_experts=2,
                num_experts_per_tok=1,
                full_attention_interval=2,
            )
            self.model = NirmalForCausalLM(config).to(self.device)
        else:
            self.model = model.to(self.device)

        self.generator = NirmalGenerator(self.model)

    # =========================================================================
    # 1. Perception & Dense Text Embeddings
    # =========================================================================
    def encode_text(self, text: str) -> torch.Tensor:
        """Extract average-pooled dense representation vector from the neural backbone."""
        h_dim = self.model.config.hidden_size
        if self.kill_switch_mode == "zeros":
            return torch.zeros(h_dim, device=self.device)
        elif self.kill_switch_mode == "random":
            return F.normalize(torch.randn(h_dim, device=self.device), p=2, dim=-1)
        elif self.kill_switch_mode == "constant":
            return F.normalize(torch.ones(h_dim, device=self.device), p=2, dim=-1)

        self.model.eval()
        tokens = self.tokenizer.encode(text, add_special_tokens=True)
        if not tokens:
            tokens = [self.tokenizer.pad_token_id]
        input_ids = torch.tensor([tokens], dtype=torch.long, device=self.device)

        with torch.no_grad():
            outputs = self.model.model(input_ids=input_ids)
            # outputs is a tuple: (hidden_states, router_loss, past_cache)
            hidden_states = outputs[0] if isinstance(outputs, tuple) else getattr(outputs, "last_hidden_state", outputs)
            # hidden_states: (1, seq_len, hidden_size)
            h = hidden_states.mean(dim=1).squeeze(0)  # (hidden_size,)
            if self.kill_switch_mode == "shuffled":
                idx = torch.randperm(h.size(0))
                h = h[idx]
            # L2 normalize
            h_norm = F.normalize(h, p=2, dim=-1)
        return h_norm

    def compute_similarity(self, text_a: str, text_b: str) -> float:
        """Compute cosine similarity between dense neural embeddings of two text strings."""
        emb_a = self.encode_text(text_a)
        emb_b = self.encode_text(text_b)
        sim = torch.dot(emb_a, emb_b).item()
        return round(float(sim), 4)

    # =========================================================================
    # 2. Working & Semantic Memory Retrieval Ranking
    # =========================================================================
    def rank_memories(self, query: str, candidate_texts: List[str]) -> List[Tuple[str, float]]:
        """Rank candidate memory records by cosine similarity to query embedding."""
        if not candidate_texts:
            return []
        q_emb = self.encode_text(query)
        scored = []
        for cand in candidate_texts:
            c_emb = self.encode_text(cand)
            sim = torch.dot(q_emb, c_emb).item()
            scored.append((cand, round(float(sim), 4)))
        scored.sort(key=lambda x: x[1], reverse=True)
        return scored

    # =========================================================================
    # 3. Neural World Model State Transition Prediction
    # =========================================================================
    def predict_state_transition(
        self,
        current_state: Dict[str, Any],
        action: Union[str, Dict[str, Any]],
        max_new_tokens: int = 24,
    ) -> Tuple[Dict[str, Any], float]:
        """
        Autoregressively predict next state tokens given current state and action.
        Returns: (predicted_state_dict, neural_confidence)
        """
        if self.kill_switch_mode == "zeros":
            return {}, 0.0
        elif self.kill_switch_mode == "random":
            return {}, round(float(torch.rand(1).item()), 4)
        elif self.kill_switch_mode == "constant":
            return dict(current_state), 0.5

        self.model.eval()
        if isinstance(action, dict):
            act_str = action.get("tool") or action.get("action") or str(action)
        else:
            act_str = str(action)

        state_repr = ", ".join(f"{k}={v}" for k, v in sorted(current_state.items()))
        prompt = f"State: {state_repr} | Action: {act_str} -> NextState:"

        prompt_tokens = self.tokenizer.encode(prompt, add_special_tokens=True)
        input_ids = torch.tensor([prompt_tokens], dtype=torch.long, device=self.device)

        with torch.no_grad():
            gen_ids = self.generator.generate(
                input_ids=input_ids,
                max_new_tokens=max_new_tokens,
                temperature=0.0,  # greedy
                eos_token_id=self.tokenizer.eos_token_id,
            )
            # Extract generated tokens
            new_tokens = gen_ids[0, len(prompt_tokens):].tolist()
            generated_str = self.tokenizer.decode(new_tokens).strip()

            # Compute average token probability as neural confidence
            logits = self.model(input_ids=gen_ids).logits[0, len(prompt_tokens)-1 : -1, :]
            probs = F.softmax(logits, dim=-1)
            target_tokens = gen_ids[0, len(prompt_tokens):]
            if target_tokens.numel() > 0:
                gathered = probs.gather(-1, target_tokens.unsqueeze(-1)).squeeze(-1)
                avg_prob = gathered.mean().item()
            else:
                avg_prob = 0.5

        # Parse generated string into state dict
        predicted_state = dict(current_state)
        # Look for key=value patterns in generated string
        matches = re.findall(r"([a-zA-Z0-9_]+)\s*=\s*([a-zA-Z0-9_.-]+)", generated_str)
        for k, v in matches:
            # Type inference for numeric
            if v.isdigit():
                predicted_state[k] = int(v)
            else:
                try:
                    predicted_state[k] = float(v)
                except ValueError:
                    predicted_state[k] = v

        return predicted_state, round(float(avg_prob), 4)

    # =========================================================================
    # 4. Structured Reasoning Proposal & Perplexity Scoring
    # =========================================================================
    def score_hypothesis(self, premise: str, hypothesis: str) -> float:
        """
        Compute conditional log-likelihood / perplexity of hypothesis given premise.
        Higher score (lower perplexity) indicates stronger deductive likelihood.
        """
        if self.kill_switch_mode == "zeros":
            return 0.0
        elif self.kill_switch_mode == "random":
            return round(float(torch.rand(1).item()), 4)
        elif self.kill_switch_mode == "constant":
            return 0.5

        self.model.eval()
        full_text = f"{premise} Therefore: {hypothesis}"
        premise_tokens = self.tokenizer.encode(f"{premise} Therefore:", add_special_tokens=True)
        full_tokens = self.tokenizer.encode(full_text, add_special_tokens=True)

        input_ids = torch.tensor([full_tokens], dtype=torch.long, device=self.device)
        labels = input_ids.clone()
        # Mask out premise tokens
        labels[0, : len(premise_tokens)] = -100

        with torch.no_grad():
            outputs = self.model(input_ids=input_ids, labels=labels)
            loss = outputs.loss.item() if outputs.loss is not None else 0.0

        # Likelihood proxy in [0, 1]
        likelihood = math.exp(-min(loss, 10.0))
        return round(float(likelihood), 4)

    # =========================================================================
    # 5. Planning: Candidate Action Step Scoring
    # =========================================================================
    def score_plan_step(self, goal: str, step_description: str) -> float:
        """Score the viability of a plan step given the goal."""
        return self.score_hypothesis(premise=f"Goal: {goal}", hypothesis=f"Action: {step_description}")

    # =========================================================================
    # 6. Learned Semantic Verification Scoring
    # =========================================================================
    def verify_agreement(self, goal: str, expected: Any, actual: Any) -> Tuple[bool, float, str]:
        """
        Neural verifier evaluates semantic agreement between expected and actual outcome.
        Returns: (is_valid, confidence_score, explanation)
        """
        if expected is None:
            # Unconstrained outcome: non-null actual is valid
            return (actual is not None), 1.0, "Unconstrained goal satisfied."

        exp_str = str(expected).strip().lower()
        act_str = str(actual).strip().lower()

        if exp_str == act_str:
            return True, 1.0, "Exact symbolic match."

        # Compute neural semantic agreement
        sim = self.compute_similarity(exp_str, act_str)
        # Also compute conditional likelihood of actual given expected
        score = self.score_hypothesis(premise=f"Expected: {exp_str}", hypothesis=act_str)
        joint_score = round(0.5 * sim + 0.5 * score, 4)
        is_valid = (joint_score >= 0.70)
        msg = f"Neural verification joint_score={joint_score:.4f} (sim={sim:.4f}, prob={score:.4f})"
        return is_valid, joint_score, msg

    # =========================================================================
    # 7. Step-Credit-Weighted Experience Learning
    # =========================================================================
    def compute_credit_weighted_loss(
        self,
        token_sequences: List[torch.Tensor],
        step_credits: List[float],
        optimizer: torch.optim.Optimizer,
    ) -> float:
        """
        Fine-tune neural core with step-level credit assignment:
        Steps with positive credit reinforce cross-entropy loss; negative credit steps are penalized.
        """
        self.model.train()
        total_loss = 0.0
        optimizer.zero_grad()

        for tokens, credit in zip(token_sequences, step_credits):
            if tokens.numel() <= 1:
                continue
            input_ids = tokens.unsqueeze(0).to(self.device)
            labels = input_ids.clone()
            outputs = self.model(input_ids=input_ids, labels=labels)
            if outputs.loss is not None:
                # Modulate step loss by assigned credit
                weighted_loss = outputs.loss * float(credit)
                weighted_loss.backward()
                total_loss += weighted_loss.item()

        optimizer.step()
        return round(float(total_loss), 4)

    def compute_semantic_similarity(self, text_a: str, text_b: str) -> float:
        """Alias for compute_similarity."""
        return self.compute_similarity(text_a, text_b)

    def rank_memories_by_relevance(
        self,
        query: str,
        candidates: List[str],
        top_k: int = 5,
    ) -> List[str]:
        """Rank and return top_k candidates by neural embedding similarity."""
        ranked = self.rank_memories(query, candidates)
        return [cand for cand, _ in ranked[:top_k]]

    def score_verification(self, observed_state: Any, expected_criteria: Any) -> float:
        """Evaluate semantic agreement score between observed state and expected criteria."""
        _, score, _ = self.verify_agreement(goal="verify", expected=expected_criteria, actual=observed_state)
        return score

    def compute_experience_loss(self, experience: Any) -> float:
        """Compute credit-weighted loss across steps in an Experience object."""
        self.model.eval()
        total_loss = 0.0
        total_weight = 0.0

        # Extract steps or actions from experience
        steps = getattr(experience, "steps", None)
        if steps is not None:
            for s in steps:
                text = f"Action: {s.action} -> Obs: {s.observation}"
                tokens = torch.tensor(self.tokenizer.encode(text), dtype=torch.long, device=self.device).unsqueeze(0)
                credit = float(getattr(s, "credit", 1.0))
                with torch.no_grad():
                    out = self.model(input_ids=tokens, labels=tokens)
                    if out.loss is not None:
                        total_loss += out.loss.item() * credit
                        total_weight += credit
        else:
            actions = getattr(experience, "actions", [])
            for a in actions:
                text = f"Action: {a}"
                tokens = torch.tensor(self.tokenizer.encode(text), dtype=torch.long, device=self.device).unsqueeze(0)
                credit = float(getattr(experience, "reward", 1.0))
                with torch.no_grad():
                    out = self.model(input_ids=tokens, labels=tokens)
                    if out.loss is not None:
                        total_loss += out.loss.item() * credit
                        total_weight += credit

        avg_loss = (total_loss / max(1e-4, total_weight)) if total_weight > 0 else 1.0
        return round(float(avg_loss), 4)
