"""
Cognitive Controller V1 for Nirmal-1.
Implements an explicit deterministic state-machine cognitive architecture orchestrating:
OBSERVE -> RETRIEVE -> REASON -> PLAN -> ACT -> VERIFY -> UPDATE -> LEARN -> DECIDE.
"""

from dataclasses import dataclass, field, asdict
from enum import Enum
import re
import time
from typing import Any, Callable, Dict, List, Optional, Union
import uuid

import torch

from nirmal.configuration_nirmal import NirmalConfig
from nirmal.model import NirmalForCausalLM
from nirmal.generation import NirmalGenerator
from nirmal.memory import WorkingMemory
from nirmal.reasoning import ReasoningEngine, ReasoningTrace, StepType
from nirmal.planning import Planner, TaskGraph, PlanNode, PlanStatus
from nirmal.tools import ToolRegistry, ToolResult
from nirmal.agent.world_state import WorldState, Observation, Action, ActionResult
from nirmal.agent.verification import DeterministicVerifier, VerificationResult
from nirmal.agent.memory.episodic import EpisodicMemory, Episode
from nirmal.agent.memory.semantic import SemanticMemory
from nirmal.agent.memory.procedural import ProceduralMemory, ProcedureTemplate, Strategy
from nirmal.learning import Experience, EpisodicBuffer
from nirmal.agent.learning_engine import CognitiveLearningEngine, LearningReport
from nirmal.agent.world_model import WorldModel, StatePrediction


class ControllerState(str, Enum):
    IDLE = "idle"
    OBSERVE = "observe"
    RETRIEVE = "retrieve"
    REASON = "reason"
    PLAN = "plan"
    ACT = "act"
    VERIFY = "verify"
    UPDATE = "update"
    LEARN = "learn"
    DONE = "done"
    FAILED = "failed"


@dataclass
class Goal:
    """Explicit goal definition with acceptance criteria."""
    goal_id: str
    description: str
    criteria: Optional[Any] = None
    task_family: str = "general"
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class StepRecord:
    """An inspectable audit record of an individual step in the cognitive cycle."""
    step_index: int
    state: ControllerState
    description: str
    action: Optional[Action] = None
    action_result: Optional[ActionResult] = None
    verification: Optional[VerificationResult] = None
    reasoning_summary: Optional[str] = None
    timestamp: float = field(default_factory=time.time)


@dataclass
class ControllerResult:
    """Final outcome of a controller execution run."""
    success: bool
    state: ControllerState
    goal: str
    final_output: Any = None
    error: Optional[str] = None
    execution_trace: List[StepRecord] = field(default_factory=list)
    episode: Optional[Episode] = None
    experience: Optional[Experience] = None
    strategy_used: Optional[str] = None
    total_steps: int = 0
    duration_sec: float = 0.0
    prediction_errors: List[float] = field(default_factory=list)
    brier_score: float = 0.0
    world_model_rules_count: int = 0


class CognitiveController:
    """Deterministic State-Machine Cognitive Controller for Nirmal-1."""

    def __init__(
        self,
        model: Optional[NirmalForCausalLM] = None,
        tool_registry: Optional[ToolRegistry] = None,
        semantic_memory: Optional[SemanticMemory] = None,
        episodic_memory: Optional[EpisodicMemory] = None,
        procedural_memory: Optional[ProceduralMemory] = None,
        verifier: Optional[DeterministicVerifier] = None,
        learning_engine: Optional[CognitiveLearningEngine] = None,
        episodic_buffer: Optional[EpisodicBuffer] = None,
        enable_memory: bool = True,
        enable_planning: bool = True,
        enable_verification: bool = True,
        enable_replanning: bool = True,
        enable_learning: bool = True,
        enable_semantic_learning: bool = True,
        enable_procedural_learning: bool = True,
        enable_strategy_selection: bool = True,
        enable_credit_assignment: bool = True,
        world_model: Optional[WorldModel] = None,
        enable_world_model: bool = True,
        enable_counterfactual_reasoning: bool = True,
        neural_bridge: Optional[Any] = None,
        enable_neural_reasoning: bool = True,
        enable_neural_verification: bool = True,
        max_replan_attempts: int = 3,
    ):
        self.model = model
        self.generator = NirmalGenerator(model) if model is not None else None
        self.tool_registry = tool_registry if tool_registry is not None else ToolRegistry()
        self.semantic_memory = semantic_memory if semantic_memory is not None else SemanticMemory()
        self.episodic_memory = episodic_memory if episodic_memory is not None else EpisodicMemory()
        self.procedural_memory = procedural_memory if procedural_memory is not None else ProceduralMemory()
        self.verifier = verifier if verifier is not None else DeterministicVerifier()
        self.learning_engine = learning_engine if learning_engine is not None else CognitiveLearningEngine(enable_credit_assignment=enable_credit_assignment)
        self.episodic_buffer = episodic_buffer if episodic_buffer is not None else EpisodicBuffer()

        if neural_bridge is not None:
            self.neural_bridge = neural_bridge
        elif model is not None:
            from nirmal.agent.neural_bridge import NeuralBridge
            self.neural_bridge = NeuralBridge(model=model)
        else:
            self.neural_bridge = None

        self.world_model = world_model if world_model is not None else WorldModel(neural_bridge=self.neural_bridge)
        if self.world_model.neural_bridge is None and self.neural_bridge is not None:
            self.world_model.neural_bridge = self.neural_bridge

        self.reasoning_engine = ReasoningEngine()
        self.planner = Planner()

        # Ablation feature flags
        self.enable_memory = enable_memory
        self.enable_planning = enable_planning
        self.enable_verification = enable_verification
        self.enable_replanning = enable_replanning
        self.enable_learning = enable_learning
        self.enable_semantic_learning = enable_semantic_learning
        self.enable_procedural_learning = enable_procedural_learning
        self.enable_strategy_selection = enable_strategy_selection
        self.enable_credit_assignment = enable_credit_assignment
        self.enable_world_model = enable_world_model
        self.enable_counterfactual_reasoning = enable_counterfactual_reasoning
        self.enable_neural_reasoning = enable_neural_reasoning
        self.enable_neural_verification = enable_neural_verification
        self.max_replan_attempts = max_replan_attempts

        # Runtime state
        self.state: ControllerState = ControllerState.IDLE
        self.current_goal: Optional[Goal] = None
        self.world_state: Optional[WorldState] = None
        self.working_memory: Optional[WorkingMemory] = None
        self.active_plan: Optional[TaskGraph] = None
        self.current_node: Optional[PlanNode] = None
        self.current_action: Optional[Action] = None
        self.current_result: Optional[ActionResult] = None
        self.last_verification: Optional[VerificationResult] = None
        self.retrieved_memories: List[str] = []
        self.strategy_used: Optional[str] = None
        self.replan_count: int = 0
        self.final_output: Any = None
        self.error_message: Optional[str] = None
        self.execution_trace: List[StepRecord] = []
        self.step_counter: int = 0
        self.last_prediction: Optional[StatePrediction] = None
        self.prediction_errors: List[float] = []
        self.pre_action_state_snapshot: Dict[str, Any] = {}

    def reset(self) -> None:
        """Reset internal controller state for a new session."""
        self.state = ControllerState.IDLE
        self.current_goal = None
        self.world_state = None
        self.working_memory = None
        self.active_plan = None
        self.current_node = None
        self.current_action = None
        self.current_result = None
        self.last_verification = None
        self.retrieved_memories.clear()
        self.strategy_used = None
        self.replan_count = 0
        self.final_output = None
        self.error_message = None
        self.execution_trace.clear()
        self.step_counter = 0
        self.last_prediction = None
        self.prediction_errors.clear()
        self.pre_action_state_snapshot.clear()

    def _record_step(
        self,
        description: str,
        action: Optional[Action] = None,
        action_result: Optional[ActionResult] = None,
        verification: Optional[VerificationResult] = None,
        reasoning_summary: Optional[str] = None,
    ) -> None:
        record = StepRecord(
            step_index=self.step_counter,
            state=self.state,
            description=description,
            action=action,
            action_result=action_result,
            verification=verification,
            reasoning_summary=reasoning_summary,
        )
        self.execution_trace.append(record)
        self.step_counter += 1

    def simulate_action(self, action: Dict[str, Any]) -> StatePrediction:
        """Simulate the effect of a single candidate action on current world state without executing it."""
        current_state_dict = {k: v.value for k, v in self.world_state.facts.items()} if self.world_state else {}
        return self.world_model.predict(current_state_dict, action)

    def simulate_plan(self, actions: List[Dict[str, Any]]) -> List[StatePrediction]:
        """Simulate a multi-step rollout of actions without taking environment actions."""
        current_state_dict = {k: v.value for k, v in self.world_state.facts.items()} if self.world_state else {}
        return self.world_model.simulate_rollout(current_state_dict, actions)

    def counterfactual_query(
        self,
        factual_action: Dict[str, Any],
        factual_outcome: Dict[str, Any],
        counterfactual_action: Dict[str, Any],
    ) -> StatePrediction:
        """Counterfactual reasoning: evaluate what would have happened under counterfactual_action."""
        current_state_dict = {k: v.value for k, v in self.world_state.facts.items()} if self.world_state else {}
        return self.world_model.counterfactual(
            factual_state=current_state_dict,
            factual_action=factual_action,
            factual_outcome=factual_outcome,
            counterfactual_action=counterfactual_action,
        )

    def _is_final_plan_node(self, node: Optional[PlanNode]) -> bool:
        """Return True if node has no dependent plan nodes remaining."""
        if self.active_plan is None or node is None:
            return True
        return not any(
            node.node_id in other.dependencies
            for other in self.active_plan.nodes.values()
            if other.status != PlanStatus.FAILED
        )

    def _build_experience(self, success: bool) -> Experience:
        """Construct a serializable Experience snapshot representing the trajectory."""
        task_id = self.current_goal.goal_id if self.current_goal else f"t_{int(time.time())}"
        task_family = self.current_goal.task_family if self.current_goal else "general"
        plan_dict = {
            "goal": self.active_plan.goal,
            "nodes": {nid: asdict(node) for nid, node in self.active_plan.nodes.items()},
        } if self.active_plan and hasattr(self.active_plan, "nodes") else {}

        actions_list = [act.to_dict() for act, _ in (self.world_state.action_history if self.world_state else [])]
        obs_list = [obs.content for obs in (self.world_state.observations if self.world_state else [])]
        verif_dict = asdict(self.last_verification) if self.last_verification else None

        return Experience(
            task_id=task_id,
            trajectory_id=task_id,
            task_family=task_family,
            context=self.working_memory.get_working_context_prompt() if self.working_memory else "",
            goal=self.current_goal.description if self.current_goal else "",
            retrieved_memory=list(self.retrieved_memories),
            proposed_plan=plan_dict,
            actions=actions_list,
            observations=obs_list,
            verification_result=verif_dict,
            reward=1.0 if success else 0.0,
            success=success,
            failure_reason=self.error_message if not success else None,
            strategy_used=self.strategy_used,
            timestamp=time.time(),
            episode_index=self.step_counter,
        )

    def step(self) -> ControllerState:
        """Execute one state transition in the cognitive cycle."""
        if self.state == ControllerState.IDLE:
            # Cannot transition from IDLE without setting a goal
            return self.state

        elif self.state == ControllerState.OBSERVE:
            # Ingest initial context into WorldState and WorkingMemory
            obs = Observation(source="environment", content=f"Initialized goal: {self.current_goal.description}")
            self.world_state.add_observation(obs)
            self.working_memory.append_observation("system", obs.content)
            self._record_step(f"Observed initial context for goal '{self.current_goal.description}'")

            self.state = ControllerState.RETRIEVE if self.enable_memory else ControllerState.REASON
            return self.state

        elif self.state == ControllerState.RETRIEVE:
            # Query semantic memory for relevant facts
            self.retrieved_memories.clear()
            if self.enable_memory:
                records = self.semantic_memory.retrieve(query=self.current_goal.description, top_k=3)
                for r in records:
                    self.retrieved_memories.append(f"{r.key}: {r.content}")
                    self.world_state.update_fact(key=r.key, value=r.content, source="semantic_memory")
                    self.working_memory.add_scratchpad_note(f"Recalled: {r.key} = {r.content}")

            self._record_step(f"Retrieved {len(self.retrieved_memories)} semantic memory records.")
            self.state = ControllerState.REASON
            return self.state

        elif self.state == ControllerState.REASON:
            # Build structured reasoning trace
            trace = ReasoningTrace(goal=self.current_goal.description)
            trace.add_step(StepType.PREMISE, f"Goal: {self.current_goal.description}")
            for mem in self.retrieved_memories:
                trace.add_step(StepType.PREMISE, f"Context: {mem}")

            # Check if retrieved facts directly resolve the goal (only for factual query goals)
            direct_answer = None
            goal_lower = self.current_goal.description.lower().strip()
            is_factual_query = any(goal_lower.startswith(prefix) for prefix in ("what is", "who is", "where is", "lookup", "retrieve fact", "query fact", "value of"))
            if is_factual_query:
                for k, f in self.world_state.facts.items():
                    if k.lower() in goal_lower or goal_lower == k.lower():
                        direct_answer = f.value
                        trace.add_step(StepType.DEDUCTION, f"Fact '{k}' matches factual query directly: {f.value}")
                        break

            if direct_answer is not None:
                if not self.enable_planning:
                    trace.add_step(StepType.CONCLUSION, f"Direct answer: {direct_answer}")
                    self.final_output = direct_answer
                    self._record_step("Reasoned direct answer from memory.", reasoning_summary=trace.format_trace())
                    self.state = ControllerState.LEARN
                    return self.state
                else:
                    trace.add_step(StepType.CONCLUSION, f"Direct answer identified: {direct_answer}")
                    self.active_plan = self.planner.create_linear_plan(
                        self.current_goal.description,
                        [{
                            "id": "answer_step",
                            "description": f"Output retrieved answer: {direct_answer}",
                            "tool_name": "string_util",
                            "tool_args": {"operation": "echo", "text": str(direct_answer)},
                        }],
                    )
                    self._record_step("Reasoned direct answer plan from memory.", reasoning_summary=trace.format_trace())
                    self.state = ControllerState.PLAN
                    return self.state

            trace.add_step(StepType.DEDUCTION, "Proceeding to task planning.")
            self._record_step("Completed reasoning phase.", reasoning_summary=trace.format_trace())
            self.state = ControllerState.PLAN
            return self.state

        elif self.state == ControllerState.PLAN:
            if not self.enable_planning:
                # Direct single-step execution bypass
                if self.final_output is not None:
                    self.state = ControllerState.LEARN
                else:
                    # Fallback single step
                    self.active_plan = self.planner.create_linear_plan(
                        self.current_goal.description,
                        [{"id": "single_step", "description": self.current_goal.description, "tool_name": "string_util", "tool_args": {"operation": "lowercase", "text": self.current_goal.description}}],
                    )
                    self.current_node = self.active_plan.nodes["single_step"]
                    self.state = ControllerState.ACT
                return self.state

            if self.active_plan is None:
                # Select strategy from procedural memory (or fallback to planner)
                template = None
                if self.enable_memory:
                    context_str = self.working_memory.get_working_context_prompt() if self.working_memory else None
                    task_family = self.current_goal.task_family if self.current_goal else None
                    subskills = self.current_goal.metadata.get("subskills") if (self.current_goal and self.current_goal.metadata) else None

                    # Extract active conditions for condition-based strategy selection
                    active_conditions = {}
                    if self.world_state and self.world_state.facts:
                        for fk, fv in self.world_state.facts.items():
                            active_conditions[fk] = fv.value
                    if self.current_goal and self.current_goal.metadata:
                        for mk, mv in self.current_goal.metadata.items():
                            if mk not in ("subskills",):
                                active_conditions[mk] = mv

                    # Check dynamic subskill composition first
                    template = self.procedural_memory.compose_strategies(
                        goal_description=self.current_goal.description,
                        task_family=task_family,
                        subskills=subskills,
                    )
                    # If not composed, select standard strategy
                    if template is None:
                        template = self.procedural_memory.select_strategy(
                            goal_description=self.current_goal.description,
                            context=context_str,
                            task_family=task_family,
                            conditions=active_conditions,
                            enable_strategy_selection=self.enable_strategy_selection,
                        )
                if template is not None:
                    self.strategy_used = template.name
                    # Format template steps with any extracted values
                    plan_steps = []
                    for s in template.steps:
                        args = dict(s["tool_args"])
                        # Interpolate placeholders from goal description or facts
                        for arg_k, arg_v in args.items():
                            if isinstance(arg_v, str) and "{" in arg_v:
                                # Extract target expression if arithmetic
                                if "{expression}" in arg_v or "expression" in arg_v:
                                    clean_expr = re.sub(
                                        r"(?i)\b(calculate|compute|what is|evaluate)\b",
                                        "",
                                        self.current_goal.description,
                                    ).replace("?", "").strip()
                                    args[arg_k] = clean_expr
                                elif "{query}" in arg_v or "query" in arg_v:
                                    args[arg_k] = self.current_goal.description
                                elif "{stem}" in arg_v:
                                    m = re.search(r"(?:key|text) '([^']+)'", self.current_goal.description, re.IGNORECASE)
                                    if m:
                                        args[arg_k] = arg_v.replace("{stem}", m.group(1))
                                elif "{input_text}" in arg_v:
                                    m = re.search(r"(?:text|key) '([^']+)'", self.current_goal.description, re.IGNORECASE)
                                    if m:
                                        args[arg_k] = arg_v.replace("{input_text}", m.group(1))
                                elif "{service}" in arg_v:
                                    m = re.search(r"(?:service|endpoint for) '([^']+)'", self.current_goal.description, re.IGNORECASE)
                                    if m:
                                        args[arg_k] = arg_v.replace("{service}", m.group(1))
                                elif "{payload}" in arg_v:
                                    m = re.search(r"(?:payload|text) '([^']+)'", self.current_goal.description, re.IGNORECASE)
                                    if m:
                                        args[arg_k] = arg_v.replace("{payload}", m.group(1))
                                elif "{target_char}" in arg_v:
                                    m = re.search(r"character '([^']+)'", self.current_goal.description, re.IGNORECASE)
                                    args[arg_k] = m.group(1) if m else ""
                                elif "{metric}" in arg_v:
                                    if "count" in self.current_goal.description.lower():
                                        args[arg_k] = "count"
                                    else:
                                        args[arg_k] = "length"
                                elif "{op1}" in arg_v:
                                    m = re.search(r"operation '([^']+)'", self.current_goal.description, re.IGNORECASE)
                                    if m:
                                        args[arg_k] = arg_v.replace("{op1}", m.group(1))
                                elif "{op2}" in arg_v:
                                    m = re.search(r"then '([^']+)'", self.current_goal.description, re.IGNORECASE)
                                    if m:
                                        args[arg_k] = arg_v.replace("{op2}", m.group(1))

                                # Generic fact interpolation from world state
                                if self.world_state and self.world_state.facts and isinstance(args[arg_k], str):
                                    for fk, fv in self.world_state.facts.items():
                                        if f"{{{fk}}}" in args[arg_k]:
                                            args[arg_k] = args[arg_k].replace(f"{{{fk}}}", str(fv.value))

                                # Generic metadata interpolation from current goal
                                if self.current_goal and self.current_goal.metadata and isinstance(args[arg_k], str):
                                    for mk, mv in self.current_goal.metadata.items():
                                        if f"{{{mk}}}" in args[arg_k]:
                                            args[arg_k] = args[arg_k].replace(f"{{{mk}}}", str(mv))
                        plan_steps.append({
                            "id": s["id"],
                            "description": s["description"],
                            "tool_name": s["tool_name"],
                            "tool_args": args,
                            "dependencies": s.get("dependencies", []),
                        })

                    # If goal requires a metric calculation but template has only transformations, append metric step
                    if (
                        ("transform" in template.task_family.lower() or "transform" in template.name.lower())
                        and len(plan_steps) == 2
                        and ("count character" in self.current_goal.description.lower() or "compute length" in self.current_goal.description.lower())
                    ):
                        char_match = re.search(r"character '([^']+)'", self.current_goal.description, re.IGNORECASE)
                        if char_match:
                            plan_steps.append({
                                "id": "step_3",
                                "description": f"Count character '{char_match.group(1)}' in step 2 output",
                                "tool_name": "string_util",
                                "tool_args": {"operation": "count", "text": "{step_2}", "param1": char_match.group(1)},
                                "dependencies": ["step_2"],
                            })
                        else:
                            plan_steps.append({
                                "id": "step_3",
                                "description": "Compute length of step 2 output",
                                "tool_name": "string_util",
                                "tool_args": {"operation": "length", "text": "{step_2}"},
                                "dependencies": ["step_2"],
                            })

                    self.active_plan = self.planner.create_linear_plan(self.current_goal.description, plan_steps)
                else:
                    # Default linear decomposition
                    self.active_plan = self.planner.plan(self.current_goal.description)
                    self.strategy_used = "dynamic_linear_planner"


            # Find ready nodes to execute
            ready_nodes = self.active_plan.get_ready_nodes()
            if ready_nodes:
                self.current_node = ready_nodes[0]
                self.active_plan.mark_in_progress(self.current_node.node_id)
                self._record_step(f"Selected plan node '{self.current_node.node_id}': {self.current_node.description}")
                self.state = ControllerState.ACT
            else:
                if self.active_plan.is_finished():
                    # Plan complete
                    completed_outputs = [
                        node.output for node in self.active_plan.nodes.values()
                        if node.output is not None and node.status == PlanStatus.COMPLETED
                    ]
                    self.final_output = completed_outputs[-1] if completed_outputs else "Goal completed."
                    self._record_step("Plan completed all execution nodes.")
                    self.state = ControllerState.LEARN
                else:
                    # Deadlock or unresolvable failure
                    self.error_message = "Plan deadlock: no ready nodes and plan is not finished."
                    self.state = ControllerState.FAILED

            return self.state

        elif self.state == ControllerState.ACT:
            if self.current_node is None:
                self.state = ControllerState.PLAN
                return self.state

            # Construct action
            tool_name = self.current_node.tool_name
            tool_args = dict(self.current_node.tool_args)
            if not tool_name:
                tool_name = "string_util"
                if "operation" not in tool_args:
                    tool_args = {"operation": "lowercase", "text": self.current_node.description}

            # Interpolate completed plan node outputs if referenced
            for node_id, dep_node in self.active_plan.nodes.items():
                if dep_node.output is not None:
                    for k, v in tool_args.items():
                        if isinstance(v, str) and f"{{{node_id}}}" in v:
                            tool_args[k] = v.replace(f"{{{node_id}}}", str(dep_node.output))

            # Interpolate world state facts if referenced
            if self.world_state and self.world_state.facts:
                for fk, fv in self.world_state.facts.items():
                    for k, v in tool_args.items():
                        if isinstance(v, str) and f"{{{fk}}}" in v:
                            tool_args[k] = v.replace(f"{{{fk}}}", str(fv.value))

            # Interpolate current goal metadata if referenced
            if self.current_goal and self.current_goal.metadata:
                for mk, mv in self.current_goal.metadata.items():
                    for k, v in tool_args.items():
                        if isinstance(v, str) and f"{{{mk}}}" in v:
                            tool_args[k] = v.replace(f"{{{mk}}}", str(mv))

            action_id = f"act_{self.current_node.node_id}_{self.step_counter}"
            self.current_action = Action(
                action_id=action_id,
                tool_name=tool_name,
                arguments=tool_args,
                expected_outcome=str(self.current_goal.criteria) if self.current_goal.criteria else None,
            )

            # Pre-action world state snapshot and world-model prediction
            current_state_dict = {k: v.value for k, v in self.world_state.facts.items()} if self.world_state else {}
            self.pre_action_state_snapshot = dict(current_state_dict)
            if self.enable_world_model:
                action_spec = {"tool": tool_name, "args": tool_args}
                self.last_prediction = self.world_model.predict(current_state_dict, action_spec)

            # Execute tool
            start_t = time.time()
            tool_result = self.tool_registry.execute(tool_name, tool_args)
            elapsed = time.time() - start_t

            self.current_result = ActionResult(
                action_id=action_id,
                success=tool_result.success,
                output=tool_result.output,
                error=tool_result.error,
                execution_time=elapsed,
            )

            self.world_state.record_action(self.current_action, self.current_result)
            pred_note = f" (predicted conf={self.last_prediction.confidence:.2f})" if (self.enable_world_model and self.last_prediction) else ""
            self._record_step(
                f"Executed tool '{tool_name}' with args {tool_args}{pred_note}",
                action=self.current_action,
                action_result=self.current_result,
            )
            self.state = ControllerState.VERIFY
            return self.state

        elif self.state == ControllerState.VERIFY:
            if not self.enable_verification:
                # Bypass verification: accept any non-fatal action
                self.last_verification = VerificationResult(
                    is_valid=self.current_result.success,
                    score=1.0 if self.current_result.success else 0.0,
                    message="Verification bypassed via ablation.",
                )
            else:
                # Perform programmatic deterministic check
                if not self.current_result.success:
                    self.last_verification = VerificationResult(
                        is_valid=False,
                        score=0.0,
                        message=f"Action execution error: {self.current_result.error}",
                    )
                elif self.current_node and "expected" in self.current_node.tool_args:
                    self.last_verification = self.verifier.verify(
                        expected=self.current_node.tool_args["expected"],
                        actual=self.current_result.output,
                    )
                elif self.current_goal and self.current_goal.criteria is not None and self._is_final_plan_node(self.current_node):
                    self.last_verification = self.verifier.verify(
                        expected=self.current_goal.criteria,
                        actual=self.current_result.output,
                    )
                else:
                    self.last_verification = self.verifier.verify(
                        expected=None,
                        actual=self.current_result.output,
                    )

            self._record_step(
                f"Verification: {'PASSED' if self.last_verification.is_valid else 'FAILED'} - {self.last_verification.message}",
                verification=self.last_verification,
            )

            if self.last_verification.is_valid:
                self.state = ControllerState.UPDATE
            else:
                # Handle verification failure
                if self.enable_replanning and self.replan_count < self.max_replan_attempts:
                    self.replan_count += 1
                    self.active_plan.mark_failed(self.current_node.node_id, self.last_verification.message)
                    # Trigger dynamic replan recovery
                    recovery_desc = f"Alternative execution to recover from failure in {self.current_node.node_id}"
                    self.planner.update_plan(self.active_plan, failed_step=self.current_node, error=self.last_verification.message)
                    self._record_step(f"Triggered dynamic replan (attempt {self.replan_count}/{self.max_replan_attempts}).")
                    self.state = ControllerState.PLAN
                else:
                    self.error_message = f"Verification failed on node {self.current_node.node_id}: {self.last_verification.message}"
                    self.state = ControllerState.FAILED

            return self.state

        elif self.state == ControllerState.UPDATE:
            # Mark current node completed and store output
            self.active_plan.mark_completed(self.current_node.node_id, output=self.current_result.output)
            self.world_state.update_fact(
                key=f"output_{self.current_node.node_id}",
                value=self.current_result.output,
                source=f"tool_{self.current_action.tool_name}",
            )
            # If output is a dictionary (e.g. from probe / observation tool), update facts and semantic memory
            if isinstance(self.current_result.output, dict):
                for k, v in self.current_result.output.items():
                    if k not in ("success", "status", "execution_time"):
                        self.world_state.update_fact(key=k, value=v, source=f"tool_{self.current_action.tool_name}")
                        self.working_memory.add_scratchpad_note(f"Discovered fact: {k} = {v}")
                        if self.enable_memory and self.enable_semantic_learning:
                            self.semantic_memory.add_fact(
                                key=k,
                                content=str(v),
                                category="world_state",
                                confidence=1.0,
                            )
            # Evaluate world model prediction and observe transition
            post_state_dict = {k: v.value for k, v in self.world_state.facts.items()} if self.world_state else {}
            if self.enable_world_model and self.last_prediction is not None:
                err = self.last_prediction.evaluate_error(post_state_dict)
                self.prediction_errors.append(err)
                action_spec = {"tool": self.current_action.tool_name, "args": self.current_action.arguments}
                self.world_model.observe_transition(
                    state=self.pre_action_state_snapshot,
                    action=action_spec,
                    next_state=post_state_dict,
                    success=self.current_result.success,
                    episode_id=self.current_goal.goal_id if self.current_goal else None,
                )
                self._record_step(f"WorldModel updated from transition (prediction error={err:.4f}).")

            self.working_memory.add_scratchpad_note(
                f"Node '{self.current_node.node_id}' produced output: {self.current_result.output}"
            )
            self._record_step(f"Updated world state with output of '{self.current_node.node_id}'.")

            # Check if all plan nodes are finished
            if self.active_plan.is_finished():
                self.final_output = self.current_result.output
                self.state = ControllerState.LEARN
            else:
                self.state = ControllerState.PLAN
            return self.state

        elif self.state == ControllerState.LEARN:
            # Create and log full Episode into EpisodicMemory
            episode_id = f"ep_{int(time.time())}_{uuid.uuid4().hex[:6]}"
            episode = Episode(
                episode_id=episode_id,
                goal=self.current_goal.description,
                context=self.working_memory.get_working_context_prompt(),
                retrieved_memories=list(self.retrieved_memories),
                reasoning_summary=f"Steps: {self.step_counter}, Replans: {self.replan_count}",
                plan={
                    "goal": self.active_plan.goal,
                    "nodes": {nid: asdict(node) for nid, node in self.active_plan.nodes.items()},
                } if self.active_plan and hasattr(self.active_plan, "nodes") else {},
                actions=[act.to_dict() for act, _ in self.world_state.action_history],
                observations=[obs.content for obs in self.world_state.observations],
                verification_results=[asdict(self.last_verification)] if self.last_verification else [],
                outcome=self.final_output,
                success=True,
                reward=1.0,
            )
            self.episodic_memory.store_episode(episode)
            self._record_step(f"Stored completed Episode '{episode_id}' into EpisodicMemory.")

            # Record Experience and trigger cognitive learning loop
            exp = self._build_experience(success=True)
            self.episodic_buffer.add(exp)
            if self.enable_learning:
                report = self.learning_engine.learn_from_experience(
                    experience=exp,
                    semantic_memory=self.semantic_memory if self.enable_memory else None,
                    procedural_memory=self.procedural_memory,
                    enable_semantic=self.enable_semantic_learning,
                    enable_procedural=self.enable_procedural_learning,
                    enable_credit_assignment=self.enable_credit_assignment,
                )
                self._record_step(
                    f"Cognitive learning: reinforced={len(report.strategies_reinforced)}, "
                    f"created={len(report.strategies_created)}, facts={len(report.facts_extracted)}"
                )

            self.state = ControllerState.DONE
            return self.state

        return self.state

    def run(self, goal: Union[str, Goal], max_steps: int = 50) -> ControllerResult:
        """Run the cognitive control loop until termination (DONE or FAILED)."""
        start_time = time.time()
        self.reset()

        if isinstance(goal, str):
            self.current_goal = Goal(goal_id=f"g_{int(time.time())}", description=goal)
        else:
            self.current_goal = goal

        self.world_state = WorldState(goal_description=self.current_goal.description)
        self.working_memory = WorkingMemory(max_token_budget=2048)
        self.working_memory.set_goal(self.current_goal.description)
        self.state = ControllerState.OBSERVE

        steps_run = 0
        while self.state not in (ControllerState.DONE, ControllerState.FAILED) and steps_run < max_steps:
            self.step()
            steps_run += 1

        duration = time.time() - start_time
        success = (self.state == ControllerState.DONE)

        if not success and self.enable_learning:
            failed_exp = self._build_experience(success=False)
            self.episodic_buffer.add(failed_exp)
            self.learning_engine.learn_from_experience(
                experience=failed_exp,
                semantic_memory=self.semantic_memory if self.enable_memory else None,
                procedural_memory=self.procedural_memory,
                enable_semantic=self.enable_semantic_learning,
                enable_procedural=self.enable_procedural_learning,
                enable_credit_assignment=self.enable_credit_assignment,
            )

        # Build episode and experience records
        latest_ep = self.episodic_memory.episodes[-1] if self.episodic_memory.episodes else None
        latest_exp = self.episodic_buffer.buffer[-1] if self.episodic_buffer.buffer else None

        brier = self.world_model.evaluate_calibration() if self.enable_world_model else 0.0
        rules_cnt = len(self.world_model.rules) if self.enable_world_model else 0

        return ControllerResult(
            success=success,
            state=self.state,
            goal=self.current_goal.description,
            final_output=self.final_output,
            error=self.error_message,
            execution_trace=list(self.execution_trace),
            episode=latest_ep,
            experience=latest_exp,
            strategy_used=self.strategy_used,
            total_steps=steps_run,
            duration_sec=duration,
            prediction_errors=list(self.prediction_errors),
            brier_score=brier,
            world_model_rules_count=rules_cnt,
        )
