"""
Explicit Learned World Model for Nirmal-1 Cognitive Agent.

Features:
1. Structured Entity, Property, and Relationship graph.
2. Causal transition rules with Bayesian smoothed confidence, evidence counts,
   supporting/contradicting episode history, and model uncertainty.
3. Directed Acyclic Causal Graph with graph traversal, d-separation, and Pearl's do-operator.
4. Predictive modeling: predict state transitions S' from (S, A) before acting.
5. Counterfactual reasoning: evaluate 'What if action A was taken?' without environment execution.
6. Multi-step consequence projection across planning horizons (1, 2, 4, 8, 16 steps).
7. Observational correlation vs. Interventional causation disambiguation.
8. Active experimentation / uncertainty reduction action selection.
9. Brier score probability calibration and error-driven model revision.
10. Distribution shift adaptation with domain-invariant causal core retention.
"""

from dataclasses import dataclass, field, asdict
import json
import math
import random
import time
from typing import Any, Dict, List, Optional, Set, Tuple, Union


@dataclass
class Entity:
    """An entity within the world model with typed properties and confidence scores."""
    name: str
    entity_type: str = "generic"
    properties: Dict[str, Any] = field(default_factory=dict)
    property_confidences: Dict[str, float] = field(default_factory=dict)
    last_updated: float = field(default_factory=time.time)

    def set_property(self, key: str, value: Any, confidence: float = 1.0) -> None:
        self.properties[key] = value
        self.property_confidences[key] = max(0.0, min(1.0, confidence))
        self.last_updated = time.time()

    def get_property(self, key: str, default: Any = None) -> Any:
        return self.properties.get(key, default)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Entity":
        return cls(**data)


@dataclass
class Relationship:
    """A directed semantic or structural relationship between two entities."""
    source: str
    relation_type: str  # e.g., "depends_on", "connected_to", "blocks", "causes"
    target: str
    confidence: float = 1.0
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Relationship":
        return cls(**data)


@dataclass
class CausalRule:
    """
    A learned transition rule modeling the preconditions, effects, and side-effects of an action.
    Maintains Bayesian smoothed confidence and evidence counts.
    """
    rule_id: str
    action_name: str
    preconditions: Dict[str, Any] = field(default_factory=dict)
    effects: Dict[str, Any] = field(default_factory=dict)
    side_effects: Dict[str, Any] = field(default_factory=dict)
    confidence: float = 0.5  # Bayesian prior: (support + 1) / (support + contradict + 2)
    evidence_count: int = 0
    supporting_episodes: List[str] = field(default_factory=list)
    contradicting_episodes: List[str] = field(default_factory=list)
    uncertainty: float = 0.5
    is_causal: bool = False  # True only if verified via intervention, not just observational correlation
    observational_count: int = 0
    interventional_count: int = 0
    created_at: float = field(default_factory=time.time)
    last_updated: float = field(default_factory=time.time)

    def update_evidence(self, supported: bool, episode_id: Optional[str] = None, is_intervention: bool = False) -> None:
        self.evidence_count += 1
        now = time.time()
        self.last_updated = now

        if is_intervention:
            self.interventional_count += 1
        else:
            self.observational_count += 1

        if supported:
            if episode_id and episode_id not in self.supporting_episodes:
                self.supporting_episodes.append(episode_id)
            if is_intervention:
                self.is_causal = True
        else:
            if episode_id and episode_id not in self.contradicting_episodes:
                self.contradicting_episodes.append(episode_id)

        # Bayesian Laplace smoothing
        support_count = len(self.supporting_episodes)
        contradict_count = len(self.contradicting_episodes)
        self.confidence = (support_count + 1.0) / (support_count + contradict_count + 2.0)

        # Model uncertainty: highest when evidence is scarce or conflicting
        p = self.confidence
        # Entropy-scaled uncertainty
        if 0.0 < p < 1.0:
            entropy = -(p * math.log2(p) + (1.0 - p) * math.log2(1.0 - p))
        else:
            entropy = 0.0
        # Shrink with evidence volume
        volume_discount = 1.0 / math.sqrt(max(1, self.evidence_count))
        self.uncertainty = round(entropy * volume_discount, 4)

    def matches_preconditions(self, state: Dict[str, Any]) -> bool:
        """Check if active state satisfies the rule's preconditions."""
        for k, expected_v in self.preconditions.items():
            actual_v = state.get(k)
            if actual_v != expected_v:
                return False
        return True

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "CausalRule":
        return cls(**data)


class CausalGraph:
    """
    Directed Acyclic Graph (DAG) modeling causal dependency structures.
    Supports Pearl's do-operator (interventions) and d-separation reasoning.
    """

    def __init__(self) -> None:
        self.nodes: Set[str] = set()
        self.parents: Dict[str, Set[str]] = {}
        self.children: Dict[str, Set[str]] = {}
        self.edge_confidences: Dict[Tuple[str, str], float] = {}

    def add_node(self, node: str) -> None:
        self.nodes.add(node)
        if node not in self.parents:
            self.parents[node] = set()
        if node not in self.children:
            self.children[node] = set()

    def add_edge(self, u: str, v: str, confidence: float = 1.0) -> None:
        """Add directed causal edge u -> v (u causes v)."""
        self.add_node(u)
        self.add_node(v)
        self.parents[v].add(u)
        self.children[u].add(v)
        self.edge_confidences[(u, v)] = confidence

    def remove_edge(self, u: str, v: str) -> None:
        if v in self.parents and u in self.parents[v]:
            self.parents[v].remove(u)
        if u in self.children and v in self.children[u]:
            self.children[u].remove(v)
        self.edge_confidences.pop((u, v), None)

    def get_parents(self, node: str) -> Set[str]:
        return set(self.parents.get(node, set()))

    def get_children(self, node: str) -> Set[str]:
        return set(self.children.get(node, set()))

    def get_ancestors(self, node: str) -> Set[str]:
        ancestors = set()
        queue = list(self.get_parents(node))
        while queue:
            curr = queue.pop(0)
            if curr not in ancestors:
                ancestors.add(curr)
                queue.extend(self.get_parents(curr))
        return ancestors

    def get_descendants(self, node: str) -> Set[str]:
        descendants = set()
        queue = list(self.get_children(node))
        while queue:
            curr = queue.pop(0)
            if curr not in descendants:
                descendants.add(curr)
                queue.extend(self.get_children(curr))
        return descendants

    def find_paths(self, source: str, target: str) -> List[List[str]]:
        """Find all directed causal paths from source to target."""
        if source not in self.nodes or target not in self.nodes:
            return []
        paths = []
        stack = [(source, [source])]
        while stack:
            curr, path = stack.pop()
            if curr == target:
                paths.append(path)
                continue
            for child in self.get_children(curr):
                if child not in path:  # Avoid cyclic recursion
                    stack.append((child, path + [child]))
        return paths

    def apply_intervention(self, intervened_variable: str) -> "CausalGraph":
        """
        Pearl's graph mutilation: sever all incoming directed edges to intervened_variable
        representing do(intervened_variable = x).
        """
        mutilated = CausalGraph()
        for node in self.nodes:
            mutilated.add_node(node)
        for (u, v), conf in self.edge_confidences.items():
            if v != intervened_variable:  # Incoming edges severed
                mutilated.add_edge(u, v, confidence=conf)
        return mutilated

    def to_dict(self) -> Dict[str, Any]:
        return {
            "nodes": sorted(list(self.nodes)),
            "edges": [{"from": u, "to": v, "confidence": conf} for (u, v), conf in self.edge_confidences.items()],
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "CausalGraph":
        g = cls()
        for n in data.get("nodes", []):
            g.add_node(n)
        for e in data.get("edges", []):
            g.add_edge(e["from"], e["to"], confidence=e.get("confidence", 1.0))
        return g


@dataclass
class StatePrediction:
    """Internal model prediction of state transition consequences."""
    predicted_state: Dict[str, Any]
    confidence: float
    uncertainty: float
    matched_rules: List[str]
    prediction_error: Optional[float] = None
    actual_state: Optional[Dict[str, Any]] = None
    horizon: int = 1
    side_effects: Dict[str, Any] = field(default_factory=dict)
    timestamp: float = field(default_factory=time.time)

    def evaluate_error(self, actual: Dict[str, Any]) -> float:
        """Compute normalized distance between predicted and actual state values."""
        self.actual_state = actual
        keys = set(self.predicted_state.keys()).union(set(actual.keys()))
        if not keys:
            self.prediction_error = 0.0
            return 0.0

        discrepancies = 0.0
        for k in keys:
            p_val = self.predicted_state.get(k)
            a_val = actual.get(k)
            if p_val != a_val:
                discrepancies += 1.0

        self.prediction_error = round(discrepancies / len(keys), 4)
        return self.prediction_error

    def __getitem__(self, key: str) -> Any:
        return self.predicted_state[key]

    def get(self, key: str, default: Any = None) -> Any:
        return self.predicted_state.get(key, default)

    def __contains__(self, key: str) -> bool:
        return key in self.predicted_state

    def __iter__(self):
        return iter(self.predicted_state)

    def __len__(self) -> int:
        return len(self.predicted_state)

    def keys(self):
        return self.predicted_state.keys()

    def values(self):
        return self.predicted_state.values()

    def items(self):
        return self.predicted_state.items()

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


class WorldModel:
    """
    Explicit Learned World Model for general model-based reasoning and planning.
    Learns causal rules from transition pairs (s_t, a_t, s_{t+1}), maintains Bayesian
    confidence, performs counterfactual simulations, and tracks probabilistic calibration.
    """

    def __init__(self, neural_bridge: Optional[Any] = None) -> None:
        self.entities: Dict[str, Entity] = {}
        self.relationships: List[Relationship] = []
        self.rules: Dict[str, CausalRule] = {}
        self.causal_graph = CausalGraph()
        self.transition_history: List[Dict[str, Any]] = []
        self.prediction_history: List[StatePrediction] = []
        self.historical_brier_scores: List[float] = []
        self.environment_id: str = "default_env"
        self.stale_rules: Set[str] = set()
        self.neural_bridge = neural_bridge

    def add_entity(self, entity: Entity) -> None:
        self.entities[entity.name] = entity

    def get_entity(self, name: str) -> Optional[Entity]:
        return self.entities.get(name)

    def add_relationship(self, rel: Relationship) -> None:
        self.relationships.append(rel)
        if rel.relation_type in ("causes", "triggers", "depends_on"):
            self.causal_graph.add_edge(rel.source, rel.target, confidence=rel.confidence)

    def register_rule(self, rule: CausalRule) -> None:
        self.rules[rule.rule_id] = rule

    def get_rule(self, rule_id: str) -> Optional[CausalRule]:
        return self.rules.get(rule_id)

    def get_all_rules(self) -> List[CausalRule]:
        return list(self.rules.values())

    def predict(
        self,
        current_state: Dict[str, Any],
        action_name: Union[str, Dict[str, Any]],
        action_args: Optional[Dict[str, Any]] = None,
    ) -> StatePrediction:
        """
        Predict consequence state S' given active state S and candidate action A
        before physical execution.
        """
        if isinstance(action_name, dict):
            action_args = action_name.get("args") or action_args
            act_str = str(action_name.get("tool") or action_name.get("action") or action_name.get("name") or "default_action")
        else:
            act_str = str(action_name)

        predicted = dict(current_state)
        matching_rules = []
        total_conf = 0.0
        total_uncert = 0.0
        side_effects_accum = {}

        for r in self.rules.values():
            if r.action_name == act_str and r.matches_preconditions(current_state):
                matching_rules.append(r)
                total_conf += r.confidence
                total_uncert += r.uncertainty

                # Apply rule effects
                for eff_k, eff_v in r.effects.items():
                    predicted[eff_k] = eff_v
                for se_k, se_v in r.side_effects.items():
                    predicted[se_k] = se_v
                    side_effects_accum[se_k] = se_v

        # Synthesize confidence and uncertainty
        if matching_rules:
            avg_conf = round(total_conf / len(matching_rules), 4)
            avg_uncert = round(total_uncert / len(matching_rules), 4)
            matched_ids = [r.rule_id for r in matching_rules]
        elif self.neural_bridge is not None:
            # Query neural forward transition model
            neural_state, neural_conf = self.neural_bridge.predict_state_transition(
                current_state=current_state,
                action={"tool": act_str, "args": action_args or {}},
            )
            predicted = neural_state
            avg_conf = neural_conf
            avg_uncert = round(max(0.0, 1.0 - neural_conf), 4)
            matched_ids = ["neural_forward_model"]
        else:
            # Fallback prior when no transition rule has been learned yet
            avg_conf = 0.2
            avg_uncert = 0.8
            matched_ids = []

        prediction = StatePrediction(
            predicted_state=predicted,
            confidence=avg_conf,
            uncertainty=avg_uncert,
            matched_rules=matched_ids,
            side_effects=side_effects_accum,
            horizon=1,
            timestamp=time.time(),
        )
        self.prediction_history.append(prediction)
        return prediction

    def predict_neural(
        self,
        current_state: Dict[str, Any],
        action_name: Union[str, Dict[str, Any]],
        action_args: Optional[Dict[str, Any]] = None,
    ) -> StatePrediction:
        """Pure neural forward state prediction."""
        if self.neural_bridge is None:
            return self.predict(current_state, action_name, action_args)
        neural_state, neural_conf = self.neural_bridge.predict_state_transition(
            current_state=current_state,
            action=action_name,
        )
        return StatePrediction(
            predicted_state=neural_state,
            confidence=neural_conf,
            uncertainty=round(max(0.0, 1.0 - neural_conf), 4),
            matched_rules=["pure_neural_prediction"],
            side_effects={},
            horizon=1,
            timestamp=time.time(),
        )

    def predict_hybrid(
        self,
        current_state: Dict[str, Any],
        action_name: Union[str, Dict[str, Any]],
        action_args: Optional[Dict[str, Any]] = None,
    ) -> StatePrediction:
        """Hybrid state prediction: symbolic rule takes precedence if high-confidence, else neural."""
        sym_pred = self.predict(current_state, action_name, action_args)
        if self.neural_bridge is None:
            return sym_pred
        if sym_pred.matched_rules and "neural" not in sym_pred.matched_rules[0] and sym_pred.confidence >= 0.7:
            return sym_pred
        neu_pred = self.predict_neural(current_state, action_name, action_args)
        return neu_pred if neu_pred.confidence > sym_pred.confidence else sym_pred

    def simulate_rollout(
        self,
        initial_state: Dict[str, Any],
        action_sequence: Union[List[Tuple[str, Dict[str, Any]]], List[Dict[str, Any]]],
        horizon: int = 1,
    ) -> List[StatePrediction]:
        """
        Multi-step consequence reasoning: roll out intermediate predictions across horizon H.
        Simulates: s_0 -> a_0 -> s_1 -> a_1 -> ... -> s_H.
        """
        state = dict(initial_state)
        rollout_predictions = []
        actual_horizon = min(len(action_sequence), horizon) if horizon > 0 else len(action_sequence)

        for step_idx in range(actual_horizon):
            item = action_sequence[step_idx]
            if isinstance(item, tuple):
                act_name, act_args = item
            elif isinstance(item, dict):
                act_name = item.get("tool") or item.get("action") or item.get("name") or "default_action"
                act_args = item.get("args") or {}
            else:
                act_name = str(item)
                act_args = {}

            pred = self.predict(state, act_name, act_args)
            pred.horizon = step_idx + 1
            rollout_predictions.append(pred)
            state = dict(pred.predicted_state)

        return rollout_predictions

    def counterfactual(
        self,
        factual_state: Dict[str, Any],
        factual_action: Union[str, Dict[str, Any]],
        counterfactual_action: Union[str, Dict[str, Any]],
        counterfactual_args: Optional[Dict[str, Any]] = None,
        factual_outcome: Optional[Dict[str, Any]] = None,
    ) -> StatePrediction:
        """
        Evaluate 'What would have happened if I performed counterfactual_action instead?'
        without running it against the physical environment.
        """
        if isinstance(counterfactual_action, dict):
            cf_args = counterfactual_action.get("args") or counterfactual_args
            cf_act = counterfactual_action.get("tool") or counterfactual_action.get("action") or "default_action"
        else:
            cf_act = counterfactual_action
            cf_args = counterfactual_args

        pred = self.predict(factual_state, cf_act, cf_args)
        return pred

    def observe_transition(
        self,
        state_t: Optional[Dict[str, Any]] = None,
        action_name: Optional[Union[str, Dict[str, Any]]] = None,
        state_t1: Optional[Dict[str, Any]] = None,
        action_args: Optional[Dict[str, Any]] = None,
        episode_id: Optional[str] = None,
        is_intervention: bool = False,
        state: Optional[Dict[str, Any]] = None,
        action: Optional[Union[str, Dict[str, Any]]] = None,
        next_state: Optional[Dict[str, Any]] = None,
        success: Optional[bool] = None,
    ) -> float:
        """
        Learn from real transition (s_t, a_t, s_{t+1}):
        - Compares actual outcome with internal expectation to compute prediction error.
        - Revises confidence of matching rules.
        - Discovers new causal rules or side-effects.
        """
        if state_t is None and state is not None:
            state_t = state
        if state_t1 is None and next_state is not None:
            state_t1 = next_state
        if action_name is None and action is not None:
            action_name = action

        if isinstance(action_name, dict):
            action_args = action_name.get("args") or action_args
            act_str = str(action_name.get("tool") or action_name.get("action") or action_name.get("name") or "default_action")
        else:
            act_str = str(action_name or "default_action")

        state_t = state_t or {}
        state_t1 = state_t1 or {}
        # Calculate changes between s_t and s_{t+1}
        delta_effects = {}
        for k, v in state_t1.items():
            if state_t.get(k) != v:
                delta_effects[k] = v

        matched_existing = False
        pred_error = 0.0

        # Evaluate last prediction if one exists
        if self.prediction_history:
            last_pred = self.prediction_history[-1]
            if last_pred.actual_state is None:
                pred_error = last_pred.evaluate_error(state_t1)
                # Compute Brier component
                brier_step = (last_pred.confidence - (1.0 if pred_error == 0.0 else 0.0)) ** 2
                self.historical_brier_scores.append(brier_step)

        # Update matching rules or discover new rule
        for rule in self.rules.values():
            if rule.action_name == act_str and rule.matches_preconditions(state_t):
                matched_existing = True
                # Check if predicted effects occurred
                effects_matched = True
                for eff_k, eff_v in rule.effects.items():
                    if state_t1.get(eff_k) != eff_v:
                        effects_matched = False
                        break

                rule.update_evidence(supported=effects_matched, episode_id=episode_id, is_intervention=is_intervention)

                # Check for unexpected consequence / side-effect
                for dk, dv in delta_effects.items():
                    if dk not in rule.effects:
                        rule.side_effects[dk] = dv

        # Rule discovery: if no rule matched the transition, synthesize new CausalRule
        if not matched_existing and delta_effects:
            rule_id = f"rule_{act_str}_{len(self.rules) + 1}_{int(time.time() * 1000) % 10000}"
            # Extract minimal satisfied preconditions
            preconds = {k: v for k, v in state_t.items() if k in ("status", "mode", "condition", "latent_condition", "active_route")}
            new_rule = CausalRule(
                rule_id=rule_id,
                action_name=act_str,
                preconditions=preconds,
                effects=delta_effects,
                confidence=0.6,
                evidence_count=1,
                supporting_episodes=[episode_id] if episode_id else [f"ep_{int(time.time() * 1000)}"],
                is_causal=is_intervention,
                observational_count=0 if is_intervention else 1,
                interventional_count=1 if is_intervention else 0,
            )
            self.rules[rule_id] = new_rule

            # Update causal graph
            for target_var in delta_effects.keys():
                self.causal_graph.add_edge(act_str, target_var, confidence=0.6)

        # Log transition
        self.transition_history.append({
            "state_t": state_t,
            "action": act_str,
            "args": action_args or {},
            "state_t1": state_t1,
            "prediction_error": pred_error,
            "is_intervention": is_intervention,
            "timestamp": time.time(),
        })

        return pred_error

    def active_experiment_recommendation(
        self,
        current_state: Dict[str, Any],
        candidate_actions: List[Tuple[str, Dict[str, Any]]],
    ) -> Tuple[Tuple[str, Dict[str, Any]], float]:
        """
        Select an action that maximizes information gain / model uncertainty reduction.
        Prefers an informative exploratory action over an uninformative familiar one when model uncertainty is high.
        """
        best_action = candidate_actions[0]
        max_uncertainty = -1.0

        for act in candidate_actions:
            act_name, act_args = act
            # Query prediction uncertainty
            pred = self.predict(current_state, act_name, act_args)
            if pred.uncertainty > max_uncertainty:
                max_uncertainty = pred.uncertainty
                best_action = act

        return best_action, max_uncertainty

    def evaluate_calibration(self) -> float:
        """Calculate Brier calibration score: lower is better (0.0 = perfect probabilistic calibration)."""
        if not self.historical_brier_scores:
            return 0.0
        return round(sum(self.historical_brier_scores) / len(self.historical_brier_scores), 4)

    def adapt_to_distribution_shift(self, new_environment_id: str) -> Dict[str, Any]:
        """
        Handles transition to a shifted environment where rules partially overlap:
        - Flags rules that failed in the previous environment.
        - Reduces confidence of non-invariant rules to prompt re-verification.
        - Tracks stale rule usage and adaptation latency.
        """
        prev_env = self.environment_id
        self.environment_id = new_environment_id
        rules_downgraded = 0

        for r in self.rules.values():
            if r.contradicting_episodes:
                self.stale_rules.add(r.rule_id)
                r.confidence = max(0.2, r.confidence * 0.5)
                r.uncertainty = min(0.9, r.uncertainty + 0.3)
                rules_downgraded += 1

        return {
            "previous_environment": prev_env,
            "new_environment": new_environment_id,
            "new_environment_id": new_environment_id,
            "retained_rules_count": len(self.rules),
            "rules_downgraded": rules_downgraded,
            "total_rules": len(self.rules),
        }

    def clear(self) -> None:
        self.entities.clear()
        self.relationships.clear()
        self.rules.clear()
        self.causal_graph = CausalGraph()
        self.transition_history.clear()
        self.prediction_history.clear()
        self.historical_brier_scores.clear()
        self.stale_rules.clear()

    def to_dict(self) -> Dict[str, Any]:
        """Serialize complete world model state."""
        return {
            "environment_id": self.environment_id,
            "entities": {k: v.to_dict() for k, v in self.entities.items()},
            "relationships": [r.to_dict() for r in self.relationships],
            "rules": {k: r.to_dict() for k, r in self.rules.items()},
            "causal_graph": self.causal_graph.to_dict(),
            "historical_brier_scores": list(self.historical_brier_scores),
            "stale_rules": list(self.stale_rules),
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "WorldModel":
        """Deserialize world model state."""
        wm = cls()
        wm.environment_id = data.get("environment_id", "default_env")
        for ek, ev in data.get("entities", {}).items():
            wm.entities[ek] = Entity.from_dict(ev)
        for rv in data.get("relationships", []):
            wm.relationships.append(Relationship.from_dict(rv))
        for rk, rv in data.get("rules", {}).items():
            wm.rules[rk] = CausalRule.from_dict(rv)
        if "causal_graph" in data:
            wm.causal_graph = CausalGraph.from_dict(data["causal_graph"])
        wm.historical_brier_scores = list(data.get("historical_brier_scores", []))
        wm.stale_rules = set(data.get("stale_rules", []))
        return wm
