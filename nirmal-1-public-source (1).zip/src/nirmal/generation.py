"""
Autoregressive token generation module for Nirmal-1.
Supports greedy decoding, temperature sampling, top-k/top-p filtering,
repetition penalty, and hybrid state caching.
"""

from typing import List, Optional, Union
import torch
import torch.nn.functional as F

from nirmal.model import NirmalForCausalLM, NirmalHybridCache


def apply_repetition_penalty(
    logits: torch.Tensor,
    generated_tokens: torch.Tensor,
    penalty: float = 1.0,
) -> torch.Tensor:
    """Applies repetition penalty to logits for tokens already produced."""
    if penalty == 1.0:
        return logits

    batch_size = logits.shape[0]
    for b in range(batch_size):
        tokens = generated_tokens[b].unique()
        token_logits = logits[b, tokens]
        # If logit is negative, multiply by penalty; if positive, divide
        token_logits = torch.where(
            token_logits < 0,
            token_logits * penalty,
            token_logits / penalty,
        )
        logits[b, tokens] = token_logits
    return logits


def top_k_top_p_filtering(
    logits: torch.Tensor,
    top_k: int = 0,
    top_p: float = 1.0,
    filter_value: float = -float("Inf"),
) -> torch.Tensor:
    """Filters logits using top-k and/or nucleus (top-p) sampling."""
    filtered_logits = logits.clone()

    if top_k > 0:
        top_k = min(max(top_k, 1), filtered_logits.size(-1))
        indices_to_remove = filtered_logits < torch.topk(filtered_logits, top_k)[0][..., -1, None]
        filtered_logits[indices_to_remove] = filter_value

    if 0.0 < top_p < 1.0:
        sorted_logits, sorted_indices = torch.sort(filtered_logits, descending=True)
        cumulative_probs = torch.cumsum(F.softmax(sorted_logits, dim=-1), dim=-1)

        sorted_indices_to_remove = cumulative_probs > top_p
        # Shift mask to keep at least one token above threshold
        sorted_indices_to_remove[..., 1:] = sorted_indices_to_remove[..., :-1].clone()
        sorted_indices_to_remove[..., 0] = False

        # Scatter into a clean zero-initialized boolean mask
        indices_to_remove = torch.zeros_like(filtered_logits, dtype=torch.bool).scatter(
            dim=-1, index=sorted_indices, src=sorted_indices_to_remove
        )
        filtered_logits[indices_to_remove] = filter_value

    return filtered_logits


class NirmalGenerator:
    """Generation controller executing autoregressive decoding with hybrid state cache."""

    def __init__(self, model: NirmalForCausalLM):
        self.model = model

    @torch.no_grad()
    def generate(
        self,
        input_ids: torch.Tensor,
        max_new_tokens: int = 32,
        temperature: float = 1.0,
        top_k: int = 50,
        top_p: float = 0.9,
        repetition_penalty: float = 1.0,
        eos_token_id: Optional[Union[int, List[int]]] = None,
        pad_token_id: Optional[int] = None,
        use_cache: bool = True,
    ) -> torch.Tensor:
        """Autoregressively generate sequence of new tokens.

        Args:
            input_ids: Prompt token tensor of shape (batch, seq_len)
            max_new_tokens: Maximum number of tokens to generate
            temperature: Sampling temperature (0.0 for greedy argmax)
            top_k: Keep highest k logits (0 to disable)
            top_p: Cumulative probability threshold for nucleus sampling
            repetition_penalty: Multiplier penalty for previously generated tokens
            eos_token_id: Stop generation if encountered
            pad_token_id: Token ID used to pad finished sequences
            use_cache: Utilize NirmalHybridCache for fast O(1) step decoding

        Returns:
            Tensor of generated tokens including prompt: (batch, seq_len + new_tokens)
        """
        self.model.eval()
        device = input_ids.device
        batch_size = input_ids.shape[0]

        if isinstance(eos_token_id, int):
            eos_tokens = {eos_token_id}
            primary_eos = eos_token_id
        elif isinstance(eos_token_id, (list, tuple, set)):
            eos_tokens = set(eos_token_id)
            primary_eos = list(eos_tokens)[0] if eos_tokens else None
        else:
            eos_tokens = set()
            primary_eos = None

        terminal_fill_token = pad_token_id if pad_token_id is not None else primary_eos

        curr_input_ids = input_ids.clone()
        cache = NirmalHybridCache() if use_cache else None

        # Track completed sequences in batch
        finished = torch.zeros(batch_size, dtype=torch.bool, device=device)

        # 1. Prefill step: process initial context
        outputs = self.model(
            input_ids=curr_input_ids,
            cache=cache,
            use_cache=use_cache,
        )
        next_token_logits = outputs.logits[:, -1, :]  # (batch, vocab_size)

        for _ in range(max_new_tokens):
            if finished.all():
                break

            # Repetition penalty
            filtered_logits = apply_repetition_penalty(
                next_token_logits.clone(), curr_input_ids, penalty=repetition_penalty
            )

            # Sampling or greedy
            if temperature == 0.0 or temperature < 1e-5:
                next_tokens = torch.argmax(filtered_logits, dim=-1, keepdim=True)
            else:
                scaled_logits = filtered_logits / temperature
                filtered_logits = top_k_top_p_filtering(scaled_logits, top_k=top_k, top_p=top_p)
                probs = F.softmax(filtered_logits, dim=-1)
                next_tokens = torch.multinomial(probs, num_samples=1)

            # Check for EOS and lock finished sequences
            for b in range(batch_size):
                if finished[b]:
                    if terminal_fill_token is not None:
                        next_tokens[b, 0] = terminal_fill_token
                elif eos_tokens and next_tokens[b, 0].item() in eos_tokens:
                    finished[b] = True

            curr_input_ids = torch.cat([curr_input_ids, next_tokens], dim=-1)

            # Next forward step: incremental with cache or full sequence without cache
            if use_cache:
                step_outputs = self.model(
                    input_ids=next_tokens,
                    cache=cache,
                    use_cache=True,
                )
            else:
                step_outputs = self.model(
                    input_ids=curr_input_ids,
                    use_cache=False,
                )

            next_token_logits = step_outputs.logits[:, -1, :]

        return curr_input_ids
