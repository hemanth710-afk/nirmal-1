"""
Memory Subsystem for Nirmal-1:
- WorkingMemory: Scratchpad, short-term buffer, and active goal state within bounded budget.
- PersistentMemory: Long-term episodic, semantic, and procedural knowledge base.
- InMemoryVectorStore & RetrievalEngine: Semantic retrieval over memories.
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
import time
from typing import Any, Callable, Dict, List, Optional
import torch


@dataclass
class MemoryRecord:
    """A persistent memory unit with semantic embeddings and metadata."""
    key: str
    content: str
    embedding: Optional[torch.Tensor] = None
    timestamp: float = field(default_factory=time.time)
    metadata: Dict[str, Any] = field(default_factory=dict)


class WorkingMemory:
    """Working memory maintaining active scratchpad, goals, and conversational context."""

    def __init__(self, max_token_budget: int = 4096):
        self.max_token_budget = max_token_budget
        self.active_goal: Optional[str] = None
        self.scratchpad: List[str] = []
        self.conversation_history: List[Dict[str, str]] = []

    def set_goal(self, goal: str) -> None:
        """Set the active top-level goal."""
        self.active_goal = goal

    def add_scratchpad_note(self, note: str) -> None:
        """Record intermediate thought, scratch deduction, or observation."""
        self.scratchpad.append(note)

    def append_message(self, role: str, content: str) -> None:
        """Add message to short-term history."""
        self.conversation_history.append({"role": role, "content": content})

    def append_observation(self, role: str, content: str) -> None:
        """Alias conforming to AGI_SPEC.md interface."""
        self.append_message(role=role, content=content)

    def get_working_context_prompt(self) -> str:
        """Render working memory as structured context for prompting the core model."""
        sections = []
        if self.active_goal:
            sections.append(f"[Active Goal]\n{self.active_goal}")

        if self.scratchpad:
            scratch_text = "\n".join(f"- {note}" for note in self.scratchpad[-10:])
            sections.append(f"[Scratchpad]\n{scratch_text}")

        if self.conversation_history:
            history_text = "\n".join(
                f"{msg['role'].capitalize()}: {msg['content']}"
                for msg in self.conversation_history[-10:]
            )
            sections.append(f"[Recent History]\n{history_text}")

        return "\n\n".join(sections)

    def prune_or_summarize(self, max_budget: Optional[int] = None) -> None:
        """Enforces token budget limits by trimming oldest history entries."""
        budget = max_budget if max_budget is not None else self.max_token_budget
        # Approximate tokens ~ 4 characters per token
        while len(self.conversation_history) > 2:
            est_tokens = len(self.get_working_context_prompt()) // 4
            if est_tokens <= budget:
                break
            # Remove oldest message (preserving goal and scratchpad)
            self.conversation_history.pop(0)

    def get_context_tokens(self, tokenize_fn: Optional[Callable[[str], List[int]]] = None) -> torch.Tensor:
        """Returns tensor of tokens representing current working memory."""
        prompt = self.get_working_context_prompt()
        if tokenize_fn is not None:
            token_ids = tokenize_fn(prompt)
        else:
            token_ids = [ord(c) % 1000 for c in prompt]  # Fallback byte encoding
        return torch.tensor([token_ids], dtype=torch.long)

    def clear_scratchpad(self) -> None:
        self.scratchpad.clear()

    def clear(self) -> None:
        """Clear all active working memory contents."""
        self.active_goal = None
        self.conversation_history.clear()
        self.scratchpad.clear()



class PersistentMemory(ABC):
    """Abstract interface for long-term memory systems."""

    @abstractmethod
    def store(self, key: str, record: MemoryRecord) -> bool:
        """Persist a memory record."""
        pass

    @abstractmethod
    def retrieve(self, query_embedding: torch.Tensor, top_k: int = 5) -> List[MemoryRecord]:
        """Retrieve top-k relevant memory records by semantic similarity."""
        pass


class InMemoryVectorStore(PersistentMemory):
    """Reference in-memory vector store using cosine similarity."""

    def __init__(self) -> None:
        self.records: Dict[str, MemoryRecord] = {}

    def store(self, key: str, record: MemoryRecord) -> bool:
        self.records[key] = record
        return True

    def get(self, key: str) -> Optional[MemoryRecord]:
        return self.records.get(key)

    def retrieve(self, query_embedding: torch.Tensor, top_k: int = 5) -> List[MemoryRecord]:
        """Find most similar records based on cosine similarity."""
        if not self.records:
            return []

        # Ensure query is 1D
        flat_query = query_embedding.float().view(-1)
        query_norm = torch.nn.functional.normalize(flat_query, p=2, dim=-1)

        scored_records = []
        for record in self.records.values():
            if record.embedding is not None:
                flat_rec = record.embedding.float().view(-1)
                if flat_rec.shape[-1] != flat_query.shape[-1]:
                    continue
                rec_norm = torch.nn.functional.normalize(flat_rec, p=2, dim=-1)
                score = (query_norm * rec_norm).sum().item()
                scored_records.append((score, record))

        scored_records.sort(key=lambda x: x[0], reverse=True)
        return [record for _, record in scored_records[:top_k]]


class RetrievalEngine:
    """Coordinates semantic search and contextual knowledge injection."""

    def __init__(self, memory_store: PersistentMemory):
        self.store = memory_store

    def retrieve_context(self, query_embedding: torch.Tensor, top_k: int = 3) -> str:
        records = self.store.retrieve(query_embedding, top_k=top_k)
        if not records:
            return ""
        return "\n\n".join(f"[Memory {r.key}]: {r.content}" for r in records)
