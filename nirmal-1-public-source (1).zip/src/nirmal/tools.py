"""
Tool System & Sandboxed Environment Subsystem for Nirmal-1:
- Tool: Abstract interface for external capabilities and APIs.
- ToolResult: Structured output from tool invocations.
- ToolRegistry: Schema generation, validation, and tool execution dispatcher.
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass
import math
import time
from typing import Any, Callable, Dict, List, Optional


@dataclass
class ToolResult:
    """Standardized response from tool execution."""
    success: bool
    output: Any = None
    error: Optional[str] = None
    execution_time_sec: float = 0.0


class Tool(ABC):
    """Base abstract class for all Nirmal-1 tools."""

    name: str
    description: str
    parameters: Dict[str, Any]

    @property
    def parameters_schema(self) -> Dict[str, Any]:
        """Conforms to AGI_SPEC.md interface."""
        return self.parameters

    @abstractmethod
    def execute(self, **kwargs: Any) -> ToolResult:
        """Run tool action with supplied arguments."""
        pass

    def to_schema(self) -> Dict[str, Any]:
        """Export as standardized tool JSON schema."""
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": self.parameters_schema,
            },
        }


class CalculatorTool(Tool):
    """Safe arithmetic and mathematical evaluation tool."""

    name = "calculator"
    description = "Evaluates a basic mathematical expression safely."
    parameters = {
        "type": "object",
        "properties": {
            "expression": {
                "type": "string",
                "description": "Mathematical expression to evaluate, e.g., '2 + 2 * 10' or 'sqrt(16)'",
            }
        },
        "required": ["expression"],
    }

    def execute(self, expression: str, **kwargs: Any) -> ToolResult:
        start_t = time.time()
        allowed_names = {
            "sin": math.sin,
            "cos": math.cos,
            "tan": math.tan,
            "sqrt": math.sqrt,
            "log": math.log,
            "exp": math.exp,
            "pi": math.pi,
            "e": math.e,
            "abs": abs,
            "round": round,
        }
        try:
            # Restricted evaluation with no globals and safe math builtins
            code = compile(expression, "<string>", "eval")
            for name in code.co_names:
                if name not in allowed_names:
                    raise ValueError(f"Access to symbol '{name}' is disallowed in calculator.")
            result = eval(code, {"__builtins__": {}}, allowed_names)
            return ToolResult(
                success=True,
                output=result,
                execution_time_sec=time.time() - start_t,
            )
        except Exception as e:
            return ToolResult(
                success=False,
                error=f"Calculator execution error: {str(e)}",
                execution_time_sec=time.time() - start_t,
            )


class StringUtilityTool(Tool):
    """Deterministic string manipulation utility tool."""

    name = "string_util"
    description = "Performs deterministic string operations: uppercase, lowercase, reverse, length, replace, split, count."
    parameters = {
        "type": "object",
        "properties": {
            "operation": {
                "type": "string",
                "enum": ["uppercase", "lowercase", "reverse", "length", "replace", "count", "echo", "identity"],
                "description": "Operation to perform",
            },
            "text": {"type": "string", "description": "Input text"},
            "param1": {"type": "string", "description": "Optional search string or target character"},
            "param2": {"type": "string", "description": "Optional replacement string"},
        },
        "required": ["operation", "text"],
    }

    def execute(self, operation: str, text: str, param1: Optional[str] = None, param2: Optional[str] = None, **kwargs: Any) -> ToolResult:
        start_t = time.time()
        try:
            if operation == "uppercase":
                out = text.upper()
            elif operation == "lowercase":
                out = text.lower()
            elif operation == "reverse":
                out = text[::-1]
            elif operation == "length":
                out = len(text)
            elif operation == "replace":
                p1 = param1 if param1 is not None else ""
                p2 = param2 if param2 is not None else ""
                out = text.replace(p1, p2)
            elif operation == "count":
                p1 = param1 if param1 is not None else ""
                out = text.count(p1)
            elif operation in ("echo", "identity"):
                out = text
            else:
                return ToolResult(success=False, error=f"Unknown operation: {operation}", execution_time_sec=time.time() - start_t)

            return ToolResult(success=True, output=out, execution_time_sec=time.time() - start_t)
        except Exception as e:
            return ToolResult(success=False, error=str(e), execution_time_sec=time.time() - start_t)


class MockEnvironmentTool(Tool):
    """Controlled test environment with programmable failure injection for replanning tests."""

    name = "mock_env"
    description = "Controlled stateful test environment allowing state inspection, actions, and programmable failure."
    parameters = {
        "type": "object",
        "properties": {
            "action": {
                "type": "string",
                "enum": ["read", "write", "fail_action", "reset"],
                "description": "Environment action to perform",
            },
            "key": {"type": "string", "description": "State key"},
            "value": {"type": "string", "description": "State value"},
        },
        "required": ["action"],
    }

    def __init__(self) -> None:
        self.state: Dict[str, Any] = {}
        self.should_fail: bool = False
        self.fail_message: str = "Simulated environmental disruption."

    def set_fail_next(self, fail: bool = True, message: str = "Simulated environmental disruption.") -> None:
        self.should_fail = fail
        self.fail_message = message

    def execute(self, action: str, key: Optional[str] = None, value: Optional[str] = None, **kwargs: Any) -> ToolResult:
        start_t = time.time()
        if self.should_fail and action != "reset":
            self.should_fail = False  # Reset flag after firing
            return ToolResult(success=False, error=self.fail_message, execution_time_sec=time.time() - start_t)

        if action == "read":
            if key is None or key not in self.state:
                return ToolResult(success=False, error=f"Key '{key}' not found in environment.", execution_time_sec=time.time() - start_t)
            return ToolResult(success=True, output=self.state[key], execution_time_sec=time.time() - start_t)
        elif action == "write":
            if key is None:
                return ToolResult(success=False, error="Key must be provided for write.", execution_time_sec=time.time() - start_t)
            self.state[key] = value
            return ToolResult(success=True, output=f"Updated {key}={value}", execution_time_sec=time.time() - start_t)
        elif action == "reset":
            self.state.clear()
            self.should_fail = False
            return ToolResult(success=True, output="Environment reset.", execution_time_sec=time.time() - start_t)
        elif action == "fail_action":
            return ToolResult(success=False, error="Action intentionally failed.", execution_time_sec=time.time() - start_t)
        else:
            return ToolResult(success=False, error=f"Unknown action: {action}", execution_time_sec=time.time() - start_t)


class ToolRegistry:
    """Central registry and execution router for tools."""

    def __init__(self) -> None:
        self._tools: Dict[str, Tool] = {}
        # Register default safe builtins
        self.register(CalculatorTool())
        self.register(StringUtilityTool())
        self.register(MockEnvironmentTool())

    def register(self, tool: Tool) -> None:
        """Register a new tool instance."""
        self._tools[tool.name] = tool

    def get(self, name: str) -> Optional[Tool]:
        """Fetch tool by name."""
        return self._tools.get(name)

    def list_tools(self) -> List[str]:
        return list(self._tools.keys())

    def get_schemas(self) -> List[Dict[str, Any]]:
        """Return schema definitions for all registered tools."""
        return [tool.to_schema() for tool in self._tools.values()]

    def execute(self, tool_name: str, arguments: Dict[str, Any]) -> ToolResult:
        """Safely dispatch tool execution by name."""
        tool = self.get(tool_name)
        if tool is None:
            return ToolResult(
                success=False,
                error=f"Tool '{tool_name}' not found in registry.",
            )
        try:
            return tool.execute(**arguments)
        except Exception as e:
            return ToolResult(
                success=False,
                error=f"Tool execution exception: {str(e)}",
            )

    def dispatch(self, tool_name: str, arguments: Dict[str, Any]) -> ToolResult:
        """Conforms to AGI_SPEC.md interface."""
        return self.execute(tool_name=tool_name, arguments=arguments)

