"""
Reasoning Subsystem for Nirmal-1:
- ReasoningStep, ReasoningTrace, VerificationResult: Formal representation of step-by-step thought trajectories.
- ReasoningEngine: Trace orchestration, step parsing, and self-consistency / verification checks.
"""

from dataclasses import dataclass, field
from enum import Enum
import re
from typing import Any, Dict, List, Optional
import torch


class StepType(str, Enum):
    PREMISE = "premise"
    DEDUCTION = "deduction"
    TOOL_CALL = "tool_call"
    OBSERVATION = "observation"
    VERIFICATION = "verification"
    CONCLUSION = "conclusion"


@dataclass
class ReasoningStep:
    """Individual step in an agent's reasoning trajectory."""
    index: int
    step_type: StepType
    content: str
    confidence: float = 1.0
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class VerificationResult:
    """Result of validating an individual reasoning step or trace."""
    is_valid: bool
    score: float = 1.0
    message: str = ""


@dataclass
class ReasoningTrace:
    """Complete structured reasoning chain."""
    goal: str
    steps: List[ReasoningStep] = field(default_factory=list)
    is_verified: bool = False
    verdict: Optional[str] = None

    def add_step(self, step_type: StepType, content: str, confidence: float = 1.0) -> ReasoningStep:
        step = ReasoningStep(
            index=len(self.steps),
            step_type=step_type,
            content=content,
            confidence=confidence,
        )
        self.steps.append(step)
        return step

    def format_trace(self) -> str:
        """Format the trace as readable multi-line markdown."""
        lines = [f"### Reasoning Trace for: {self.goal}"]
        for step in self.steps:
            lines.append(f"Step {step.index + 1} [{step.step_type.value.upper()}]: {step.content}")
        if self.verdict:
            lines.append(f"Verdict: {self.verdict} (Verified: {self.is_verified})")
        return "\n".join(lines)


class ReasoningEngine:
    """Orchestrates structured reasoning, parsing of thinking tokens, and consistency verification."""

    @staticmethod
    def parse_thinking_block(raw_text: str) -> Dict[str, str]:
        """Extract thinking scratchpad content and final answer if delimited by tags."""
        match = re.search(r"<think>(.*?)</think>(.*)", raw_text, re.DOTALL)
        if match:
            return {
                "thinking": match.group(1).strip(),
                "response": match.group(2).strip(),
            }
        return {"thinking": "", "response": raw_text.strip()}

    @staticmethod
    def verify_step(step: ReasoningStep) -> VerificationResult:
        """Verifies validity and non-emptiness of an individual reasoning step."""
        if not step.content.strip():
            return VerificationResult(is_valid=False, score=0.0, message="Step content is empty.")
        if step.confidence < 0.0 or step.confidence > 1.0:
            return VerificationResult(is_valid=False, score=0.0, message="Confidence must be in [0, 1].")
        return VerificationResult(is_valid=True, score=step.confidence, message="Step verified.")

    @staticmethod
    def verify_consistency(trace: ReasoningTrace) -> bool:
        """Heuristic check for reasoning consistency and terminal conclusion."""
        if not trace.steps:
            trace.is_verified = False
            trace.verdict = "Empty reasoning trace."
            return False

        has_conclusion = any(s.step_type == StepType.CONCLUSION for s in trace.steps)
        if not has_conclusion:
            trace.is_verified = False
            trace.verdict = "Trace missing terminal conclusion."
            return False

        # Validate each individual step
        for step in trace.steps:
            res = ReasoningEngine.verify_step(step)
            if not res.is_valid:
                trace.is_verified = False
                trace.verdict = f"Step {step.index + 1} invalid: {res.message}"
                return False

        trace.is_verified = True
        trace.verdict = "Trace structurally valid."
        return True

    @staticmethod
    def generate_trace(goal: str, raw_model_output: Optional[str] = None) -> ReasoningTrace:
        """Constructs a ReasoningTrace from raw thought strings or model outputs."""
        trace = ReasoningTrace(goal=goal)
        trace.add_step(StepType.PREMISE, f"Goal: {goal}")

        if raw_model_output is not None:
            parsed = ReasoningEngine.parse_thinking_block(raw_model_output)
            if parsed["thinking"]:
                for line in parsed["thinking"].split("\n"):
                    line = line.strip()
                    if line:
                        trace.add_step(StepType.DEDUCTION, line)
            if parsed["response"]:
                trace.add_step(StepType.CONCLUSION, parsed["response"])
        else:
            trace.add_step(StepType.CONCLUSION, "Pending evaluation.")

        ReasonEngine = ReasoningEngine.verify_consistency(trace)
        return trace
