# V10.10 Associative Binding Artifacts
## V10.10-SPEC-AMENDMENT-01 Approved Implementation

Research-only artifacts. Production remains **STRICT NO-GO**.

### Active Specification & Artifacts (Amendment 01)
- `amendment_01_study_plan.json` — frozen scientific plan under Amendment 01.
- `amendment_01_experiment_matrix.json` — bounded registered campaign matrix under Amendment 01.
- `amendment_01_manifest.json` — amendment manifest tracking implementation-validation benchmark and superseded artifacts.
- `benchmark_amendment_01/benchmark_manifest.json` — immutable implementation-validation benchmark manifest.
- `protected_scope_initial.json` / `protected_scope_final.json` — protected-path status snapshots (clean, zero diffs).
- `legacy/continuity.json` — V10.9 F8 continuity replay (`CONTINUITY_PASS`).

### Superseded Pre-Amendment Artifacts (Preserved for Historical Provenance)
- `study_plan.json` — superseded by `amendment_01_study_plan.json`.
- `experiment_matrix.json` — superseded by `amendment_01_experiment_matrix.json`.
- `benchmark/benchmark_manifest.json` — superseded historical benchmark manifest.
- `benchmark/b2_validation_seed{42,43,44}.jsonl` — legacy benchmark files (seed 42 excluded from amended primary campaign).

### Safe Inspection Commands
```bash
python scripts/v10_10_run_study.py --phase plan
python scripts/v10_10_run_study.py --phase legacy --execute
pytest tests/test_v10_10_*.py
pytest tests/test_v10_9_*.py
```

### Execution Boundary
Phases A–F are strictly **BLOCKED** and not run. Any attempted scientific model training fails closed.
Candidate C: 0 updates, 0 instantiations.
Corpus count: 233,997 tokens.
Production: STRICT NO-GO (0/6 external approvals).
