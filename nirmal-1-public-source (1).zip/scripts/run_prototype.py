"""
End-to-End Nirmal-1 Prototype Verification Script.

Demonstrates:
1. Prototype model initialization with exact target hyperparameters.
2. Forward pass, loss computation, and backpropagation.
3. Autoregressive generation using NirmalGenerator with hybrid caching.
4. Cognitive AGI subsystem operations (Memory, Reasoning, Planning, Tools).
5. Checkpointing save and restore cycle.
"""

from pathlib import Path
import sys
import tempfile
import torch

# Ensure src and root are in pythonpath
root_dir = Path(__file__).parent.parent
sys.path.insert(0, str(root_dir / "src"))
sys.path.insert(0, str(root_dir))

from nirmal.configuration_nirmal import NirmalConfig
from nirmal.model import NirmalForCausalLM
from nirmal.generation import NirmalGenerator
from nirmal.memory import WorkingMemory, InMemoryVectorStore, MemoryRecord, RetrievalEngine
from nirmal.reasoning import ReasoningEngine, StepType, ReasoningTrace
from nirmal.planning import Planner, PlanStatus
from nirmal.tools import ToolRegistry
from training.checkpoint import CheckpointManager


def main() -> None:
    print("=" * 70)
    print("        NIRMAL-1 AGI RESEARCH PROTOTYPE DEMONSTRATION")
    print("=" * 70)

    # -------------------------------------------------------------
    # 1. Model Initialization
    # -------------------------------------------------------------
    print("\n[1] Initializing Nirmal-1 Core Neural Model with Target Specs...")
    config = NirmalConfig(
        vocab_size=32000,
        hidden_size=512,
        num_hidden_layers=12,
        num_attention_heads=8,
        num_key_value_heads=2,
        head_dim=64,
        context_length=8192,
        num_experts=8,
        num_experts_per_tok=2,
        full_attention_interval=4,
    )
    model = NirmalForCausalLM(config)
    param_counts = model.count_parameters()

    print(f"  - Hidden Size: {config.hidden_size}")
    print(f"  - Layers: {config.num_hidden_layers}")
    print(f"  - Attention Heads: {config.num_attention_heads} Query / {config.num_key_value_heads} KV (GQA)")
    print(f"  - Head Dimension: {config.head_dim}")
    print(f"  - Experts: {config.num_experts} total, Top-{config.num_experts_per_tok} active per token")
    print(f"  - Total Parameters: {param_counts['total']:,}")
    print(f"  - Layer Breakdown: {config.layer_types[:4]} ... (repeating pattern)")

    # -------------------------------------------------------------
    # 2. Forward & Backward Pass Verification
    # -------------------------------------------------------------
    print("\n[2] Executing Forward Pass and Backpropagation...")
    batch_size = 2
    seq_len = 16
    input_ids = torch.randint(0, config.vocab_size, (batch_size, seq_len))
    labels = input_ids.clone()

    outputs = model(input_ids=input_ids, labels=labels)
    total_loss = outputs.loss
    router_loss = outputs.router_loss

    print(f"  - Logits Shape: {outputs.logits.shape}")
    print(f"  - Total Loss: {total_loss.item():.4f}")
    print(f"  - Router Aux Loss: {router_loss.item():.5f}")

    total_loss.backward()
    grad_norm = sum(p.grad.norm().item() for p in model.parameters() if p.grad is not None)
    print(f"  - Backward Pass Successful. Total Gradient L1 Norm: {grad_norm:.4f}")

    # -------------------------------------------------------------
    # 3. Autoregressive Generation with Hybrid State Cache
    # -------------------------------------------------------------
    print("\n[3] Testing Autoregressive Token Generation...")
    generator = NirmalGenerator(model)
    prompt = torch.tensor([[101, 2045, 3120, 102]])
    generated_tokens = generator.generate(
        input_ids=prompt,
        max_new_tokens=8,
        temperature=0.7,
        top_k=40,
        top_p=0.9,
        use_cache=True,
    )
    print(f"  - Prompt Length: {prompt.shape[-1]} tokens")
    print(f"  - Generated Sequence Length: {generated_tokens.shape[-1]} tokens")
    print(f"  - Generated IDs: {generated_tokens[0].tolist()}")

    # -------------------------------------------------------------
    # 4. Cognitive AGI Subsystems Demonstration
    # -------------------------------------------------------------
    print("\n[4] Demonstrating Cognitive Subsystems...")

    # A. Memory
    working_memory = WorkingMemory(max_token_budget=1024)
    working_memory.set_goal("Investigate mathematical properties of delta recurrence.")
    working_memory.add_scratchpad_note("Delta rule ensures bounded associative updates.")

    vector_store = InMemoryVectorStore()
    embedding = torch.randn(64)
    vector_store.store("delta_paper", MemoryRecord(key="delta_paper", content="DeltaNet balances linear memory with associative recall.", embedding=embedding))
    retrieval = RetrievalEngine(vector_store)
    recalled = retrieval.retrieve_context(embedding, top_k=1)
    print(f"  - Working Memory Context Generated:\n{working_memory.get_working_context_prompt()[:120]}...")
    print(f"  - Memory Recalled: '{recalled}'")

    # B. Reasoning
    trace = ReasoningTrace(goal="Calculate 25 * 4 + 10")
    trace.add_step(StepType.PREMISE, "Target calculation: 25 * 4 + 10")
    trace.add_step(StepType.DEDUCTION, "25 * 4 = 100")
    trace.add_step(StepType.CONCLUSION, "100 + 10 = 110")
    ReasoningEngine.verify_consistency(trace)
    print(f"  - Reasoning Trace Verified: {trace.is_verified} (Verdict: {trace.verdict})")

    # C. Planning
    planner = Planner()
    plan_steps = [
        {"id": "step_1", "description": "Retrieve equation constants", "tool_name": "search"},
        {"id": "step_2", "description": "Compute expression", "tool_name": "calculator", "dependencies": ["step_1"]},
    ]
    graph = planner.create_linear_plan(goal="Solve equation", steps=plan_steps)
    ready = graph.get_ready_nodes()
    print(f"  - Plan DAG Initialized. Immediate ready step: {ready[0].node_id} ({ready[0].description})")
    graph.mark_completed("step_1", output={"const": 42})
    next_ready = graph.get_ready_nodes()
    print(f"  - Dependency Resolved. Next ready step: {next_ready[0].node_id} ({next_ready[0].description})")

    # D. Tools
    registry = ToolRegistry()
    res = registry.execute("calculator", {"expression": "25 * 4 + 10"})
    print(f"  - Calculator Tool Execution: 25 * 4 + 10 = {res.output} (Success: {res.success})")

    # -------------------------------------------------------------
    # 5. Checkpointing Save & Restore
    # -------------------------------------------------------------
    print("\n[5] Testing Checkpointing Save & Restore...")
    with tempfile.TemporaryDirectory() as tmpdir:
        ckpt_mgr = CheckpointManager(save_dir=tmpdir, max_to_keep=2)
        saved_dir = ckpt_mgr.save(model=model, step=1, loss=total_loss.item())
        print(f"  - Checkpoint saved to: {saved_dir.name}")

        new_model = NirmalForCausalLM(config)
        meta = ckpt_mgr.load(saved_dir, new_model)
        print(f"  - Checkpoint restored. Meta: step={meta.get('step')}, loss={meta.get('loss'):.4f}")

    print("\n" + "=" * 70)
    print("  ALL PROTOTYPE COMPONENTS VERIFIED SUCCESSFULLY!")
    print("=" * 70)


if __name__ == "__main__":
    main()
