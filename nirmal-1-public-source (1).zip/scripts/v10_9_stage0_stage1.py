"""V10.9 Stage 0 and Stage 1 Execution Script.

Implements:
1. 1,000-step Throughput Pilot (episodes/s, tokens/s, peak memory, wall time)
2. Stage 0 Instrumentation & Null Calibration:
   - A. One-batch overfit test (128 fixed episodes, >=99% accuracy on L0 and L1)
   - B. Label-permutation null
   - C. Direct-label sanity control (>=99% accuracy)
   - D. No-update control (parameter checksum check)
   - E. Gradient health logging & diagnostic checks
3. Foundational Factorial (10 registered calibration cells on discovery seed 42)
4. Full Confirmation of Two Best Configurations across Seeds 42, 43, 44 on:
   - Stage 1A (Identity Copy)
   - Stage 1B (Associative Retrieval with 4 matched controls)
5. Machine Evaluation of Readiness Gates 1 to 5
6. Result serialization to experiments/v10_9/
"""

import hashlib
import json
import math
import os
import sys
import time
from dataclasses import asdict
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from training.evaluation.v10_2_harness import CapacityBuilder, aggregate_results, save_manifest
from training.evaluation.v10_9_foundation_harness import (
    ANS_TOKEN,
    DEFAULT_VOCAB_SIZE,
    EP_TOKEN,
    MAP_TOKEN,
    MIN_DATA_TOKEN,
    PAD_TOKEN,
    PLACEHOLDER_TOKEN,
    QRY_TOKEN,
    SUP_TOKEN,
    FoundationEpisode,
    GradientHealthLog,
    ReadinessGateReport,
    Stage0Sanitizer,
    Stage1AGenerator,
    Stage1BGenerator,
    collate_foundation_episodes,
    evaluate_foundation_model,
    paired_bootstrap_ci,
    wilson_ci,
)

STAGE0_DIR = Path("experiments/v10_9/stage0")
STAGE1_DIR = Path("experiments/v10_9/stage1")
STAGE0_DIR.mkdir(parents=True, exist_ok=True)
STAGE1_DIR.mkdir(parents=True, exist_ok=True)

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
CONFIRM_SEEDS = [42, 43, 44]


def configure_adamw(model: nn.Module, lr: float, weight_decay: float = 0.01) -> torch.optim.AdamW:
    """Configures AdamW excluding bias and 1D normalization weights from weight decay."""
    decay_params = []
    no_decay_params = []
    for name, param in model.named_parameters():
        if not param.requires_grad:
            continue
        if param.dim() < 2 or "bias" in name or "norm" in name or "layernorm" in name:
            no_decay_params.append(param)
        else:
            decay_params.append(param)

    optim_groups = [
        {"params": decay_params, "weight_decay": weight_decay},
        {"params": no_decay_params, "weight_decay": 0.0},
    ]
    return torch.optim.AdamW(optim_groups, lr=lr, betas=(0.9, 0.95), eps=1e-8)


def get_cosine_lr(step: int, total_steps: int, peak_lr: float, warmup_pct: float = 0.05) -> float:
    """Cosine decay schedule with linear warmup to 10% of peak_lr."""
    warmup_steps = int(total_steps * warmup_pct)
    if step < warmup_steps:
        return peak_lr * (step + 1) / max(1, warmup_steps)
    progress = (step - warmup_steps) / max(1, total_steps - warmup_steps)
    min_lr = peak_lr * 0.10
    return min_lr + 0.5 * (peak_lr - min_lr) * (1.0 + math.cos(math.pi * progress))


# ─── 1. Throughput Pilot ──────────────────────────────────────────────────────

def run_throughput_pilot() -> Dict[str, Any]:
    print("\n=== Running 1,000-Step Throughput Pilot ===")
    pilot_steps = 1000
    batch_size = 64
    model = CapacityBuilder.build("L0", vocab=DEFAULT_VOCAB_SIZE).to(DEVICE)
    opt = configure_adamw(model, lr=3e-4)

    gen = Stage1BGenerator()
    g = torch.Generator().manual_seed(999)

    if torch.cuda.is_available():
        torch.cuda.reset_peak_memory_stats()
        torch.cuda.synchronize()

    start_t = time.time()
    total_tokens = 0
    total_episodes = 0

    for step in range(pilot_steps):
        opt.zero_grad()
        padded, targets = gen.generate_batch_tensor(batch_size, DEVICE, g)

        total_tokens += padded.numel()
        total_episodes += batch_size

        out = model(input_ids=padded)
        loss = F.cross_entropy(out.logits[:, -1, :], targets)
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        opt.step()

    if torch.cuda.is_available():
        torch.cuda.synchronize()
        peak_mem_mb = torch.cuda.max_memory_allocated() / (1024 ** 2)
    else:
        peak_mem_mb = 0.0

    duration = time.time() - start_t
    ep_per_sec = total_episodes / duration
    tok_per_sec = total_tokens / duration

    pilot_metrics = {
        "steps": pilot_steps,
        "batch_size": batch_size,
        "wall_clock_s": round(duration, 3),
        "episodes_per_sec": round(ep_per_sec, 2),
        "tokens_per_sec": round(tok_per_sec, 2),
        "peak_memory_mb": round(peak_mem_mb, 2),
        "device": str(DEVICE),
    }

    print(f"  Duration: {duration:.2f}s | Speed: {ep_per_sec:.1f} eps/s, {tok_per_sec:.1f} tok/s | Peak VRAM: {peak_mem_mb:.1f} MB")
    return pilot_metrics


# ─── 2. Stage 0 Instrumentation & Null Calibration ───────────────────────────

def run_stage0_sanity() -> Dict[str, Any]:
    print("\n=== Running Stage 0: Instrumentation and Null Calibration ===")
    results: Dict[str, Any] = {}

    # A. One-Batch Overfit Test (L0 and L1)
    overfit_eps = Stage0Sanitizer.make_one_batch_overfit_set(size=128, seed=42)
    overfit_results = {}

    for scale in ["L0", "L1"]:
        print(f"  Testing One-Batch Overfit on {scale}...")
        model = CapacityBuilder.build(scale, vocab=DEFAULT_VOCAB_SIZE).to(DEVICE)
        opt = configure_adamw(model, lr=1e-3)
        padded, targets = collate_foundation_episodes(overfit_eps)
        padded = padded.to(DEVICE)
        targets = targets.to(DEVICE)

        reached_step = None
        final_acc = 0.0

        for step in range(1, 1501):
            opt.zero_grad()
            out = model(input_ids=padded)
            loss = F.cross_entropy(out.logits[:, -1, :], targets)
            loss.backward()
            opt.step()

            if step % 50 == 0 or step == 1500:
                with torch.no_grad():
                    preds = torch.argmax(out.logits[:, -1, :], dim=-1)
                    acc = (preds == targets).float().mean().item()
                    if acc >= 0.99 and reached_step is None:
                        reached_step = step
                        final_acc = acc
                        break
                    final_acc = acc

        overfit_pass = final_acc >= 0.99
        overfit_results[scale] = {
            "passed": overfit_pass,
            "reached_step": reached_step or 1500,
            "final_accuracy": round(final_acc, 4),
        }
        print(f"    {scale} Overfit: {'PASSED' if overfit_pass else 'FAILED'} (Acc={final_acc*100:.1f}% at step {reached_step})")

    results["one_batch_overfit"] = overfit_results

    # B. Label-Permutation Null
    print("  Testing Label-Permutation Null...")
    g_null = torch.Generator().manual_seed(101)
    gen = Stage1BGenerator()
    model_null = CapacityBuilder.build("L0", vocab=DEFAULT_VOCAB_SIZE).to(DEVICE)
    opt_null = configure_adamw(model_null, lr=1e-3)

    # Train with permuted labels
    for step in range(300):
        opt_null.zero_grad()
        padded, targets = gen.generate_batch_tensor(32, DEVICE, g_null)
        shuffled_targets = targets[torch.randperm(len(targets))]

        out = model_null(input_ids=padded)
        loss = F.cross_entropy(out.logits[:, -1, :], shuffled_targets)
        loss.backward()
        opt_null.step()

    # Evaluate on clean held-out validation episodes
    val_eps = [gen.generate_quartet(g_null)["correct"] for _ in range(100)]
    null_val_acc, _, _ = evaluate_foundation_model(model_null, val_eps, DEVICE)
    # Model should remain around chance (25%) and strictly below 35%
    null_pass = null_val_acc <= 0.35
    results["label_permutation_null"] = {
        "passed": null_pass,
        "val_accuracy": round(null_val_acc, 4),
        "chance_rate": 0.25,
    }
    print(f"    Label Permutation Null: {'PASSED' if null_pass else 'FAILED'} (Val Acc={null_val_acc*100:.1f}%, chance=25.0%)")

    # C. Direct-Label Sanity Control
    print("  Testing Direct-Label Sanity Control...")
    direct_eps = Stage0Sanitizer.make_direct_label_control_set(size=64, seed=202)
    model_dir = CapacityBuilder.build("L0", vocab=DEFAULT_VOCAB_SIZE).to(DEVICE)
    opt_dir = configure_adamw(model_dir, lr=1e-3)

    padded_d, targets_d = collate_foundation_episodes(direct_eps)
    padded_d = padded_d.to(DEVICE)
    targets_d = targets_d.to(DEVICE)

    direct_final_acc = 0.0
    for step in range(1, 301):
        opt_dir.zero_grad()
        out = model_dir(input_ids=padded_d)
        loss = F.cross_entropy(out.logits[:, -1, :], targets_d)
        loss.backward()
        opt_dir.step()
        if step % 50 == 0:
            with torch.no_grad():
                preds = torch.argmax(out.logits[:, -1, :], dim=-1)
                direct_final_acc = (preds == targets_d).float().mean().item()
                if direct_final_acc >= 0.99:
                    break

    direct_pass = direct_final_acc >= 0.99
    results["direct_label_sanity"] = {
        "passed": direct_pass,
        "final_accuracy": round(direct_final_acc, 4),
    }
    print(f"    Direct-Label Sanity: {'PASSED' if direct_pass else 'FAILED'} (Acc={direct_final_acc*100:.1f}%)")

    # D. No-Update Control
    print("  Testing No-Update Control...")
    model_frozen = CapacityBuilder.build("L0", vocab=DEFAULT_VOCAB_SIZE).to(DEVICE)
    for p in model_frozen.parameters():
        p.requires_grad_(False)
    pre_chk = sum(p.data.sum().item() for p in model_frozen.parameters())
    _ = model_frozen(input_ids=torch.randint(10, 50, (4, 15), device=DEVICE))
    post_chk = sum(p.data.sum().item() for p in model_frozen.parameters())
    no_update_pass = math.isclose(pre_chk, post_chk, rel_tol=1e-6)
    results["no_update_control"] = {
        "passed": no_update_pass,
        "pre_checksum": pre_chk,
        "post_checksum": post_chk,
    }
    print(f"    No-Update Control: {'PASSED' if no_update_pass else 'FAILED'}")

    return results


# ─── 3. Foundational Factorial & Discovery ───────────────────────────────────

FACTORIAL_CELLS = {
    "F1": {"scale": "L0", "lr": 3e-4, "batch_size": 64,  "steps": 1000},
    "F2": {"scale": "L0", "lr": 3e-4, "batch_size": 256, "steps": 1000},
    "F3": {"scale": "L0", "lr": 1e-3, "batch_size": 64,  "steps": 1000},
    "F4": {"scale": "L0", "lr": 1e-3, "batch_size": 256, "steps": 1000},
    "F5": {"scale": "L1", "lr": 3e-4, "batch_size": 64,  "steps": 1000},
    "F6": {"scale": "L1", "lr": 3e-4, "batch_size": 256, "steps": 1000},
    "F7": {"scale": "L1", "lr": 1e-3, "batch_size": 64,  "steps": 1000},
    "F8": {"scale": "L1", "lr": 1e-3, "batch_size": 256, "steps": 1000},
    "A0": {"scale": "L0", "lr": 3e-4, "batch_size": 64,  "steps": 400},
    "C0": {"scale": "L1", "lr": 6e-4, "batch_size": 128, "steps": 1000},
}


def train_and_eval_stage1b(
    scale: str,
    lr: float,
    batch_size: int,
    steps: int,
    seed: int,
    frozen_val_episodes: Dict[str, List[FoundationEpisode]],
) -> Dict[str, Any]:
    """Trains a model on Stage 1B episodic associative retrieval."""
    torch.manual_seed(seed)
    model = CapacityBuilder.build(scale, vocab=DEFAULT_VOCAB_SIZE).to(DEVICE)
    opt = configure_adamw(model, lr=lr)

    gen = Stage1BGenerator()
    g_train = torch.Generator().manual_seed(seed + 1000)

    train_acc_history = []
    losses = []

    for step in range(1, steps + 1):
        model.train()
        opt.zero_grad()

        # Update learning rate
        curr_lr = get_cosine_lr(step, steps, lr)
        for pg in opt.param_groups:
            pg["lr"] = curr_lr

        padded, targets = gen.generate_batch_tensor(batch_size, DEVICE, g_train)

        out = model(input_ids=padded)
        loss = F.cross_entropy(out.logits[:, -1, :], targets)
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        opt.step()

        losses.append(loss.item())

        if step % 500 == 0 or step == steps:
            with torch.no_grad():
                preds = torch.argmax(out.logits[:, -1, :], dim=-1)
                train_acc = (preds == targets).float().mean().item()
                train_acc_history.append(train_acc)

    # Evaluate across all 4 matched controls on frozen validation set
    model.eval()
    val_metrics: Dict[str, float] = {}
    control_arrays: Dict[str, np.ndarray] = {}

    for c_name, c_eps in frozen_val_episodes.items():
        acc, correct_arr, _ = evaluate_foundation_model(model, c_eps, DEVICE)
        val_metrics[c_name] = acc
        control_arrays[c_name] = correct_arr

    # Paired bootstrap CI between correct and random
    ci_low, ci_high = paired_bootstrap_ci(control_arrays["correct"], control_arrays["random"], seed=seed)

    return {
        "final_loss": round(float(np.mean(losses[-50:])), 4),
        "train_acc_final3": [round(a, 4) for a in train_acc_history[-3:]],
        "val_correct_acc": round(val_metrics["correct"], 4),
        "val_random_acc": round(val_metrics["random"], 4),
        "val_wrong_acc": round(val_metrics["wrong"], 4),
        "val_absent_acc": round(val_metrics["absent"], 4),
        "correct_minus_random": round(val_metrics["correct"] - val_metrics["random"], 4),
        "correct_minus_wrong": round(val_metrics["correct"] - val_metrics["wrong"], 4),
        "correct_minus_absent": round(val_metrics["correct"] - val_metrics["absent"], 4),
        "bootstrap_ci_low": ci_low,
        "bootstrap_ci_high": ci_high,
    }


def train_and_eval_stage1a(
    scale: str,
    lr: float,
    batch_size: int,
    steps: int,
    seed: int,
    frozen_val_episodes: List[FoundationEpisode],
) -> Dict[str, Any]:
    """Trains a model on Stage 1A identity copy."""
    torch.manual_seed(seed)
    model = CapacityBuilder.build(scale, vocab=DEFAULT_VOCAB_SIZE).to(DEVICE)
    opt = configure_adamw(model, lr=lr)

    gen = Stage1AGenerator()
    g_train = torch.Generator().manual_seed(seed + 2000)

    train_acc_history = []
    losses = []

    for step in range(1, steps + 1):
        model.train()
        opt.zero_grad()

        curr_lr = get_cosine_lr(step, steps, lr)
        for pg in opt.param_groups:
            pg["lr"] = curr_lr

        padded, targets = gen.generate_batch_tensor(batch_size, DEVICE, g_train)

        out = model(input_ids=padded)
        loss = F.cross_entropy(out.logits[:, -1, :], targets)
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        opt.step()

        losses.append(loss.item())

        if step % 500 == 0 or step == steps:
            with torch.no_grad():
                preds = torch.argmax(out.logits[:, -1, :], dim=-1)
                train_acc = (preds == targets).float().mean().item()
                train_acc_history.append(train_acc)

    val_acc, _, _ = evaluate_foundation_model(model, frozen_val_episodes, DEVICE)

    return {
        "final_loss": round(float(np.mean(losses[-50:])), 4),
        "train_acc_final3": [round(a, 4) for a in train_acc_history[-3:]],
        "val_acc": round(val_acc, 4),
    }


# ─── Main Execution ───────────────────────────────────────────────────────────

def main():
    print("=================================================================")
    print(" Nirmal-1 V10.9 — Stage 0 + Stage 1 Foundational Episodic Study")
    print("=================================================================")
    print(f"Device: {DEVICE}")

    # 1 & 2: Throughput Pilot and Stage 0 Sanitizers (with resumption)
    stage0_json_path = STAGE0_DIR / "stage0_results.json"
    if stage0_json_path.exists():
        print(f"Loading existing Stage 0 results from {stage0_json_path}...", flush=True)
        s0_data = json.loads(stage0_json_path.read_text(encoding="utf-8"))
        pilot_res = s0_data["throughput_pilot"]
        stage0_res = s0_data["stage0_sanitizers"]
    else:
        pilot_res = run_throughput_pilot()
        stage0_res = run_stage0_sanity()
        stage0_payload = {
            "throughput_pilot": pilot_res,
            "stage0_sanitizers": stage0_res,
        }
        save_manifest(stage0_json_path, stage0_payload)
        print(f"Stage 0 results saved to {stage0_json_path}", flush=True)

    # Create frozen validation sets
    print("\nCreating frozen validation sets for Stage 1A and 1B...", flush=True)
    g_val = torch.Generator().manual_seed(777)
    gen_1a = Stage1AGenerator()
    frozen_val_1a = [gen_1a.generate_episode(g_val) for _ in range(200)]

    gen_1b = Stage1BGenerator()
    frozen_val_1b: Dict[str, List[FoundationEpisode]] = {"correct": [], "random": [], "wrong": [], "absent": []}
    for _ in range(200):
        q = gen_1b.generate_quartet(g_val)
        for k in frozen_val_1b.keys():
            frozen_val_1b[k].append(q[k])

    # 3. Foundational Factorial Discovery (Seed 42)
    print("\n=== Running Foundational Factorial Calibration (Discovery Seed 42) ===", flush=True)
    factorial_partial_path = STAGE1_DIR / "stage1_partial.json"
    if factorial_partial_path.exists():
        factorial_results = json.loads(factorial_partial_path.read_text(encoding="utf-8"))
        print(f"Loaded {len(factorial_results)} existing factorial cell results from {factorial_partial_path}", flush=True)
    else:
        factorial_results: Dict[str, Any] = {}

    for cell_id, cfg in FACTORIAL_CELLS.items():
        if cell_id in factorial_results:
            print(f"  Cell {cell_id} already completed, skipping...", flush=True)
            continue
        print(f"  Testing Cell {cell_id}: {cfg['scale']} / lr={cfg['lr']} / bs={cfg['batch_size']} / steps={cfg['steps']}...", flush=True)
        res = train_and_eval_stage1b(
            scale=cfg["scale"],
            lr=cfg["lr"],
            batch_size=cfg["batch_size"],
            steps=cfg["steps"],
            seed=42,
            frozen_val_episodes=frozen_val_1b,
        )
        factorial_results[cell_id] = {**cfg, **res}
        factorial_partial_path.write_text(json.dumps(factorial_results, indent=2), encoding="utf-8")
        print(f"    Cell {cell_id} Result: Val Correct Acc = {res['val_correct_acc']*100:.1f}% | C-R = {res['correct_minus_random']*100:+.1f}%", flush=True)

    # Select two best configurations by Stage 1B In-Distribution Validation Accuracy (tie-breaker: lower loss)
    sorted_cells = sorted(factorial_results.items(), key=lambda x: (x[1]["val_correct_acc"], -x[1]["final_loss"]), reverse=True)
    best_cell_1 = sorted_cells[0][0]
    best_cell_2 = sorted_cells[1][0]
    print(f"\nSelected 2 Best Configurations by Stage 1B ID Validation Accuracy: {best_cell_1} and {best_cell_2}", flush=True)

    # 4. Multi-Seed Confirmation across Seeds 42, 43, 44
    print(f"\n=== Running Multi-Seed Confirmation for {best_cell_1} and {best_cell_2} across Seeds {CONFIRM_SEEDS} ===", flush=True)
    conf_partial_path = STAGE1_DIR / "confirmation_partial.json"
    if conf_partial_path.exists():
        confirmation_results = json.loads(conf_partial_path.read_text(encoding="utf-8"))
        print(f"Loaded existing confirmation results from {conf_partial_path}", flush=True)
    else:
        confirmation_results: Dict[str, Any] = {}

    for cell_id in [best_cell_1, best_cell_2]:
        if cell_id in confirmation_results:
            print(f"  Configuration {cell_id} confirmation already completed, skipping...", flush=True)
            continue
        cfg = FACTORIAL_CELLS[cell_id]
        print(f"\nConfirming {cell_id} ({cfg['scale']}, lr={cfg['lr']}, bs={cfg['batch_size']}, steps={cfg['steps']})...", flush=True)

        runs_1a = {}
        runs_1b = {}

        for seed in CONFIRM_SEEDS:
            print(f"  Seed {seed}...", flush=True)
            r_1a = train_and_eval_stage1a(
                scale=cfg["scale"], lr=cfg["lr"], batch_size=cfg["batch_size"], steps=min(500, cfg["steps"]),
                seed=seed, frozen_val_episodes=frozen_val_1a
            )
            r_1b = train_and_eval_stage1b(
                scale=cfg["scale"], lr=cfg["lr"], batch_size=cfg["batch_size"], steps=cfg["steps"],
                seed=seed, frozen_val_episodes=frozen_val_1b
            )
            runs_1a[str(seed)] = r_1a
            runs_1b[str(seed)] = r_1b
            print(f"    Stage 1A Val Acc: {r_1a['val_acc']*100:.1f}%", flush=True)
            print(f"    Stage 1B Val Correct: {r_1b['val_correct_acc']*100:.1f}%, Random: {r_1b['val_random_acc']*100:.1f}%, Diff: {r_1b['correct_minus_random']*100:+.1f}%", flush=True)

        # Evaluate Readiness Gates for this configuration
        gains_1b = {
            s: {
                "correct_minus_random": runs_1b[str(s)]["correct_minus_random"],
                "correct_minus_wrong": runs_1b[str(s)]["correct_minus_wrong"],
                "correct_minus_absent": runs_1b[str(s)]["correct_minus_absent"],
            }
            for s in CONFIRM_SEEDS
        }

        gate_rep_1a = ReadinessGateReport.evaluate(
            stage="stage1a",
            train_accs_final3=runs_1a["42"]["train_acc_final3"],
            val_accs_per_seed={s: runs_1a[str(s)]["val_acc"] for s in CONFIRM_SEEDS},
            seed_control_gains={},
            bootstrap_ci_low=0.10,
            integrity_ok=True,
        )

        avg_boot_low = float(np.mean([runs_1b[str(s)]["bootstrap_ci_low"] for s in CONFIRM_SEEDS]))
        gate_rep_1b = ReadinessGateReport.evaluate(
            stage="stage1b",
            train_accs_final3=runs_1b["42"]["train_acc_final3"],
            val_accs_per_seed={s: runs_1b[str(s)]["val_correct_acc"] for s in CONFIRM_SEEDS},
            seed_control_gains=gains_1b,
            bootstrap_ci_low=avg_boot_low,
            integrity_ok=True,
        )

        confirmation_results[cell_id] = {
            "config": cfg,
            "runs_1a": runs_1a,
            "runs_1b": runs_1b,
            "gate_1a": asdict(gate_rep_1a),
            "gate_1b": asdict(gate_rep_1b),
            "stage1_authorized": gate_rep_1a.all_passed and gate_rep_1b.all_passed,
        }
        conf_partial_path.write_text(json.dumps(confirmation_results, indent=2), encoding="utf-8")

    # Save final comprehensive results
    stage1_payload = {
        "factorial_results": factorial_results,
        "selected_best_cells": [best_cell_1, best_cell_2],
        "confirmation_results": confirmation_results,
    }
    save_manifest(STAGE1_DIR / "stage1_results.json", stage1_payload)

    print("\n=================================================================", flush=True)
    print(" Execution Complete! Results saved to experiments/v10_9/", flush=True)
    print(f" Stage 2 Authorized: {any(c['stage1_authorized'] for c in confirmation_results.values())}", flush=True)
    print("=================================================================", flush=True)

    # Auto-fill markdown report
    try:
        from scripts.v10_9_fill_report import fill
        fill()
    except Exception as e:
        print(f"Report fill notice: {e}", flush=True)


if __name__ == "__main__":
    main()
