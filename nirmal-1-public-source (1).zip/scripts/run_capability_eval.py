import torch
import torch.nn as nn
from typing import Dict, List, Any
import numpy as np
import random
from nirmal.configuration_nirmal import NirmalConfig
from nirmal.model import NirmalForCausalLM

def set_seed(seed: int):
    torch.manual_seed(seed)
    np.random.seed(seed)
    random.seed(seed)

class CapabilityEvaluator:
    def __init__(self, vocab_size=500):
        self.vocab_size = vocab_size
        self.config = NirmalConfig(
            vocab_size=self.vocab_size,
            hidden_size=64,
            num_hidden_layers=2,
            num_attention_heads=2,
            head_dim=32,
            num_key_value_heads=1,
            num_experts=2,
            num_experts_per_tok=1,
            full_attention_interval=2,
        )

    def generate_dummy_dataset(self, length: int) -> torch.Tensor:
        return torch.randint(0, self.vocab_size, (length,))

    def get_eval_suite(self) -> Dict[str, torch.Tensor]:
        # 10 task families
        tasks = [
            "abstract reasoning", "mathematical reasoning", "causal reasoning",
            "planning", "long-horizon planning", "programming",
            "compositional reasoning", "OOD transfer", "uncertainty handling",
            "structured prediction"
        ]
        suite = {}
        for idx, t in enumerate(tasks):
            # Deterministic per task
            set_seed(42 + idx)
            suite[t] = self.generate_dummy_dataset(50)
        return suite

    def train_and_eval(self, data_mixture: torch.Tensor, steps: int = 10, seed: int = 42) -> Dict[str, float]:
        set_seed(seed)
        model = NirmalForCausalLM(self.config)
        optimizer = torch.optim.Adam(model.parameters(), lr=1e-3)
        
        # Train
        model.train()
        batch_size = 4
        seq_len = 16
        
        for step in range(steps):
            if step * batch_size * seq_len + batch_size * seq_len > len(data_mixture):
                break
            
            batch_data = data_mixture[step*batch_size*seq_len:(step+1)*batch_size*seq_len].view(batch_size, seq_len)
            optimizer.zero_grad()
            outputs = model(input_ids=batch_data, labels=batch_data)
            loss = outputs.loss
            loss.backward()
            optimizer.step()
            
        # Eval
        model.eval()
        suite = self.get_eval_suite()
        results = {}
        with torch.no_grad():
            for task, task_data in suite.items():
                batch_data = task_data[:16].view(1, 16)
                outputs = model(input_ids=batch_data, labels=batch_data)
                # Compute accuracy (exact match next token)
                logits = outputs.logits
                preds = torch.argmax(logits, dim=-1)
                acc = (preds == batch_data).float().mean().item()
                results[task] = acc
                
        return results

def run_experiment():
    evaluator = CapabilityEvaluator()
    set_seed(100)
    baseline_data = evaluator.generate_dummy_dataset(1000)
    set_seed(200)
    balanced_data = evaluator.generate_dummy_dataset(1000)
    set_seed(300)
    curriculum_data = evaluator.generate_dummy_dataset(1000)
    
    conditions = {
        "BASELINE": baseline_data,
        "CAPABILITY_BALANCED": balanced_data,
        "CAPABILITY_CURRICULUM": curriculum_data
    }
    
    seeds = [1, 2, 3]
    all_results = {}
    
    for condition_name, data in conditions.items():
        print(f"Running {condition_name}...")
        cond_res = {}
        for s in seeds:
            res = evaluator.train_and_eval(data, steps=10, seed=s)
            for k, v in res.items():
                if k not in cond_res:
                    cond_res[k] = []
                cond_res[k].append(v)
        
        # Avg
        avg_res = {k: np.mean(v) for k, v in cond_res.items()}
        all_results[condition_name] = avg_res
        
    return all_results

if __name__ == "__main__":
    res = run_experiment()
    for k, v in res.items():
        print(f"\nCondition: {k}")
        for task, acc in v.items():
            print(f"  {task}: {acc:.4f}")
