import json
from pathlib import Path
import time

OUT = Path("experiments/v10_4")
REPORT = Path("docs/V10_4_INDUCTIVE_BIAS_REUSABLE_ALGORITHM_STUDY.md")

def wait_for_results():
    while True:
        files = list(OUT.glob("v10_4_results_*.json"))
        if files:
            files.sort()
            return json.loads(files[-1].read_text())
        print("Waiting for results...")
        time.sleep(5)

def format_acc(res):
    if res is None: return "N/A"
    return f"{res['mean']*100:.2f}% ± {res['ci95']*100:.2f}%"

def fill_report():
    data = wait_for_results()
    text = REPORT.read_text()
    
    interventions = [
        ("E_A_baseline", "E_A"),
        ("E_B_continuous", "E_B"),
        ("E_C_binding", "E_C"),
        ("E_D_recurrent", "E_D"),
        ("E_E_latent", "E_E")
    ]
    
    for key, prefix in interventions:
        if key in data:
            text = text.replace(f"{{{prefix}_train}}", format_acc(data[key].get("train")))
            text = text.replace(f"{{{prefix}_val}}", format_acc(data[key].get("val")))
            text = text.replace(f"{{{prefix}_ood}}", format_acc(data[key].get("ood")))
            iso_pct = data[key].get('iso_pct', 0.0) * 100
            text = text.replace(f"{{{prefix}_iso}}", f"{iso_pct:.1f}%")
            
    # Calculate primary failure
    e_a_ood = data.get("E_A_baseline", {}).get("ood", {}).get("mean", 0.0)
    best_ood = max([data.get(k[0], {}).get("ood", {}).get("mean", 0.0) for k in interventions])
    
    if best_ood >= 0.8:
        cls = "ROBUST_ALGORITHMIC_INVARIANCE"
        rec = "Inductive bias successfully induced generalization. Advance to production-scale evaluation."
    elif best_ood > e_a_ood + 0.1:
        cls = "GENERALIZATION_SIGNAL"
        rec = "Signal detected. Requires hyperparameter sweeps and scale validation."
    else:
        cls = "NO_SIGNAL"
        rec = "Inductive bias modifications failed to induce representation abstraction."
        
    text = text.replace("[PENDING CLASSIFICATION]", f"**{cls}**\n\nThe most effective intervention peaked at {best_ood*100:.2f}% OOD accuracy.")
    text = text.replace("[PENDING]", f"**Recommendation:** {rec}")
    
    REPORT.write_text(text)
    print("Report populated successfully.")

if __name__ == "__main__":
    fill_report()
