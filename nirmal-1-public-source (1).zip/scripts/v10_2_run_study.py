"""
V10.2 Capacity-Scale Systematic Generalization Study.
Executes Phase 2-6 using the v10.2_harness.
"""
import json
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import torch
import numpy as np
from training.evaluation.v10_2_harness import (
    TaskConfig, TaskGenerator, CapacityBuilder, apply_repr,
    acc, aggregate_results, save_manifest, ResourceGuard
)

torch.set_num_threads(8)

OUT = Path("experiments/v10_2")
OUT.mkdir(parents=True, exist_ok=True)

SEEDS = [42, 43, 44]
LEVELS = ["L0", "L1", "L2"]
REPR_MODES = ["identity", "value_relative"]
STEPS = 50

# ------------------------------------------------------------------
# Phase 4: OOD Taxonomy configurations
# ------------------------------------------------------------------
TAXONOMY = {
    "A_SAME_VOCAB":        TaskConfig("increment", 3, (10, 30), (10, 30), (10, 30), 8, 100),
    "B_SURFACE_FORM":      TaskConfig("double_step",3, (10, 30), (10, 30), (10, 30), 8, 100),
    "C_PARTIAL_DISJOINT":  TaskConfig("increment", 3, (10, 30), (10, 30), (20, 40), 8, 100),
    "D_FULLY_DISJOINT":    TaskConfig("increment", 3, (10, 30), (10, 30), (60, 80), 8, 100),
    "E_LONGER_CONTEXT":    TaskConfig("increment", 5, (10, 30), (10, 30), (10, 30), 8, 100),
    "F_POSITIONAL_SHIFT":  TaskConfig("increment", 3, (10, 30), (10, 30), (10, 30), 8, 100), # we'll reverse the tensor
    "G_ISOMORPHIC_RULE":   TaskConfig("increment", 3, (10, 30), (10, 30), (80, 100), 8, 100), # different disjoint
    "H_COMPOSITIONAL":     TaskConfig("copy",      4, (10, 30), (10, 30), (10, 30), 8, 100),
}


def run_experiment(level: str, repr_mode: str, seed: int, taxonomy_key: str) -> dict:
    torch.manual_seed(seed)
    np.random.seed(seed)
    
    cfg = TAXONOMY[taxonomy_key]
    gen = TaskGenerator()
    splits = gen.generate(cfg)
    
    # Immutable Hashes
    train_hash = gen.hash_dataset(splits["train"])
    ood_hash   = gen.hash_dataset(splits["ood"])

    lo = cfg.train_vocab[0]
    olo = cfg.ood_vocab[0]

    # For compositional/surface-form, we just train on increment and test on the target to see if it transfers?
    # No, taxonomy means we train on the train_split of THAT config and test on OOD split.
    # Actually, Phase 4 asks to evaluate OOD taxonomy. We will train on the train_split.
    
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    
    train_x = apply_repr(splits["train"], repr_mode, lo).clamp(0, 99).to(device)
    val_x   = apply_repr(splits["val"],   repr_mode, lo).clamp(0, 99).to(device)
    
    if taxonomy_key == "F_POSITIONAL_SHIFT":
        ood_x = apply_repr(apply_repr(splits["ood"], "reversed"), repr_mode, olo).clamp(0, 99).to(device)
    else:
        ood_x = apply_repr(splits["ood"], repr_mode, olo).clamp(0, 99).to(device)

    model = CapacityBuilder.build(level).to(device)
    opt = torch.optim.AdamW(model.parameters(), lr=5e-3)
    
    for _ in range(STEPS):
        model.train()
        opt.zero_grad()
        loss = model(input_ids=train_x, labels=train_x).loss
        loss.backward()
        opt.step()

    t_a = acc(model, train_x)
    v_a = acc(model, val_x)
    o_a = acc(model, ood_x)
    
    # Classify failure
    failure_class = "NONE"
    if t_a < 0.5:
        failure_class = "TRAINING_SIGNAL"
    elif o_a < 0.1:
        if v_a >= 0.8:
            failure_class = "REPRESENTATION"
        else:
            failure_class = "CAPACITY"

    return {
        "level": level,
        "repr_mode": repr_mode,
        "seed": seed,
        "taxonomy": taxonomy_key,
        "train_acc": t_a,
        "val_acc": v_a,
        "ood_acc": o_a,
        "ood_gap": v_a - o_a,
        "failure_class": failure_class,
        "params": CapacityBuilder.count_params(model),
        "train_hash": train_hash,
        "ood_hash": ood_hash
    }


def main():
    print("=== V10.2 Phase 2-6 ===")
    results = []
    
    # To save time and because L4 is 5M params, we will only run full taxonomy on L0 and L4
    # But for Phase 5 (Representation Discovery), we run FULL_DISJOINT across ALL levels.
    
    for level in LEVELS:
        if not ResourceGuard.check(500, 30):
            print(f"Skipping {level} due to resources.")
            continue
            
        for repr_mode in REPR_MODES:
            # Phase 5: Representation Discovery Test (FULL_DISJOINT) across ALL levels
            tax_key = "D_FULLY_DISJOINT"
            for seed in SEEDS:
                print(f"Running Phase 5: {level} | {repr_mode} | {tax_key} | seed={seed}...", flush=True)
                res = run_experiment(level, repr_mode, seed, tax_key)
                results.append(res)
                
            if level == "L2":
                for tax_key in TAXONOMY.keys():
                    if tax_key == "D_FULLY_DISJOINT": continue # already done
                    for seed in SEEDS:
                        print(f"Running Phase 4: {level} | {repr_mode} | {tax_key} | seed={seed}...", flush=True)
                        res = run_experiment(level, repr_mode, seed, tax_key)
                        results.append(res)

    # Aggregate results
    aggregated = {}
    for r in results:
        key = f"{r['level']}_{r['repr_mode']}_{r['taxonomy']}"
        if key not in aggregated:
            aggregated[key] = {"train": [], "val": [], "ood": [], "gap": [], "params": r["params"], "failure": r["failure_class"]}
        aggregated[key]["train"].append(r["train_acc"])
        aggregated[key]["val"].append(r["val_acc"])
        aggregated[key]["ood"].append(r["ood_acc"])
        aggregated[key]["gap"].append(r["ood_gap"])

    final_report = {}
    for key, data in aggregated.items():
        final_report[key] = {
            "params": data["params"],
            "train": aggregate_results(data["train"]),
            "val": aggregate_results(data["val"]),
            "ood": aggregate_results(data["ood"]),
            "gap": aggregate_results(data["gap"]),
            "primary_failure": data["failure"]
        }
    
    ts = int(time.time())
    save_manifest(OUT / f"v10_2_results_{ts}.json", final_report)
    print("Done! Results saved.")

if __name__ == "__main__":
    main()
