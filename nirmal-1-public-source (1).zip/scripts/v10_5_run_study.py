"""V10.5 Few-Shot Rule Induction Study Runner."""

import json
import sys
import time
from pathlib import Path
from typing import Any, Dict, List

import numpy as np
import torch
import torch.nn.functional as F

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from training.evaluation.v10_2_harness import (
    CapacityBuilder,
    aggregate_results,
    save_manifest,
)
from training.evaluation.v10_5_harness import (
    ALL_RULES,
    DISJOINT_OOD_VOCAB,
    HELD_OUT_RULES,
    FewShotRuleFamily,
    FewShotTaskGenerator,
    TRAIN_RULES,
    TRAIN_VOCAB,
    VAL_VOCAB,
    evaluate_few_shot_acc,
)

OUT = Path("experiments/v10_5")
OUT.mkdir(parents=True, exist_ok=True)

STEPS = 250
SEEDS = [42, 43, 44]
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
VOCAB_SIZE = 250
CAPACITY = "L0"
DEMO_COUNTS = [0, 1, 2, 4, 8]


def train_few_shot_model(seed: int, gen: FewShotTaskGenerator) -> Any:
    """Trains L0 model on multi-rule demonstrations within TRAIN_VOCAB."""
    torch.manual_seed(seed)
    model = CapacityBuilder.build(CAPACITY, vocab=VOCAB_SIZE).to(DEVICE)
    opt = torch.optim.AdamW(model.parameters(), lr=5e-3)

    for step in range(STEPS):
        model.train()
        opt.zero_grad()

        # Alternate rules and demo counts during training
        rule = TRAIN_RULES[step % len(TRAIN_RULES)]
        k = [0, 1, 2, 4][(step // len(TRAIN_RULES)) % 4]

        batch = gen.build_batch(
            rule=rule,
            vocab_range=TRAIN_VOCAB,
            num_demos=k,
            batch_size=16,
            seed=seed + step,
        )
        input_ids = batch["input_ids"].to(DEVICE)

        out = model(input_ids=input_ids, labels=input_ids)
        loss = out.loss
        loss.backward()
        opt.step()

    return model


def run_seed_evaluations(seed: int) -> Dict[str, Any]:
    print(f"--- Running Seed {seed} ---")
    gen = FewShotTaskGenerator(vocab_size=VOCAB_SIZE)
    model = train_few_shot_model(seed, gen)

    # Reference training batch for leakage verification
    ref_train = gen.build_batch("increment", TRAIN_VOCAB, num_demos=4, batch_size=32, seed=seed)

    # Experiment A & G: Demonstration Count Curve across Train Rules
    demo_curve_val: Dict[int, float] = {}
    demo_curve_disjoint: Dict[int, float] = {}

    for k in DEMO_COUNTS:
        val_accs = []
        disjoint_accs = []
        for r in TRAIN_RULES:
            b_val = gen.build_batch(r, VAL_VOCAB, num_demos=k, batch_size=32, seed=seed + 1000 + k)
            b_ood = gen.build_batch(r, DISJOINT_OOD_VOCAB, num_demos=k, batch_size=32, seed=seed + 2000 + k)

            # Leakage verify
            cert = gen.leakage_certificate(ref_train["input_ids"], b_ood["input_ids"])
            assert cert["valid"], f"Leakage failure for rule {r} k={k}"

            val_accs.append(evaluate_few_shot_acc(model, b_val, DEVICE))
            disjoint_accs.append(evaluate_few_shot_acc(model, b_ood, DEVICE))

        demo_curve_val[k] = float(np.mean(val_accs))
        demo_curve_disjoint[k] = float(np.mean(disjoint_accs))

    # Experiment C: Held-Out Rules
    held_out_results: Dict[str, Dict[str, float]] = {}
    for r in HELD_OUT_RULES:
        held_out_results[r] = {}
        for k in DEMO_COUNTS:
            b_val = gen.build_batch(r, VAL_VOCAB, num_demos=k, batch_size=32, seed=seed + 3000 + k)
            b_ood = gen.build_batch(r, DISJOINT_OOD_VOCAB, num_demos=k, batch_size=32, seed=seed + 4000 + k)
            held_out_results[r][f"val_k{k}"] = evaluate_few_shot_acc(model, b_val, DEVICE)
            held_out_results[r][f"disjoint_k{k}"] = evaluate_few_shot_acc(model, b_ood, DEVICE)

    # Experiment D: Demonstration Quality & Controls (at k=4 demos on increment)
    b_correct = gen.build_batch("increment", DISJOINT_OOD_VOCAB, num_demos=4, batch_size=32, seed=seed + 5000)
    b_random = gen.build_batch("increment", DISJOINT_OOD_VOCAB, num_demos=4, batch_size=32, seed=seed + 5001, random_demos=True)
    b_diff_rule = gen.build_batch("increment", DISJOINT_OOD_VOCAB, num_demos=4, batch_size=32, seed=seed + 5002, demo_rule="copy")
    b_distractor = gen.build_batch("increment", DISJOINT_OOD_VOCAB, num_demos=4, batch_size=32, seed=seed + 5003, distractor=True)
    b_1_clear = gen.build_batch("increment", DISJOINT_OOD_VOCAB, num_demos=1, batch_size=32, seed=seed + 5004)

    quality_results = {
        "ctrl_correct": evaluate_few_shot_acc(model, b_correct, DEVICE),
        "ctrl_random": evaluate_few_shot_acc(model, b_random, DEVICE),
        "ctrl_diff_rule": evaluate_few_shot_acc(model, b_diff_rule, DEVICE),
        "d1_clear_1demo": evaluate_few_shot_acc(model, b_1_clear, DEVICE),
        "d3_consistent_4demos": evaluate_few_shot_acc(model, b_correct, DEVICE),
        "d4_distractor_4demos": evaluate_few_shot_acc(model, b_distractor, DEVICE),
    }

    # Experiment E: Order Robustness (at k=4 demos on increment)
    b_orig = gen.build_batch("increment", DISJOINT_OOD_VOCAB, num_demos=4, batch_size=32, seed=seed + 6000, order="original")
    b_rev = gen.build_batch("increment", DISJOINT_OOD_VOCAB, num_demos=4, batch_size=32, seed=seed + 6000, order="reversed")
    b_perm = gen.build_batch("increment", DISJOINT_OOD_VOCAB, num_demos=4, batch_size=32, seed=seed + 6000, order="permuted")

    order_results = {
        "order_original": evaluate_few_shot_acc(model, b_orig, DEVICE),
        "order_reversed": evaluate_few_shot_acc(model, b_rev, DEVICE),
        "order_permuted": evaluate_few_shot_acc(model, b_perm, DEVICE),
    }

    # Experiment F: Surface Remapping across disjoint sub-blocks (k=4 demos)
    sub_blocks = [(130, 160), (160, 190), (190, 220)]
    remapping_accs = []
    for idx, sb in enumerate(sub_blocks):
        b_sb = gen.build_batch("increment", sb, num_demos=4, batch_size=32, seed=seed + 7000 + idx)
        remapping_accs.append(evaluate_few_shot_acc(model, b_sb, DEVICE))

    remapping_results = {
        "sub_block_1": remapping_accs[0],
        "sub_block_2": remapping_accs[1],
        "sub_block_3": remapping_accs[2],
        "mean_remapping": float(np.mean(remapping_accs)),
    }

    return {
        "seed": seed,
        "demo_curve_val": demo_curve_val,
        "demo_curve_disjoint": demo_curve_disjoint,
        "held_out_results": held_out_results,
        "quality_results": quality_results,
        "order_results": order_results,
        "remapping_results": remapping_results,
    }


def main():
    print("=== Nirmal-1 V10.5 Few-Shot Rule Induction Study ===")
    print(f"Device: {DEVICE}, Capacity: {CAPACITY}, Steps: {STEPS}, Seeds: {SEEDS}")

    all_seed_runs = []
    for seed in SEEDS:
        res = run_seed_evaluations(seed)
        all_seed_runs.append(res)

    # Multi-seed aggregation
    aggregated: Dict[str, Any] = {
        "metadata": {
            "capacity": CAPACITY,
            "steps": STEPS,
            "seeds": SEEDS,
            "vocab_size": VOCAB_SIZE,
            "train_rules": TRAIN_RULES,
            "held_out_rules": HELD_OUT_RULES,
            "device": str(DEVICE),
        },
        "exp_a_demo_counts": {},
        "exp_c_held_out": {},
        "exp_d_quality": {},
        "exp_e_order": {},
        "exp_f_remapping": {},
    }

    # Aggregate Demo Curve
    for k in DEMO_COUNTS:
        val_vals = [r["demo_curve_val"][k] for r in all_seed_runs]
        disjoint_vals = [r["demo_curve_disjoint"][k] for r in all_seed_runs]
        aggregated["exp_a_demo_counts"][f"k{k}"] = {
            "val": aggregate_results(val_vals),
            "disjoint_ood": aggregate_results(disjoint_vals),
        }
        print(
            f"k={k} demos -> Val: {aggregated['exp_a_demo_counts'][f'k{k}']['val']['mean']*100:.2f}%, "
            f"Disjoint OOD: {aggregated['exp_a_demo_counts'][f'k{k}']['disjoint_ood']['mean']*100:.2f}%"
        )

    # Aggregate Held Out Rules
    for hr in HELD_OUT_RULES:
        aggregated["exp_c_held_out"][hr] = {}
        for k in DEMO_COUNTS:
            val_vals = [r["held_out_results"][hr][f"val_k{k}"] for r in all_seed_runs]
            disjoint_vals = [r["held_out_results"][hr][f"disjoint_k{k}"] for r in all_seed_runs]
            aggregated["exp_c_held_out"][hr][f"k{k}"] = {
                "val": aggregate_results(val_vals),
                "disjoint_ood": aggregate_results(disjoint_vals),
            }

    # Aggregate Quality Controls
    for qk in all_seed_runs[0]["quality_results"].keys():
        vals = [r["quality_results"][qk] for r in all_seed_runs]
        aggregated["exp_d_quality"][qk] = aggregate_results(vals)

    # Aggregate Order
    for ok in all_seed_runs[0]["order_results"].keys():
        vals = [r["order_results"][ok] for r in all_seed_runs]
        aggregated["exp_e_order"][ok] = aggregate_results(vals)

    # Aggregate Remapping
    for rk in all_seed_runs[0]["remapping_results"].keys():
        vals = [r["remapping_results"][rk] for r in all_seed_runs]
        aggregated["exp_f_remapping"][rk] = aggregate_results(vals)

    # Save manifest
    ts = int(time.time())
    out_file = OUT / f"v10_5_results_{ts}.json"
    save_manifest(out_file, aggregated)
    print(f"Results saved to: {out_file}")


if __name__ == "__main__":
    main()
