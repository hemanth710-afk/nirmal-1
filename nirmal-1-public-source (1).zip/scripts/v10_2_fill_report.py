import json
import time
from pathlib import Path

OUT = Path("experiments/v10_2")
REPORT = Path("docs/V10_2_CAPACITY_SCALE_SYSTEMATIC_GENERALIZATION_STUDY.md")

def wait_for_results():
    while True:
        files = list(OUT.glob("v10_2_results_*.json"))
        if files:
            files.sort()
            return json.loads(files[-1].read_text())
        print("Waiting for results...")
        time.sleep(10)

def format_acc(res):
    if res is None: return "N/A"
    return f"{res['mean']*100:.2f}% ± {res['ci95']*100:.2f}%"

def fill_report():
    res = wait_for_results()
    text = REPORT.read_text()
    
    # Phase 5
    for lvl in ["L0", "L1", "L2", "L3", "L4"]:
        k_id = f"{lvl}_identity_D_FULLY_DISJOINT"
        k_vr = f"{lvl}_value_relative_D_FULLY_DISJOINT"
        
        text = text.replace(f"{{{k_id}}}", format_acc(res.get(k_id, {}).get("ood")))
        text = text.replace(f"{{{k_vr}}}", format_acc(res.get(k_vr, {}).get("ood")))
        
    # Phase 4
    for tax in ["A_SAME_VOCAB", "B_SURFACE_FORM", "C_PARTIAL_DISJOINT", "D_FULLY_DISJOINT", "E_LONGER_CONTEXT", "F_POSITIONAL_SHIFT", "G_ISOMORPHIC_RULE", "H_COMPOSITIONAL"]:
        k_id = f"L2_identity_{tax}"
        k_vr = f"L2_value_relative_{tax}"
        
        text = text.replace(f"{{{k_id}}}", format_acc(res.get(k_id, {}).get("ood")))
        text = text.replace(f"{{{k_vr}}}", format_acc(res.get(k_vr, {}).get("ood")))
        
        fail_id = res.get(k_id, {}).get("primary_failure", "N/A")
        text = text.replace(f"{{fail_{tax.split('_')[0]}}}", fail_id)
        
    REPORT.write_text(text)
    print("Report populated successfully.")

if __name__ == "__main__":
    fill_report()
