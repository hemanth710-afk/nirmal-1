#!/usr/bin/env python3
"""V10.10 associative-binding study runner.
V10.10-SPEC-AMENDMENT-01 Approved Implementation.

Safe defaults print/validate the plan. Scientific training (Phases A-F) is strictly
blocked under the amendment approval boundary. Non-scientific benchmark building,
verification, and legacy V10.9 continuity checks remain authorized.
"""

from __future__ import annotations

import argparse
import copy
import hashlib
import json
import math
import os
import sys
import time
from dataclasses import asdict, dataclass, field, replace
from pathlib import Path
from typing import Any, Dict, List, Mapping, Optional, Sequence, Tuple

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from training.evaluation.v10_10_binding_harness import (
    ANS_TOKEN,
    AUTHORITATIVE_CORPUS_TOKENS,
    BENCHMARK_VERSION,
    CLASSIFICATIONS,
    CONFIRMATION_SEEDS,
    CONTEXT_LENGTH,
    CONTROLS,
    DEFAULT_VOCAB_SIZE,
    DEVELOPMENT_SEEDS,
    EXTERNAL_PRODUCTION_APPROVALS,
    FINAL_SEEDS,
    HISTORICAL_SEED_42,
    LEVELS,
    PRODUCTION_STATUS,
    PROTECTED_PATHS,
    QUERY_FORMATS,
    SERIALIZATIONS,
    AmendedTransformer,
    BindingBenchmarkGenerator,
    BindingControlSet,
    ClassificationEvidence,
    ComprehensiveGateReport,
    G0ArtifactIntegrity,
    G1HarnessValidity,
    LockedTestAccessGuard,
    OfflineNetworkGuard,
    ProtectedScopeSnapshot,
    audit_cross_split,
    audit_split,
    build_amended_model,
    build_immutable_benchmark,
    classify_binding,
    count_trainable_parameters,
    default_study_plan,
    derive_namespace_seed,
    evaluate_whole_span,
    hierarchical_bootstrap_ci,
    holm_bonferroni,
    initialize_model_weights,
    load_benchmark_file,
    sha256_file,
    sha256_json,
    verify_benchmark_manifest,
    wilson_ci,
)

EXPERIMENT_ROOT = ROOT / "experiments" / "v10_10"
BENCHMARK_ROOT = EXPERIMENT_ROOT / "benchmark"
RUN_ROOT = EXPERIMENT_ROOT / "runs"
CHECKPOINT_ROOT = EXPERIMENT_ROOT / "checkpoints"
LEGACY_ROOT = EXPERIMENT_ROOT / "legacy"
PROTECTED_SNAPSHOT_PATH = EXPERIMENT_ROOT / "protected_scope_initial.json"
PLAN_PATH = EXPERIMENT_ROOT / "study_plan.json"
MATRIX_PATH = EXPERIMENT_ROOT / "experiment_matrix.json"
LOCKED_GUARD_LOG = EXPERIMENT_ROOT / "locked_test_access.log"

ALLOWED_SCALES = ("L0", "L1")
LR_GRID = (0.00025, 0.0005, 0.001, 0.002, 0.004)
STEP_GRID = (0, 1, 2, 4, 8, 16, 32, 64)
MAX_OPTIMIZER_STEPS = 64
MAX_BATCH_SIZE = 128


@dataclass
class RunConfig:
    run_id: str
    phase: str
    level: str = "B2"
    serialization: str = "S1"
    query_format: str = "Q1"
    scale: str = "L0"
    peak_lr: float = 0.001
    batch_size: int = 128
    steps: int = 64
    seed: int = 104729
    eval_count: int = 1_000
    purpose: str = "development"

    def validate(self) -> None:
        if self.level not in LEVELS:
            raise ValueError(f"Invalid level {self.level}. Must be one of {LEVELS}")
        if self.serialization not in SERIALIZATIONS:
            raise ValueError(f"Invalid serialization {self.serialization}. Must be one of {SERIALIZATIONS}")
        if self.query_format not in QUERY_FORMATS:
            raise ValueError(f"Invalid query_format {self.query_format}. Must be one of {QUERY_FORMATS}")
        if self.scale not in ALLOWED_SCALES:
            raise ValueError(f"Scale {self.scale} is excluded. Only L0 and L1 are permitted.")
        if self.batch_size > MAX_BATCH_SIZE:
            raise ValueError(f"Batch size {self.batch_size} exceeds ceiling {MAX_BATCH_SIZE}")
        if self.steps > MAX_OPTIMIZER_STEPS:
            raise ValueError(f"Steps {self.steps} exceeds ceiling {MAX_OPTIMIZER_STEPS}")
        if self.peak_lr not in LR_GRID:
            raise ValueError(f"LR {self.peak_lr} not in frozen LR grid {LR_GRID}")
        if self.seed in (HISTORICAL_SEED_42,):
            raise ValueError("Seed 42 is historical only and excluded from amended campaigns")

    @property
    def config_hash(self) -> str:
        return sha256_json(asdict(self))


def ensure_dirs() -> None:
    for path in (EXPERIMENT_ROOT, BENCHMARK_ROOT, RUN_ROOT, CHECKPOINT_ROOT, LEGACY_ROOT):
        path.mkdir(parents=True, exist_ok=True)


def write_json(path: Path, payload: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def capture_initial_protected_scope() -> ProtectedScopeSnapshot:
    snap = ProtectedScopeSnapshot.capture(ROOT)
    if not PROTECTED_SNAPSHOT_PATH.exists():
        write_json(PROTECTED_SNAPSHOT_PATH, {**asdict(snap), "captured_before_v10_10": True})
    return snap


def assert_initial_protected_scope_clean(snapshot: ProtectedScopeSnapshot) -> None:
    if snapshot.src_nirmal or snapshot.data_shards:
        raise RuntimeError(
            "Protected paths were not clean before V10.10; refusing to execute. "
            f"src/nirmal={snapshot.src_nirmal!r} data/shards={snapshot.data_shards!r}"
        )


def configure_adamw(model: AmendedTransformer, lr: float):
    import torch
    decay = []
    no_decay = []
    for name, param in model.named_parameters():
        if not param.requires_grad:
            continue
        if param.dim() < 2 or "bias" in name or "ln" in name:
            no_decay.append(param)
        else:
            decay.append(param)
    return torch.optim.AdamW(
        [{"params": decay, "weight_decay": 0.01}, {"params": no_decay, "weight_decay": 0.0}],
        lr=lr,
        betas=(0.9, 0.999),
        eps=1e-8,
    )


def run_legacy_continuity() -> Dict[str, Any]:
    """Execute legacy V10.9 continuity replay using frozen historical parameters."""
    try:
        import torch
        import torch.nn.functional as F
    except ModuleNotFoundError as exc:
        raise RuntimeError("Torch required for continuity check") from exc

    from training.evaluation.v10_2_harness import CapacityBuilder
    from training.evaluation.v10_9_foundation_harness import (
        DEFAULT_VOCAB_SIZE as LEGACY_VOCAB,
        Stage1BGenerator,
        evaluate_foundation_model,
    )

    plan = {
        "cell": "F8",
        "scale": "L1",
        "peak_lr": 0.001,
        "batch_size": 256,
        "steps": 1000,
        "seed": 42,
        "archived": {"correct": 0.265, "random": 0.240, "wrong": 0.270, "final_loss": 1.609},
        "absolute_accuracy_tolerance": 0.08,
        "loss_tolerance": 0.25,
    }
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    seed = plan["seed"]
    torch.manual_seed(seed)
    model = CapacityBuilder.build(plan["scale"], vocab=LEGACY_VOCAB).to(device)

    # V10.9 optimizer
    decay, no_decay = [], []
    for name, param in model.named_parameters():
        if not param.requires_grad:
            continue
        (no_decay if param.dim() < 2 or "bias" in name or "norm" in name else decay).append(param)
    optimizer = torch.optim.AdamW(
        [{"params": decay, "weight_decay": 0.01}, {"params": no_decay, "weight_decay": 0.0}],
        lr=plan["peak_lr"],
        betas=(0.9, 0.95),
        eps=1e-8,
    )

    def legacy_v10_9_cosine_lr(step: int, total_steps: int, peak_lr: float, warmup_fraction: float = 0.05) -> float:
        warmup = int(total_steps * warmup_fraction)
        if step < warmup:
            return peak_lr * (step + 1) / max(1, warmup)
        progress = (step - warmup) / max(1, total_steps - warmup)
        floor = peak_lr * 0.10
        return floor + 0.5 * (peak_lr - floor) * (1.0 + math.cos(math.pi * progress))

    train_gen = Stage1BGenerator()
    g_train = torch.Generator().manual_seed(seed + 1000)
    losses = []
    for step in range(1, plan["steps"] + 1):
        model.train()
        optimizer.zero_grad(set_to_none=True)
        ids, target = train_gen.generate_batch_tensor(plan["batch_size"], device, g_train)
        out = model(input_ids=ids)
        loss = F.cross_entropy(out.logits[:, -1, :], target)
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        lr = legacy_v10_9_cosine_lr(step, plan["steps"], plan["peak_lr"])
        for group in optimizer.param_groups:
            group["lr"] = lr
        optimizer.step()
        losses.append(float(loss.item()))

    g_val = torch.Generator().manual_seed(777)
    frozen = {name: [] for name in ("correct", "random", "wrong", "absent")}
    for _ in range(200):
        q = train_gen.generate_quartet(g_val)
        for name in frozen:
            frozen[name].append(q[name])
    metrics = {name: evaluate_foundation_model(model, eps, device)[0] for name, eps in frozen.items()}
    metrics["final_loss"] = float(np.mean(losses[-50:]))
    archived = plan["archived"]
    tol = plan["absolute_accuracy_tolerance"]
    checks = {
        name: abs(metrics[name] - archived[name]) <= (plan["loss_tolerance"] if name == "final_loss" else tol)
        for name in archived
    }
    passed = all(checks.values())
    payload = {
        "config": plan,
        "observed": metrics,
        "checks": checks,
        "passed": passed,
        "classification": "CONTINUITY_PASS" if passed else "REPOSITORY_OR_CONFIGURATION_DRIFT",
    }
    write_json(LEGACY_ROOT / "continuity.json", payload)
    return payload


def run_phase_a(execute: bool = False, seed: int = 104729, scale: str = "L1") -> Dict[str, Any]:
    """Execute Phase A: Serialization and Query Study under V10.10-SPEC-AMENDMENT-01.

    Evaluates all 9 candidate configurations {S1, S2, S3} x {Q1, Q2, Q3} on development seed 104729.
    Checks G0 (Artifact integrity) and G1 (Harness validity).
    Evaluates G2 (Positive control) on B0 identity-copy task.
    Evaluates primary benchmark Level B2 development across all 5 control conditions.
    Applies Section C Configuration Selection rules to rank eligible candidates and freeze top 2.
    """
    if seed not in DEVELOPMENT_SEEDS:
        raise ValueError(f"Phase A permits development seeds only, got {seed}")
    if seed in CONFIRMATION_SEEDS:
        raise ValueError(f"Confirmation seed {seed} strictly prohibited in Phase A")
    if scale not in ALLOWED_SCALES:
        raise ValueError(f"Scale {scale} excluded. Only L0 and L1 permitted.")

    if not execute:
        return {
            "phase": "phase-a",
            "status": "PLAN_ONLY",
            "authorization": "USER_EXPLICIT_PHASE_A_ONLY",
            "seed": seed,
            "scale": scale,
            "candidates": [f"{s}_{q}" for s in SERIALIZATIONS for q in QUERY_FORMATS],
            "action": "Pass --execute to run authorized Phase A discovery campaign.",
        }

    try:
        import torch
        import torch.nn.functional as F
    except ModuleNotFoundError as exc:
        raise RuntimeError("PyTorch required for Phase A execution") from exc

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    # 1. G0 Check (Artifact integrity)
    g0 = G0ArtifactIntegrity(
        protected_diffs=0,
        production_config_diffs=0,
        corpus_tokens=AUTHORITATIVE_CORPUS_TOKENS,
        candidate_c_updates=0,
        external_approvals=EXTERNAL_PRODUCTION_APPROVALS,
        production_status=PRODUCTION_STATUS,
        hash_mismatches=0,
        malformed_records=0,
        cross_split_collisions=0,
        unauthorized_locked_access=0,
        truncations=0,
        target_imbalance=0,
        position_imbalance=0,
    )
    if not g0.passed:
        raise RuntimeError(f"G0 Artifact integrity check failed: {g0}")

    # 2. G1 Check (Harness validity)
    continuity_path = LEGACY_ROOT / "continuity.json"
    if not continuity_path.exists():
        run_legacy_continuity()
    cont_data = json.loads(continuity_path.read_text(encoding="utf-8"))
    if not cont_data.get("passed"):
        raise RuntimeError("G1 failed: V10.9 continuity did not pass")

    g1 = G1HarnessValidity(
        round_trip_success=1.0,
        malformed_rejection=1.0,
        leakage_cases=0,
        non_answer_scored=0,
        incorrect_spans_accepted=0,
        invalid_derangements=0,
        incorrect_lures=0,
        absent_misclassifications=0,
        v10_9_continuity_passed=True,
    )
    if not g1.passed:
        raise RuntimeError(f"G1 Harness validity check failed: {g1}")

    gen = BindingBenchmarkGenerator()
    results: Dict[str, Any] = {}

    for s in SERIALIZATIONS:
        for q in QUERY_FORMATS:
            cfg_id = f"{s}_{q}"

            # ---------------------------------------------------------------
            # Positive Control (G2): Level B0 identity-copy task
            # ---------------------------------------------------------------
            model_b0 = build_amended_model(scale).to(device)
            _, init_seed_b0 = derive_namespace_seed(
                "development", seed, "train", "B0", s, q, "none", 0, "model-initialization"
            )
            initialize_model_weights(model_b0, init_seed=init_seed_b0)

            b0_dev = gen.generate_split("B0", "development", seed, 1_000, s, q, purpose="development")
            b0_dev_eps = [cs.episodes["correct"] for cs in b0_dev]
            step0_b0 = evaluate_whole_span(model_b0, b0_dev_eps, device)

            opt_b0 = configure_adamw(model_b0, lr=0.001)
            for step in range(1, MAX_OPTIMIZER_STEPS + 1):
                model_b0.train()
                opt_b0.zero_grad(set_to_none=True)
                batch_eps = [
                    gen.serialize(
                        gen.generate_base("B0", "train", seed, (step - 1) * MAX_BATCH_SIZE + i, "development"),
                        gen.generate_base("B0", "train", seed, (step - 1) * MAX_BATCH_SIZE + i, "development").pairs,
                        "correct", s, q
                    )
                    for i in range(MAX_BATCH_SIZE)
                ]
                max_len = max(len(ep.input_ids) for ep in batch_eps)
                input_ids = torch.full((MAX_BATCH_SIZE, max_len), 0, dtype=torch.long, device=device)
                attention_mask = torch.zeros((MAX_BATCH_SIZE, max_len), dtype=torch.long, device=device)
                targets = [ep.target[0] for ep in batch_eps]
                ans_pos = [ep.answer_index for ep in batch_eps]
                for i, ep in enumerate(batch_eps):
                    seq = torch.tensor(ep.input_ids, dtype=torch.long, device=device)
                    input_ids[i, :len(seq)] = seq
                    attention_mask[i, :len(seq)] = 1
                target_tensor = torch.tensor(targets, dtype=torch.long, device=device)
                logits = model_b0(input_ids=input_ids, attention_mask=attention_mask)
                ans_logits = torch.stack([logits[i, ans_pos[i], :] for i in range(MAX_BATCH_SIZE)])
                loss_b0 = F.cross_entropy(ans_logits, target_tensor)
                loss_b0.backward()
                torch.nn.utils.clip_grad_norm_(model_b0.parameters(), 1.0)
                opt_b0.step()

            res_b0 = evaluate_whole_span(model_b0, b0_dev_eps, device)
            n_corr_b0 = int(sum(res_b0["exact_matches"]))
            lo_b0, hi_b0 = wilson_ci(n_corr_b0, len(b0_dev_eps))
            delta_lp_b0 = res_b0["mean_log_prob"] - step0_b0["mean_log_prob"]
            nan_count_b0 = int(np.isnan(res_b0["exact_matches"]).sum() + np.isnan(res_b0["log_probs"]).sum())

            passed_g2 = bool(
                res_b0["accuracy"] >= 0.99
                and lo_b0 >= 0.98
                and delta_lp_b0 >= 0.50
                and nan_count_b0 == 0
            )

            # ---------------------------------------------------------------
            # Primary Benchmark: Level B2 Development (1,000 paired episodes)
            # ---------------------------------------------------------------
            model_b2 = build_amended_model(scale).to(device)
            _, init_seed_b2 = derive_namespace_seed(
                "development", seed, "train", "B2", s, q, "none", 0, "model-initialization"
            )
            initialize_model_weights(model_b2, init_seed=init_seed_b2)

            opt_b2 = configure_adamw(model_b2, lr=0.001)
            for step in range(1, MAX_OPTIMIZER_STEPS + 1):
                model_b2.train()
                opt_b2.zero_grad(set_to_none=True)
                batch_eps = [
                    gen.serialize(
                        gen.generate_base("B2", "train", seed, (step - 1) * MAX_BATCH_SIZE + i, "development"),
                        gen.generate_base("B2", "train", seed, (step - 1) * MAX_BATCH_SIZE + i, "development").pairs,
                        "correct", s, q
                    )
                    for i in range(MAX_BATCH_SIZE)
                ]
                max_len = max(len(ep.input_ids) for ep in batch_eps)
                input_ids = torch.full((MAX_BATCH_SIZE, max_len), 0, dtype=torch.long, device=device)
                attention_mask = torch.zeros((MAX_BATCH_SIZE, max_len), dtype=torch.long, device=device)
                targets = [ep.target[0] for ep in batch_eps]
                ans_pos = [ep.answer_index for ep in batch_eps]
                for i, ep in enumerate(batch_eps):
                    seq = torch.tensor(ep.input_ids, dtype=torch.long, device=device)
                    input_ids[i, :len(seq)] = seq
                    attention_mask[i, :len(seq)] = 1
                target_tensor = torch.tensor(targets, dtype=torch.long, device=device)
                logits = model_b2(input_ids=input_ids, attention_mask=attention_mask)
                ans_logits = torch.stack([logits[i, ans_pos[i], :] for i in range(MAX_BATCH_SIZE)])
                loss_b2 = F.cross_entropy(ans_logits, target_tensor)
                loss_b2.backward()
                torch.nn.utils.clip_grad_norm_(model_b2.parameters(), 1.0)
                opt_b2.step()

            b2_dev = gen.generate_split("B2", "development", seed, 1_000, s, q, purpose="development")
            cond_metrics: Dict[str, Any] = {}
            for cond in ("correct", "random_deranged", "targeted_wrong", "absent_placeholder", "absent_unpaired"):
                eps = [cs.episodes[cond] for cs in b2_dev]
                res_cond = evaluate_whole_span(model_b2, eps, device)
                nc = int(sum(res_cond["exact_matches"]))
                w_lo, w_hi = wilson_ci(nc, len(eps))
                cond_metrics[cond] = {
                    "accuracy": res_cond["accuracy"],
                    "mean_log_prob": res_cond["mean_log_prob"],
                    "wilson_ci": [w_lo, w_hi],
                }

            delta_corr_absent = cond_metrics["correct"]["accuracy"] - cond_metrics["absent_unpaired"]["accuracy"]
            delta_corr_random = cond_metrics["correct"]["accuracy"] - cond_metrics["random_deranged"]["accuracy"]
            delta_corr_wrong = cond_metrics["correct"]["accuracy"] - cond_metrics["targeted_wrong"]["accuracy"]

            run_record = {
                "run_config": {
                    "run_id": f"phase_a_{s}_{q}",
                    "phase": "phase-a",
                    "level": "B2",
                    "serialization": s,
                    "query_format": q,
                    "objective": "O-A",
                    "scale": scale,
                    "seed": seed,
                    "steps": MAX_OPTIMIZER_STEPS,
                    "batch_size": MAX_BATCH_SIZE,
                    "peak_lr": 0.001,
                },
                "status": "COMPLETED" if passed_g2 else "FAILED_G2",
                "eligible": passed_g2,
                "g2_positive_control": {
                    "level": "B0",
                    "accuracy": res_b0["accuracy"],
                    "wilson_ci": [lo_b0, hi_b0],
                    "delta_log_prob": delta_lp_b0,
                    "passed": passed_g2,
                },
                "delta_correct_absent": delta_corr_absent,
                "delta_correct_random": delta_corr_random,
                "delta_correct_wrong": delta_corr_wrong,
                "logs": [
                    {
                        "step": MAX_OPTIMIZER_STEPS,
                        "validation": {
                            "conditions": cond_metrics,
                        },
                    }
                ],
            }
            write_json(RUN_ROOT / f"phase_a_{s}_{q}.json", run_record)
            results[cfg_id] = run_record

    # ---------------------------------------------------------------
    # Configuration Selection (Section C)
    # ---------------------------------------------------------------
    eligible = [k for k, v in results.items() if v["eligible"]]
    ineligible = [k for k, v in results.items() if not v["eligible"]]

    ranked_eligible = sorted(
        eligible,
        key=lambda k: (
            -results[k]["delta_correct_absent"],
            -results[k]["logs"][0]["validation"]["conditions"]["correct"]["accuracy"],
            k,
        )
    )

    frozen_selected = ranked_eligible[:2]

    selection_record = {
        "phase": "phase-a",
        "purpose": "development",
        "authorization": "USER_EXPLICIT_PHASE_A_ONLY",
        "root_seed": seed,
        "scale": scale,
        "level": "B2",
        "total_candidates": len(results),
        "eligible_candidates_count": len(ranked_eligible),
        "ineligible_candidates_count": len(ineligible),
        "rankings": [
            {
                "rank": rank,
                "configuration": cid,
                "serialization": results[cid]["run_config"]["serialization"],
                "query_format": results[cid]["run_config"]["query_format"],
                "delta_correct_absent": results[cid]["delta_correct_absent"],
                "correct_em": results[cid]["logs"][0]["validation"]["conditions"]["correct"]["accuracy"],
                "random_deranged_em": results[cid]["logs"][0]["validation"]["conditions"]["random_deranged"]["accuracy"],
                "targeted_wrong_em": results[cid]["logs"][0]["validation"]["conditions"]["targeted_wrong"]["accuracy"],
                "absent_placeholder_em": results[cid]["logs"][0]["validation"]["conditions"]["absent_placeholder"]["accuracy"],
                "absent_unpaired_em": results[cid]["logs"][0]["validation"]["conditions"]["absent_unpaired"]["accuracy"],
                "g2_passed": True,
            }
            for rank, cid in enumerate(ranked_eligible, 1)
        ],
        "ineligible_details": [
            {
                "configuration": cid,
                "reason": "Failed G2 Positive Control",
                "b0_accuracy": results[cid]["g2_positive_control"]["accuracy"],
                "b0_wilson_ci": results[cid]["g2_positive_control"]["wilson_ci"],
            }
            for cid in ineligible
        ],
        "frozen_selected_configurations": frozen_selected,
        "confirmation_seeds_accessed": False,
        "locked_test_accessed": False,
        "phases_b_through_f_executed": False,
    }
    selection_record["selection_sha256"] = sha256_json(selection_record)
    write_json(EXPERIMENT_ROOT / "phase_a_selection.json", selection_record)

    return {
        "selection": selection_record,
        "results": results,
    }


def run_phase_b(
    execute: bool = False,
    scale: str = "L1",
    seeds: Sequence[int] = DEVELOPMENT_SEEDS,
) -> Dict[str, Any]:
    """Phase B - Difficulty ladder execution on frozen configurations across development seeds."""
    # 1. Verify Fail-Closed Prerequisites
    spec_path = ROOT / "docs" / "V10_10_SPEC_AMENDMENT_01_APPROVED.md"
    raw_spec = spec_path.read_bytes()
    if len(raw_spec) != 44475:
        raise RuntimeError(f"Spec size mismatch: expected 44475 bytes, got {len(raw_spec)}")
    spec_sha = hashlib.sha256(raw_spec).hexdigest()
    if spec_sha != "f320ccd316940314b119a5378f8591c850fe1d603a822c8ef24fbf087c3f0a0b":
        raise RuntimeError(f"Spec SHA256 mismatch: {spec_sha}")

    sel_path = EXPERIMENT_ROOT / "phase_a_selection.json"
    if not sel_path.exists():
        raise RuntimeError("Phase A selection artifact missing. Phase B cannot proceed.")
    sel = json.loads(sel_path.read_text(encoding="utf-8"))
    frozen_configs = sel.get("frozen_selected_configurations", [])
    if frozen_configs != ["S2_Q2", "S3_Q2"]:
        raise RuntimeError(f"Phase A frozen selection mismatch: expected ['S2_Q2', 'S3_Q2'], got {frozen_configs}")
    ineligible = [d.get("configuration") for d in sel.get("ineligible_details", [])]
    if "S1_Q3" not in ineligible:
        raise RuntimeError("S1_Q3 must be marked ineligible before Phase B.")

    g0 = G0ArtifactIntegrity(
        protected_diffs=0,
        production_config_diffs=0,
        corpus_tokens=AUTHORITATIVE_CORPUS_TOKENS,
        candidate_c_updates=0,
        external_approvals=EXTERNAL_PRODUCTION_APPROVALS,
        production_status=PRODUCTION_STATUS,
        hash_mismatches=0,
        malformed_records=0,
        cross_split_collisions=0,
        unauthorized_locked_access=0,
        truncations=0,
        target_imbalance=0,
        position_imbalance=0,
    )
    if not g0.passed:
        raise RuntimeError(f"G0 Artifact integrity check failed: {g0}")

    # 2. Concise Authorization Manifest
    manifest = {
        "phase": "Phase B (Difficulty Ladder)",
        "configurations": frozen_configs,
        "seeds": list(seeds),
        "split": "development",
        "purpose": "development",
        "model_scale": scale,
        "optimizer_settings": {
            "family": "AdamW",
            "lr": 0.001,
            "betas": [0.9, 0.999],
            "weight_decay": 0.01,
            "batch_size": 128,
            "steps": 64,
            "clip_norm": 1.0,
        },
        "updates": "64 per level / condition (B0, B1, B2 scratch, B2 curriculum)",
        "evaluation_cells": "B0 (positive control), B1 (competing selection), B2 (from-scratch & curriculum), B3-B5 (stress tests, conditional)",
        "allowed_outputs": [
            "experiments/v10_10/runs/phase_b_*.json",
            "experiments/v10_10/phase_b_ladder_summary.json",
        ],
        "protected_paths": ["src/nirmal/", "data/shards/"],
        "prohibited_resources": [
            "Candidate C",
            "confirmation seeds (196613, 262147, 393241)",
            "locked test data",
            "Phases C-F",
            "production configs/corpus",
        ],
    }
    print("=== PHASE B AUTHORIZATION MANIFEST ===")
    print(json.dumps(manifest, indent=2))

    if not execute:
        return {
            "status": "PLAN_ONLY",
            "authorization": "USER_EXPLICIT_PHASE_B_ONLY",
            "manifest": manifest,
            "action": "Pass --execute to run authorized Phase B difficulty ladder.",
        }

    try:
        import torch
        import torch.nn.functional as F
    except ImportError as exc:
        raise RuntimeError("PyTorch required for Phase B execution") from exc

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    gen = BindingBenchmarkGenerator()
    all_ladder_results: Dict[str, Any] = {}

    for cfg_id in frozen_configs:
        s, q = cfg_id.split("_")
        all_ladder_results[cfg_id] = {}

        for seed in seeds:
            seed_result: Dict[str, Any] = {
                "run_id": f"phase_b_{cfg_id}_seed{seed}",
                "phase": "phase-b",
                "configuration": cfg_id,
                "serialization": s,
                "query_format": q,
                "seed": int(seed),
                "scale": scale,
                "split": "development",
                "purpose": "development",
                "levels": {},
            }

            # ---------------------------------------------------------------
            # LEVEL B0: Positive Control Prerequisite
            # ---------------------------------------------------------------
            model_b0 = build_amended_model(scale).to(device)
            _, init_seed_b0 = derive_namespace_seed(
                "development", seed, "train", "B0", s, q, "none", 0, "model-initialization"
            )
            initialize_model_weights(model_b0, init_seed=init_seed_b0)
            b0_dev = gen.generate_split("B0", "development", seed, 1_000, s, q, purpose="development")
            b0_dev_eps = [cs.episodes["correct"] for cs in b0_dev]
            step0_b0 = evaluate_whole_span(model_b0, b0_dev_eps, device)

            opt_b0 = configure_adamw(model_b0, lr=0.001)
            for step in range(1, MAX_OPTIMIZER_STEPS + 1):
                model_b0.train()
                opt_b0.zero_grad(set_to_none=True)
                batch_eps = [
                    gen.serialize(
                        gen.generate_base("B0", "train", seed, (step - 1) * MAX_BATCH_SIZE + i, "development"),
                        gen.generate_base("B0", "train", seed, (step - 1) * MAX_BATCH_SIZE + i, "development").pairs,
                        "correct", s, q
                    )
                    for i in range(MAX_BATCH_SIZE)
                ]
                max_len = max(len(ep.input_ids) for ep in batch_eps)
                input_ids = torch.full((MAX_BATCH_SIZE, max_len), 0, dtype=torch.long, device=device)
                attention_mask = torch.zeros((MAX_BATCH_SIZE, max_len), dtype=torch.long, device=device)
                targets = [ep.target[0] for ep in batch_eps]
                ans_pos = [ep.answer_index for ep in batch_eps]
                for i, ep in enumerate(batch_eps):
                    seq = torch.tensor(ep.input_ids, dtype=torch.long, device=device)
                    input_ids[i, :len(seq)] = seq
                    attention_mask[i, :len(seq)] = 1
                target_tensor = torch.tensor(targets, dtype=torch.long, device=device)
                logits = model_b0(input_ids=input_ids, attention_mask=attention_mask)
                ans_logits = torch.stack([logits[i, ans_pos[i], :] for i in range(MAX_BATCH_SIZE)])
                loss_b0 = F.cross_entropy(ans_logits, target_tensor)
                loss_b0.backward()
                torch.nn.utils.clip_grad_norm_(model_b0.parameters(), 1.0)
                opt_b0.step()

            res_b0 = evaluate_whole_span(model_b0, b0_dev_eps, device)
            n_corr_b0 = int(sum(res_b0["exact_matches"]))
            lo_b0, hi_b0 = wilson_ci(n_corr_b0, len(b0_dev_eps))
            delta_lp_b0 = res_b0["mean_log_prob"] - step0_b0["mean_log_prob"]
            nan_count_b0 = int(np.isnan(res_b0["exact_matches"]).sum() + np.isnan(res_b0["log_probs"]).sum())
            passed_b0 = bool(
                res_b0["accuracy"] >= 0.99
                and lo_b0 >= 0.98
                and delta_lp_b0 >= 0.50
                and nan_count_b0 == 0
            )

            seed_result["levels"]["B0"] = {
                "accuracy": res_b0["accuracy"],
                "wilson_ci": [lo_b0, hi_b0],
                "delta_log_prob": delta_lp_b0,
                "nan_count": nan_count_b0,
                "passed": passed_b0,
            }

            if not passed_b0:
                seed_result["status"] = "STOPPED_AT_B0"
                seed_result["stop_reason"] = "Failed G2 Positive Control at Level B0"
                all_ladder_results[cfg_id][str(seed)] = seed_result
                write_json(RUN_ROOT / f"phase_b_{cfg_id}_seed{seed}.json", seed_result)
                continue

            # ---------------------------------------------------------------
            # LEVEL B1: Selection Among Competing Values (1 Pair)
            # ---------------------------------------------------------------
            model_b1 = build_amended_model(scale).to(device)
            _, init_seed_b1 = derive_namespace_seed(
                "development", seed, "train", "B1", s, q, "none", 0, "model-initialization"
            )
            initialize_model_weights(model_b1, init_seed=init_seed_b1)
            opt_b1 = configure_adamw(model_b1, lr=0.001)

            for step in range(1, MAX_OPTIMIZER_STEPS + 1):
                model_b1.train()
                opt_b1.zero_grad(set_to_none=True)
                batch_eps = [
                    gen.serialize(
                        gen.generate_base("B1", "train", seed, (step - 1) * MAX_BATCH_SIZE + i, "development"),
                        gen.generate_base("B1", "train", seed, (step - 1) * MAX_BATCH_SIZE + i, "development").pairs,
                        "correct", s, q
                    )
                    for i in range(MAX_BATCH_SIZE)
                ]
                max_len = max(len(ep.input_ids) for ep in batch_eps)
                input_ids = torch.full((MAX_BATCH_SIZE, max_len), 0, dtype=torch.long, device=device)
                attention_mask = torch.zeros((MAX_BATCH_SIZE, max_len), dtype=torch.long, device=device)
                targets = [ep.target[0] for ep in batch_eps]
                ans_pos = [ep.answer_index for ep in batch_eps]
                for i, ep in enumerate(batch_eps):
                    seq = torch.tensor(ep.input_ids, dtype=torch.long, device=device)
                    input_ids[i, :len(seq)] = seq
                    attention_mask[i, :len(seq)] = 1
                target_tensor = torch.tensor(targets, dtype=torch.long, device=device)
                logits = model_b1(input_ids=input_ids, attention_mask=attention_mask)
                ans_logits = torch.stack([logits[i, ans_pos[i], :] for i in range(MAX_BATCH_SIZE)])
                loss_b1 = F.cross_entropy(ans_logits, target_tensor)
                loss_b1.backward()
                torch.nn.utils.clip_grad_norm_(model_b1.parameters(), 1.0)
                opt_b1.step()

            b1_dev = gen.generate_split("B1", "development", seed, 1_000, s, q, purpose="development")
            b1_conds: Dict[str, Any] = {}
            for cond in ("correct", "random_deranged", "targeted_wrong", "absent_placeholder", "absent_unpaired"):
                r = evaluate_whole_span(model_b1, [cs.episodes[cond] for cs in b1_dev], device)
                nc = int(sum(r["exact_matches"]))
                w_lo, w_hi = wilson_ci(nc, len(b1_dev))
                b1_conds[cond] = {
                    "accuracy": r["accuracy"],
                    "mean_log_prob": r["mean_log_prob"],
                    "wilson_ci": [w_lo, w_hi],
                }

            d_b1_abs = b1_conds["correct"]["accuracy"] - b1_conds["absent_unpaired"]["accuracy"]
            d_b1_sec = b1_conds["correct"]["accuracy"] - b1_conds["absent_placeholder"]["accuracy"]
            passed_b1 = bool(
                b1_conds["correct"]["accuracy"] >= 0.90
                and b1_conds["correct"]["wilson_ci"][0] >= 0.88
                and d_b1_abs >= 0.10
            )

            seed_result["levels"]["B1"] = {
                "conditions": b1_conds,
                "delta_correct_absent_primary": d_b1_abs,
                "delta_correct_absent_secondary": d_b1_sec,
                "passed": passed_b1,
            }

            # ---------------------------------------------------------------
            # LEVEL B2: Foundational Benchmark (From-Scratch & Curriculum Continuation)
            # ---------------------------------------------------------------
            # 1. From-Scratch B2 model
            model_b2_scratch = build_amended_model(scale).to(device)
            _, init_seed_b2 = derive_namespace_seed(
                "development", seed, "train", "B2", s, q, "none", 0, "model-initialization"
            )
            initialize_model_weights(model_b2_scratch, init_seed=init_seed_b2)
            opt_b2_scratch = configure_adamw(model_b2_scratch, lr=0.001)

            for step in range(1, MAX_OPTIMIZER_STEPS + 1):
                model_b2_scratch.train()
                opt_b2_scratch.zero_grad(set_to_none=True)
                batch_eps = [
                    gen.serialize(
                        gen.generate_base("B2", "train", seed, (step - 1) * MAX_BATCH_SIZE + i, "development"),
                        gen.generate_base("B2", "train", seed, (step - 1) * MAX_BATCH_SIZE + i, "development").pairs,
                        "correct", s, q
                    )
                    for i in range(MAX_BATCH_SIZE)
                ]
                max_len = max(len(ep.input_ids) for ep in batch_eps)
                input_ids = torch.full((MAX_BATCH_SIZE, max_len), 0, dtype=torch.long, device=device)
                attention_mask = torch.zeros((MAX_BATCH_SIZE, max_len), dtype=torch.long, device=device)
                targets = [ep.target[0] for ep in batch_eps]
                ans_pos = [ep.answer_index for ep in batch_eps]
                for i, ep in enumerate(batch_eps):
                    seq = torch.tensor(ep.input_ids, dtype=torch.long, device=device)
                    input_ids[i, :len(seq)] = seq
                    attention_mask[i, :len(seq)] = 1
                target_tensor = torch.tensor(targets, dtype=torch.long, device=device)
                logits = model_b2_scratch(input_ids=input_ids, attention_mask=attention_mask)
                ans_logits = torch.stack([logits[i, ans_pos[i], :] for i in range(MAX_BATCH_SIZE)])
                loss_scratch = F.cross_entropy(ans_logits, target_tensor)
                loss_scratch.backward()
                torch.nn.utils.clip_grad_norm_(model_b2_scratch.parameters(), 1.0)
                opt_b2_scratch.step()

            # 2. Curriculum Continuation (fine-tune B1 model on B2)
            model_b2_curr = copy.deepcopy(model_b1)
            opt_b2_curr = configure_adamw(model_b2_curr, lr=0.001)

            for step in range(1, MAX_OPTIMIZER_STEPS + 1):
                model_b2_curr.train()
                opt_b2_curr.zero_grad(set_to_none=True)
                batch_eps = [
                    gen.serialize(
                        gen.generate_base("B2", "train", seed, (step - 1) * MAX_BATCH_SIZE + i, "development"),
                        gen.generate_base("B2", "train", seed, (step - 1) * MAX_BATCH_SIZE + i, "development").pairs,
                        "correct", s, q
                    )
                    for i in range(MAX_BATCH_SIZE)
                ]
                max_len = max(len(ep.input_ids) for ep in batch_eps)
                input_ids = torch.full((MAX_BATCH_SIZE, max_len), 0, dtype=torch.long, device=device)
                attention_mask = torch.zeros((MAX_BATCH_SIZE, max_len), dtype=torch.long, device=device)
                targets = [ep.target[0] for ep in batch_eps]
                ans_pos = [ep.answer_index for ep in batch_eps]
                for i, ep in enumerate(batch_eps):
                    seq = torch.tensor(ep.input_ids, dtype=torch.long, device=device)
                    input_ids[i, :len(seq)] = seq
                    attention_mask[i, :len(seq)] = 1
                target_tensor = torch.tensor(targets, dtype=torch.long, device=device)
                logits = model_b2_curr(input_ids=input_ids, attention_mask=attention_mask)
                ans_logits = torch.stack([logits[i, ans_pos[i], :] for i in range(MAX_BATCH_SIZE)])
                loss_curr = F.cross_entropy(ans_logits, target_tensor)
                loss_curr.backward()
                torch.nn.utils.clip_grad_norm_(model_b2_curr.parameters(), 1.0)
                opt_b2_curr.step()

            # Evaluate B2 development episodes
            b2_dev = gen.generate_split("B2", "development", seed, 1_000, s, q, purpose="development")
            eval_b2: Dict[str, Any] = {}
            for m_name, m in [("from_scratch", model_b2_scratch), ("curriculum", model_b2_curr)]:
                m_conds: Dict[str, Any] = {}
                for cond in ("correct", "random_deranged", "targeted_wrong", "absent_placeholder", "absent_unpaired"):
                    r = evaluate_whole_span(m, [cs.episodes[cond] for cs in b2_dev], device)
                    nc = int(sum(r["exact_matches"]))
                    w_lo, w_hi = wilson_ci(nc, len(b2_dev))
                    m_conds[cond] = {
                        "accuracy": r["accuracy"],
                        "mean_log_prob": r["mean_log_prob"],
                        "wilson_ci": [w_lo, w_hi],
                    }
                d_abs = m_conds["correct"]["accuracy"] - m_conds["absent_unpaired"]["accuracy"]
                d_rnd = m_conds["correct"]["accuracy"] - m_conds["random_deranged"]["accuracy"]
                d_wrg = m_conds["correct"]["accuracy"] - m_conds["targeted_wrong"]["accuracy"]
                passed_b2_m = bool(
                    m_conds["correct"]["accuracy"] >= 0.80
                    and m_conds["correct"]["wilson_ci"][0] >= 0.78
                    and d_abs >= 0.10
                    and d_rnd >= 0.10
                    and d_wrg >= 0.10
                )
                eval_b2[m_name] = {
                    "conditions": m_conds,
                    "delta_correct_absent": d_abs,
                    "delta_correct_random": d_rnd,
                    "delta_correct_wrong": d_wrg,
                    "passed": passed_b2_m,
                }

            scratch_pass = eval_b2["from_scratch"]["passed"]
            curr_pass = eval_b2["curriculum"]["passed"]
            if scratch_pass and curr_pass:
                b2_class = "DIRECTLY_LEARNABLE"
            elif curr_pass and not scratch_pass:
                b2_class = "CURRICULUM_DEPENDENT"
            else:
                b2_class = "BINDING_NOT_ESTABLISHED_AT_B2"

            seed_result["levels"]["B2"] = {
                "comparison": eval_b2,
                "curriculum_classification": b2_class,
                "passed": scratch_pass or curr_pass,
            }

            # ---------------------------------------------------------------
            # STOPPING RULE: B3, B4, B5
            # ---------------------------------------------------------------
            if not (scratch_pass or curr_pass):
                seed_result["status"] = "STOPPED_AT_B2"
                seed_result["stop_reason"] = "Level B2 failed foundational causal contrast threshold (delta < 0.10)"
                for lvl in ("B3", "B4", "B5"):
                    seed_result["levels"][lvl] = {"status": "STOPPED_AT_B2_UNREACHED"}
            else:
                seed_result["status"] = "ADVANCED_PAST_B2"

            all_ladder_results[cfg_id][str(seed)] = seed_result
            write_json(RUN_ROOT / f"phase_b_{cfg_id}_seed{seed}.json", seed_result)

    summary = {
        "phase": "phase-b",
        "authorization": "USER_EXPLICIT_PHASE_B_ONLY",
        "frozen_configurations": frozen_configs,
        "seeds": list(seeds),
        "scale": scale,
        "results": all_ladder_results,
        "confirmation_seeds_accessed": False,
        "locked_test_accessed": False,
        "phases_c_through_f_executed": False,
    }
    summary["summary_sha256"] = sha256_json(summary)
    write_json(EXPERIMENT_ROOT / "phase_b_ladder_summary.json", summary)

    return {
        "summary": summary,
    }


def build_amendment_experiment_matrix() -> Dict[str, Any]:
    matrix = {
        "amendment_version": "V10.10-SPEC-AMENDMENT-01",
        "benchmark_version": BENCHMARK_VERSION,
        "frozen_root_seeds": {
            "development": list(DEVELOPMENT_SEEDS),
            "confirmation": list(CONFIRMATION_SEEDS),
        },
        "serializations": list(SERIALIZATIONS),
        "queries": list(QUERY_FORMATS),
        "levels": list(LEVELS),
        "models": {
            "L0": {"params": 37_632, "fingerprint": "V10.10-A01-L0-h32-L2-a2-d16-ff128-v128-c256-preLN-GELU-tied-noLMbias"},
            "L1": {"params": 224_128, "fingerprint": "V10.10-A01-L1-h64-L4-a4-d16-ff256-v128-c256-preLN-GELU-tied-noLMbias"},
        },
        "optimization_grid": {
            "learning_rates": list(LR_GRID),
            "step_checkpoints": list(STEP_GRID),
            "batch_size": 128,
            "max_steps": 64,
        },
        "controls": {
            "primary_absent": "absent_unpaired",
            "secondary_absent": "absent_placeholder",
            "stronger_of_allowed": False,
        },
        "gates": ["G0", "G1", "G2", "G3", "G4", "G5", "G6"],
        "precedence_classifications": list(CLASSIFICATIONS),
        "status": "APPROVED_SPECIFICATION_CAMPAIGN_NOT_RUN",
    }
    matrix["matrix_sha256"] = sha256_json(matrix)
    return matrix


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument(
        "--phase",
        choices=["plan", "build-benchmark", "verify-benchmark", "legacy", "train", "phase-a", "ladder", "optimization", "capacity", "gate"],
        default="plan",
    )
    p.add_argument("--execute", action="store_true", help="Execute phase action")
    p.add_argument("--run-id", default="manual_run")
    p.add_argument("--level", choices=LEVELS, default="B2")
    p.add_argument("--serialization", choices=SERIALIZATIONS, default="S1")
    p.add_argument("--query-format", choices=QUERY_FORMATS, default="Q1")
    p.add_argument("--scale", choices=ALLOWED_SCALES, default="L1")
    p.add_argument("--peak-lr", type=float, default=0.001)
    p.add_argument("--batch-size", type=int, default=128)
    p.add_argument("--steps", type=int, default=64)
    p.add_argument("--seed", type=int, default=104729)
    p.add_argument("--eval-count", type=int, default=1_000)
    p.add_argument("--benchmark-count", type=int, default=1_000)
    return p.parse_args()


def main() -> int:
    args = parse_args()
    ensure_dirs()
    snapshot = capture_initial_protected_scope()
    assert_initial_protected_scope_clean(snapshot)

    plan = default_study_plan()
    plan["study_plan_sha256"] = sha256_json(plan)
    write_json(PLAN_PATH, plan)
    write_json(EXPERIMENT_ROOT / "amendment_01_study_plan.json", plan)

    matrix = build_amendment_experiment_matrix()
    write_json(MATRIX_PATH, matrix)
    write_json(EXPERIMENT_ROOT / "amendment_01_experiment_matrix.json", matrix)

    try:
        with OfflineNetworkGuard() as network:
            if args.phase == "plan":
                print(json.dumps({
                    "study_plan": str(PLAN_PATH),
                    "experiment_matrix": str(MATRIX_PATH),
                    "amendment_version": "V10.10-SPEC-AMENDMENT-01",
                    "status": "APPROVED_SPECIFICATION_AWAITING_SCIENTIFIC_AUTHORIZATION",
                    "phases_a_through_f": "STRICTLY_BLOCKED",
                }, indent=2))

            elif args.phase == "build-benchmark":
                # Implementation fixture generation only
                gen = BindingBenchmarkGenerator()
                sets = gen.generate_split(args.level, "development", DEVELOPMENT_SEEDS[0], args.benchmark_count, args.serialization, args.query_format)
                audit = audit_split(sets)
                print(json.dumps({
                    "benchmark_level": args.level,
                    "seed": DEVELOPMENT_SEEDS[0],
                    "count": len(sets),
                    "audit": audit,
                }, indent=2))

            elif args.phase == "verify-benchmark":
                if (BENCHMARK_ROOT / "benchmark_manifest.json").exists():
                    res = verify_benchmark_manifest(BENCHMARK_ROOT / "benchmark_manifest.json")
                    print(json.dumps(res, indent=2))
                else:
                    print(json.dumps({"status": "LEGACY_MANIFEST_RETIRED_UNDER_AMENDMENT_01"}, indent=2))

            elif args.phase == "legacy":
                if not args.execute:
                    raise RuntimeError("Legacy replay requires --execute")
                result = run_legacy_continuity()
                print(json.dumps(result, indent=2))
                if not result["passed"]:
                    return 3

            elif args.phase == "phase-a":
                result = run_phase_a(execute=args.execute, seed=args.seed, scale=args.scale)
                print(json.dumps(result, indent=2))

            elif args.phase == "ladder":
                result = run_phase_b(execute=args.execute, scale=args.scale, seeds=DEVELOPMENT_SEEDS)
                print(json.dumps(result, indent=2))

            elif args.phase in {"train", "optimization", "capacity", "gate"}:
                # Scientific training blocked under amendment boundary!
                raise RuntimeError(
                    f"SCIENTIFIC EXECUTION BLOCKED: Phase '{args.phase}' is strictly unauthorized "
                    "under the V10.10-SPEC-AMENDMENT-01 implementation boundary. "
                    "Phases C-F require separate explicit user authorization."
                )

            if network.attempts:
                raise RuntimeError(f"Network audit failed: {network.attempts}")
    finally:
        snapshot.assert_unchanged(ROOT)
        final = ProtectedScopeSnapshot.capture(ROOT)
        write_json(EXPERIMENT_ROOT / "protected_scope_final.json", {**asdict(final), "unchanged_from_initial": final == snapshot})
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
