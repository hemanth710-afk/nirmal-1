import sys
import time
import json
import torch
from pathlib import Path
import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from training.evaluation.v10_2_harness import CapacityBuilder, save_manifest, TaskConfig, aggregate_results
from training.evaluation.v10_3_harness import (
    V10_3_TaskGenerator, relational_consistency_loss, contrastive_isomorphic_loss, acc
)

OUT = Path("experiments/v10_3")
OUT.mkdir(parents=True, exist_ok=True)

STEPS = 100
SEEDS = [42, 43, 44]
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# We will use L0 for rapid algorithmic iteration as established in V10.3 spec
CAPACITY = "L0"
VOCAB_SIZE = 150

def run_intervention(intervention: str, seed: int):
    torch.manual_seed(seed)
    gen = V10_3_TaskGenerator()
    
    # We test on Fully-Disjoint OOD (surface 9, [135, 145])
    ood_cfg = TaskConfig("increment", 3, (135, 145), (135, 145), (135, 145), 16, seed)
    ood_data = gen.generate(ood_cfg)["train"].to(DEVICE)
    
    # Baseline surface (surface 0, [0, 10])
    base_cfg = TaskConfig("increment", 3, (0, 10), (0, 10), (0, 10), 16, seed)
    base_data = gen.generate(base_cfg)["train"].to(DEVICE)
    
    # Validation data (surface 0)
    val_cfg = TaskConfig("increment", 3, (0, 10), (0, 10), (0, 10), 16, seed + 100)
    val_data = gen.generate(val_cfg)["train"].to(DEVICE)
    
    model = CapacityBuilder.build(CAPACITY, vocab=VOCAB_SIZE).to(DEVICE)
    opt = torch.optim.AdamW(model.parameters(), lr=5e-3)
    
    # Scaffold-On refers to the training process itself containing auxiliary losses/data
    for step in range(STEPS):
        model.train()
        opt.zero_grad()
        loss = 0.0
        
        if "diversity" in intervention:
            div_data = gen.generate_diversity("increment", 8, 3, 16, seed + step)
            surfaces = [s.to(DEVICE) for s in div_data["train_surfaces"]]
            # Train on all 8 surfaces
            for s in surfaces:
                loss += model(input_ids=s, labels=s).loss
            loss = loss / 8.0
            
            main_batch = surfaces[0] # use first surface for relational/contrastive reference
            second_batch = surfaces[1]
        elif intervention == "curriculum":
            curr = [s.to(DEVICE) for s in gen.generate_curriculum(16, seed + step)]
            idx = min(step // (STEPS // len(curr)), len(curr) - 1)
            main_batch = curr[idx]
            loss += model(input_ids=main_batch, labels=main_batch).loss
            second_batch = curr[(idx+1)%len(curr)]
        else:
            rng = torch.Generator().manual_seed(seed + step)
            base_inputs = torch.randint(0, 10, (16, 3), generator=rng)
            main_batch = gen._apply_rule(base_inputs, "increment").to(DEVICE)
            loss += model(input_ids=main_batch, labels=main_batch).loss
            
            second_inputs = torch.randint(15, 25, (16, 3), generator=rng)
            second_batch = gen._apply_rule(second_inputs, "increment").to(DEVICE)

        # Auxiliary objectives
        if "relational" in intervention:
            loss += 0.5 * relational_consistency_loss(model, main_batch, second_batch)
            
        if "contrastive" in intervention:
            cp = gen.generate_contrastive_pairs(16, 3, seed + step)
            loss += 0.5 * contrastive_isomorphic_loss(
                model, cp["pos_a"].to(DEVICE), cp["pos_b"].to(DEVICE),
                cp["neg_a"].to(DEVICE), cp["neg_b"].to(DEVICE)
            )
            
        loss.backward()
        opt.step()

    # SCAFFOLD-OFF EVALUATION (Experiment F constraint)
    # The evaluation uses exactly `acc` which is purely ordinary inference on OOD tokens, no auxiliary losses.
    
    t_a = acc(model, base_data)
    v_a = acc(model, val_data)
    o_a = acc(model, ood_data)
    
    return {
        "intervention": intervention,
        "seed": seed,
        "train_acc": t_a,
        "val_acc": v_a,
        "ood_acc": o_a,
    }

def main():
    print("=== V10.3 Algorithmic Representation Discovery ===")
    results = {}
    
    interventions = [
        "E1_baseline",
        "E2_diversity",
        "E3_relational",
        "E4_contrastive",
        "E5_diversity_relational",
        "E6_diversity_contrastive",
        "E7_diversity_relational_contrastive",
        "E8_curriculum"
    ]
    
    for inv in interventions:
        print(f"Running {inv}...")
        inv_res = []
        for seed in SEEDS:
            print(f"  Seed {seed}...")
            r = run_intervention(inv, seed)
            inv_res.append(r)
            
        results[inv] = {
            "train": aggregate_results([x["train_acc"] for x in inv_res]),
            "val": aggregate_results([x["val_acc"] for x in inv_res]),
            "ood": aggregate_results([x["ood_acc"] for x in inv_res]),
        }
        print(f"  OOD: {results[inv]['ood']['mean']*100:.2f}%")

    ts = int(time.time())
    save_manifest(OUT / f"v10_3_results_{ts}.json", results)
    print("Done! Results saved.")

if __name__ == "__main__":
    main()
