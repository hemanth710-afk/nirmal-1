"""Auto-populates docs/V10_8_LEARNING_TO_LEARN_RULE_INDUCTION_STUDY.md from JSON results."""

import json
from pathlib import Path

OUT_DIR = Path("experiments/v10_8")
REPORT_PATH = Path("docs/V10_8_LEARNING_TO_LEARN_RULE_INDUCTION_STUDY.md")


def load_results() -> dict:
    files = sorted(OUT_DIR.glob("v10_8_results_*.json"))
    if not files:
        raise FileNotFoundError("No V10.8 results JSON found.")
    return json.loads(files[-1].read_text(encoding="utf-8"))


def fmt_pct(stat: dict) -> str:
    if not isinstance(stat, dict) or "mean" not in stat:
        return "N/A"
    return f"{stat['mean']*100:.2f}% +/- {stat['ci95']*100:.2f}%"


def fill():
    data = load_results()
    text = REPORT_PATH.read_text(encoding="utf-8")

    # Benchmark SHA
    sha = data.get("benchmark_sha256", "N/A")
    text = text.replace("{BENCHMARK_SHA}", sha)

    conditions = ["BASELINE", "META-1", "META-2", "META-3", "CAPACITY_L1"]

    # 1. Levels Table (L1 - L5)
    lvl_rows = [
        "| Condition | Scale | Params | L1 (Unseen Sym) | L2 (Unseen Param) | L3 (Held-Out Fam Known) | L4 (Held-Out Fam Unseen) | L5 (Composed) |",
        "|---|---|---|---|---|---|---|---|",
    ]
    for cond in conditions:
        if cond in data["conditions"]:
            c_data = data["conditions"][cond]
            lvl = c_data["agg_levels"]
            lvl_rows.append(
                f"| **{cond}** | {c_data['scale']} | {c_data['param_count']:,} "
                f"| {fmt_pct(lvl['L1'])} | {fmt_pct(lvl['L2'])} | {fmt_pct(lvl['L3'])} | {fmt_pct(lvl['L4'])} | {fmt_pct(lvl['L5'])} |"
            )
    text = text.replace("{LEVELS_TABLE}", "\n".join(lvl_rows))

    # 2. Demonstration Curves Table (Correct support across k)
    demo_rows = [
        "| Condition | k=0 | k=1 | k=2 | k=4 | k=8 | k=16 | Context Gain (k16 - k0) |",
        "|---|---|---|---|---|---|---|---|",
    ]
    for cond in conditions:
        if cond in data["conditions"]:
            c_data = data["conditions"][cond]
            curve = c_data["agg_demo_curves"]["correct"]
            k0 = curve["0"]["mean"]
            k16 = curve["16"]["mean"]
            gain = k16 - k0
            demo_rows.append(
                f"| **{cond}** | {fmt_pct(curve['0'])} | {fmt_pct(curve['1'])} | {fmt_pct(curve['2'])} "
                f"| {fmt_pct(curve['4'])} | {fmt_pct(curve['8'])} | {fmt_pct(curve['16'])} | {gain*100:+.2f}% |"
            )
    text = text.replace("{DEMO_CURVES_TABLE}", "\n".join(demo_rows))

    # 3. Controls Table
    ctrl_rows = [
        "| Condition | Correct Support | Random Support | Wrong-Rule Support | Label-Noise (20%) | Support Utility |",
        "|---|---|---|---|---|---|",
    ]
    for cond in conditions:
        if cond in data["conditions"]:
            c_data = data["conditions"][cond]
            ctrl = c_data["agg_controls"]
            c_corr = ctrl["correct"]["mean"]
            c_rand = ctrl["random"]["mean"]
            util = c_corr - c_rand
            ctrl_rows.append(
                f"| **{cond}** | {fmt_pct(ctrl['correct'])} | {fmt_pct(ctrl['random'])} "
                f"| {fmt_pct(ctrl['wrong_rule'])} | {fmt_pct(ctrl['label_noise'])} | {util*100:+.2f}% |"
            )
    text = text.replace("{CONTROLS_TABLE}", "\n".join(ctrl_rows))

    # 4. Classifications
    cls_lines = []
    for cond in conditions:
        if cond in data["conditions"]:
            c_data = data["conditions"][cond]
            tags = ", ".join([f"`{t}`" for t in c_data["classifications"]])
            cls_lines.append(f"- **{cond}:** {tags}")
    text = text.replace("{CLASSIFICATIONS_SUMMARY}", "\n".join(cls_lines))

    REPORT_PATH.write_text(text, encoding="utf-8")
    print(f"Report populated successfully: {REPORT_PATH}")


if __name__ == "__main__":
    fill()
