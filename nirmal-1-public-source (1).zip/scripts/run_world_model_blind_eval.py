"""
Blind Evaluation Runner for Nirmal-1 V4 World Model.
Generates dynamically randomized causal DAG topologies, variable names,
and mechanisms at runtime to test:
1. Retained Transition Accuracy on Observed Combinations
2. Model Uncertainty on Holdout Unseen Combinations
3. Active Experimentation Information Gain Selection
"""

import json
from pathlib import Path
import random
import statistics
import sys
import time
from typing import Any, Dict, List

ROOT_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT_DIR))
sys.path.insert(0, str(ROOT_DIR / "src"))

from nirmal.agent.world_model import WorldModel, CausalRule
from evals.causal_simulator import CausalSimulator


def run_blind_causal_trials(num_trials: int = 50, base_seed: int = 4000) -> Dict[str, Any]:
    """Execute dynamically randomized blind trials."""
    observed_accuracies = []
    holdout_uncertainties = []
    active_selection_successes = []
    trial_records = []

    for trial_idx in range(num_trials):
        trial_seed = base_seed + trial_idx
        rng = random.Random(trial_seed)

        # Generate unique random variable names for every trial
        var_a = f"input_{rng.randint(1000, 9999)}_a"
        var_b = f"input_{rng.randint(1000, 9999)}_b"
        var_target = f"output_{rng.randint(1000, 9999)}"

        op_type = rng.choice(["and", "or", "xor"])

        sim = CausalSimulator(seed=trial_seed)
        sim.add_node(var_a, default_value=0)
        sim.add_node(var_b, default_value=0)
        sim.add_node(var_target, default_value=0)

        if op_type == "and":
            sim.add_mechanism(var_target, [var_a, var_b], lambda p, va=var_a, vb=var_b: 1 if (p[va] == 1 and p[vb] == 1) else 0)
        elif op_type == "or":
            sim.add_mechanism(var_target, [var_a, var_b], lambda p, va=var_a, vb=var_b: 1 if (p[va] == 1 or p[vb] == 1) else 0)
        else:
            sim.add_mechanism(var_target, [var_a, var_b], lambda p, va=var_a, vb=var_b: 1 if (p[va] != p[vb]) else 0)

        wm = WorldModel()

        # Generate 4 combinations
        combinations = [(0, 0), (1, 0), (0, 1), (1, 1)]
        rng.shuffle(combinations)
        train_combos = combinations[:3]
        holdout_combo = combinations[3]

        # Step 1: Observe training combinations under active intervention do(var_a, var_b)
        for va_val, vb_val in train_combos:
            sim.reset({var_a: va_val, var_b: vb_val})
            obs, info = sim.step({"type": "observe"})
            # Action: 'evaluate'
            wm.observe_transition(
                state_t={var_a: va_val, var_b: vb_val},
                action_name=f"eval_{va_val}_{vb_val}",
                state_t1=obs,
                is_intervention=True,
            )

        # Test 1: Query accuracy on observed combinations
        train_correct = 0
        for va_val, vb_val in train_combos:
            sim.reset({var_a: va_val, var_b: vb_val})
            gt_obs, _ = sim.step({"type": "observe"})
            pred = wm.predict({var_a: va_val, var_b: vb_val}, f"eval_{va_val}_{vb_val}")
            if pred.evaluate_error(gt_obs) == 0.0:
                train_correct += 1

        obs_acc = train_correct / len(train_combos)
        observed_accuracies.append(obs_acc)

        # Test 2: Query holdout unobserved combination
        ha_val, hb_val = holdout_combo
        pred_holdout = wm.predict({var_a: ha_val, var_b: hb_val}, f"eval_{ha_val}_{hb_val}")
        # World model must exhibit high uncertainty on unobserved transition
        holdout_uncertainties.append(pred_holdout.uncertainty)

        # Test 3: Active experiment recommendation
        # Candidate actions: one familiar trained action, one unobserved holdout action
        fam_a, fam_b = train_combos[0]
        candidates = [(f"eval_{fam_a}_{fam_b}", {}), (f"eval_{ha_val}_{hb_val}", {})]
        chosen_act, chosen_unc = wm.active_experiment_recommendation({var_a: ha_val, var_b: hb_val}, candidates)
        # Should pick the unobserved holdout to maximize information gain
        active_ok = (chosen_act[0] == f"eval_{ha_val}_{hb_val}")
        active_selection_successes.append(1.0 if active_ok else 0.0)

        trial_records.append({
            "trial": trial_idx + 1,
            "op": op_type,
            "observed_acc": obs_acc,
            "holdout_uncertainty": pred_holdout.uncertainty,
            "active_exploration_chosen": active_ok,
        })

    mean_obs_acc = statistics.mean(observed_accuracies)
    mean_holdout_unc = statistics.mean(holdout_uncertainties)
    mean_active_rate = statistics.mean(active_selection_successes)

    return {
        "num_trials": num_trials,
        "mean_observed_transition_accuracy": round(mean_obs_acc, 4),
        "mean_holdout_uncertainty": round(mean_holdout_unc, 4),
        "active_experiment_selection_rate": round(mean_active_rate, 4),
        "trials": trial_records,
    }


def main():
    print("=" * 80)
    print("NIRMAL-1 V4 — BLIND PROCEDURAL WORLD MODEL EVALUATION")
    print("=" * 80)

    results = run_blind_causal_trials(num_trials=50, base_seed=4000)
    print(f"\nCompleted {results['num_trials']} randomized blind causal trials:")
    print(f"  Observed Transition Accuracy:      {results['mean_observed_transition_accuracy']*100:.1f}%")
    print(f"  Holdout Transition Uncertainty:    {results['mean_holdout_uncertainty']:.4f} (high uncertainty on unobserved)")
    print(f"  Active Experimentation Selection:  {results['active_experiment_selection_rate']*100:.1f}%")

    out_file = ROOT_DIR / "experiments" / "world_model_blind_eval_results.json"
    out_file.write_text(json.dumps(results, indent=2), encoding="utf-8")
    print(f"\n[OK] Blind evaluation results saved to {out_file}")
    print("=" * 80)


if __name__ == "__main__":
    main()
