import json
from pathlib import Path
import time

OUT = Path("experiments/v10_3")
REPORT = Path("docs/V10_3_ALGORITHMIC_REPRESENTATION_DISCOVERY_STUDY.md")

def wait_for_results():
    while True:
        files = list(OUT.glob("v10_3_results_*.json"))
        if files:
            files.sort()
            return json.loads(files[-1].read_text())
        print("Waiting for results...")
        time.sleep(5)

def format_acc(res):
    if res is None: return "N/A"
    return f"{res['mean']*100:.2f}% ± {res['ci95']*100:.2f}%"

def fill_report():
    data = wait_for_results()
    text = REPORT.read_text()
    
    interventions = [
        ("E1_baseline", "E1"),
        ("E2_diversity", "E2"),
        ("E3_relational", "E3"),
        ("E4_contrastive", "E4"),
        ("E5_diversity_relational", "E5"),
        ("E6_diversity_contrastive", "E6"),
        ("E7_diversity_relational_contrastive", "E7"),
        ("E8_curriculum", "E8")
    ]
    
    for key, prefix in interventions:
        if key in data:
            text = text.replace(f"{{{prefix}_train}}", format_acc(data[key].get("train")))
            text = text.replace(f"{{{prefix}_val}}", format_acc(data[key].get("val")))
            text = text.replace(f"{{{prefix}_ood}}", format_acc(data[key].get("ood")))
            
    # Calculate primary failure
    e1_ood = data.get("E1_baseline", {}).get("ood", {}).get("mean", 0.0)
    best_ood = max([data.get(k[0], {}).get("ood", {}).get("mean", 0.0) for k in interventions])
    
    if best_ood >= 0.8:
        cls = "ROBUST_ALGORITHMIC_INVARIANCE"
        rec = "Advance to production-scale evaluation."
    elif best_ood > e1_ood + 0.1:
        cls = "SURFACE_DIVERSITY_SIGNAL"
        rec = "Signal detected. Requires hyperparameter sweeps and scale validation."
    else:
        cls = "NO_INTERNALIZED_INVARIANCE_DETECTED"
        rec = "Algorithmic interventions failed to induce representation abstraction. Rethink fundamentally."
        
    text = text.replace("[PENDING CLASSIFICATION]", f"**{cls}**\n\nThe most effective algorithmic interventions peaked at {best_ood*100:.2f}% OOD accuracy. Compared to the E1 baseline of {e1_ood*100:.2f}%, this indicates: {cls}.")
    text = text.replace("[PENDING]", f"**Recommendation:** {rec}")
    
    REPORT.write_text(text)
    print("Report populated successfully.")

if __name__ == "__main__":
    fill_report()
