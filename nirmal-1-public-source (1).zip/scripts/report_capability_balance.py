import json
import argparse
from pathlib import Path

def generate_report(data_dir: Path):
    taxonomy_path = data_dir / "capability_taxonomy.json"
    taxonomy = {}
    if taxonomy_path.exists():
        with open(taxonomy_path, "r", encoding="utf-8") as f:
            taxonomy = json.load(f).get("categories", {})
            
    # Load analysis results
    report_path = data_dir / "capability_analysis" / "capability_report.json"
    if not report_path.exists():
        print("No capability report found at", report_path)
        return
        
    with open(report_path, "r", encoding="utf-8") as f:
        report = json.load(f)
        
    print(f"{'CAPABILITY':<30} | {'TOKENS':<15} | {'PERCENT':<10} | {'STATUS':<15}")
    print("-" * 75)
    
    tokens_by_cap = report.get("tokens_by_capability", {})
    pct_by_cap = report.get("percentage_by_capability", {})
    
    for cap, tokens in sorted(tokens_by_cap.items(), key=lambda x: x[1], reverse=True):
        pct = pct_by_cap.get(cap, 0.0)
        status = taxonomy.get(cap, {}).get("type", "UNKNOWN")
        print(f"{cap:<30} | {tokens:<15} | {pct:>6.2f}%   | {status:<15}")
        
    print("-" * 75)
    print(f"AGI_ORIENTED_SHARE:    {report.get('AGI_ORIENTED_SHARE', 0.0):.2f}%")
    print(f"CONVENTIONAL_AI_SHARE: {report.get('CONVENTIONAL_AI_SHARE', 0.0):.2f}%")
    print(f"UNKNOWN_SHARE:         {report.get('UNKNOWN_SHARE', 0.0):.2f}%")
    print("-" * 75)
    print("DOCUMENTS:", report.get("total_documents", 0)) # assuming total_docs is added to report
    
    source_contrib = report.get("source_contribution", {})
    print("SOURCE_COUNT:", len(source_contrib))
    
    quality_dist = report.get("quality_distribution", {})
    print("QUALITY:", quality_dist)

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Generate Capability Balance Report")
    parser.add_argument("--data-dir", type=str, default="data", help="Path to data directory")
    args = parser.parse_args()
    
    generate_report(Path(args.data_dir))
