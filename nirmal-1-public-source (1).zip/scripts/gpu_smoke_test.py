"""
Real GPU Smoke Test for Nirmal-1 on Local Hardware.

Validates the actual Nirmal-1 architecture (DeltaNet, GQA, MoE, CausalLM) on CUDA:
1. Environment & Hardware Probe (Device, Compute Capability, Total VRAM)
2. Safety Safeguards (Rejects large-scale models, catches CUDA OOM)
3. Model Instantiation on CUDA
4. Forward Pass with Loss Computation
5. Backward Pass (Autograd Gradient Flow)
6. Optimizer Step (AdamW)
7. CUDA Synchronization & Memory Telemetry (Allocated, Reserved, Peak)
8. Clean Memory Release & Exit Status

IMPORTANT DISCLAIMER:
Passing this smoke test confirms that the implemented Nirmal-1 neural code path
executes correctly on CUDA without CPU fallbacks or runtime exceptions.
It does NOT imply that the 25.91B parameter production model can train on this device.
"""

import os
from pathlib import Path
import sys
import time
import torch
import torch.nn as nn

# Ensure project root and src/ are in sys.path
REPO_ROOT = Path(__file__).resolve().parent.parent
SRC_DIR = REPO_ROOT / "src"
for p in (str(SRC_DIR), str(REPO_ROOT)):
    if p not in sys.path:
        sys.path.insert(0, p)

from nirmal.configuration_nirmal import NirmalConfig
from nirmal.model import NirmalForCausalLM


def run_gpu_smoke_test() -> bool:
    print("=" * 80)
    print("NIRMAL-1: REAL GPU SMOKE TEST & CUDA VALIDATION")
    print("=" * 80)

    # 1. Environment & GPU Probe
    print("\n[STEP 1] PROBING PYTORCH & CUDA SUBSYSTEM...")
    print(f"PyTorch Version:         {torch.__version__}")
    print(f"CUDA Available:          {torch.cuda.is_available()}")

    if not torch.cuda.is_available():
        print("\n[ERROR] CUDA is not available. Smoke test aborted.")
        return False

    device_count = torch.cuda.device_count()
    device_idx = 0
    device = torch.device(f"cuda:{device_idx}")
    device_name = torch.cuda.get_device_name(device_idx)
    props = torch.cuda.get_device_properties(device_idx)
    total_vram_gb = props.total_memory / (1024 ** 3)
    compute_cap = f"{props.major}.{props.minor}"

    print(f"Device Index:            {device_idx}")
    print(f"Device Name:             {device_name}")
    print(f"Compute Capability:      {compute_cap}")
    print(f"Total GPU VRAM:          {total_vram_gb:.2f} GB")

    # 2. Safety Safeguards
    print("\n[STEP 2] ENFORCING SAFETY SAFEGUARDS...")
    # Refuse any configuration attempting production scale
    MAX_ALLOWED_TEST_PARAMS = 50_000_000  # 50M parameter ceiling for local smoke test

    # Define a tiny test configuration exercising ALL components:
    # - Layer 0: DeltaNet + SparseMoE
    # - Layer 1: Causal GQA with RoPE + SparseMoE
    test_config = NirmalConfig(
        vocab_size=256,
        hidden_size=64,
        num_hidden_layers=2,
        num_attention_heads=2,
        num_key_value_heads=1,
        head_dim=32,
        context_length=64,
        intermediate_size=128,
        num_experts=2,
        num_experts_per_tok=1,
        full_attention_interval=2,
        moe_layer_interval=1,
        tie_word_embeddings=False,
    )

    # Estimate parameter count before allocation
    approx_params = (
        test_config.vocab_size * test_config.hidden_size * 2
        + test_config.num_hidden_layers * (
            test_config.hidden_size * test_config.hidden_size * 4
            + test_config.num_experts * test_config.hidden_size * test_config.intermediate_size * 3
        )
    )

    if approx_params > MAX_ALLOWED_TEST_PARAMS:
        print(f"[REJECTED] Model size exceeds local smoke-test safety limit ({approx_params:,} > {MAX_ALLOWED_TEST_PARAMS:,}).")
        return False

    print(f"Target Safety Level:     PASS (Approved for {total_vram_gb:.2f} GB VRAM)")
    print(f"Config Vocab Size:       {test_config.vocab_size}")
    print(f"Config Hidden Size:      {test_config.hidden_size}")
    print(f"Config Layers:           {test_config.num_hidden_layers} (Types: {test_config.layer_types})")
    print(f"Config Attention Heads:  {test_config.num_attention_heads} (KV Heads: {test_config.num_key_value_heads}, Head Dim: {test_config.head_dim})")
    print(f"Config Sparse MoE:       {test_config.num_experts} experts, top-{test_config.num_experts_per_tok} active per token")

    # 3. Model Construction & Transfer to CUDA
    print("\n[STEP 3] CONSTRUCTING REAL NIRMAL-1 MODEL ON CUDA:0...")
    torch.cuda.reset_peak_memory_stats(device_idx)
    start_time = time.perf_counter()

    try:
        model = NirmalForCausalLM(test_config)
        param_counts = model.count_parameters()
        print(f"Total Parameters:        {param_counts['total']:,} ({param_counts['total'] * 4 / (1024**2):.2f} MB in FP32)")
        print(f"Trainable Parameters:    {param_counts['trainable']:,}")

        model = model.to(device)
        print("Model successfully moved to cuda:0.")

        # Verify all parameters reside on CUDA
        all_cuda = all(p.is_cuda for p in model.parameters())
        all_buffers_cuda = all(b.is_cuda for b in model.buffers())
        print(f"All Parameters on CUDA:  {all_cuda}")
        print(f"All Buffers on CUDA:     {all_buffers_cuda}")

        if not (all_cuda and all_buffers_cuda):
            print("[ERROR] Detected parameters or buffers not on CUDA!")
            return False

        # 4. Synthetic Input Batch
        print("\n[STEP 4] CREATING SYNTHETIC BATCH ON CUDA:0...")
        batch_size = 2
        seq_len = 16
        torch.manual_seed(42)
        input_ids = torch.randint(0, test_config.vocab_size, (batch_size, seq_len), device=device, dtype=torch.long)
        labels = input_ids.clone()
        # Set last token of batch 0 to ignore_index
        labels[0, -1] = -100

        print(f"Input IDs Shape:         {tuple(input_ids.shape)} on {input_ids.device}")
        print(f"Labels Shape:            {tuple(labels.shape)} on {labels.device}")

        # 5. Forward Pass
        print("\n[STEP 5] RUNNING FORWARD PASS...")
        model.train()
        outputs = model(input_ids=input_ids, labels=labels)

        logits = outputs.logits
        loss = outputs.loss
        router_loss = outputs.router_loss

        print(f"Forward Output Logits:   {tuple(logits.shape)} on {logits.device}")
        print(f"Router Auxiliary Loss:   {router_loss.item():.6f}")
        print(f"Total Combined Loss:     {loss.item():.6f}")

        # Verify numerical sanity
        if torch.isnan(loss) or torch.isinf(loss):
            print("[ERROR] Forward loss returned NaN or Inf!")
            return False

        # 6. Backward Pass
        print("\n[STEP 6] RUNNING BACKWARD PASS (AUTOGRAD GRADIENT FLOW)...")
        loss.backward()

        # Check gradient presence across parameter groups
        has_grads = []
        for name, param in model.named_parameters():
            if param.requires_grad:
                if param.grad is None:
                    has_grads.append((name, False))
                elif torch.isnan(param.grad).any():
                    print(f"[ERROR] NaN gradient detected in parameter {name}!")
                    return False
                else:
                    has_grads.append((name, True))

        grad_success = all(g[1] for g in has_grads)
        print(f"Gradients Populated:     {grad_success} ({len(has_grads)} trainable tensors verified)")
        if not grad_success:
            missing = [g[0] for g in has_grads if not g[1]]
            print(f"[WARNING] Parameters missing gradients: {missing}")

        # 7. Optimizer Step
        print("\n[STEP 7] EXECUTING OPTIMIZER STEP (ADAMW)...")
        optimizer = torch.optim.AdamW(model.parameters(), lr=1e-3)
        optimizer.step()
        optimizer.zero_grad(set_to_none=True)
        print("Optimizer step completed successfully.")

        # 8. CUDA Synchronization & Memory Telemetry
        print("\n[STEP 8] SYNCHRONIZING CUDA & RECORDING TELEMETRY...")
        torch.cuda.synchronize(device_idx)
        elapsed_sec = time.perf_counter() - start_time

        allocated_mb = torch.cuda.memory_allocated(device_idx) / (1024 ** 2)
        reserved_mb = torch.cuda.memory_reserved(device_idx) / (1024 ** 2)
        peak_allocated_mb = torch.cuda.max_memory_allocated(device_idx) / (1024 ** 2)

        print(f"Execution Wall Time:     {elapsed_sec * 1000:.2f} ms")
        print(f"Current VRAM Allocated:  {allocated_mb:.2f} MB")
        print(f"Current VRAM Reserved:   {reserved_mb:.2f} MB")
        print(f"Peak VRAM Allocated:     {peak_allocated_mb:.2f} MB ({peak_allocated_mb / 1024:.3f} GB)")
        print(f"VRAM Headroom on 6GB:    {(total_vram_gb * 1024 - peak_allocated_mb):.2f} MB")

        # 9. Clean Up
        print("\n[STEP 9] CLEANING UP GPU MEMORY...")
        del model, outputs, logits, loss, router_loss, input_ids, labels, optimizer
        torch.cuda.empty_cache()
        torch.cuda.synchronize(device_idx)
        post_cleanup_allocated = torch.cuda.memory_allocated(device_idx) / (1024 ** 2)
        print(f"VRAM after cleanup:      {post_cleanup_allocated:.2f} MB")

        print("\n" + "=" * 80)
        print("SMOKE TEST RESULT:       PASS")
        print("=" * 80)
        print("All architectural components (DeltaNet, GQA, MoE, CausalLM, Autograd) executed on CUDA.")
        print("Disclaimer: Confirms code compatibility; does NOT claim 25.91B production readiness.")
        print("=" * 80)
        return True

    except torch.cuda.OutOfMemoryError as oom_err:
        print(f"\n[CUDA OOM ERROR] Out of GPU memory: {oom_err}")
        torch.cuda.empty_cache()
        return False
    except Exception as e:
        print(f"\n[UNEXPECTED ERROR] {e}")
        import traceback
        traceback.print_exc()
        return False


if __name__ == "__main__":
    success = run_gpu_smoke_test()
    sys.exit(0 if success else 1)
