"""
Master Joint Launch Readiness Gate & Progress Evaluator for Nirmal-1 V8.4.

Enforces the Joint Launch Readiness Rule:
- DATA_READY: Must have >= 200B verified tokens, 100% permissive licenses, 0 exact dups.
- HARDWARE_READY: Must have verified production cluster (>= 8x H100 80GB GPUs).
- JOINT VERDICT:
  - If BOTH DATA_READY and HARDWARE_READY: "READY"
  - If either is partially ready: "PARTIALLY READY"
  - If both conditions fail: "NO-GO"

Generates:
- experiments/v8_4_data_progress.json
- experiments/v8_4_hardware_status.json
- experiments/v8_4_launch_readiness.json
"""

import argparse
import json
import os
from pathlib import Path
import sys
from typing import Any, Dict, List, Optional

REPO_ROOT = Path(__file__).resolve().parent.parent
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from scripts.count_verified_production_tokens import find_and_count_shards, TARGET_PRODUCTION_TOKENS
from scripts.check_production_data_ready import evaluate_data_readiness
from scripts.check_training_hardware_ready import probe_local_hardware, evaluate_hardware_readiness
from training.cost_model import TrainingCostModel


def run_launch_readiness_audit(output_dir: Optional[Path] = None) -> Dict[str, Any]:
    out_dir = output_dir or (REPO_ROOT / "experiments")
    out_dir.mkdir(parents=True, exist_ok=True)

    print("=" * 80)
    print("NIRMAL-1 V8.4: JOINT PRE-TRAINING LAUNCH READINESS AUDIT")
    print("=" * 80)

    # 1. Evaluate Data Readiness
    print("\n[STAGE 1] EVALUATING PRODUCTION DATA READINESS...")
    data_rep = evaluate_data_readiness()
    print(f"Data Verdict: {data_rep['verdict']} (Verified: {data_rep['metrics']['local_verified_tokens']:,} / Required: {data_rep['metrics']['planned_tokens']:,})")
    for chk, status in data_rep["checks"].items():
        print(f"  - {chk}: {status}")

    # 2. Evaluate Hardware Readiness
    print("\n[STAGE 2] EVALUATING PHYSICAL HARDWARE READINESS...")
    host_info = probe_local_hardware()
    hw_rep = evaluate_hardware_readiness(host_info)
    print(f"Hardware Verdict: {hw_rep['verdict']} (CUDA: {host_info['cuda_available']}, GPUs: {host_info['gpu_count']}, VRAM: {host_info['total_vram_gb']} GB)")
    for chk, status in hw_rep["comparison_checks"].items():
        print(f"  - {chk}: {status}")

    # 3. Evaluate Cloud Cluster Cost & Scaling Model
    print("\n[STAGE 3] EVALUATING CLUSTER TOPOLOGY SCALING & COST PROJECTIONS...")
    cost_model = TrainingCostModel()
    cost_projections = cost_model.evaluate_all_topologies(target_tokens=TARGET_PRODUCTION_TOKENS)
    for p in cost_projections:
        print(f"  Topology: {p['topology_name']:<35} | {p['throughput_tokens_per_sec']:>10,.0f} tok/s | {p['total_training_days']:>5.2f} days | ${p['total_projected_cost_usd']:>10,.2f}")

    # 4. Joint Launch Readiness Gate
    data_ready = data_rep["is_ready"]
    hw_ready = hw_rep["is_ready"]

    if data_ready and hw_ready:
        joint_verdict = "READY"
    elif data_ready or hw_ready:
        joint_verdict = "PARTIALLY READY"
    else:
        joint_verdict = "NO-GO"

    print("\n" + "=" * 80)
    print(f"JOINT LAUNCH VERDICT:    {joint_verdict}")
    print("=" * 80)
    print(f"  DATA_READY:            {data_ready} ({data_rep['verdict']})")
    print(f"  HARDWARE_READY:        {hw_ready} ({hw_rep['verdict']})")
    print("-" * 80)
    print("CRITICAL LAUNCH BLOCKERS:")
    all_blockers = []
    if not data_ready:
        all_blockers.extend(data_rep["blocking_issues"])
    if not hw_ready:
        all_blockers.extend(hw_rep["deficits_and_blockers"])

    for b in all_blockers:
        print(f"  [X] {b}")
    print("=" * 80)

    # 5. Serialize Artifacts
    data_progress_file = out_dir / "v8_4_data_progress.json"
    hw_status_file = out_dir / "v8_4_hardware_status.json"
    launch_gate_file = out_dir / "v8_4_launch_readiness.json"

    with open(data_progress_file, "w", encoding="utf-8") as f:
        json.dump(data_rep, f, indent=2)

    with open(hw_status_file, "w", encoding="utf-8") as f:
        json.dump(hw_rep, f, indent=2)

    joint_summary = {
        "timestamp": "2026-09-06T19:45:00Z",
        "milestone": "NIRMAL-1 V8.4",
        "joint_verdict": joint_verdict,
        "data_ready": data_ready,
        "hardware_ready": hw_ready,
        "all_blockers": all_blockers,
        "data_summary": data_rep["metrics"],
        "hardware_summary": {
            "os": host_info["os"],
            "cuda_available": host_info["cuda_available"],
            "gpu_count": host_info["gpu_count"],
            "total_vram_gb": host_info["total_vram_gb"],
        },
        "cluster_cost_projections": cost_projections,
        "policy": "Launch is PROHIBITED unless BOTH data_ready=True and hardware_ready=True.",
    }

    with open(launch_gate_file, "w", encoding="utf-8") as f:
        json.dump(joint_summary, f, indent=2)

    print(f"\nArtifacts saved successfully:")
    print(f"  - {data_progress_file}")
    print(f"  - {hw_status_file}")
    print(f"  - {launch_gate_file}")

    return joint_summary


def main():
    parser = argparse.ArgumentParser(description="Run Nirmal-1 V8.4 Launch Readiness Gate.")
    parser.add_argument("--output-dir", type=str, default=None, help="Directory to save JSON artifacts.")
    args = parser.parse_args()

    out_p = Path(args.output_dir) if args.output_dir else None
    run_launch_readiness_audit(out_p)


if __name__ == "__main__":
    main()
