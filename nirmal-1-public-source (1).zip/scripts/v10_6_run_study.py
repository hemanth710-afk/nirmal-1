"""V10.6 Symbol/Relation Decoupling Study Runner.

Executes ablations A0–A6 across 3 seeds, Phases 2–9:
  A0: Identity only baseline
  A1: Identity + learned pairwise relation encoder
  A2: Identity + frozen random relation (control)
  A3: Identity + permutation augmentation (no extra channel)
  A4: Identity + relation + permutation augmentation
  A5: Identity + relation + permutation augmentation + consistency objective
  A6: Best candidate with ALL scaffolds removed at eval time
"""

import json
import sys
import time
from pathlib import Path
from typing import Any, Dict, List, Tuple

import numpy as np
import torch
import torch.nn.functional as F

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from training.evaluation.v10_2_harness import CapacityBuilder, aggregate_results, save_manifest
from training.evaluation.v10_6_harness import (
    ALL_RULES, DISJOINT_OOD, HOLDOUT_RULES, TRAIN_RULES, TRAIN_VOCAB,
    DualChannelWrapper, PermutationAugmentor, V10_6_DataBuilder,
    apply_rule, build_ablation_model, permutation_consistency_loss,
    relation_invariance_score, scaffold_off_acc,
)

OUT = Path("experiments/v10_6")
OUT.mkdir(parents=True, exist_ok=True)

STEPS   = 500
SEEDS   = [42, 43, 44]
DEVICE  = torch.device("cuda" if torch.cuda.is_available() else "cpu")
VOCAB   = 250
LEVEL   = "L0"
REL_DIM = 16
BS      = 32


def make_batch(rule: str, vocab_range: Tuple[int, int], seed: int) -> torch.Tensor:
    db = V10_6_DataBuilder(VOCAB)
    return db.make_batch(rule, vocab_range, BS, seed).to(DEVICE)


def train_ablation(ablation: str, seed: int) -> Dict[str, Any]:
    torch.manual_seed(seed)
    model  = build_ablation_model(ablation, vocab_size=VOCAB, level=LEVEL, rel_dim=REL_DIM).to(DEVICE)
    aug    = PermutationAugmentor(rng_seed=seed)
    params = [p for p in model.parameters() if p.requires_grad]
    opt    = torch.optim.AdamW(params, lr=5e-3, weight_decay=1e-4)

    param_count = sum(p.numel() for p in model.parameters())

    for step in range(STEPS):
        model.train()
        opt.zero_grad()

        # Cycle through train rules for diversity
        rule = TRAIN_RULES[step % len(TRAIN_RULES)]
        g = torch.Generator().manual_seed(seed + step)
        db = V10_6_DataBuilder(VOCAB)
        batch = db.make_batch(rule, TRAIN_VOCAB, BS, seed + step).to(DEVICE)

        # Permutation augmentation (A3, A4, A5, A6)
        use_perm = ablation in ("A3", "A4", "A5", "A6")
        aug_batch = None
        if use_perm:
            g2 = torch.Generator(); g2.manual_seed(seed + step + 100000)
            aug_batch = aug.remap(batch, DISJOINT_OOD[0], DISJOINT_OOD[1], rule, g=g2).to(DEVICE)

        # Primary loss
        if ablation == "A3":
            # Identity + perm aug, NO relation encoder → use base model directly
            loss = model.base(input_ids=batch, labels=batch).loss
            if aug_batch is not None:
                loss = loss + model.base(input_ids=aug_batch, labels=aug_batch).loss
        else:
            out  = model(input_ids=batch, labels=batch)
            loss = out.loss
            if aug_batch is not None:
                out2 = model(input_ids=aug_batch, labels=aug_batch)
                loss = loss + out2.loss

        # Permutation consistency objective (A5, A6)
        use_cons = ablation in ("A5", "A6") and aug_batch is not None
        if use_cons:
            cons = permutation_consistency_loss(model, batch, aug_batch)
            loss = loss + 0.1 * cons

        loss.backward()
        torch.nn.utils.clip_grad_norm_(params, 1.0)
        opt.step()

    # ── Evaluation ────────────────────────────────────────────────────────────
    model.eval()
    db = V10_6_DataBuilder(VOCAB)

    result: Dict[str, Any] = {"ablation": ablation, "seed": seed, "param_count": param_count}

    # For A6 (Phase 7): permanently disable consistency + relation for eval
    if ablation == "A6":
        model.use_relation = False  # scaffold removed

    # Per-rule evaluation
    for rule in ALL_RULES:
        train_b = db.make_batch(rule, TRAIN_VOCAB, BS, seed=seed + 9000)
        ood_b   = db.make_batch(rule, DISJOINT_OOD, BS, seed=seed + 9001)
        # Verify leakage
        cert    = db.leakage_certificate(train_b, ood_b)
        assert cert["valid"], f"Leakage failure: {rule}"
        result[f"{rule}_train"] = scaffold_off_acc(model, train_b, train_b, DEVICE)
        result[f"{rule}_ood"]   = scaffold_off_acc(model, ood_b,   ood_b,   DEVICE)

    # Overall aggregates
    train_accs = [result[f"{r}_train"] for r in ALL_RULES]
    ood_accs   = [result[f"{r}_ood"]   for r in ALL_RULES]
    result["mean_train"]      = float(np.mean(train_accs))
    result["mean_ood"]        = float(np.mean(ood_accs))
    result["held_out_mean_ood"] = float(np.mean([result[f"{r}_ood"] for r in HOLDOUT_RULES]))
    result["train_rule_mean_ood"] = float(np.mean([result[f"{r}_ood"] for r in TRAIN_RULES]))

    # Relation invariance diagnostic (only for models with relation encoder)
    if model.relation_encoder is not None and ablation != "A6":
        same_pairs, diff_pairs = [], []
        for _ in range(4):
            sa = db.make_batch("increment",   TRAIN_VOCAB,  BS, seed=_ + 1000)
            sb = db.make_batch("increment",   DISJOINT_OOD, BS, seed=_ + 2000)
            dc = db.make_batch("double_step", DISJOINT_OOD, BS, seed=_ + 3000)
            same_pairs.append((sa.to(DEVICE), sb.to(DEVICE)))
            diff_pairs.append((sa.to(DEVICE), dc.to(DEVICE)))
        inv = relation_invariance_score(model, same_pairs, diff_pairs)
        result["d_same"]         = inv["d_same"]
        result["d_diff"]         = inv["d_diff"]
        result["invariance_gap"] = inv["invariance_gap"]
    else:
        result["d_same"]         = None
        result["d_diff"]         = None
        result["invariance_gap"] = None

    return result


def main():
    print(f"=== V10.6 Symbol/Relation Decoupling Study ===")
    print(f"Device: {DEVICE}, Level: {LEVEL}, Steps: {STEPS}, Seeds: {SEEDS}")

    ablations = ["A0", "A1", "A2", "A3", "A4", "A5", "A6"]
    all_results: Dict[str, Any] = {}

    # Leakage certificate (once)
    db = V10_6_DataBuilder(VOCAB)
    ref_train = db.make_batch("increment", TRAIN_VOCAB, BS, 42)
    ref_ood   = db.make_batch("increment", DISJOINT_OOD, BS, 42)
    cert = db.leakage_certificate(ref_train, ref_ood)
    all_results["leakage"] = cert
    print(f"Leakage certificate: {cert}")

    for ablation in ablations:
        print(f"\n--- Ablation {ablation} ---")
        seed_runs = []
        for seed in SEEDS:
            print(f"  Seed {seed}...", flush=True)
            r = train_ablation(ablation, seed)
            seed_runs.append(r)
            print(f"    mean_ood={r['mean_ood']*100:.2f}%  held_out_ood={r['held_out_mean_ood']*100:.2f}%")

        # Aggregate across seeds
        agg: Dict[str, Any] = {
            "param_count": seed_runs[0]["param_count"],
        }
        for metric in ["mean_train", "mean_ood", "held_out_mean_ood", "train_rule_mean_ood"]:
            agg[metric] = aggregate_results([r[metric] for r in seed_runs])

        for rule in ALL_RULES:
            for split in ["train", "ood"]:
                key = f"{rule}_{split}"
                agg[key] = aggregate_results([r[key] for r in seed_runs])

        # Invariance diagnostics
        for dk in ["d_same", "d_diff", "invariance_gap"]:
            vals = [r[dk] for r in seed_runs if r[dk] is not None]
            agg[dk] = float(np.mean(vals)) if vals else None

        all_results[ablation] = agg
        print(f"  -> Agg mean_ood: {agg['mean_ood']['mean']*100:.2f}% +/- {agg['mean_ood']['ci95']*100:.2f}%")

    # OOD gain over baseline A0
    a0_mean = all_results["A0"]["mean_ood"]["mean"]
    for ab in ablations[1:]:
        gain = all_results[ab]["mean_ood"]["mean"] - a0_mean
        all_results[ab]["ood_gain_over_a0"] = round(gain, 4)

    ts = int(time.time())
    out_path = OUT / f"v10_6_results_{ts}.json"
    save_manifest(out_path, all_results)
    print(f"\nResults saved to: {out_path}")


if __name__ == "__main__":
    main()
