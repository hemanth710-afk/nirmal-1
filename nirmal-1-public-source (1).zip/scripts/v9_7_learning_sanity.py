import json
import time
import hashlib
from pathlib import Path
from typing import Dict, List, Any
import numpy as np
import torch
import torch.nn as nn
from nirmal.configuration_nirmal import NirmalConfig
from nirmal.model import NirmalForCausalLM
import psutil

class ResourceGuard:
    @staticmethod
    def check_safe_to_run(est_vram_mb: int, est_ram_mb: int, est_time_s: int) -> bool:
        mem = psutil.virtual_memory()
        free_ram_mb = mem.available / (1024 * 1024)
        if est_ram_mb > free_ram_mb * 0.8:
            return False
        if est_ram_mb > 4096 or est_time_s > 300:
            return False
        return True

class SanityTaskGenerator:
    def __init__(self, vocab_size=100):
        self.vocab_size = vocab_size
        
    def generate_sequence_copy(self, batch_size=4, seq_len=16, offset=10):
        # Generates a sequence where the second half is a copy of the first half
        half = seq_len // 2
        data = torch.randint(offset, self.vocab_size, (batch_size, half))
        full = torch.cat([data, data], dim=1)
        return full

class LearningSanityEvaluator:
    def __init__(self, seed=42):
        self.seed = seed
        self.config = NirmalConfig(
            vocab_size=100,
            hidden_size=32,
            num_hidden_layers=2,
            num_attention_heads=2,
            head_dim=16,
            num_key_value_heads=1,
            num_experts=2,
            num_experts_per_tok=1,
            full_attention_interval=2,
        )
        self.tasks = ["TASK_A_SEQUENCE_COPY", "TASK_B_SIMPLE_ARITHMETIC", "TASK_C_SYMBOLIC_TRANSFORMATION"]
    
    def evaluate_model_state(self, train_acc: float, val_acc: float, ood_acc: float) -> str:
        if train_acc <= 0.1:
            return "RANDOM"
        elif train_acc > 0.9 and val_acc < 0.2:
            return "OVERFIT"
        elif train_acc > 0.8 and val_acc > 0.8 and ood_acc < 0.5:
            return "PARTIALLY_GENERALIZING"
        elif train_acc > 0.8 and val_acc > 0.8 and ood_acc > 0.8:
            return "GENERALIZING"
        else:
            return "PARTIALLY_TRAINED"

    def run_sanity_training(self):
        torch.manual_seed(self.seed)
        np.random.seed(self.seed)
        
        model = NirmalForCausalLM(self.config)
        optimizer = torch.optim.AdamW(model.parameters(), lr=0.005)
        generator = SanityTaskGenerator()
        
        # Single fixed batch for overfit test
        train_data = generator.generate_sequence_copy(batch_size=8, seq_len=16, offset=10)
        
        metrics = []
        target_steps = [0, 1, 2, 4, 8, 16, 32, 64]
        
        for step in range(65):
            model.train()
            optimizer.zero_grad()
            outputs = model(input_ids=train_data, labels=train_data)
            loss = outputs.loss
            loss.backward()
            
            # Optimization Health Checks
            grad_norm = sum(p.grad.norm().item() for p in model.parameters() if p.grad is not None)
            
            # Update parameters
            optimizer.step()
            
            if step in target_steps:
                model.eval()
                with torch.no_grad():
                    # Train eval
                    train_out = model(input_ids=train_data, labels=train_data)
                    train_preds = torch.argmax(train_out.logits, dim=-1)
                    # Shifted accuracy (next token)
                    train_acc = (train_preds[:, :-1] == train_data[:, 1:]).float().mean().item()
                    
                    # Val eval (new data, same distribution)
                    val_data = generator.generate_sequence_copy(batch_size=8, seq_len=16, offset=10)
                    val_out = model(input_ids=val_data, labels=val_data)
                    val_preds = torch.argmax(val_out.logits, dim=-1)
                    val_acc = (val_preds[:, :-1] == val_data[:, 1:]).float().mean().item()
                    
                    # OOD eval (different offset)
                    ood_data = generator.generate_sequence_copy(batch_size=8, seq_len=16, offset=50)
                    ood_out = model(input_ids=ood_data, labels=ood_data)
                    ood_preds = torch.argmax(ood_out.logits, dim=-1)
                    ood_acc = (ood_preds[:, :-1] == ood_data[:, 1:]).float().mean().item()
                
                metrics.append({
                    "step": step,
                    "loss": loss.item(),
                    "grad_norm": grad_norm,
                    "train_acc": train_acc,
                    "val_acc": val_acc,
                    "ood_acc": ood_acc,
                    "state": self.evaluate_model_state(train_acc, val_acc, ood_acc)
                })
        
        return metrics

if __name__ == "__main__":
    if ResourceGuard.check_safe_to_run(0, 500, 60):
        evaluator = LearningSanityEvaluator()
        results = evaluator.run_sanity_training()
        for r in results:
            print(f"Step {r['step']:02d} | Loss: {r['loss']:.4f} | GradNorm: {r['grad_norm']:.4f} | "
                  f"Train Acc: {r['train_acc']:.4f} | Val Acc: {r['val_acc']:.4f} | State: {r['state']}")
        
        final_state = results[-1]['state']
        if final_state in ["OVERFIT", "PARTIALLY_GENERALIZING", "GENERALIZING"]:
            print("\nCONCLUSION: MINIMUM_LEARNABLE_LOCAL_SCALE found. (CASE 1: Sanity tasks learn, capability tasks remain at floor).")
        else:
            print("\nCONCLUSION: TRAINING_PIPELINE_LEARNING_FAILURE. (CASE 2: Sanity tasks also fail).")
