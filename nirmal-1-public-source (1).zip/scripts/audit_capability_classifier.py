import argparse
import json
from training.acquisition.capability_classifier import CapabilityClassifier
from pathlib import Path

def run_audit():
    classifier = CapabilityClassifier(Path("data/capability_taxonomy.json"))
    
    fixtures = [
        {
            "text": "Consider the following proof: \\begin{equation} x = 1 \\end{equation}. Hence the theorem is proved.",
            "meta": {"url": "arxiv.org/abs/math"},
            "expected": ["mathematical reasoning"]
        },
        {
            "text": "def calculate_sum(a, b):\n    return a + b\nimport math",
            "meta": {"source_id": "github"},
            "expected": ["programming"]
        },
        {
            "text": "user: How do I boil an egg? assistant: Boil water, then put the egg in for 7 minutes.",
            "meta": {},
            "expected": ["conventional dialogue"]
        },
        {
            "text": "Random unknown content that does not map to anything.",
            "meta": {},
            "expected": ["UNKNOWN"]
        }
    ]
    
    total = len(fixtures)
    correct = 0
    unknowns = 0
    multi_labels = 0
    
    print("==================================================")
    print("CAPABILITY CLASSIFIER AUDIT")
    print("==================================================")
    
    for idx, f in enumerate(fixtures):
        labels, conf = classifier.classify_document(f["text"], f["meta"])
        
        # Calculate match
        matched = set(labels) == set(f["expected"])
        if matched:
            correct += 1
            
        if "UNKNOWN" in labels:
            unknowns += 1
            
        if len(labels) > 1 and "UNKNOWN" not in labels:
            multi_labels += 1
            
        # Ablations
        labels_text, _ = classifier.classify_document(f["text"], {})
        labels_meta, _ = classifier.classify_document("", f["meta"])
        
        print(f"Fixture {idx}:")
        print(f"  Expected: {f['expected']}")
        print(f"  Full:     {labels} ({conf})")
        print(f"  Text Only:{labels_text}")
        print(f"  Meta Only:{labels_meta}")
        print()
        
    precision = correct / total if total > 0 else 0
    recall = precision # Simplified for exact match
    coverage = (total - unknowns) / total if total > 0 else 0
    unknown_rate = unknowns / total if total > 0 else 0
    multi_rate = multi_labels / total if total > 0 else 0
    
    print("==================================================")
    print("METRICS:")
    print(f"Precision:      {precision:.2f}")
    print(f"Recall:         {recall:.2f}")
    print(f"Coverage:       {coverage:.2f}")
    print(f"Unknown Rate:   {unknown_rate:.2f}")
    print(f"Multi-label Rate:{multi_rate:.2f}")
    print("==================================================")
    
if __name__ == "__main__":
    run_audit()
