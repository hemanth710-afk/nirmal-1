import sys
import time
import json
import torch
import torch.nn.functional as F
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from training.evaluation.v10_2_harness import CapacityBuilder, save_manifest, TaskConfig, aggregate_results
from training.evaluation.v10_3_harness import V10_3_TaskGenerator
from training.evaluation.v10_4_harness import (
    ContinuousRelationWrapper, WeightBindingWrapper, 
    RecurrentWrapper, LatentRuleSupervisor,
    isomorphic_representation_probe, check_ordinary_inference
)

OUT = Path("experiments/v10_4")
OUT.mkdir(parents=True, exist_ok=True)

STEPS = 100
SEEDS = [42, 43, 44]
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")

CAPACITY = "L0"
VOCAB_SIZE = 150
HIDDEN_SIZE = 32

def run_intervention(intervention: str, seed: int):
    torch.manual_seed(seed)
    gen = V10_3_TaskGenerator()
    
    # Fully-Disjoint OOD (surface 9, [135, 145])
    ood_cfg = TaskConfig("increment", 3, (135, 145), (135, 145), (135, 145), 16, seed)
    ood_data = gen.generate(ood_cfg)["train"].to(DEVICE)
    
    # Baseline surface (surface 0, [0, 10])
    base_cfg = TaskConfig("increment", 3, (0, 10), (0, 10), (0, 10), 16, seed)
    base_data = gen.generate(base_cfg)["train"].to(DEVICE)
    
    # Validation data (surface 0)
    val_cfg = TaskConfig("increment", 3, (0, 10), (0, 10), (0, 10), 16, seed + 100)
    val_data = gen.generate(val_cfg)["train"].to(DEVICE)
    
    base_model = CapacityBuilder.build(CAPACITY, vocab=VOCAB_SIZE)
    
    if intervention == "E_B_continuous":
        model = ContinuousRelationWrapper(base_model, HIDDEN_SIZE).to(DEVICE)
    elif intervention == "E_C_binding":
        model = WeightBindingWrapper(base_model, HIDDEN_SIZE).to(DEVICE)
    elif intervention == "E_D_recurrent":
        model = RecurrentWrapper(base_model, HIDDEN_SIZE).to(DEVICE)
    elif intervention == "E_E_latent":
        model = LatentRuleSupervisor(base_model, HIDDEN_SIZE, num_rules=2).to(DEVICE)
    else: # E_A_baseline
        model = LatentRuleSupervisor(base_model, HIDDEN_SIZE, num_rules=2).to(DEVICE)
        
    opt = torch.optim.AdamW(model.parameters(), lr=5e-3)
    
    for step in range(STEPS):
        model.train()
        opt.zero_grad()
        
        rng = torch.Generator().manual_seed(seed + step)
        
        # We use a diverse 8-surface setup for training so they have a chance to abstract
        # (Diversity was 0% in V10.3, so it's a good rigorous base constraint to test bias)
        div_data = gen.generate_diversity("increment", 8, 3, 16, seed + step)
        surfaces = [s.to(DEVICE) for s in div_data["train_surfaces"]]
        
        loss = 0.0
        for s in surfaces:
            if intervention == "E_B_continuous":
                logits = model.forward_with_transition(s)
                shift_logits = logits[..., :-1, :].contiguous()
                shift_labels = s[..., 1:].contiguous()
                loss += F.cross_entropy(shift_logits.view(-1, shift_logits.size(-1)), shift_labels.view(-1))
            elif intervention == "E_C_binding":
                logits = model.forward_bound(s)
                shift_logits = logits[..., :-1, :].contiguous()
                shift_labels = s[..., 1:].contiguous()
                loss += F.cross_entropy(shift_logits.view(-1, shift_logits.size(-1)), shift_labels.view(-1))
            elif intervention == "E_D_recurrent":
                logits = model.forward_recurrent(s)
                shift_logits = logits[..., :-1, :].contiguous()
                shift_labels = s[..., 1:].contiguous()
                loss += F.cross_entropy(shift_logits.view(-1, shift_logits.size(-1)), shift_labels.view(-1))
            elif intervention == "E_E_latent":
                base_loss = model(input_ids=s, labels=s).loss
                # Supervise with rule 0 ("increment")
                rule_labels = torch.zeros(s.size(0), dtype=torch.long, device=DEVICE)
                sup_loss = model.supervise(s, rule_labels)
                loss += base_loss + sup_loss
            else: # E_A_baseline
                loss += model(input_ids=s, labels=s).loss
                
        loss = loss / 8.0
        loss.backward()
        opt.step()

    # Evaluation
    model.eval()
    
    # Experiment F: Isomorphic Representation Probe
    cp = gen.generate_contrastive_pairs(16, 3, seed)
    xa = cp["pos_a"].to(DEVICE)
    xb = cp["pos_b"].to(DEVICE)
    xc = cp["neg_b"].to(DEVICE) # different rule
    
    iso_success, d_ab, d_ac = isomorphic_representation_probe(model, xa, xb, xc)
    
    t_a, _ = check_ordinary_inference(model, base_data, labels=base_data)
    v_a, _ = check_ordinary_inference(model, val_data, labels=val_data)
    o_a, _ = check_ordinary_inference(model, ood_data, labels=ood_data)
    
    return {
        "intervention": intervention,
        "seed": seed,
        "train_acc": t_a,
        "val_acc": v_a,
        "ood_acc": o_a,
        "iso_success": iso_success,
        "d_ab": d_ab,
        "d_ac": d_ac
    }

def main():
    print("=== V10.4 Inductive Bias Study ===")
    results = {}
    
    interventions = [
        "E_A_baseline",
        "E_B_continuous",
        "E_C_binding",
        "E_D_recurrent",
        "E_E_latent"
    ]
    
    for inv in interventions:
        print(f"Running {inv}...")
        inv_res = []
        for seed in SEEDS:
            print(f"  Seed {seed}...")
            r = run_intervention(inv, seed)
            inv_res.append(r)
            
        results[inv] = {
            "train": aggregate_results([x["train_acc"] for x in inv_res]),
            "val": aggregate_results([x["val_acc"] for x in inv_res]),
            "ood": aggregate_results([x["ood_acc"] for x in inv_res]),
            "iso_pct": sum([x["iso_success"] for x in inv_res]) / len(inv_res)
        }
        print(f"  OOD: {results[inv]['ood']['mean']*100:.2f}%, ISO_Probe: {results[inv]['iso_pct']*100:.1f}%")

    ts = int(time.time())
    save_manifest(OUT / f"v10_4_results_{ts}.json", results)
    print("Done! Results saved.")

if __name__ == "__main__":
    main()
