"""
Transfer Learning V2 Comprehensive Benchmark & Statistical Evaluation Script.

Runs full evaluation across:
1. Five random seeds (1..5) with statistical aggregation (mean, std, min, max).
2. True Train / Transfer / Composition / Holdout partitions.
3. Negative learning failure reduction under environmental trap condition C.
4. Learning curve analysis across episode budgets: 0, 1, 2, 4, 8, 16 episodes.
5. Seven-condition memory ablation matrix (Full, No Episodic, No Semantic, No Procedural, No Working, No Replan, No Verif).
6. Outputs machine-readable results to experiments/transfer_v2_results.json and prints Markdown tables.
"""

import json
import math
import os
from pathlib import Path
import statistics
import sys
import time
from typing import Any, Dict, List, Tuple

# Ensure project root and src are on sys.path
ROOT_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT_DIR))
sys.path.insert(0, str(ROOT_DIR / "src"))


from nirmal.agent.controller import CognitiveController, Goal
from nirmal.agent.memory.procedural import ProceduralMemory
from nirmal.agent.memory.semantic import SemanticMemory
from nirmal.agent.memory.episodic import EpisodicMemory
from nirmal.agent.learning_engine import CognitiveLearningEngine
from nirmal.agent.verification import DeterministicVerifier
from nirmal.learning import EpisodicBuffer
from nirmal.tools import ToolRegistry, MockEnvironmentTool
from evals.transfer_tasks import TransferTask, get_task_suite_for_seed


def create_agent(env: MockEnvironmentTool, **kwargs: Any) -> CognitiveController:
    """Instantiate a controller with optional ablation feature flags."""
    tools = ToolRegistry()
    tools.register(env)
    return CognitiveController(
        tool_registry=tools,
        semantic_memory=SemanticMemory() if kwargs.get("enable_semantic", True) else None,
        episodic_memory=EpisodicMemory() if kwargs.get("enable_episodic", True) else None,
        procedural_memory=ProceduralMemory() if kwargs.get("enable_procedural", True) else None,
        verifier=DeterministicVerifier() if kwargs.get("enable_verification", True) else None,
        learning_engine=CognitiveLearningEngine(),
        episodic_buffer=EpisodicBuffer(),
        enable_memory=kwargs.get("enable_memory", True),
        enable_planning=kwargs.get("enable_planning", True),
        enable_verification=kwargs.get("enable_verification", True),
        enable_replanning=kwargs.get("enable_replanning", True),
        enable_learning=kwargs.get("enable_learning", True),
        enable_semantic_learning=kwargs.get("enable_semantic_learning", True),
        enable_procedural_learning=kwargs.get("enable_procedural_learning", True),
        enable_strategy_selection=kwargs.get("enable_strategy_selection", True),
    )


def eval_tasks(agent: CognitiveController, env: MockEnvironmentTool, tasks: List[TransferTask], wipe_working_memory: bool = False) -> float:
    """Evaluate agent success rate on a partition with frozen learning."""
    if not tasks:
        return 0.0
    successes = 0
    orig_learning = agent.enable_learning
    agent.enable_learning = False
    try:
        for task in tasks:
            if wipe_working_memory and agent.working_memory:
                agent.working_memory.clear()
            env.state.clear()
            env.state.update(task.initial_env_state)
            res = agent.run(task.to_goal())
            if res.success and res.final_output == task.expected_output:
                successes += 1
    finally:
        agent.enable_learning = orig_learning
    return successes / len(tasks)



def train_tasks(agent: CognitiveController, env: MockEnvironmentTool, tasks: List[TransferTask], max_episodes: int = 50) -> int:
    """Run training episodes sequentially."""
    episodes_run = 0
    for task in tasks:
        if episodes_run >= max_episodes:
            break
        env.state.clear()
        env.state.update(task.initial_env_state)
        agent.run(task.to_goal())
        episodes_run += 1
    return episodes_run


def run_statistical_evaluations(seeds: List[int] = [1, 2, 3, 4, 5]) -> Dict[str, Any]:
    """Run evaluation across all seeds and aggregate statistical metrics."""
    seed_results = {}
    baseline_scores = []
    learned_scores = []
    transfer_gains = []
    comp_xy_scores = []
    comp_xyz_scores = []
    holdout_scores = []
    neg_reduction_scores = []

    for s in seeds:
        suite = get_task_suite_for_seed(s)
        env = MockEnvironmentTool()

        # 1. Baseline Agent
        baseline_agent = create_agent(env)
        base_score = eval_tasks(baseline_agent, env, suite["transfer"])

        # 2. Learned Agent
        learned_agent = create_agent(env)
        train_tasks(learned_agent, env, suite["experience"])
        learn_score = eval_tasks(learned_agent, env, suite["transfer"])

        gain = learn_score - base_score

        # 3. Composition
        comp_xy_task = [t for t in suite["composition"] if t.task_family == "composition_xy"]
        comp_xyz_task = [t for t in suite["composition"] if t.task_family == "composition_xyz"]
        c_xy = eval_tasks(learned_agent, env, comp_xy_task)
        c_xyz = eval_tasks(learned_agent, env, comp_xyz_task)

        # 4. Holdout
        h_score = eval_tasks(learned_agent, env, suite["holdout"])

        # 5. Negative Learning Failure Reduction
        neg_task = [t for t in suite["transfer"] if t.task_family == "skill_resilient_routing"]
        base_neg_fail = 1.0 if eval_tasks(baseline_agent, env, neg_task) == 0.0 else 0.0
        learn_neg_fail = 1.0 if eval_tasks(learned_agent, env, neg_task) == 0.0 else 0.0
        neg_reduction = base_neg_fail - learn_neg_fail

        baseline_scores.append(base_score)
        learned_scores.append(learn_score)
        transfer_gains.append(gain)
        comp_xy_scores.append(c_xy)
        comp_xyz_scores.append(c_xyz)
        holdout_scores.append(h_score)
        neg_reduction_scores.append(neg_reduction)

        seed_results[f"seed_{s}"] = {
            "baseline_transfer": base_score,
            "learned_transfer": learn_score,
            "transfer_gain": gain,
            "composition_xy": c_xy,
            "composition_xyz": c_xyz,
            "holdout_accuracy": h_score,
            "negative_failure_reduction": neg_reduction,
        }

    def calc_stats(arr: List[float]) -> Dict[str, float]:
        mean = statistics.mean(arr)
        std = statistics.stdev(arr) if len(arr) > 1 else 0.0
        return {
            "mean": round(mean, 4),
            "std": round(std, 4),
            "min": round(min(arr), 4),
            "max": round(max(arr), 4),
        }

    aggregated = {
        "baseline_transfer": calc_stats(baseline_scores),
        "learned_transfer": calc_stats(learned_scores),
        "transfer_gain": calc_stats(transfer_gains),
        "composition_xy": calc_stats(comp_xy_scores),
        "composition_xyz": calc_stats(comp_xyz_scores),
        "holdout_accuracy": calc_stats(holdout_scores),
        "negative_failure_reduction": calc_stats(neg_reduction_scores),
    }

    return {"per_seed": seed_results, "aggregate": aggregated}


def run_learning_curves(seed: int = 1, budgets: List[int] = [0, 1, 2, 4, 8, 16]) -> Dict[str, Any]:
    """Measure performance as a function of experience episode budget."""
    suite = get_task_suite_for_seed(seed)
    curve_results = {}

    # Pool experience tasks cyclically to provide budget
    exp_pool = suite["experience"] * 5

    for budget in budgets:
        env = MockEnvironmentTool()
        agent = create_agent(env)

        if budget > 0:
            tasks_to_run = exp_pool[:budget]
            train_tasks(agent, env, tasks_to_run, max_episodes=budget)

        transfer_score = eval_tasks(agent, env, suite["transfer"])
        comp_score = eval_tasks(agent, env, suite["composition"])
        holdout_score = eval_tasks(agent, env, suite["holdout"])

        curve_results[f"budget_{budget}"] = {
            "episodes": budget,
            "transfer_accuracy": round(transfer_score, 4),
            "composition_accuracy": round(comp_score, 4),
            "holdout_accuracy": round(holdout_score, 4),
            "procedural_strategies_count": len(agent.procedural_memory.list_strategies()),
        }

    return curve_results


def run_ablation_matrix(seed: int = 1) -> Dict[str, Any]:
    """Evaluate performance across 7 ablation conditions."""
    suite = get_task_suite_for_seed(seed)
    ablations = {
        "Full System": {},
        "No Episodic Memory": {"enable_episodic": False},
        "No Semantic Memory": {"enable_semantic": False, "enable_semantic_learning": False},
        "No Procedural Memory": {"enable_procedural": False, "enable_procedural_learning": False},
        "No Working Memory (Wipe)": {"wipe_working_memory": True},
        "No Replanning Recovery": {"enable_replanning": False},
        "No Strategy Selection": {"enable_strategy_selection": False},
    }

    ablation_results = {}

    for name, config in ablations.items():
        env = MockEnvironmentTool()
        wipe_wm = config.pop("wipe_working_memory", False)
        agent = create_agent(env, **config)

        # Pre-experience baseline
        pre_exp_score = eval_tasks(agent, env, suite["transfer"], wipe_working_memory=wipe_wm)

        # Training
        train_tasks(agent, env, suite["experience"])

        # Post-experience & Transfer
        post_exp_score = eval_tasks(agent, env, suite["experience"], wipe_working_memory=wipe_wm)
        transfer_score = eval_tasks(agent, env, suite["transfer"], wipe_working_memory=wipe_wm)
        comp_score = eval_tasks(agent, env, suite["composition"], wipe_working_memory=wipe_wm)

        gain = transfer_score - pre_exp_score

        ablation_results[name] = {
            "pre_experience": round(pre_exp_score, 4),
            "post_experience": round(post_exp_score, 4),
            "transfer_accuracy": round(transfer_score, 4),
            "composition_accuracy": round(comp_score, 4),
            "transfer_gain": round(gain, 4),
        }

    return ablation_results


def main() -> None:
    print("=" * 70)
    print("NIRMAL-1 TRANSFER LEARNING V2 EVALUATION PROTOCOL")
    print("=" * 70)

    # 1. 5-Seed Statistical Evaluations
    print("\n[1/3] Running 5-Seed Statistical Evaluation...")
    stats_data = run_statistical_evaluations(seeds=[1, 2, 3, 4, 5])
    agg = stats_data["aggregate"]

    print("\n### 5-Seed Aggregate Performance Table")
    print("| Metric | Mean | Std | Min | Max |")
    print("|---|---|---|---|---|")
    for metric, vals in agg.items():
        print(f"| {metric} | {vals['mean']} | {vals['std']} | {vals['min']} | {vals['max']} |")

    # 2. Learning Curves
    print("\n[2/3] Evaluating Learning Curves (Budgets: 0, 1, 2, 4, 8, 16)...")
    curves_data = run_learning_curves(seed=1, budgets=[0, 1, 2, 4, 8, 16])

    print("\n### Empirical Learning Curve Table (Seed 1)")
    print("| Episodes Budget | Transfer Acc | Composition Acc | Holdout Acc | Strategies Learned |")
    print("|---|---|---|---|---|")
    for b_key, b_val in curves_data.items():
        print(f"| {b_val['episodes']} | {b_val['transfer_accuracy']} | {b_val['composition_accuracy']} | {b_val['holdout_accuracy']} | {b_val['procedural_strategies_count']} |")

    # 3. Ablation Matrix
    print("\n[3/3] Evaluating 7 Memory & Controller Ablations...")
    ablation_data = run_ablation_matrix(seed=1)

    print("\n### Systematic Ablation Matrix Table (Seed 1)")
    print("| Condition | Pre-Exp | Post-Exp | Transfer Acc | Comp Acc | Transfer Gain |")
    print("|---|---|---|---|---|---|")
    for cond_name, c_res in ablation_data.items():
        print(f"| {cond_name} | {c_res['pre_experience']} | {c_res['post_experience']} | {c_res['transfer_accuracy']} | {c_res['composition_accuracy']} | {c_res['transfer_gain']} |")

    # Save to experiments/transfer_v2_results.json
    out_dir = Path(__file__).resolve().parent.parent / "experiments"
    out_dir.mkdir(parents=True, exist_ok=True)
    out_path = out_dir / "transfer_v2_results.json"

    full_output = {
        "milestone": "TRANSFER LEARNING V2 — PROVE LEARNING GENERALIZES",
        "timestamp": time.time(),
        "seeds_evaluated": [1, 2, 3, 4, 5],
        "statistical_evaluation": stats_data,
        "learning_curves": curves_data,
        "ablation_matrix": ablation_data,
    }

    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(full_output, f, indent=2)

    print(f"\n[OK] Evaluation completed successfully. Results saved to {out_path.relative_to(out_dir.parent)}")


if __name__ == "__main__":
    main()
