#!/usr/bin/env python3
"""Fill V10.10 report result tables from machine-readable local artifacts."""

from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any, Dict, Iterable, List

ROOT = Path(__file__).resolve().parents[1]
REPORT = ROOT / "docs" / "V10_10_ASSOCIATIVE_BINDING_CALIBRATION_STUDY.md"
EXP = ROOT / "experiments" / "v10_10"
START = "<!-- V10_10_GENERATED_RESULTS_START -->"
END = "<!-- V10_10_GENERATED_RESULTS_END -->"


def load_json(path: Path) -> Dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def pct(value: Any) -> str:
    return "—" if value is None else f"{100.0 * float(value):.2f}%"


def run_rows(run_files: Iterable[Path]) -> List[str]:
    rows = [
        "| Run | Phase | Level | Format | Query | Objective | Scale | Seed | Steps | Correct | Random | Wrong | Placeholder absent | Unpaired absent | Status |",
        "|---|---|---|---|---|---|---|---:|---:|---:|---:|---:|---:|---:|---|",
    ]
    for path in sorted(run_files):
        run = load_json(path)
        cfg = run.get("run_config", {})
        logs = run.get("logs", [])
        final = logs[-1] if logs else {}
        conditions = final.get("validation", {}).get("conditions", {})
        rows.append(
            "| {run} | {phase} | {level} | {fmt} | {query} | {obj} | {scale} | {seed} | {steps} | {correct} | {random} | {wrong} | {ap} | {au} | `{status}` |".format(
                run=cfg.get("run_id", path.stem), phase=cfg.get("phase", "—"), level=cfg.get("level", "—"),
                fmt=cfg.get("serialization", "—"), query=cfg.get("query_format", "—"), obj=cfg.get("objective", "—"),
                scale=cfg.get("scale", "—"), seed=cfg.get("seed", "—"), steps=cfg.get("steps", "—"),
                correct=pct(conditions.get("correct", {}).get("accuracy")),
                random=pct(conditions.get("random_deranged", {}).get("accuracy")),
                wrong=pct(conditions.get("targeted_wrong", {}).get("accuracy")),
                ap=pct(conditions.get("absent_placeholder", {}).get("accuracy")),
                au=pct(conditions.get("absent_unpaired", {}).get("accuracy")),
                status=run.get("status", "UNKNOWN"),
            )
        )
    if len(rows) == 2:
        rows.append("| No scientific training runs executed | — | — | — | — | — | — | — | — | — | — | — | — | — | `NOT RUN` |")
    return rows


def format_gate_report_line(level: str, classification: str, gate: Dict[str, Any]) -> str:
    """Format gate line using exact V10.10-SPEC-AMENDMENT-01 terminology for G0 through G6."""
    g0 = gate.get("g0", gate.get("gate0_integrity", gate.get("G0", "UNKNOWN")))
    g1 = gate.get("g1", gate.get("gate1_train", gate.get("G1", "UNKNOWN")))
    g2 = gate.get("g2", gate.get("gate2_validation", gate.get("G2", "UNKNOWN")))
    g3 = gate.get("g3", gate.get("gate3_causal", gate.get("G3", "UNKNOWN")))
    g4 = gate.get("g4", gate.get("gate4_seeds", gate.get("G4", "UNKNOWN")))
    g5 = gate.get("g5", gate.get("gate5_position_order", gate.get("G5", "UNKNOWN")))
    g6 = gate.get("g6", gate.get("scaling", gate.get("G6", "UNKNOWN")))
    return (
        f"- **{level}:** classification `{classification}`; "
        f"G0 (Artifact integrity)={g0}, "
        f"G1 (Harness validity)={g1}, "
        f"G2 (Positive control)={g2}, "
        f"G3 (Negative-control specificity)={g3}, "
        f"G4 (Core binding)={g4}, "
        f"G5 (Robustness)={g5}, "
        f"G6 (Scaling)={g6}."
    )


def render() -> str:
    manifest_path = EXP / "benchmark" / "benchmark_manifest.json"
    continuity_path = EXP / "legacy" / "continuity.json"
    gate_files = sorted(EXP.glob("gate_*.json"))
    run_files = [p for p in (EXP / "runs").glob("*.json") if not p.name.endswith(".partial.json")]

    lines = [START, "## Generated execution results", ""]
    if manifest_path.exists():
        manifest = load_json(manifest_path)
        lines += [
            f"- **Benchmark hash:** `{manifest.get('top_level_sha256', 'MISSING')}`",
            f"- **Benchmark:** {manifest.get('level')} / {manifest.get('split')} / {manifest.get('count_per_seed')} episodes per seed",
        ]
    else:
        lines.append("- **Benchmark hash:** `NOT GENERATED`")

    if continuity_path.exists():
        continuity = load_json(continuity_path)
        lines.append(f"- **Legacy continuity:** `{continuity.get('classification', 'UNKNOWN')}`")
    else:
        lines.append("- **Legacy continuity:** `NOT RUN`")

    lines += ["", "### Registered run ledger", "", *run_rows(run_files), "", "### Readiness gates and classification", ""]
    if gate_files:
        for path in gate_files:
            payload = load_json(path)
            gate = payload.get("gate", {})
            lines.append(
                format_gate_report_line(
                    str(gate.get("level", path.stem)),
                    str(payload.get("classification", "UNKNOWN")),
                    gate,
                )
            )
    else:
        lines.append("- No three-seed gate artifact exists. Classification: `NOT EVALUATED`.")

    lines += [
        "",
        "### Execution claim boundary",
        "",
        "Only artifacts listed above were executed. Missing phases remain `NOT RUN`. "
        "No associative-binding result is claimed without a passing B2 three-seed gate artifact.",
        END,
    ]
    return "\n".join(lines)


def fill() -> None:
    text = REPORT.read_text(encoding="utf-8")
    if START not in text or END not in text:
        raise RuntimeError("Report is missing generated-result boundary markers")
    before, rest = text.split(START, 1)
    _, after = rest.split(END, 1)
    REPORT.write_text(before + render() + after, encoding="utf-8")
    print(f"Updated {REPORT.relative_to(ROOT)}")


if __name__ == "__main__":
    fill()
