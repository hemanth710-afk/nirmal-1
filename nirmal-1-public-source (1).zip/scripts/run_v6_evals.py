"""
Script: scripts/run_v6_evals.py
Capability Scorecard and 8-Way Baseline Benchmark Harness for Nirmal-1 V6.
Executes:
1. Basic Neural Learning Gate (loss convergence, non-triviality, unseen validation)
2. Standalone Neural Capability Evaluations:
   - Compositional Reasoning (2-hop, 3-hop)
   - Out-of-Distribution Generalization (Symmetric)
   - Unbiased Few-Shot In-Context Learning (0, 1, 2, 4, 8, 16 shots)
   - Long-Horizon Branching Rollouts (Horizons 1, 2, 4, 8, 16, 32 with traps)
   - Neural World Model State Transitions
   - Causal Learning (Interventions & Counterfactuals)
   - Memorization vs Abstraction Audit (Adversarial Probes)
3. 8-Way Baseline Comparison Matrix (Random, Majority, Regex, kNN, Symbolic, Untrained, Trained, Hybrid)
4. Tokenizer Comparison Analysis (Character vs Subword BPE)
Outputs: experiments/neural_v6_scorecard.json
"""

import json
from pathlib import Path
import sys
import time
from typing import Any, Dict
import torch

# Ensure project root and src/ are in sys.path
_PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(_PROJECT_ROOT))
sys.path.insert(0, str(_PROJECT_ROOT / "src"))

from nirmal.configuration_nirmal import NirmalConfig
from nirmal.model import NirmalForCausalLM
from training.dataset import CharTokenizer
from training.clean_dataset import CleanCurriculumGenerator
from training.train_v6 import TrainerV6
from training.subword_tokenizer import compare_tokenizers
from training.evaluate_v6 import (
    evaluate_neural_composition_v6,
    evaluate_neural_ood_v6,
    evaluate_neural_fewshot_v6,
    evaluate_neural_long_horizon_v6,
    evaluate_neural_world_model_v6,
    evaluate_neural_causal_v6,
    evaluate_neural_memorization_v6,
    run_8way_baseline_comparison_v6,
)


def run_v6_evaluation_suite() -> Dict[str, Any]:
    print("=" * 75)
    print("NIRMAL-1 V6: SCIENTIFIC CAPABILITY EVALUATION & SCORECARD")
    print("=" * 75)

    device = torch.device("cpu")
    tokenizer = CharTokenizer()

    # 1. Models setup: Untrained vs Trained
    print("[1/5] Initializing Untrained and Trained neural cores...")
    cfg = NirmalConfig(
        vocab_size=tokenizer.vocab_size,
        hidden_size=128,
        num_hidden_layers=4,
        num_attention_heads=4,
        num_key_value_heads=2,
        head_dim=32,
        context_length=128,
        intermediate_size=256,
        num_experts=4,
        num_experts_per_tok=2,
        full_attention_interval=2,
    )
    untrained_model = NirmalForCausalLM(cfg).to(device)

    # Train a baseline model on clean curriculum
    generator = CleanCurriculumGenerator(seed=42)
    train_set, val_set, test_set = generator.generate_full_clean_dataset(
        train_count_per_domain=30,
        val_count_per_domain=10,
        test_count_per_domain=10,
    )

    trained_model = NirmalForCausalLM(cfg).to(device)
    trainer = TrainerV6(model=trained_model, tokenizer=tokenizer, learning_rate=4e-4)
    train_summary = trainer.train(
        train_examples=train_set,
        val_examples=val_set,
        total_steps=50,
        batch_size=4,
        seq_len=64,
        warmup_steps=5,
        eval_interval=10,
        seed=42,
    )
    print(f"      -> Pretraining completed: Val Loss {train_summary.initial_val_loss} -> {train_summary.final_val_loss} (PPL: {train_summary.final_perplexity})")

    # 2. Standalone capability evaluations
    print("\n[2/5] Running Standalone Capability Evaluators (Memory-free)...")
    comp_res = evaluate_neural_composition_v6(trained_model, tokenizer, device)
    print(f"      - Compositional Reasoning (2-hop: {comp_res['acc_2hop'] * 100}%, 3-hop: {comp_res['acc_3hop'] * 100}%) -> Mean: {comp_res['overall_compositional_acc'] * 100}%")

    ood_res = evaluate_neural_ood_v6(trained_model, tokenizer, device)
    print(f"      - True OOD Generalization (Symmetric): {ood_res['ood_accuracy'] * 100}%")

    fewshot_res = evaluate_neural_fewshot_v6(trained_model, tokenizer, device, shot_counts=[0, 1, 2, 4, 8, 16])
    print(f"      - Unbiased Few-Shot Scaling: {fewshot_res}")

    lh_res = evaluate_neural_long_horizon_v6(trained_model, tokenizer, device, horizons=[1, 2, 4, 8, 16, 32])
    print(f"      - Long-Horizon Branching Rollouts: {lh_res}")

    wm_res = evaluate_neural_world_model_v6(trained_model, tokenizer, device)
    print(f"      - Neural World Model Prediction: {wm_res['world_model_acc'] * 100}%")

    causal_res = evaluate_neural_causal_v6(trained_model, tokenizer, device)
    print(f"      - Causal Intervention & Counterfactual: {causal_res['causal_accuracy'] * 100}%")

    mem_res = evaluate_neural_memorization_v6(trained_model, tokenizer, device)
    print(f"      - Memorization vs Abstraction Resilience: {mem_res['memorization_resilience'] * 100}%")

    # 3. 8-Way Baseline Comparison Matrix
    print("\n[3/5] Computing 8-Way Baseline Comparison Matrix...")
    baselines_matrix = run_8way_baseline_comparison_v6(trained_model, untrained_model, tokenizer, device)
    for b_name, b_metrics in baselines_matrix.items():
        print(f"      - {b_name:25s}: Mean Score = {b_metrics['mean'] * 100:.1f}%")

    # 4. Tokenizer Comparison
    print("\n[4/5] Executing Tokenizer Comparative Evaluation (Char vs Subword BPE)...")
    corpus_sample = [ex.text for ex in train_set[:20]]
    tok_comparison = compare_tokenizers(corpus_sample)
    print(f"      - Compression Ratio: {tok_comparison.compression_ratio}x (Char: {tok_comparison.char_tokens_per_char} vs Subword: {tok_comparison.subword_tokens_per_char} tpc)")
    print(f"      - Numerical Fidelity: Char={tok_comparison.numerical_fidelity_char}, Subword={tok_comparison.numerical_fidelity_subword}")
    print(f"      - Recommendation:     {tok_comparison.decision}")

    # 5. Basic Neural Learning Gate Check
    print("\n[5/5] Assessing Basic Neural Learning Gate...")
    learning_gate_passed = (
        train_summary.loss_improvement > 0 and
        train_summary.final_val_loss < train_summary.initial_val_loss and
        baselines_matrix["7_trained_neural_v6"]["mean"] >= baselines_matrix["1_random_baseline"]["mean"]
    )
    print(f"      -> Basic Neural Learning Gate Status: {'PASSED' if learning_gate_passed else 'FAILED'}")

    # Package into experiments/neural_v6_scorecard.json
    scorecard = {
        "timestamp_unix": time.time(),
        "milestone": "NIRMAL-1 V6",
        "learning_gate_passed": learning_gate_passed,
        "clean_training_telemetry": {
            "initial_val_loss": train_summary.initial_val_loss,
            "final_val_loss": train_summary.final_val_loss,
            "loss_improvement": train_summary.loss_improvement,
            "initial_perplexity": train_summary.initial_perplexity,
            "final_perplexity": train_summary.final_perplexity,
            "perplexity_reduction": train_summary.perplexity_reduction,
            "average_throughput_tok_sec": train_summary.average_throughput,
        },
        "capabilities": {
            "compositional_reasoning": comp_res,
            "ood_generalization": ood_res,
            "few_shot_in_context": fewshot_res,
            "long_horizon_rollout": lh_res,
            "neural_world_model": wm_res,
            "causal_reasoning": causal_res,
            "memorization_audit": mem_res,
        },
        "eight_way_baselines": baselines_matrix,
        "tokenizer_comparison": tok_comparison.to_dict(),
    }

    out_file = Path("experiments/neural_v6_scorecard.json")
    out_file.parent.mkdir(parents=True, exist_ok=True)
    out_file.write_text(json.dumps(scorecard, indent=2), encoding="utf-8")
    print(f"\n[OK] Neural capability scorecard saved to {out_file}")
    print("=" * 75)
    return scorecard


if __name__ == "__main__":
    run_v6_evaluation_suite()
