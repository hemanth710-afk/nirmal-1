"""
Authoritative Production External Data Acquisition Runner (Nirmal-1 V8.4).

Usage:
    python scripts/acquire_external_source.py --dry-run --source fineweb_edu_permissive
    python scripts/acquire_external_source.py --execute --source nirmal_synthetic_v8_2

Security & Invariant Rules:
- Default mode is always --dry-run.
- In --execute mode: strictly enforces all 14 hard gates including G14 Source Approval Gate.
- Unapproved sources strictly fail closed and cannot be downloaded.
- Never prints credentials, secret tokens, signed URLs, or secret headers.
- Emits immutable acquisition record in data/acquisition_records/.
"""

import argparse
import json
import sys
import time
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(REPO_ROOT))

from training.acquisition.evidence import SourceEvidenceManager, ApprovalStatus
from training.acquisition.official_evidence import (
    OfficialEvidenceManager,
    MAX_INSPECTION_BYTES,
    SourceVerificationRecord,
)
from training.acquisition.common import (
    AcquisitionConfig,
    AcquisitionResult,
    SourceApprovalError,
    StagingSpaceError,
    ChecksumMismatchError,
)
from training.acquisition.hf_snapshot_sync import HuggingFaceSnapshotSyncAdapter
from training.acquisition.s3_bulk_sync import S3BulkSyncAdapter
from training.acquisition.wikimedia_parser import WikimediaDumpParserAdapter


def create_adapter(config: AcquisitionConfig, method: str):
    m = method.upper()
    if "HUGGINGFACE" in m or "HF" in m:
        return HuggingFaceSnapshotSyncAdapter(config)
    elif "S3" in m or "BIGCODE" in m or "TOGETHER" in m:
        return S3BulkSyncAdapter(config)
    elif "WIKIMEDIA" in m:
        return WikimediaDumpParserAdapter(config)
    else:
        return S3BulkSyncAdapter(config)


def main() -> int:
    parser = argparse.ArgumentParser(description="Nirmal-1 Production Source Acquisition Runner")
    parser.add_argument("--source", type=str, required=True, help="Source identifier to acquire")
    parser.add_argument("--dry-run", action="store_true", help="Dry run simulation mode (default)")
    parser.add_argument("--execute", action="store_true", help="Execute real acquisition (requires APPROVED status)")
    parser.add_argument("--inspect", action="store_true", help="Inspect official metadata and legal artifacts only")
    parser.add_argument("--revision", type=str, default=None, help="Target snapshot revision override")

    args = parser.parse_args()

    # Determine mode: --inspect or --execute or default dry-run
    is_inspect = args.inspect
    is_dry_run = not args.execute and not is_inspect

    evidence_mgr = SourceEvidenceManager()
    dossier = evidence_mgr.load_dossier(args.source)

    if not dossier:
        print(f"[FAIL] No source evidence dossier found for '{args.source}' in data/source_evidence/.")
        return 1

    if is_inspect:
        print("======================================================================")
        print(f"NIRMAL-1 SOURCE INSPECTION: {args.source}")
        print("MODE: INSPECT (OFFICIAL REMOTE METADATA & LEGAL VERIFICATION)")
        print("======================================================================")
        official_mgr = OfficialEvidenceManager()

        try:
            record = official_mgr.load_verification_record(args.source)
            if not record:
                record = official_mgr.generate_source_evidence(args.source)
        except ValueError as e:
            print(f"[FAIL] Inspection failed: {str(e)}")
            return 1

        # 1. Byte limit check: cannot exceed MAX_INSPECTION_BYTES (500 KB)
        total_ev_bytes = sum(a.byte_size for a in record.artifacts.values())
        if total_ev_bytes > MAX_INSPECTION_BYTES:
            print(f"[FAIL] SAFETY VIOLATION: Inspection artifacts ({total_ev_bytes} bytes) exceed limit ({MAX_INSPECTION_BYTES} bytes)")
            return 7

        # 2. Check cryptographic SHA-256 integrity
        valid_integrity, integrity_errors = official_mgr.verify_artifact_integrity(args.source)
        if not valid_integrity:
            print(f"[FAIL] EVIDENCE INTEGRITY ERROR: {integrity_errors}")
            return 8

        # 3. Print findings
        print("\n--- OFFICIAL REMOTE SOURCE INSPECTION FINDINGS ---")
        print(f"Source ID:                   {record.source_id}")
        print(f"Canonical URL:               {record.canonical_url}")
        print(f"Official Endpoint:           {record.official_endpoint}")
        print(f"Declared License:            {record.declared_license}")
        print(f"Observed License:            {record.observed_license}")
        print(f"Version Identifier:          {record.version_identifier} ({record.version_status})")
        print(f"Revision Identifier:         {record.revision_identifier} ({record.revision_status})")
        print(f"Approval Status:             {record.approval_status}")
        print("\nVerified Official Artifacts:")
        for name, art in record.artifacts.items():
            print(f"  [{art.evidence_type:<15}] {art.artifact_name:<30} SHA-256: {art.sha256_hash[:16]}... ({art.byte_size} bytes)")

        print("\nAttribution Requirements:")
        for attr in record.attribution_requirements:
            print(f"  - {attr}")

        print("\nRedistribution Restrictions & Known Exclusions:")
        for r in record.redistribution_restrictions:
            print(f"  - [Restriction] {r}")
        for exc in record.known_exclusions:
            print(f"  - [Exclusion] {exc}")

        print(f"\nBenchmark Contamination Assessment: {record.benchmark_contamination_notes}")

        # Save audit record
        timestamp = time.strftime("%Y%m%dT%H%M%SZ", time.gmtime())
        record_dir = REPO_ROOT / "data" / "acquisition_records"
        record_dir.mkdir(parents=True, exist_ok=True)
        inspect_log_path = record_dir / f"record_inspect_{args.source}_{timestamp}.json"
        with open(inspect_log_path, "w", encoding="utf-8") as f:
            json.dump(record.to_dict(), f, indent=2)

        print(f"\nInspection Audit Log:        {inspect_log_path}")
        print("\n[PASS] REMOTE INSPECTION COMPLETED SAFELY.")
        print("Note: No production shards or large data payloads were downloaded.")
        print("======================================================================")
        return 0

    print("======================================================================")
    print(f"NIRMAL-1 SOURCE ACQUISITION: {args.source}")
    print(f"MODE: {'DRY RUN (SIMULATION)' if is_dry_run else 'EXECUTE (REAL ACQUISITION)'}")
    print("======================================================================")

    # Check G14 Source Approval Gate
    is_approved, reason = evidence_mgr.check_source_approval(args.source)
    print(f"SOURCE APPROVAL STATUS: {dossier.approval_status.value}")
    print(f"EVIDENCE EVALUATION:    {'PASSED' if is_approved else 'BLOCKED'}")

    if not is_dry_run and not is_approved:
        print(f"\n[FAIL] GATE G14 FAILED: Source '{args.source}' is NOT APPROVED for production acquisition.")
        print(f"Reason: {reason}")
        print("Production acquisition aborted (Fail-Closed).")
        return 2

    # Build Configuration
    target_rev = args.revision or dossier.snapshot_revision_identifier
    config = AcquisitionConfig(
        source_id=args.source,
        target_revision=target_rev,
        canonical_url=dossier.canonical_url,
        dry_run=is_dry_run,
        expected_checksum=dossier.source_checksum if is_approved else None,
    )

    adapter = create_adapter(config, dossier.acquisition_method)

    try:
        result = adapter.acquire()
    except StagingSpaceError as e:
        print(f"[FAIL] DISK SAFETY ERROR: {str(e)}")
        return 3
    except ChecksumMismatchError as e:
        print(f"[FAIL] CHECKSUM VERIFICATION ERROR: {str(e)}")
        return 4
    except SourceApprovalError as e:
        print(f"[FAIL] SOURCE APPROVAL ERROR: {str(e)}")
        return 5
    except Exception as e:
        print(f"[FAIL] ACQUISITION ERROR: {str(e)}")
        return 6

    print("\n--- ACQUISITION ACCOUNTING SUMMARY ---")
    print(f"Success:                 {result.success}")
    print(f"Dry Run:                 {result.dry_run}")
    print(f"Documents Discovered:    {result.documents_discovered}")
    print(f"Documents Accepted:      {result.documents_accepted}")
    print(f"Documents Rejected:      {result.documents_rejected}")
    print(f"Secrets Removed:         {result.secret_removals}")
    print(f"Contamination Removed:   {result.contamination_removals}")
    print(f"Exact Dedup Removed:     {result.exact_dedup_removals}")
    print(f"Tokens Accepted:         {result.tokens_accepted}")
    print(f"Final Verified Tokens:   {result.final_verified_token_count}")
    print(f"Acquisition Audit Log:   {result.record_file_path}")

    if is_dry_run:
        print("\n[PASS] DRY RUN COMPLETED SUCCESSFULLY.")
        print("Note: No authoritative production files were written.")
    else:
        print("\n[PASS] ACQUISITION COMPLETED AND ATOMICALLY PROMOTED.")

    print("======================================================================")
    return 0


if __name__ == "__main__":
    sys.exit(main())
