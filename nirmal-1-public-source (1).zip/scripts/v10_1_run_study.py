"""
V10.1 Study Runner — executes Experiments A, B, and C, writes machine-readable results.
All output goes to experiments/v10_1/.
"""
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from training.acquisition.v10_1_ood_amplification import (
    TaskConfig, BUDGETS, SEEDS, CURRICULUM_RULES, VOCAB_CONDITIONS,
    run_dose, run_curriculum, run_vocab_condition, aggregate, ResourceGuard,
)

OUT = Path("experiments/v10_1")
OUT.mkdir(parents=True, exist_ok=True)

# Canonical task (same as V10.0 BASELINE_2 / disjoint copy)
TASK = TaskConfig("copy", seq_len=4,
                  train_vocab=(10, 35), val_vocab=(10, 35),
                  ood_vocab=(60, 85), batch_size=8, seed=1000)


# ==========================================================================
# EXPERIMENT A — Dose Response
# ==========================================================================
print("=== EXPERIMENT A: Dose Response ===")
dose_results: dict = {"identity": {}, "value_relative": {}}

for repr_mode in ("identity", "value_relative"):
    for budget in BUDGETS:
        if not ResourceGuard.check(200, 60):
            print(f"  [SKIP] {repr_mode} budget={budget} — resource guard")
            continue
        runs = []
        for seed in SEEDS:
            print(f"  [{repr_mode}] budget={budget} seed={seed} ...", flush=True)
            r = run_dose(repr_mode, budget, seed, TASK, OUT / "exp_a")
            runs.append(r)

        # Extract final checkpoint OOD
        final_oods = [r.checkpoints[-1].ood_acc for r in runs]
        final_vals = [r.checkpoints[-1].val_acc  for r in runs]
        import numpy as np
        dose_results[repr_mode][budget] = {
            "mean_ood": round(float(np.mean(final_oods)), 4),
            "std_ood":  round(float(np.std(final_oods)),  4),
            "mean_val": round(float(np.mean(final_vals)),  4),
            "best_ood": round(float(max(final_oods)),      4),
            "worst_ood":round(float(min(final_oods)),      4),
            "per_seed": {
                SEEDS[i]: {
                    "ood": runs[i].checkpoints[-1].ood_acc,
                    "val": runs[i].checkpoints[-1].val_acc,
                    "train": runs[i].checkpoints[-1].train_acc,
                    "checkpoints": [vars(c) for c in runs[i].checkpoints],
                }
                for i in range(len(runs))
            }
        }

# Print Exp A summary
print("\n--- Exp A Final OOD (at each budget) ---")
print(f"{'Budget':>8}  {'identity OOD':>14}  {'value_rel OOD':>14}")
for b in BUDGETS:
    id_ood = dose_results["identity"].get(b, {}).get("mean_ood", "N/A")
    vr_ood = dose_results["value_relative"].get(b, {}).get("mean_ood", "N/A")
    print(f"{b:>8}  {str(id_ood):>14}  {str(vr_ood):>14}")


# ==========================================================================
# EXPERIMENT B — Multi-Rule Curriculum
# ==========================================================================
print("\n=== EXPERIMENT B: Multi-Rule Curriculum ===")
curr_results: dict = {}

for curr_name, rules in CURRICULUM_RULES.items():
    if not ResourceGuard.check(200, 60):
        print(f"  [SKIP] {curr_name}")
        continue
    runs = []
    for seed in SEEDS:
        print(f"  [{curr_name}] seed={seed} ...", flush=True)
        r = run_curriculum(curr_name, rules, seed, OUT / "exp_b")
        runs.append(r)
    oods = [r.ood_acc for r in runs]
    import numpy as np
    curr_results[curr_name] = {
        "mean_ood": round(float(np.mean(oods)), 4),
        "std_ood":  round(float(np.std(oods)),  4),
        "per_seed": {SEEDS[i]: vars(runs[i]) for i in range(len(runs))},
    }
    print(f"  OOD = {curr_results[curr_name]['mean_ood']:.4f} ± {curr_results[curr_name]['std_ood']:.4f}")


# ==========================================================================
# EXPERIMENT C — Vocab Condition
# ==========================================================================
print("\n=== EXPERIMENT C: Vocab Condition ===")
vocab_results: dict = {}

for cond_name, task_cfg in VOCAB_CONDITIONS.items():
    if not ResourceGuard.check(200, 60):
        print(f"  [SKIP] {cond_name}")
        continue
    runs = []
    for seed in SEEDS:
        print(f"  [{cond_name}] seed={seed} ...", flush=True)
        r = run_vocab_condition(cond_name, task_cfg, seed, OUT / "exp_c")
        runs.append(r)
    oods = [r.ood_acc for r in runs]
    vocab_results[cond_name] = {
        "mean_ood": round(float(np.mean(oods)), 4),
        "std_ood":  round(float(np.std(oods)),  4),
        "cert_valid": all(r.cert_valid for r in runs),
        "per_seed": {SEEDS[i]: vars(runs[i]) for i in range(len(runs))},
    }
    print(f"  OOD = {vocab_results[cond_name]['mean_ood']:.4f} ± {vocab_results[cond_name]['std_ood']:.4f}")


# ==========================================================================
# Save machine-readable master results
# ==========================================================================
master = {
    "experiment_a_dose": dose_results,
    "experiment_b_curriculum": curr_results,
    "experiment_c_vocab": vocab_results,
}
with open(OUT / "v10_1_results.json", "w") as f:
    json.dump(master, f, indent=2)
print(f"\nResults saved to {OUT / 'v10_1_results.json'}")
