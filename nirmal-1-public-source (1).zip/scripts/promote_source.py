"""
NIRMAL-1 V9.0: REAL SOURCE PROMOTION GATE CLI TOOL

Provides command-line interface for the controlled promotion of verified pilot sources:
  python scripts/promote_source.py --source wikipedia_open_corpus --dry-run
  python scripts/promote_source.py --source wikipedia_open_corpus --execute
  python scripts/promote_source.py --rollback prom_wikipedia_open_corpus_...

Options:
  --source <source_id>        Source identifier to evaluate/promote.
  --dry-run                   Evaluate 20-point checklist and print proposed tokens/hashes without modifying disk.
  --execute                   Execute controlled promotion into data/promotion/.
  --rollback <promotion_id>   Safely rollback previously promoted artifact.
  --manifest <path>           Explicit path to pilot manifest (optional).
  --promotion-dir <path>      Custom promotion directory root (optional).
"""

import argparse
import json
from pathlib import Path
import sys

# Ensure repository root is in sys.path
REPO_ROOT = Path(__file__).resolve().parent.parent
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from training.acquisition.promotion_gate import (
    RealSourcePromotionGate,
    PromotionResult,
    StateTransitionError,
    PromotionSecurityError,
    PromotionLimitExceededError,
    ManifestChainIntegrityError,
)


def format_checklist_summary(checklist: dict) -> str:
    lines = []
    lines.append("-" * 75)
    lines.append(f"{'Checklist Point':<40} | {'Status':<18} | Details")
    lines.append("-" * 75)
    items = checklist.get("items", {})
    for k, it in sorted(items.items()):
        status = it.get("status", "UNKNOWN")
        name = it.get("name", k)
        details = it.get("details", "")
        if len(details) > 40:
            details = details[:37] + "..."
        lines.append(f"{name:<40} | {status:<18} | {details}")
    lines.append("-" * 75)
    return "\n".join(lines)


def main() -> int:
    parser = argparse.ArgumentParser(description="Nirmal-1 Real Source Promotion Gate CLI")
    parser.add_argument("--source", type=str, help="Source identifier to evaluate or promote (e.g. wikipedia_open_corpus)")
    parser.add_argument("--dry-run", action="store_true", help="Perform dry-run evaluation without creating verified promotion artifacts.")
    parser.add_argument("--execute", action="store_true", help="Execute promotion of verified pilot source into data/promotion/.")
    parser.add_argument("--rollback", type=str, help="Rollback an existing promotion by promotion ID.")
    parser.add_argument("--manifest", type=str, default=None, help="Optional explicit path to pilot manifest JSON.")
    parser.add_argument("--promotion-dir", type=str, default=None, help="Optional custom promotion directory path.")
    parser.add_argument("--force-human-approval", action="store_true", help="Simulate human legal signoff for CC-BY-SA testing.")

    args = parser.parse_args()

    prom_dir = Path(args.promotion_dir) if args.promotion_dir else None
    gate = RealSourcePromotionGate(promotion_dir=prom_dir)

    # Rollback mode
    if args.rollback:
        print(f"[*] Executing rollback for promotion ID: {args.rollback}")
        try:
            report = gate.rollback_promotion(args.rollback)
            print(f"[+] Rollback successful: {json.dumps(report, indent=2)}")
            return 0
        except KeyError as e:
            print(f"[-] Rollback failed: {e}")
            return 1
        except Exception as e:
            print(f"[-] Unexpected error during rollback: {e}")
            return 2

    # Promotion / Evaluation mode
    if not args.source:
        print("[-] Error: --source <source_id> or --rollback <promotion_id> is required.")
        parser.print_help()
        return 2

    source_id = args.source
    manifest_path = Path(args.manifest) if args.manifest else None

    if not args.execute and not args.dry_run:
        print("[!] Defaulting to --dry-run evaluation mode. Use --execute to commit promotion.")
        args.dry_run = True

    mode_str = "DRY-RUN EVALUATION" if args.dry_run else "CONTROLLED PROMOTION"
    print(f"[*] Starting {mode_str} for source '{source_id}'...")

    try:
        res: PromotionResult = gate.promote_source(
            source_id=source_id,
            pilot_manifest_path=manifest_path,
            dry_run=args.dry_run,
            force_human_approval=args.force_human_approval,
        )

        print("\n" + format_checklist_summary(res.checklist_result) + "\n")

        print(f"[*] Promotion ID: {res.promotion_id}")
        print(f"[*] Gate State:   {res.state}")
        print(f"[*] Verdict:      {res.verdict}")
        print(f"[*] Documents:    {res.documents_promoted}")
        print(f"[*] Tokens:       {res.tokens_promoted}")

        if res.promoted_shard_path:
            print(f"[*] Promoted Shard:    {res.promoted_shard_path}")
        if res.promoted_manifest_path:
            print(f"[*] Promoted Manifest: {res.promoted_manifest_path}")

        if res.human_review_records:
            print(f"[!] Human Review Boundaries ({len(res.human_review_records)}):")
            for h in res.human_review_records:
                print(f"    - {h}")

        if res.verdict == "APPROVED":
            print(f"\n[+] SUCCESS: Source '{source_id}' meets all criteria and is APPROVED_FOR_PRODUCTION.")
            return 0
        elif res.verdict == "DRY_RUN":
            print(f"\n[+] DRY-RUN SUCCESS: Source '{source_id}' evaluated. All checks accounted.")
            return 0
        elif res.verdict == "NEEDS_HUMAN_REVIEW":
            print(f"\n[!] PROMOTION PENDING: Source '{source_id}' held at human review boundary.")
            return 1
        else:
            print(f"\n[-] REJECTED: Source '{source_id}' failed promotion criteria. Error: {res.error_message}")
            return 1

    except (PromotionSecurityError, PromotionLimitExceededError, ManifestChainIntegrityError) as e:
        print(f"[-] CRITICAL GATE FAILURE: {type(e).__name__}: {e}")
        return 1
    except Exception as e:
        print(f"[-] UNEXPECTED ERROR: {type(e).__name__}: {e}")
        return 2


if __name__ == "__main__":
    sys.exit(main())
