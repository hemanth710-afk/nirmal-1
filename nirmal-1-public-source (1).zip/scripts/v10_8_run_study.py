"""V10.8 Learning-to-Learn Rule Induction Study Runner.

Executes the approved scientific matrix:
- Conditions: BASELINE, META-1, META-2, META-3, and CAPACITY_L1
- Seeds: 42, 43, 44
- Validates Immutable Benchmark MANIFEST.sha256 before evaluation (fails closed if tampered)
- Evaluates Levels L1 to L5
- Evaluates Demonstration Curves (k in {0, 1, 2, 4, 8, 16})
- Evaluates Full Controls Matrix
- Computes Wilson 95% CIs, Mean, Std, Support Utility, and Classifications
- Saves JSON results to experiments/v10_8/
"""

import hashlib
import json
import os
import sys
import time
from pathlib import Path
from typing import Any, Dict, List, Tuple

import numpy as np
import torch
import torch.nn.functional as F

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from training.evaluation.v10_2_harness import CapacityBuilder, aggregate_results, save_manifest
from training.evaluation.v10_8_harness import (
    DEFAULT_VOCAB_SIZE,
    HELD_OUT_TRANSLATE_C,
    P_FIELD,
    PAD_TOKEN,
    QST_TOKEN,
    SEP_TOKEN,
    Episode,
    EpisodeBuilder,
    LeakageAuditor,
    RuleDefinition,
    RuleSampler,
    classify_v10_8_study,
    collate_episodes,
    compute_metrics,
    evaluate_model_on_episodes,
)

BENCHMARK_DIR = Path("experiments/v10_8/benchmark")
MANIFEST_FILE = BENCHMARK_DIR / "MANIFEST.sha256"
DATA_FILE = BENCHMARK_DIR / "benchmark_data.pt"
OUT_DIR = Path("experiments/v10_8")
OUT_DIR.mkdir(parents=True, exist_ok=True)

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
SEEDS = [42, 43, 44]
STEPS = 400
BATCH_SIZE = 32
LR = 5e-3


def verify_benchmark_integrity():
    """Recomputes SHA-256 for all tracked benchmark files and aborts if tampered."""
    assert MANIFEST_FILE.exists(), "Benchmark manifest missing!"
    lines = MANIFEST_FILE.read_text(encoding="utf-8").strip().splitlines()
    for line in lines:
        expected_hash, fname = line.strip().split()
        target = BENCHMARK_DIR / fname
        if not target.exists():
            target = Path("scripts") / fname
        assert target.exists(), f"Benchmark file {fname} not found!"
        actual_hash = hashlib.sha256(target.read_bytes()).hexdigest()
        assert actual_hash == expected_hash, f"BENCHMARK INTEGRITY VIOLATION: {fname} hash mismatch!"
    print("Benchmark integrity verified via MANIFEST.sha256: VALID.")


def deserialize_episode(d: Dict[str, Any]) -> Episode:
    rule = RuleDefinition(family=d["rule_family"], params=tuple(d["rule_params"]))
    return Episode(
        input_ids=torch.tensor(d["input_ids"], dtype=torch.long),
        target=int(d["target"]),
        k=d["k"],
        rule=rule,
        symbol_regime=d["symbol_regime"],
        is_unseen_symbol=d["is_unseen_symbol"],
        qx_val=d["qx_val"],
        qy_val=d["qy_val"],
        support_xs=[],
    )


def load_benchmark_episodes() -> Dict[str, Any]:
    raw = torch.load(DATA_FILE, weights_only=False)
    processed: Dict[str, Any] = {}

    for k, v in raw.items():
        if isinstance(v, list):
            processed[k] = [deserialize_episode(ep_d) for ep_d in v]
        elif isinstance(v, dict):
            sub_d = {}
            for sub_k, sub_v in v.items():
                if isinstance(sub_v, dict):
                    sub_sub = {}
                    for k_shot, ep_list in sub_v.items():
                        sub_sub[int(k_shot)] = [deserialize_episode(ep_d) for ep_d in ep_list]
                    sub_d[sub_k] = sub_sub
                elif isinstance(sub_v, list):
                    sub_d[sub_k] = [deserialize_episode(ep_d) for ep_d in sub_v]
            processed[k] = sub_d

    return processed


def train_condition(
    condition: str,
    seed: int,
    scale: str = "L0",
) -> Tuple[torch.nn.Module, float, float]:
    """Trains a model on the specified episodic meta-learning condition."""
    torch.manual_seed(seed)
    model = CapacityBuilder.build(scale, vocab=DEFAULT_VOCAB_SIZE).to(DEVICE)
    opt = torch.optim.AdamW(model.parameters(), lr=LR, weight_decay=1e-4)

    builder = EpisodeBuilder(p=P_FIELD)
    sampler = RuleSampler(p=P_FIELD, held_out_c=HELD_OUT_TRANSLATE_C)
    g = torch.Generator().manual_seed(seed + 1000)

    losses = []
    correct_train = 0
    total_train = 0

    k_options = [1, 2, 4, 8]

    for step in range(STEPS):
        model.train()
        opt.zero_grad()

        episodes = []
        for _ in range(BATCH_SIZE):
            if condition == "BASELINE":
                # Non-episodic mapping: fixed rule, no support examples (k=0)
                rule = RuleDefinition("translate", (5,))
                ep = builder.build_episode(rule, k=0, symbol_regime="V-A", is_unseen_symbol=False, g=g)
            elif condition == "META-1":
                rule = sampler.sample_seen_rule(g, broad_diversity=False)
                k_shot = k_options[torch.randint(0, len(k_options), (1,), generator=g).item()]
                ep = builder.build_episode(rule, k=k_shot, symbol_regime="V-A", is_unseen_symbol=False, g=g)
            elif condition in ("META-2", "CAPACITY_L1"):
                rule = sampler.sample_seen_rule(g, broad_diversity=False)
                regime = "V-A" if torch.rand(1, generator=g).item() < 0.5 else "V-B"
                k_shot = k_options[torch.randint(0, len(k_options), (1,), generator=g).item()]
                ep = builder.build_episode(rule, k=k_shot, symbol_regime=regime, is_unseen_symbol=False, g=g)
            elif condition == "META-3":
                rule = sampler.sample_seen_rule(g, broad_diversity=True)
                regime = "V-A" if torch.rand(1, generator=g).item() < 0.5 else "V-B"
                k_shot = k_options[torch.randint(0, len(k_options), (1,), generator=g).item()]
                ep = builder.build_episode(rule, k=k_shot, symbol_regime=regime, is_unseen_symbol=False, g=g)
            else:
                raise ValueError(f"Unknown condition: {condition}")

            episodes.append(ep)

        padded, targets = collate_episodes(episodes)
        padded = padded.to(DEVICE)
        targets = targets.to(DEVICE)

        out = model(input_ids=padded)
        logits = out.logits
        # Predict target qy at position of qx (last token index -1)
        pred_logits = logits[:, -1, :]
        loss = F.cross_entropy(pred_logits, targets)

        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        opt.step()

        losses.append(loss.item())
        preds = torch.argmax(pred_logits, dim=-1)
        correct_train += (preds == targets).sum().item()
        total_train += len(targets)

    final_loss = float(np.mean(losses[-50:]))
    train_acc = float(correct_train / total_train)
    return model, final_loss, train_acc


def main():
    print("=== Nirmal-1 V10.8 — Learning-to-Learn Rule Induction Study ===")
    print(f"Device: {DEVICE}, Seeds: {SEEDS}, Steps: {STEPS}, Batch Size: {BATCH_SIZE}")

    verify_benchmark_integrity()
    benchmark = load_benchmark_episodes()

    conditions = ["BASELINE", "META-1", "META-2", "META-3", "CAPACITY_L1"]
    all_study_results: Dict[str, Any] = {}

    for cond in conditions:
        scale = "L1" if cond == "CAPACITY_L1" else "L0"
        print(f"\n--- Running Condition: {cond} (Scale: {scale}) ---")
        cond_seed_runs = []

        for seed in SEEDS:
            start_t = time.time()
            model, final_loss, train_acc = train_condition(cond, seed=seed, scale=scale)
            train_duration = time.time() - start_t

            param_count = sum(p.numel() for p in model.parameters())

            # Evaluate on Benchmark Levels L1-L5
            l1_res = evaluate_model_on_episodes(model, benchmark["L1_known_rule_unseen_symbols"], DEVICE)
            l2_res = evaluate_model_on_episodes(model, benchmark["L2_known_family_unseen_parameter"], DEVICE)
            l3_res = evaluate_model_on_episodes(model, benchmark["L3_held_out_family_known_symbols"], DEVICE)
            l4_res = evaluate_model_on_episodes(model, benchmark["L4_held_out_family_unseen_symbols"], DEVICE)
            l5_res = evaluate_model_on_episodes(model, benchmark["L5_composed_rule_unseen_symbols"], DEVICE)

            # Evaluate Demonstration Curves (k in {0, 1, 2, 4, 8, 16})
            demo_curve_results: Dict[str, Dict[str, Any]] = {}
            for support_type in ["correct", "random", "wrong_rule"]:
                demo_curve_results[support_type] = {}
                for k in [0, 1, 2, 4, 8, 16]:
                    k_eps = benchmark["demonstration_curves"][support_type][k]
                    k_metrics = evaluate_model_on_episodes(model, k_eps, DEVICE)
                    demo_curve_results[support_type][str(k)] = k_metrics

            # Evaluate Controls
            control_results: Dict[str, Any] = {}
            for c_name, c_eps in benchmark["controls"].items():
                control_results[c_name] = evaluate_model_on_episodes(model, c_eps, DEVICE)

            k16_acc = demo_curve_results["correct"]["16"]["accuracy"]
            k0_acc = demo_curve_results["correct"]["0"]["accuracy"]
            k_gain = k16_acc - k0_acc

            c_corr = control_results["correct"]["accuracy"]
            c_rand = control_results["random"]["accuracy"]
            support_gain = c_corr - c_rand

            run_record = {
                "seed": seed,
                "scale": scale,
                "param_count": param_count,
                "train_loss": final_loss,
                "train_acc": train_acc,
                "wall_clock_s": train_duration,
                "levels": {
                    "L1": l1_res,
                    "L2": l2_res,
                    "L3": l3_res,
                    "L4": l4_res,
                    "L5": l5_res,
                },
                "demo_curves": demo_curve_results,
                "controls": control_results,
                "k16_vs_k0_gain": round(k_gain, 4),
                "support_utility": round(support_gain, 4),
            }
            cond_seed_runs.append(run_record)
            print(
                f"  Seed {seed}: L1={l1_res['accuracy']*100:.1f}%, L2={l2_res['accuracy']*100:.1f}%, "
                f"L3={l3_res['accuracy']*100:.1f}%, L4={l4_res['accuracy']*100:.1f}%, L5={l5_res['accuracy']*100:.1f}%, "
                f"k-gain={k_gain*100:+.1f}%, SupportUtil={support_gain*100:+.1f}%"
            )

        # Aggregate metrics across seeds
        agg_levels = {}
        for lvl in ["L1", "L2", "L3", "L4", "L5"]:
            accs = [r["levels"][lvl]["accuracy"] for r in cond_seed_runs]
            agg_levels[lvl] = aggregate_results(accs)

        agg_demo = {}
        for st in ["correct", "random", "wrong_rule"]:
            agg_demo[st] = {}
            for k_s in ["0", "1", "2", "4", "8", "16"]:
                accs = [r["demo_curves"][st][k_s]["accuracy"] for r in cond_seed_runs]
                agg_demo[st][k_s] = aggregate_results(accs)

        agg_controls = {}
        for c_name in cond_seed_runs[0]["controls"].keys():
            accs = [r["controls"][c_name]["accuracy"] for r in cond_seed_runs]
            agg_controls[c_name] = aggregate_results(accs)

        avg_train_acc = float(np.mean([r["train_acc"] for r in cond_seed_runs]))
        avg_k_gain = float(np.mean([r["k16_vs_k0_gain"] for r in cond_seed_runs]))
        avg_support_gain = float(np.mean([r["support_utility"] for r in cond_seed_runs]))

        classifications = classify_v10_8_study(
            l1_acc=agg_levels["L1"]["mean"],
            l2_acc=agg_levels["L2"]["mean"],
            l3_acc=agg_levels["L3"]["mean"],
            l4_acc=agg_levels["L4"]["mean"],
            l5_acc=agg_levels["L5"]["mean"],
            k16_vs_k0_gain=avg_k_gain,
            correct_vs_random_gain=avg_support_gain,
            train_acc=avg_train_acc,
        )

        all_study_results[cond] = {
            "scale": scale,
            "param_count": cond_seed_runs[0]["param_count"],
            "agg_levels": agg_levels,
            "agg_demo_curves": agg_demo,
            "agg_controls": agg_controls,
            "mean_train_acc": avg_train_acc,
            "mean_k_gain": avg_k_gain,
            "mean_support_utility": avg_support_gain,
            "classifications": classifications,
            "runs": cond_seed_runs,
        }
        print(f"  -> {cond} Aggregate: L1={agg_levels['L1']['mean']*100:.1f}%, Tags={classifications}")

    ts = int(time.time())
    out_file = OUT_DIR / f"v10_8_results_{ts}.json"
    manifest_info = MANIFEST_FILE.read_text(encoding="utf-8").strip().splitlines()
    benchmark_sha256 = manifest_info[0].split()[0]

    final_payload = {
        "benchmark_sha256": benchmark_sha256,
        "conditions": all_study_results,
        "device": str(DEVICE),
        "seeds": SEEDS,
        "steps": STEPS,
        "batch_size": BATCH_SIZE,
        "learning_rate": LR,
    }

    save_manifest(out_file, final_payload)
    print(f"\nV10.8 Study completed successfully! Results saved to: {out_file}")


if __name__ == "__main__":
    main()
