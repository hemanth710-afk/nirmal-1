"""
World Model & General Reasoning V4 Evaluation Runner for Nirmal-1.

Evaluates:
1. 10 Independent Random Seeds (1..10):
   - Predict-before-act accuracy
   - Average prediction error
   - Brier calibration score (0.0 = perfect probabilistic calibration)
   - Counterfactual reasoning accuracy
   - Interventional vs Observational causal disambiguation rate
   - Multi-step consequence horizons (1, 2, 4, 8, 16)
   - Distribution shift adaptation across Env A -> Env B -> Env C
   - System A (V3 procedural baseline) vs System B (V4 world model agent) comparison and Gain
2. 8-Way Causal Ablation Matrix:
   - Full System
   - World Model OFF
   - Learning Engine OFF
   - Procedural Memory OFF
   - Semantic Memory OFF
   - Episodic Memory OFF
   - Counterfactual Reasoning OFF
   - Verification OFF
3. AST Anti-Leakage Scan of src/nirmal/.
4. Serialization to experiments/world_model_v4_results.json.
"""

import ast
import json
import math
import os
from pathlib import Path
import random
import statistics
import sys
import time
from typing import Any, Dict, List, Optional, Tuple

ROOT_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT_DIR))
sys.path.insert(0, str(ROOT_DIR / "src"))

from nirmal.agent.world_model import WorldModel, CausalRule, CausalGraph, StatePrediction
from nirmal.agent.controller import CognitiveController, Goal, ControllerState
from nirmal.tools import ToolRegistry, CalculatorTool, StringUtilityTool, MockEnvironmentTool
from evals.causal_simulator import CausalSimulator


def evaluate_causal_system_seed(seed: int) -> Dict[str, Any]:
    """Run full causal world-model evaluation for a single random seed."""
    rng = random.Random(seed)
    wm = WorldModel()

    # --- 1. Causal Discovery & Disambiguation Evaluation ---
    # Create confounded simulator: U is latent. U -> X and U -> Y. Z is true cause of Y.
    sim = CausalSimulator.create_confounded_system(seed=seed)

    # Passive observations where U active
    for _ in range(5):
        sim.state["U"] = 1
        obs, info = sim.step({"type": "observe"})
        wm.observe_transition(state_t=info["pre_state"], action_name="observe", state_t1=obs, is_intervention=False)

    # Active interventions: do(X=1) and do(Z=1)
    sim.reset({"U": 0, "X": 0, "Y": 0, "Z": 0})
    obs_x, info_x = sim.step({"type": "do", "target": "X", "value": 1})
    wm.observe_transition(state_t=info_x["pre_state"], action_name="do_X", state_t1=obs_x, is_intervention=True)

    sim.reset({"U": 0, "X": 0, "Y": 0, "Z": 0})
    obs_z, info_z = sim.step({"type": "do", "target": "Z", "value": 1})
    wm.observe_transition(state_t=info_z["pre_state"], action_name="do_Z", state_t1=obs_z, is_intervention=True)

    # Disambiguation check: did do(X) avoid causing Y, and did do(Z) cause Y?
    x_caused_y = (obs_x.get("Y") == 1)
    z_caused_y = (obs_z.get("Y") == 1)
    disambiguation_success = (not x_caused_y) and z_caused_y

    # --- 2. Predict-Before-Act & Calibration ---
    # Train rules on a 5-step operational task
    for step in range(5):
        s_curr = {"step": step, "val": step * 10}
        s_next = {"step": step + 1, "val": (step + 1) * 10}
        wm.observe_transition(s_curr, f"act_{step}", s_next, is_intervention=True)

    # Evaluate predictions across 10 query transitions
    prediction_errors = []
    calibration_records = []
    correct_predictions = 0

    for step in range(5):
        s_curr = {"step": step, "val": step * 10}
        s_expected = {"step": step + 1, "val": (step + 1) * 10}
        pred = wm.predict(s_curr, f"act_{step}")
        err = pred.evaluate_error(s_expected)
        prediction_errors.append(err)
        is_exact = (err == 0.0)
        if is_exact:
            correct_predictions += 1
        calibration_records.append((pred.confidence, 1.0 if is_exact else 0.0))

    pred_accuracy = correct_predictions / max(1, len(prediction_errors))
    avg_pred_error = statistics.mean(prediction_errors) if prediction_errors else 0.0
    brier_score = statistics.mean([(p - o) ** 2 for p, o in calibration_records]) if calibration_records else 0.0

    # --- 3. Multi-Step Horizon Reasoning (1, 2, 4, 8, 16) ---
    horizon_results = {}
    # Build 16-step chain
    wm_chain = WorldModel()
    for i in range(16):
        wm_chain.register_rule(CausalRule(
            rule_id=f"r_step_{i}",
            action_name=f"fwd_{i}",
            preconditions={"stage": i},
            effects={"stage": i + 1},
            confidence=0.98,
        ))

    for h in [1, 2, 4, 8, 16]:
        actions = [(f"fwd_{i}", {}) for i in range(h)]
        rollout = wm_chain.simulate_rollout({"stage": 0}, actions, horizon=h)
        final_stage = rollout[-1].predicted_state.get("stage", -1) if rollout else -1
        h_err = abs(final_stage - h) / max(1, h)
        horizon_results[f"h_{h}"] = {
            "predicted_final": final_stage,
            "target": h,
            "error": round(h_err, 4),
            "success": (final_stage == h),
        }

    # --- 4. Counterfactual Reasoning ---
    wm_cf = WorldModel()
    wm_cf.register_rule(CausalRule(rule_id="r_a", action_name="act_a", effects={"risk": 0.8, "reward": 100}, confidence=0.9))
    wm_cf.register_rule(CausalRule(rule_id="r_b", action_name="act_b", effects={"risk": 0.0, "reward": 80}, confidence=0.95))

    cf_pred = wm_cf.counterfactual(
        factual_state={"risk": 0.0, "reward": 0},
        factual_action="act_a",
        counterfactual_action="act_b",
    )
    cf_success = (cf_pred.predicted_state.get("risk") == 0.0 and cf_pred.predicted_state.get("reward") == 80)

    # --- 5. Distribution Shift (Env A -> Env B -> Env C) ---
    env_a, env_b, env_c = CausalSimulator.create_distribution_shift_family(seed=seed)
    wm_shift = WorldModel()
    wm_shift.register_rule(CausalRule(rule_id="inv_1", action_name="step_v1", effects={"v2": 1}, confidence=0.9))
    wm_shift.register_rule(CausalRule(rule_id="shift_1", action_name="step_v3", effects={"out1": 1}, confidence=0.9))

    rep_b = wm_shift.adapt_to_distribution_shift("env_b")
    # Shift observation
    wm_shift.observe_transition({"v3": 1}, "step_v3", {"out1": 0})
    shift_b_adapted = (wm_shift.rules["shift_1"].confidence < 0.9)

    rep_c = wm_shift.adapt_to_distribution_shift("env_c")
    shift_c_adapted = ("inv_1" in wm_shift.rules and wm_shift.rules["inv_1"].confidence == 0.9)

    shift_success = shift_b_adapted and shift_c_adapted

    # --- 6. System A (Procedural Baseline) vs System B (World Model) ---
    tools = ToolRegistry()
    tools.register(CalculatorTool())
    tools.register(StringUtilityTool())

    sys_a = CognitiveController(tool_registry=tools, enable_world_model=False)
    sys_b = CognitiveController(tool_registry=tools, enable_world_model=True)

    # Test goal requiring arithmetic computation
    goal = Goal(goal_id=f"g_cmp_{seed}", description=f"Calculate {10 + seed} * 4", criteria=float((10 + seed) * 4))
    res_a = sys_a.run(goal)
    res_b = sys_b.run(goal)

    sys_a_score = 1.0 if res_a.success else 0.0
    sys_b_score = 1.0 if res_b.success else 0.0

    return {
        "seed": seed,
        "disambiguation_success": disambiguation_success,
        "prediction_accuracy": round(pred_accuracy, 4),
        "avg_prediction_error": round(avg_pred_error, 4),
        "brier_score": round(brier_score, 4),
        "horizons": horizon_results,
        "counterfactual_success": cf_success,
        "distribution_shift_success": shift_success,
        "system_a_score": sys_a_score,
        "system_b_score": sys_b_score,
        "world_model_gain": round(sys_b_score - sys_a_score, 4),
    }


def run_ablation_matrix(seeds: List[int]) -> Dict[str, Dict[str, float]]:
    """Evaluate 8-way ablation matrix across multiple seeds."""
    ablations = {
        "Full_System": {},
        "WorldModel_OFF": {"enable_world_model": False},
        "Learning_OFF": {"enable_learning": False},
        "Procedural_OFF": {"enable_procedural_learning": False},
        "Semantic_OFF": {"enable_semantic_learning": False},
        "Episodic_OFF": {"enable_memory": False},
        "Counterfactual_OFF": {"enable_counterfactual_reasoning": False},
        "Verification_OFF": {"enable_verification": False},
    }

    results = {}
    tools = ToolRegistry()
    tools.register(CalculatorTool())
    tools.register(StringUtilityTool())

    for name, flags in ablations.items():
        scores = []
        for seed in seeds:
            controller = CognitiveController(tool_registry=tools, **flags)
            goal = Goal(
                goal_id=f"ablation_{name}_{seed}",
                description=f"Calculate {seed * 5} + 15",
                criteria=float(seed * 5 + 15),
            )
            res = controller.run(goal)
            scores.append(1.0 if res.success else 0.0)

        results[name] = {
            "mean_accuracy": round(statistics.mean(scores), 4),
            "std_dev": round(statistics.stdev(scores) if len(scores) > 1 else 0.0, 4),
        }

    return results


def run_ast_anti_leakage_scan() -> Tuple[bool, List[str]]:
    """Scan src/nirmal/ to verify zero hardcoded benchmark tokens."""
    src_dir = ROOT_DIR / "src" / "nirmal"
    python_files = list(src_dir.rglob("*.py"))
    forbidden_tokens = {
        "exp_skill_x", "exp_skill_y", "exp_skill_z", "trans_param", "comp_xy",
        "causal_sim", "confounded_system", "ground_truth_dag"
    }

    violations = []
    for f in python_files:
        tree = ast.parse(f.read_text(encoding="utf-8"), filename=str(f))
        for node in ast.walk(tree):
            if isinstance(node, ast.Constant) and isinstance(node.value, str):
                v_lower = node.value.lower()
                for token in forbidden_tokens:
                    if token in v_lower:
                        violations.append(f"{f.name}:{node.lineno} contains '{token}'")

    return (len(violations) == 0), violations


def main():
    print("=" * 80)
    print("NIRMAL-1 V4 — LEARNED WORLD MODEL & GENERAL REASONING EVALUATION")
    print("=" * 80)

    seeds = list(range(1, 11))
    print(f"\n1. Executing multi-seed evaluation across {len(seeds)} random seeds: {seeds}")

    per_seed_results = []
    for s in seeds:
        res = evaluate_causal_system_seed(s)
        per_seed_results.append(res)
        print(f"  Seed {s:2d}: PredAcc={res['prediction_accuracy']*100:.1f}%, "
              f"PredErr={res['avg_prediction_error']:.3f}, Brier={res['brier_score']:.4f}, "
              f"Disambig={'PASS' if res['disambiguation_success'] else 'FAIL'}, "
              f"CF={'PASS' if res['counterfactual_success'] else 'FAIL'}, "
              f"Shift={'PASS' if res['distribution_shift_success'] else 'FAIL'}")

    # Aggregations
    accs = [r["prediction_accuracy"] for r in per_seed_results]
    errs = [r["avg_prediction_error"] for r in per_seed_results]
    briers = [r["brier_score"] for r in per_seed_results]
    disambig_rate = sum(1 for r in per_seed_results if r["disambiguation_success"]) / len(seeds)
    cf_rate = sum(1 for r in per_seed_results if r["counterfactual_success"]) / len(seeds)
    shift_rate = sum(1 for r in per_seed_results if r["distribution_shift_success"]) / len(seeds)
    sys_a_mean = statistics.mean([r["system_a_score"] for r in per_seed_results])
    sys_b_mean = statistics.mean([r["system_b_score"] for r in per_seed_results])

    print("\n" + "-" * 80)
    print("STATISTICAL SUMMARY (10 SEEDS)")
    print("-" * 80)
    print(f"Prediction Accuracy:   Mean={statistics.mean(accs)*100:.2f}% | Std={statistics.stdev(accs)*100:.2f}% | "
          f"Min={min(accs)*100:.1f}% | Max={max(accs)*100:.1f}%")
    print(f"Average Prediction Error: Mean={statistics.mean(errs):.4f} | Std={statistics.stdev(errs):.4f}")
    print(f"Brier Calibration Score:  Mean={statistics.mean(briers):.4f} | Std={statistics.stdev(briers):.4f}")
    print(f"Causal Disambiguation:    {disambig_rate*100:.1f}% ({sum(1 for r in per_seed_results if r['disambiguation_success'])}/{len(seeds)})")
    print(f"Counterfactual Accuracy:  {cf_rate*100:.1f}% ({sum(1 for r in per_seed_results if r['counterfactual_success'])}/{len(seeds)})")
    print(f"Distribution Shift Acc:   {shift_rate*100:.1f}% ({sum(1 for r in per_seed_results if r['distribution_shift_success'])}/{len(seeds)})")
    print(f"System A (Procedural):    Mean Accuracy={sys_a_mean*100:.1f}%")
    print(f"System B (World Model):   Mean Accuracy={sys_b_mean*100:.1f}%")
    print(f"Gain (World Model):       {(sys_b_mean - sys_a_mean)*100:+.1f} points")

    # Horizon breakdown
    print("\n" + "-" * 80)
    print("MULTI-STEP PLANNING HORIZON BREAKDOWN")
    print("-" * 80)
    first_seed_h = per_seed_results[0]["horizons"]
    for h_key, h_data in first_seed_h.items():
        print(f"  Horizon {h_data['target']:2d} Steps: Predicted={h_data['predicted_final']} | Target={h_data['target']} | Error={h_data['error']:.4f} | {'PASS' if h_data['success'] else 'FAIL'}")

    # 2. 8-Way Ablation Matrix
    print("\n" + "-" * 80)
    print("2. EXECUTING 8-WAY ABLATION MATRIX ACROSS 10 SEEDS")
    print("-" * 80)
    ablation_results = run_ablation_matrix(seeds)
    for name, data in ablation_results.items():
        print(f"  {name:<25}: Accuracy={data['mean_accuracy']*100:.1f}% (+/- {data['std_dev']*100:.2f}%)")

    # 3. AST Anti-Leakage Scan
    print("\n" + "-" * 80)
    print("3. AST ANTI-LEAKAGE SCAN")
    print("-" * 80)
    leak_passed, violations = run_ast_anti_leakage_scan()
    if leak_passed:
        print("  AST Anti-Leakage Scan: PASSED (0 hardcoded benchmark literals detected in src/nirmal/)")
    else:
        print(f"  AST Anti-Leakage Scan: FAILED with {len(violations)} violations:")
        for v in violations:
            print(f"    - {v}")

    # 4. Save results to experiments/
    exp_dir = ROOT_DIR / "experiments"
    exp_dir.mkdir(exist_ok=True)
    out_file = exp_dir / "world_model_v4_results.json"

    final_payload = {
        "milestone": "NIRMAL-1 V4 — LEARNED WORLD MODEL & GENERAL REASONING",
        "timestamp": time.time(),
        "seeds": seeds,
        "metrics": {
            "prediction_accuracy_mean": statistics.mean(accs),
            "prediction_accuracy_std": statistics.stdev(accs),
            "avg_prediction_error_mean": statistics.mean(errs),
            "brier_score_mean": statistics.mean(briers),
            "causal_disambiguation_rate": disambig_rate,
            "counterfactual_accuracy": cf_rate,
            "distribution_shift_retention": shift_rate,
            "system_a_procedural_mean": sys_a_mean,
            "system_b_world_model_mean": sys_b_mean,
            "world_model_gain": sys_b_mean - sys_a_mean,
        },
        "per_seed_results": per_seed_results,
        "horizon_evaluation": first_seed_h,
        "ablation_matrix": ablation_results,
        "ast_anti_leakage_passed": leak_passed,
    }

    out_file.write_text(json.dumps(final_payload, indent=2), encoding="utf-8")
    print(f"\n[OK] Results successfully saved to {out_file}")
    print("=" * 80)


if __name__ == "__main__":
    main()
