import json
import time
import hashlib
from pathlib import Path
from typing import Dict, List, Any
import numpy as np
import torch
import torch.nn as nn
from nirmal.configuration_nirmal import NirmalConfig
from nirmal.model import NirmalForCausalLM
import psutil

class ResourceGuard:
    @staticmethod
    def check_safe_to_run(est_vram_mb: int, est_ram_mb: int, est_time_s: int) -> bool:
        mem = psutil.virtual_memory()
        free_ram_mb = mem.available / (1024 * 1024)
        if est_ram_mb > free_ram_mb * 0.8 or est_ram_mb > 4096 or est_time_s > 300:
            return False
        return True

class GeneralizationTaskGenerator:
    def __init__(self, vocab_size=100):
        self.vocab_size = vocab_size
        
    def generate_task(self, level: str, batch_size: int, seq_len: int, subset_start: int, subset_end: int):
        # Generates synthetic tokens matching the strict subset boundaries for train/val vs OOD
        if level == "LEVEL_0_COPY":
            half = seq_len // 2
            a = torch.randint(subset_start, subset_end, (batch_size, half))
            return torch.cat([a, a], dim=1)
        elif level == "LEVEL_1_PATTERN":
            half = seq_len // 2
            a = torch.randint(subset_start, subset_end, (batch_size, half))
            return a.repeat_interleave(2, dim=1)[:, :seq_len]
        elif level == "LEVEL_2_SIMPLE_RULE":
            # Simple a, a+1, a+2 rule
            start_vals = torch.randint(subset_start, subset_end - seq_len, (batch_size, 1))
            offsets = torch.arange(seq_len).unsqueeze(0).expand(batch_size, seq_len)
            return start_vals + offsets
        elif level == "LEVEL_3_COMPOSITION":
            # Composition of step and pattern: a, a, a+1, a+1
            start_vals = torch.randint(subset_start, subset_end - seq_len, (batch_size, 1))
            offsets = torch.arange(seq_len // 2).unsqueeze(0).expand(batch_size, seq_len // 2)
            base = start_vals + offsets
            return base.repeat_interleave(2, dim=1)[:, :seq_len]
        elif level == "LEVEL_4_OOD_RULE":
            # Just another rule representation
            start_vals = torch.randint(subset_start, subset_end - seq_len, (batch_size, 1))
            offsets = torch.arange(seq_len).unsqueeze(0).expand(batch_size, seq_len) * 2
            return start_vals + offsets
        else:
            return torch.randint(subset_start, subset_end, (batch_size, seq_len))

class GeneralizationEvaluator:
    def __init__(self):
        self.scales = {
            "MICRO": {"layers": 2, "dim": 32, "ram": 100, "time": 10},
            "SMALL": {"layers": 4, "dim": 64, "ram": 300, "time": 40},
            "MEDIUM": {"layers": 8, "dim": 128, "ram": 900, "time": 120}
        }
        
    def evaluate_model_state(self, train_acc: float, val_acc: float, comp_acc: float, ood_acc: float) -> str:
        if ood_acc >= 0.8:
            return "GENERALIZING"
        elif comp_acc >= 0.8:
            return "COMPOSING"
        elif val_acc >= 0.8:
            return "INTERPOLATING"
        elif train_acc >= 0.8:
            return "MEMORIZING"
        elif train_acc >= 0.2:
            return "LEARNING"
        else:
            return "RANDOM"

    def run_experiment(self):
        generator = GeneralizationTaskGenerator()
        levels = ["LEVEL_0_COPY", "LEVEL_1_PATTERN", "LEVEL_2_SIMPLE_RULE", "LEVEL_3_COMPOSITION", "LEVEL_4_OOD_RULE"]
        
        best_scale = "NO_GENERALIZATION_SCALE_FOUND"
        
        for scale_name, scale_cfg in self.scales.items():
            print(f"\n--- Testing {scale_name} ---")
            if not ResourceGuard.check_safe_to_run(0, scale_cfg["ram"], scale_cfg["time"]):
                print(f"Aborted due to Resource Guard.")
                break
                
            scale_achieved_generalization = False
            
            config = NirmalConfig(
                vocab_size=100, hidden_size=scale_cfg["dim"], num_hidden_layers=scale_cfg["layers"],
                num_attention_heads=2, head_dim=scale_cfg["dim"] // 2, num_key_value_heads=1, num_experts=2, num_experts_per_tok=1, full_attention_interval=2
            )
            
            # We'll just run one seed per scale in this local demo to respect safe compute boundaries, 
            # while fully implementing the mechanics of the logic.
            for level in levels:
                torch.manual_seed(42)
                model = NirmalForCausalLM(config)
                optimizer = torch.optim.AdamW(model.parameters(), lr=0.005)
                
                # disjoint vocab subsets: Train/Val (10-40), Comp (40-60), OOD (60-90)
                train_data = generator.generate_task(level, batch_size=8, seq_len=8, subset_start=10, subset_end=40)
                val_data = generator.generate_task(level, batch_size=8, seq_len=8, subset_start=10, subset_end=40)
                comp_data = generator.generate_task(level, batch_size=8, seq_len=8, subset_start=40, subset_end=60)
                ood_data = generator.generate_task(level, batch_size=8, seq_len=8, subset_start=60, subset_end=90)
                
                for step in range(65):
                    model.train()
                    optimizer.zero_grad()
                    out = model(input_ids=train_data, labels=train_data)
                    loss = out.loss
                    loss.backward()
                    optimizer.step()
                
                model.eval()
                with torch.no_grad():
                    def get_acc(data):
                        out = model(input_ids=data, labels=data)
                        preds = torch.argmax(out.logits, dim=-1)
                        return (preds[:, :-1] == data[:, 1:]).float().mean().item()
                    
                    t_acc = get_acc(train_data)
                    v_acc = get_acc(val_data)
                    c_acc = get_acc(comp_data)
                    o_acc = get_acc(ood_data)
                    
                    state = self.evaluate_model_state(t_acc, v_acc, c_acc, o_acc)
                    print(f"Task: {level:20s} | Train: {t_acc:.2f} | Val: {v_acc:.2f} | OOD: {o_acc:.2f} | State: {state}")
                    
                    if state == "GENERALIZING":
                        scale_achieved_generalization = True
                        
            if scale_achieved_generalization:
                best_scale = scale_name
                break
                
        print(f"\nMINIMUM_GENERALIZATION_SCALE: {best_scale}")
        return best_scale

if __name__ == "__main__":
    evaluator = GeneralizationEvaluator()
    evaluator.run_experiment()
