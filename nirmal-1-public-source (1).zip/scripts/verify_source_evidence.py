"""
Command-Line Verification Tool for Source Evidence Dossiers (Nirmal-1 V8.4).

Usage:
    python scripts/verify_source_evidence.py

Verifies:
- All source evidence dossiers in data/source_evidence/
- Integrity of on-disk evidence files and SHA-256 hashes
- Invariant enforcement: APPROVED status requires physical evidence on disk
- Rejection status of prohibited/proprietary sources
"""

import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(REPO_ROOT))

from training.acquisition.evidence import (
    SourceEvidenceManager,
    ApprovalStatus,
    EvidenceValidationError,
)


def run_verification() -> int:
    print("======================================================================")
    print("NIRMAL-1 SOURCE EVIDENCE DOSSIER VERIFICATION")
    print("======================================================================")

    mgr = SourceEvidenceManager()
    dossiers = mgr.load_all_dossiers()

    if not dossiers:
        print("[FAIL] No source evidence dossiers found in data/source_evidence/")
        return 1

    total = len(dossiers)
    approved_count = 0
    under_review_count = 0
    rejected_count = 0
    validation_failures = 0

    print(f"{'SOURCE ID':<32} {'DECLARED LIC':<12} {'STATUS':<16} {'EVIDENCE ON DISK':<18}")
    print("-" * 80)

    for sid in sorted(dossiers.keys()):
        dossier = dossiers[sid]
        evidence_present = False

        if dossier.license_evidence_file_path:
            p = Path(dossier.license_evidence_file_path)
            if not p.is_absolute():
                p = mgr.evidence_dir / p
            if p.exists() and p.stat().st_size > 0:
                evidence_present = True

        evidence_str = "YES [VALID]" if evidence_present else "NO [PENDING]"

        # Validate dossier rules
        try:
            dossier.validate(base_dir=mgr.evidence_dir)
            val_str = dossier.approval_status.value
        except EvidenceValidationError as e:
            val_str = "INVALID_RULE"
            validation_failures += 1
            print(f"[FAIL] {sid}: {str(e)}")

        print(f"{sid:<32} {dossier.declared_license:<12} {val_str:<16} {evidence_str:<18}")

        if dossier.approval_status == ApprovalStatus.APPROVED:
            approved_count += 1
        elif dossier.approval_status == ApprovalStatus.UNDER_REVIEW:
            under_review_count += 1
        elif dossier.approval_status == ApprovalStatus.REJECTED:
            rejected_count += 1

    print("-" * 80)
    print(f"Total Dossiers: {total} | Approved: {approved_count} | Under Review: {under_review_count} | Rejected: {rejected_count}")
    print("======================================================================")

    if validation_failures > 0:
        print(f"[FAIL] {validation_failures} dossier(s) violated strict approval invariants.")
        return 1

    # Invariant: external 6 sources must be UNDER_REVIEW
    external_pending = [
        "fineweb_edu_permissive",
        "the_stack_v2_permissive",
        "arxiv_open_access_papers",
        "dolma_v1_7_permissive",
        "redpajama_v2_permissive",
        "wikipedia_open_corpus",
    ]
    for ext in external_pending:
        if ext in dossiers and dossiers[ext].approval_status != ApprovalStatus.UNDER_REVIEW:
            print(f"[FAIL] External source '{ext}' must be UNDER_REVIEW (got {dossiers[ext].approval_status.value}).")
            return 1

    print("[PASS] All dossiers verified. External production sources remain appropriately UNDER_REVIEW.")
    return 0


if __name__ == "__main__":
    sys.exit(run_verification())
