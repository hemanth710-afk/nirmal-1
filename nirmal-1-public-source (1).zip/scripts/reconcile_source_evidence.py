#!/usr/bin/env python3
"""
NIRMAL-1 V8.6 INDEPENDENT SOURCE RECONCILIATION CLI

Audits and reconciles project data claims against current first-party official sources,
upstream revision realities, licensing models, and evidence artifact independence.

Usage:
  python scripts/reconcile_source_evidence.py [--source <source_id>] [--strict]
"""

import argparse
import json
from pathlib import Path
import sys
import time

REPO_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(REPO_ROOT))

from training.acquisition.source_reconciliation import (
    IndependentSourceReconciler,
    RevisionVerificationStatus,
    ReconciliationResult,
    EvidenceOrigin,
)

ACQUISITION_RECORDS_DIR = REPO_ROOT / "data" / "acquisition_records"


def main():
    parser = argparse.ArgumentParser(
        description="Nirmal-1 V8.6 Independent Source Reconciliation CLI"
    )
    parser.add_argument(
        "--source",
        type=str,
        default=None,
        help="Optional specific source ID to reconcile.",
    )
    parser.add_argument(
        "--strict",
        action="store_true",
        help="Exit non-zero if any external source is marked APPROVED or has critical unhandled mismatches.",
    )
    args = parser.parse_args()

    reconciler = IndependentSourceReconciler()
    ACQUISITION_RECORDS_DIR.mkdir(parents=True, exist_ok=True)

    print("=" * 88)
    print("NIRMAL-1 V8.6: INDEPENDENT SOURCE RECONCILIATION & EVIDENCE AUDIT")
    print("=" * 88)

    if args.source:
        summaries = {args.source: reconciler.reconcile_source(args.source)}
    else:
        summaries = reconciler.reconcile_all()

    # Table Header
    print(f"{'SOURCE ID':<30} {'REVISION STATUS':<16} {'LICENSE RESULT':<16} {'STATUS':<14} {'BLOCKERS':<8}")
    print("-" * 88)

    critical_violations = 0
    for src_id, s in summaries.items():
        blockers_count = len(s.unresolved_blockers)
        print(f"{src_id:<30} {s.revision_status.value:<16} {s.license_result.value:<16} {s.overall_status:<14} {blockers_count:<8}")

        # Check invariant: No external candidate source may be APPROVED
        if src_id not in ("nirmal_synthetic_v8_2", "proprietary_forum_scrapes", "non_commercial_research_corpus"):
            if s.overall_status == "APPROVED":
                critical_violations += 1

    print("-" * 88)
    print()

    # Detailed report for the six candidate external sources
    candidate_sources = [
        "fineweb_edu_permissive",
        "the_stack_v2_permissive",
        "arxiv_open_access_papers",
        "dolma_v1_7_permissive",
        "redpajama_v2_permissive",
        "wikipedia_open_corpus",
    ]

    print("=" * 88)
    print("DETAILED INDEPENDENT RECONCILIATION (6 EXTERNAL CANDIDATE SOURCES)")
    print("=" * 88)

    for src_id in candidate_sources:
        if src_id not in summaries:
            continue
        s = summaries[src_id]
        print(f"\n[{src_id}] - {s.canonical_name}")
        print(f"  Overall Status:  {s.overall_status}")
        print(f"  Revision Status: {s.revision_status.value}")
        print(f"  License Result:  {s.license_result.value}")
        print("  Reconciliation Breakdown:")
        for e in s.entries:
            if not e.field.startswith("evidence_artifact_"):
                print(f"    - {e.field:<18} [{e.result.value:<13}] (Claim: {e.project_claim[:35]}... | Obs: {e.official_observation[:35]}...)")
        print("  Evidence Artifact Independence:")
        for art_name, origin in s.evidence_artifacts_origin.items():
            print(f"    * {art_name:<30}: origin={origin.value} (Cannot independently satisfy legal approval)")
        if s.unresolved_blockers:
            print("  Unresolved Fail-Closed Blockers:")
            for b in s.unresolved_blockers:
                print(f"    ! {b}")

    # Generate full machine-readable report
    full_report = reconciler.generate_full_report()
    timestamp = full_report["timestamp"]
    record_path = ACQUISITION_RECORDS_DIR / f"reconciliation_{timestamp}.json"
    with open(record_path, "w", encoding="utf-8") as f:
        json.dump(full_report, f, indent=2)

    print("\n" + "=" * 88)
    print(f"Immutable reconciliation record written to: {record_path}")
    print(f"Verified tokens on disk: 233,997 / 200,000,000,000 (Deficit: 199,999,766,003)")
    print(f"Approved external sources: 0 / 6")
    print(f"External training data shards downloaded: 0 (SAFETY INVARIANT PRESERVED)")
    print("=" * 88)

    if critical_violations > 0:
        print(f"\n[FAIL] Detected {critical_violations} unauthorized external source approvals!")
        sys.exit(1)

    if args.strict and any(s.overall_status == "APPROVED" for k, s in summaries.items() if k in candidate_sources):
        print("\n[FAIL-STRICT] Strict check failed: external source approved.")
        sys.exit(1)

    print("\n[PASS] INDEPENDENT SOURCE RECONCILIATION COMPLETED SUCCESSFULLY.")
    print("ALL 6 EXTERNAL SOURCES REMAIN UNDER_REVIEW. PRODUCTION LAUNCH: STRICT NO-GO.")
    sys.exit(0)


if __name__ == "__main__":
    main()
