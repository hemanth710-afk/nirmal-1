"""
Script: scripts/run_v6_leakage_audit.py
Automated Leakage and Deduplication Audit for Nirmal-1 V6.
Verifies:
1. Exact SHA-256 deduplication across Train, Val, and Test
2. Structural fingerprint deduplication
3. Cross-split isolation: TRAIN ∩ VAL = 0, TRAIN ∩ TEST = 0, VAL ∩ TEST = 0
4. Domain balance and generator provenance
Outputs: experiments/v6_leakage_audit.json
"""

import hashlib
import json
from pathlib import Path
import sys
import time
from typing import Any, Dict

# Ensure project root and src/ are in sys.path
_PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(_PROJECT_ROOT))
sys.path.insert(0, str(_PROJECT_ROOT / "src"))

from training.clean_dataset import CleanCurriculumGenerator
from training.data_pipeline import DataPipeline, DataLeakageError


def run_leakage_audit() -> Dict[str, Any]:
    print("=" * 70)
    print("NIRMAL-1 V6: SCIENTIFIC DATA LEAKAGE & INTEGRITY AUDIT")
    print("=" * 70)

    start_time = time.time()
    generator = CleanCurriculumGenerator(seed=42, version="v6.0")
    pipeline = DataPipeline(seed=42, generator_version="v6.0")

    print("[1/4] Generating full 12-domain clean curriculum...")
    train_set, val_set, test_set = generator.generate_full_clean_dataset(
        train_count_per_domain=60,
        val_count_per_domain=20,
        test_count_per_domain=20,
    )

    print(f"      - Raw Train Examples: {len(train_set)}")
    print(f"      - Raw Val Examples:   {len(val_set)}")
    print(f"      - Raw Test Examples:  {len(test_set)}")

    print("[2/4] Verifying internal deduplication (0% duplicate requirement)...")
    train_unique, train_dups = pipeline.deduplicate(train_set)
    val_unique, val_dups = pipeline.deduplicate(val_set)
    test_unique, test_dups = pipeline.deduplicate(test_set)

    print(f"      - Train Duplicates: {train_dups} ({train_dups / len(train_set) * 100:.2f}%)")
    print(f"      - Val Duplicates:   {val_dups}")
    print(f"      - Test Duplicates:  {test_dups}")

    print("[3/4] Verifying cross-split cryptographic isolation...")
    try:
        stats = pipeline.verify_split_isolation(train_set, val_set, test_set)
        print("      -> SPLIT ISOLATION PASSED: 0 LEAKAGE DETECTED.")
        print(f"      - Train intersect Val:  {stats.train_val_overlap} items")
        print(f"      - Train intersect Test: {stats.train_test_overlap} items")
        print(f"      - Val intersect Test:   {stats.val_test_overlap} items")
        leakage_passed = True
        error_msg = None
    except DataLeakageError as e:
        print(f"      -> LEAKAGE FAILURE: {e}")
        leakage_passed = False
        error_msg = str(e)
        stats = None

    print("[4/4] Generating audit report artifact...")
    elapsed = time.time() - start_time
    report = {
        "timestamp_unix": time.time(),
        "elapsed_seconds": round(elapsed, 3),
        "generator_version": "v6.0",
        "leakage_passed": leakage_passed,
        "error_message": error_msg,
        "train_count": len(train_set),
        "train_unique": len(train_unique),
        "train_duplicate_rate_pct": round(train_dups / len(train_set) * 100, 2),
        "val_count": len(val_set),
        "val_unique": len(val_unique),
        "test_count": len(test_set),
        "test_unique": len(test_unique),
        "train_val_overlap": stats.train_val_overlap if stats else -1,
        "train_test_overlap": stats.train_test_overlap if stats else -1,
        "val_test_overlap": stats.val_test_overlap if stats else -1,
        "domain_counts": stats.domain_counts if stats else {},
    }

    out_path = Path("experiments/v6_leakage_audit.json")
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(f"[OK] Audit report saved to {out_path}")
    print("=" * 70)
    return report


if __name__ == "__main__":
    run_leakage_audit()
