"""
Full Capability Evaluation and Preliminary AGI Capability Index Runner for Nirmal-1 V7.
Executes:
1. 8-Way Baseline Evaluation:
   - 1. Random baseline
   - 2. Untrained Small model
   - 3. V6 trained Small model (char-level, 20k tokens)
   - 4. V7 trained Small model (BPE, 100k tokens)
   - 5. V7 trained Medium model (BPE, 1M tokens)
   - 6. V7 trained Large model (BPE, 10M tokens)
   - 7. V7 best neural + symbolic hybrid
   - 8. Theoretical ceiling / human-level reference
2. Computes the Preliminary NIRMAL AGI CAPABILITY INDEX (Reference = 100.0, Target > 110.0)
3. Evaluates detailed sub-benchmarks (Composition, Few-Shot, Long-Horizon, World Model, Causal, Long Context, Continual Learning)
Outputs structured report to experiments/v7_capability_results.json.
"""

import json
from pathlib import Path
import sys

# Ensure repository root is in sys.path
REPO_ROOT = Path(__file__).resolve().parent.parent
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from training.evaluate_v7 import run_full_v7_evaluations, CATEGORIES_12


def run_capability_eval() -> dict:
    print("==================================================")
    print("NIRMAL-1 V7: CAPABILITY EVALUATION & AGI INDEX")
    print("==================================================")

    res = run_full_v7_evaluations(quick_mode=True)
    res_dict = res.to_dict()

    print("\n--- 8-WAY BASELINE COMPARISON & AGI CAPABILITY INDEX ---")
    print(f"{'Baseline':<25} | {'Composite Index':<15} | {'Target Met (>110)':<18}")
    print("-" * 65)

    for k, p in res.eight_way_baselines.items():
        met_str = "YES" if p.composite_index >= res.target_score else "NO"
        print(f"{p.name:<25} | {p.composite_index:<15.2f} | {met_str:<18}")

    print("\n--- 12 CAPABILITY CATEGORIES BREAKDOWN (0 - 100) ---")
    print(f"{'Category':<35} | {'V6 Small':<10} | {'V7 Small':<10} | {'V7 Med':<10} | {'V7 Large':<10} | {'V7 Hybrid':<10}")
    print("-" * 95)
    b3 = res.eight_way_baselines["v6_trained_small"].scores
    b4 = res.eight_way_baselines["v7_trained_small"].scores
    b5 = res.eight_way_baselines["v7_trained_medium"].scores
    b6 = res.eight_way_baselines["v7_trained_large"].scores
    b7 = res.eight_way_baselines["v7_hybrid"].scores

    for cat in CATEGORIES_12:
        print(f"{cat:<35} | {b3[cat]:<10.1f} | {b4[cat]:<10.1f} | {b5[cat]:<10.1f} | {b6[cat]:<10.1f} | {b7[cat]:<10.1f}")

    print("\n--- AGI CAPABILITY INDEX SUMMARY ---")
    print(f"Reference Baseline Index: 100.00")
    print(f"Milestone Target Index:   > {res.target_score:.2f}")
    print(f"V7 Large Model (Neural):  {res.v7_large_index:.2f} (Target Met: {res.v7_large_index >= res.target_score})")
    print(f"V7 Best Hybrid System:    {res.v7_hybrid_index:.2f} (Target Met: {res.v7_hybrid_index >= res.target_score})")

    out_file = REPO_ROOT / "experiments" / "v7_capability_results.json"
    out_file.parent.mkdir(parents=True, exist_ok=True)
    with open(out_file, "w", encoding="utf-8") as f:
        json.dump(res_dict, f, indent=2)

    print(f"\nSuccessfully saved capability results to: {out_file}")
    return res_dict


if __name__ == "__main__":
    run_capability_eval()
