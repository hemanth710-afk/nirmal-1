"""Auto-populates docs/V10_7_RULE_GENERALIZATION_AND_ALGORITHM_TRANSFER.md from JSON results."""

import json
import time
from pathlib import Path

OUT_DIR = Path("experiments/v10_7")
REPORT_PATH = Path("docs/V10_7_RULE_GENERALIZATION_AND_ALGORITHM_TRANSFER.md")


def load_results() -> dict:
    files = sorted(OUT_DIR.glob("v10_7_results_*.json"))
    if not files:
        raise FileNotFoundError("No V10.7 results JSON found.")
    return json.loads(files[-1].read_text(encoding="utf-8"))


def fmt_stat(stat: dict) -> str:
    if not isinstance(stat, dict) or "mean" not in stat:
        return "N/A"
    return f"{stat['mean']*100:.2f}% +/- {stat['ci95']*100:.2f}%"


def fill():
    data = load_results()
    text = REPORT_PATH.read_text(encoding="utf-8")

    # 1. Leakage
    cert = data["leakage"]
    cert_str = (
        f"- `vocab_disjoint`: `{cert['vocab_disjoint']}`\n"
        f"- `no_row_overlap`: `{cert['no_row_overlap']}`\n"
        f"- `no_subseq_leak`: `{cert['no_subseq_leak']}`\n"
        f"- `valid`: `{cert['valid']}`"
    )
    text = text.replace("{LEAKAGE_CERT}", cert_str)

    # 2. Experiment B Table (Known Rule Transfer across Vocabularies)
    exp_b = data["exp_b_rule_transfer"]
    b_rows = [
        "| Rule | Same Vocab [10, 110) | Partial Vocab [70, 170) | Disjoint Vocab [130, 230) |",
        "|---|---|---|---|",
    ]
    for rule, stats in exp_b["per_rule"].items():
        b_rows.append(
            f"| **{rule}** | {fmt_stat(stats['same_vocab'])} | {fmt_stat(stats['partial_vocab'])} | {fmt_stat(stats['disjoint_vocab'])} |"
        )
    b_rows.append(
        f"| **OVERALL MEAN** | **{fmt_stat(exp_b['overall_same'])}** | **{fmt_stat(exp_b['overall_partial'])}** | **{fmt_stat(exp_b['overall_disjoint'])}** |"
    )
    text = text.replace("{EXP_B_TABLE}", "\n".join(b_rows))

    # 3. Experiment C Table (Held-Out Rule Generalization)
    exp_c = data["exp_c_held_out"]
    c_rows = [
        "| Held-Out Rule | C1: Known Vocab [10, 110) (Level 2) | C2: Disjoint Vocab [130, 230) (Level 3) | Generalization Verdict |",
        "|---|---|---|---|",
    ]
    for r_name, stats in exp_c.items():
        c1_s = fmt_stat(stats["c1_known_vocab"])
        c2_s = fmt_stat(stats["c2_disjoint_vocab"])
        v = "NO_TRANSFER" if stats["c1_known_vocab"]["mean"] < 0.10 else "TRANSFER_DETECTED"
        c_rows.append(f"| **{r_name}** | {c1_s} | {c2_s} | `{v}` |")
    text = text.replace("{EXP_C_TABLE}", "\n".join(c_rows))

    # 4. Experiment D Table (Few-Shot Rule Discovery Curve)
    exp_d = data["exp_d_few_shot"]
    d_rows = [
        "| Held-Out Rule | k=0 Shots | k=1 Shot | k=2 Shots | k=4 Shots | k=8 Shots |",
        "|---|---|---|---|---|---|",
    ]
    for r_name, curve in exp_d.items():
        cells = [fmt_stat(curve[str(k)]["disjoint_vocab"]) for k in [0, 1, 2, 4, 8]]
        d_rows.append(f"| **{r_name} (Disjoint)** | " + " | ".join(cells) + " |")
    text = text.replace("{EXP_D_TABLE}", "\n".join(d_rows))

    # 5. Experiment E Table (Cross-Rule Transfer)
    exp_e = data["exp_e_cross_rule"]
    e_rows = [
        "| Source Rule -> Target Rule | Source Disjoint OOD | Target Known Vocab | Target Disjoint OOD | Transfer Status |",
        "|---|---|---|---|---|",
    ]
    for pair_name, stats in exp_e.items():
        s_disj = fmt_stat(stats["src_disjoint"])
        t_tr = fmt_stat(stats["tgt_train"])
        t_disj = fmt_stat(stats["tgt_disjoint"])
        status = "ISOLATED" if stats["tgt_disjoint"]["mean"] < 0.10 else "CROSS_TRANSFERRED"
        e_rows.append(f"| **{stats['source_rule']} -> {stats['target_rule']}** | {s_disj} | {t_tr} | {t_disj} | `{status}` |")
    text = text.replace("{EXP_E_TABLE}", "\n".join(e_rows))

    # 6. Experiment F Table (Permutation Intensity Ablation)
    exp_f = data["exp_f_intensity"]
    f_rows = [
        "| Intensity Level | Permutation Probability | Train Accuracy | Known Rule Disjoint OOD | Held-out Rule Disjoint OOD |",
        "|---|---|---|---|---|",
    ]
    for level, stats in exp_f.items():
        f_rows.append(
            f"| **{level}** | {stats['perm_prob']*100:.0f}% | {fmt_stat(stats['train_acc'])} | {fmt_stat(stats['known_disjoint_ood'])} | {fmt_stat(stats['held_out_ood'])} |"
        )
    text = text.replace("{EXP_F_TABLE}", "\n".join(f_rows))

    # 7. Experiment G (Diagnostics)
    exp_g = data["exp_g_diagnostics"]
    g_str = (
        f"- Same-rule cross-vocab distance ($d_{{same}}$): `{exp_g['d_same']['mean']:.4f} +/- {exp_g['d_same']['ci95']:.4f}`\n"
        f"- Different-rule distance ($d_{{diff}}$): `{exp_g['d_diff']['mean']:.4f} +/- {exp_g['d_diff']['ci95']:.4f}`\n"
        f"- Invariance Gap ($d_{{diff}} - d_{{same}}$): `{exp_g['invariance_gap']['mean']:.4f} +/- {exp_g['invariance_gap']['ci95']:.4f}`\n"
        f"- Distance Ratio ($d_{{same}} / d_{{diff}}$): `{exp_g['ratio']['mean']:.4f}`"
    )
    text = text.replace("{EXP_G_DIAGNOSTICS}", g_str)

    # 8. Experiment H (Forgetting)
    exp_h = data["exp_h_retention"]
    h_rows = [
        "| Training Stage | " + " | ".join([f"**{r}**" for r in data["exp_b_rule_transfer"]["per_rule"].keys()]) + " |",
        "|---| " + " | ".join(["---"] * len(data["exp_b_rule_transfer"]["per_rule"])) + " |",
    ]
    for s_idx, s_name in enumerate(exp_h["stage_names"]):
        row_vals = [f"{exp_h['avg_matrix'][s_idx][r]*100:.1f}%" for r in data["exp_b_rule_transfer"]["per_rule"].keys()]
        h_rows.append(f"| {s_name} | " + " | ".join(row_vals) + " |")
    text = text.replace("{EXP_H_TABLE}", "\n".join(h_rows))
    text = text.replace("{AVG_FORGETTING}", f"{exp_h['metrics']['avg_forgetting']*100:.2f}%")
    text = text.replace("{AVG_RETENTION}", f"{exp_h['metrics']['avg_final_retention']*100:.2f}%")

    # 9. Levels & Classification
    lvls = data["levels"]
    cls_str = ", ".join([f"`{c}`" for c in data["classification"]])
    text = text.replace("{LEVEL_1_SCORE}", f"{lvls['level1_rule_transfer']*100:.2f}%")
    text = text.replace("{LEVEL_2_SCORE}", f"{lvls['level2_rule_generalization']*100:.2f}%")
    text = text.replace("{LEVEL_3_SCORE}", f"{lvls['level3_compositional']*100:.2f}%")
    text = text.replace("{CLASSIFICATION_TAGS}", cls_str)

    REPORT_PATH.write_text(text, encoding="utf-8")
    print(f"Report successfully updated: {REPORT_PATH}")


if __name__ == "__main__":
    fill()
