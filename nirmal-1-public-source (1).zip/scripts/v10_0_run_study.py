"""
V10.0 Study Runner — executes the full 8-axis intervention matrix.

Baselines + 6 Interventions, 3 seeds each, deterministic.
All output written to experiments/v10_0/.
"""
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from training.acquisition.v10_0_intervention_engine import (
    TaskConfig, RunConfig, InterventionSummary,
    run_multi_seed, ResourceGuard,
)

OUT = Path("experiments/v10_0")
OUT.mkdir(parents=True, exist_ok=True)

SEEDS = [42, 43, 44]
BASE_STEPS = 64

# ------------------------------------------------------------------
# Shared task: COPY rule, fully disjoint vocab (hardest OOD)
# ------------------------------------------------------------------
TASK_DISJOINT = TaskConfig(
    rule="copy", seq_len=4,
    train_vocab=(10, 35), val_vocab=(10, 35),
    ood_vocab=(60, 85),
    batch_size=8, seed=1000,
)

# Partially overlapping vocab (easier generalisation signal)
TASK_PARTIAL = TaskConfig(
    rule="increment", seq_len=4,
    train_vocab=(10, 50), val_vocab=(10, 50),
    ood_vocab=(40, 80),   # 10-token overlap [40-50)
    batch_size=8, seed=1001,
)

# Isomorphic: same rule, different surfaces
TASK_ISOMORPHIC = TaskConfig(
    rule="increment", seq_len=3,
    train_vocab=(10, 30), val_vocab=(10, 30),
    ood_vocab=(60, 80),
    batch_size=8, seed=1002,
)


def make_cfgs(intervention: str, repr_mode="identity",
              objective="causal_lm", position_mode="normal",
              steps=BASE_STEPS, hidden=32, layers=2) -> list:
    return [
        RunConfig(intervention=intervention, seed=s, steps=steps,
                  repr_mode=repr_mode, objective=objective,
                  position_mode=position_mode, hidden=hidden, layers=layers)
        for s in SEEDS
    ]


# ------------------------------------------------------------------
# Build intervention matrix
# ------------------------------------------------------------------

EXPERIMENTS = [
    # Baselines
    ("BASELINE_1_V9_UNCHANGED",      make_cfgs("BASELINE_1_V9_UNCHANGED"),      TASK_DISJOINT),
    ("BASELINE_2_REPR_CHANGED",      make_cfgs("BASELINE_2_REPR_CHANGED",
                                               repr_mode="value_relative"),      TASK_DISJOINT),
    ("BASELINE_3_OBJ_CHANGED",       make_cfgs("BASELINE_3_OBJ_CHANGED",
                                               objective="relation_consistency"), TASK_DISJOINT),
    ("BASELINE_4_STRUCT_DIVERSITY",  make_cfgs("BASELINE_4_STRUCT_DIVERSITY"),   TASK_PARTIAL),

    # Interventions
    ("INT_A_MODULAR_REPR",           make_cfgs("INT_A_MODULAR_REPR",
                                               repr_mode="modular"),             TASK_DISJOINT),
    ("INT_B_PARTIAL_VOCAB",          make_cfgs("INT_B_PARTIAL_VOCAB"),           TASK_PARTIAL),
    ("INT_C_POSITION_REVERSED",      make_cfgs("INT_C_POSITION_REVERSED",
                                               position_mode="reversed"),        TASK_ISOMORPHIC),
    ("INT_D_CONTRASTIVE_OBJ",        make_cfgs("INT_D_CONTRASTIVE_OBJ",
                                               objective="contrastive_iso"),     TASK_ISOMORPHIC),
    ("INT_E_ISOMORPHIC_TRANSFER",    make_cfgs("INT_E_ISOMORPHIC_TRANSFER"),     TASK_ISOMORPHIC),
    ("INT_F_MODULAR_ISOMORPHIC",     make_cfgs("INT_F_MODULAR_ISOMORPHIC",
                                               repr_mode="modular"),             TASK_ISOMORPHIC),
    ("INT_G_SCALE_SMALL",            make_cfgs("INT_G_SCALE_SMALL",
                                               hidden=64, layers=4),             TASK_ISOMORPHIC),
    ("INT_H_SCALE_MEDIUM",           make_cfgs("INT_H_SCALE_MEDIUM",
                                               hidden=128, layers=8),            TASK_ISOMORPHIC),
]


def run_study() -> list:
    summaries = []
    for name, cfgs, task in EXPERIMENTS:
        if not ResourceGuard.check(400, 60):
            print(f"[SKIP] {name} — resource guard triggered.")
            continue
        print(f"[RUN]  {name} ...", flush=True)
        summary = run_multi_seed(name, cfgs, task, OUT)
        summaries.append(summary)
        ood_s = f"{summary.mean_ood:.3f}±{summary.std_ood:.3f}"
        print(f"       OOD={ood_s}  Val={summary.mean_val:.3f}  "
              f"Fail={summary.primary_failure}")

    # Save machine-readable results
    rows = []
    for s in summaries:
        rows.append({
            "intervention": s.intervention,
            "mean_ood":     s.mean_ood,
            "std_ood":      s.std_ood,
            "mean_val":     s.mean_val,
            "mean_train":   s.mean_train,
            "best_ood":     s.best_ood,
            "worst_ood":    s.worst_ood,
            "primary_failure": s.primary_failure,
        })
    with open(OUT / "results.json", "w") as f:
        json.dump(rows, f, indent=2)

    return summaries


if __name__ == "__main__":
    summaries = run_study()
    print("\n=== V10.0 RESULTS ===")
    print(f"{'Intervention':<35} {'OOD mean':>10} {'OOD std':>8} {'Val':>7} {'Failure'}")
    print("-" * 80)
    for s in summaries:
        print(f"{s.intervention:<35} {s.mean_ood:>10.4f} {s.std_ood:>8.4f} "
              f"{s.mean_val:>7.4f} {s.primary_failure}")
