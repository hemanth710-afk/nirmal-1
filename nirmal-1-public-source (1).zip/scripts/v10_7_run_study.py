"""V10.7 Rule Generalization and Algorithm Transfer Study Runner.

Executes:
- Experiment A & B: Multi-rule training and Known Rule / New Symbol transfer (same, partial, disjoint)
- Experiment C: Held-out rule generalization (C1 known vocab vs C2 disjoint vocab)
- Experiment D: Few-shot in-context rule discovery for held-out rules (k in {0, 1, 2, 4, 8})
- Experiment E: Cross-rule inductive transfer between structurally related rules
- Experiment F: Permutation-intensity ablation (F0 to F4)
- Experiment G: Representation diagnostics (same-rule vs diff-rule distance)
- Experiment H: Catastrophic forgetting in progressive sequential training
"""

import json
import os
import sys
import time
from pathlib import Path
from typing import Any, Dict, List, Tuple

import numpy as np
import torch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from training.evaluation.v10_2_harness import CapacityBuilder, aggregate_results, save_manifest
from training.evaluation.v10_7_harness import (
    ALL_RULES,
    DISJOINT_VOCAB,
    PARTIAL_VOCAB,
    TRAIN_VOCAB,
    PermutationAugmentor,
    V10_7_DataBuilder,
    classify_generalization,
    compute_representation_diagnostics,
    compute_retention_metrics,
    evaluate_few_shot_acc,
    evaluate_seq_acc,
)

OUT = Path("experiments/v10_7")
OUT.mkdir(parents=True, exist_ok=True)

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
SEEDS = [42, 43, 44]
VOCAB_SIZE = 250
LEVEL = "L0"
BS = 32


def train_model(
    train_rules: List[str],
    steps: int,
    seed: int,
    perm_prob: float = 1.0,
    lr: float = 5e-3,
) -> torch.nn.Module:
    """Trains an L0 model on specified rules with permutation augmentation."""
    torch.manual_seed(seed)
    model = CapacityBuilder.build(LEVEL, vocab=VOCAB_SIZE).to(DEVICE)
    aug = PermutationAugmentor(rng_seed=seed)
    db = V10_7_DataBuilder(VOCAB_SIZE)
    opt = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=1e-4)

    for step in range(steps):
        model.train()
        opt.zero_grad()

        rule = train_rules[step % len(train_rules)]
        batch = db.make_batch(rule, TRAIN_VOCAB, BS, seed=seed + step).to(DEVICE)

        loss = model(input_ids=batch, labels=batch).loss

        if perm_prob > 0.0:
            g = torch.Generator().manual_seed(seed + step + 50000)
            perm_batch = aug.maybe_remap(batch, rule, prob=perm_prob, target_vocab=DISJOINT_VOCAB, g=g).to(DEVICE)
            loss_perm = model(input_ids=perm_batch, labels=perm_batch).loss
            loss = loss + loss_perm

        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        opt.step()

    return model


def run_experiment_a_and_b(db: V10_7_DataBuilder) -> Dict[str, Any]:
    print("\n--- Running Experiment A & B: Multi-Rule Training & Rule Transfer ---")
    seed_data: Dict[int, Dict[str, Any]] = {}

    for seed in SEEDS:
        print(f"  Seed {seed}...", flush=True)
        model = train_model(ALL_RULES, steps=400, seed=seed, perm_prob=1.0)
        model.eval()

        rule_results = {}
        for rule in ALL_RULES:
            b_same = db.make_batch(rule, TRAIN_VOCAB, BS, seed=seed + 1000)
            b_part = db.make_batch(rule, PARTIAL_VOCAB, BS, seed=seed + 2000)
            b_disj = db.make_batch(rule, DISJOINT_VOCAB, BS, seed=seed + 3000)

            rule_results[rule] = {
                "same_vocab": evaluate_seq_acc(model, b_same, DEVICE),
                "partial_vocab": evaluate_seq_acc(model, b_part, DEVICE),
                "disjoint_vocab": evaluate_seq_acc(model, b_disj, DEVICE),
            }

        seed_data[seed] = {
            "per_rule": rule_results,
            "mean_same": float(np.mean([r["same_vocab"] for r in rule_results.values()])),
            "mean_partial": float(np.mean([r["partial_vocab"] for r in rule_results.values()])),
            "mean_disjoint": float(np.mean([r["disjoint_vocab"] for r in rule_results.values()])),
        }
        print(
            f"    same={seed_data[seed]['mean_same']*100:.2f}%, "
            f"partial={seed_data[seed]['mean_partial']*100:.2f}%, "
            f"disjoint={seed_data[seed]['mean_disjoint']*100:.2f}%"
        )

    # Aggregate across seeds
    per_rule_agg = {}
    for rule in ALL_RULES:
        per_rule_agg[rule] = {
            "same_vocab": aggregate_results([seed_data[s]["per_rule"][rule]["same_vocab"] for s in SEEDS]),
            "partial_vocab": aggregate_results([seed_data[s]["per_rule"][rule]["partial_vocab"] for s in SEEDS]),
            "disjoint_vocab": aggregate_results([seed_data[s]["per_rule"][rule]["disjoint_vocab"] for s in SEEDS]),
        }

    return {
        "seeds": seed_data,
        "per_rule": per_rule_agg,
        "overall_same": aggregate_results([seed_data[s]["mean_same"] for s in SEEDS]),
        "overall_partial": aggregate_results([seed_data[s]["mean_partial"] for s in SEEDS]),
        "overall_disjoint": aggregate_results([seed_data[s]["mean_disjoint"] for s in SEEDS]),
    }


def run_experiment_c_and_d(db: V10_7_DataBuilder) -> Tuple[Dict[str, Any], Dict[str, Any]]:
    print("\n--- Running Experiment C & D: Held-out Rule & Few-shot Rule Discovery ---")
    holdout_targets = ["simple_composition", "double_step"]
    k_shots_list = [0, 1, 2, 4, 8]

    exp_c_results: Dict[str, Any] = {}
    exp_d_results: Dict[str, Any] = {}

    for held_out in holdout_targets:
        print(f"  Held-out Rule: {held_out}")
        train_rules = [r for r in ALL_RULES if r != held_out]

        c_seed_runs = []
        d_seed_runs = []

        for seed in SEEDS:
            model = train_model(train_rules, steps=350, seed=seed, perm_prob=1.0)
            model.eval()

            # Experiment C: 0-shot on held-out rule
            b_c1 = db.make_batch(held_out, TRAIN_VOCAB, BS, seed=seed + 4000)
            b_c2 = db.make_batch(held_out, DISJOINT_VOCAB, BS, seed=seed + 5000)
            acc_c1 = evaluate_seq_acc(model, b_c1, DEVICE)
            acc_c2 = evaluate_seq_acc(model, b_c2, DEVICE)
            c_seed_runs.append({"seed": seed, "c1_known_vocab": acc_c1, "c2_disjoint_vocab": acc_c2})

            # Experiment D: few-shot in-context evaluation
            fs_curve = {}
            for k in k_shots_list:
                in_train, tgt_train = db.make_few_shot_batch(held_out, TRAIN_VOCAB, k_shots=k, batch_size=BS, seed=seed + 6000 + k)
                in_disj, tgt_disj = db.make_few_shot_batch(held_out, DISJOINT_VOCAB, k_shots=k, batch_size=BS, seed=seed + 7000 + k)
                acc_k_train = evaluate_few_shot_acc(model, in_train, tgt_train, DEVICE)
                acc_k_disj = evaluate_few_shot_acc(model, in_disj, tgt_disj, DEVICE)
                fs_curve[k] = {"known_vocab": acc_k_train, "disjoint_vocab": acc_k_disj}

            d_seed_runs.append({"seed": seed, "curve": fs_curve})

        exp_c_results[held_out] = {
            "c1_known_vocab": aggregate_results([r["c1_known_vocab"] for r in c_seed_runs]),
            "c2_disjoint_vocab": aggregate_results([r["c2_disjoint_vocab"] for r in c_seed_runs]),
            "raw_runs": c_seed_runs,
        }

        # Aggregate Exp D curves
        agg_curve = {}
        for k in k_shots_list:
            agg_curve[k] = {
                "known_vocab": aggregate_results([r["curve"][k]["known_vocab"] for r in d_seed_runs]),
                "disjoint_vocab": aggregate_results([r["curve"][k]["disjoint_vocab"] for r in d_seed_runs]),
            }
        exp_d_results[held_out] = agg_curve

        print(
            f"    C1 (known vocab)={exp_c_results[held_out]['c1_known_vocab']['mean']*100:.2f}%, "
            f"C2 (disjoint)={exp_c_results[held_out]['c2_disjoint_vocab']['mean']*100:.2f}%"
        )

    return exp_c_results, exp_d_results


def run_experiment_e(db: V10_7_DataBuilder) -> Dict[str, Any]:
    print("\n--- Running Experiment E: Cross-Rule Inductive Transfer ---")
    pairs = [
        ("increment", "double_step"),
        ("copy", "reverse"),
        ("fixed_shift", "simple_composition"),
    ]
    results: Dict[str, Any] = {}

    for src_rule, tgt_rule in pairs:
        pair_key = f"{src_rule}_to_{tgt_rule}"
        print(f"  Transfer: {src_rule} -> {tgt_rule}")
        runs = []

        for seed in SEEDS:
            # Train only on source rule
            model = train_model([src_rule], steps=250, seed=seed, perm_prob=1.0)
            model.eval()

            # Evaluate on source rule (disjoint OOD)
            b_src_disj = db.make_batch(src_rule, DISJOINT_VOCAB, BS, seed=seed + 100)
            acc_src = evaluate_seq_acc(model, b_src_disj, DEVICE)

            # Evaluate on target rule (train vocab and disjoint vocab)
            b_tgt_train = db.make_batch(tgt_rule, TRAIN_VOCAB, BS, seed=seed + 200)
            b_tgt_disj = db.make_batch(tgt_rule, DISJOINT_VOCAB, BS, seed=seed + 300)
            acc_tgt_train = evaluate_seq_acc(model, b_tgt_train, DEVICE)
            acc_tgt_disj = evaluate_seq_acc(model, b_tgt_disj, DEVICE)

            runs.append({
                "seed": seed,
                "src_disjoint": acc_src,
                "tgt_train": acc_tgt_train,
                "tgt_disjoint": acc_tgt_disj,
            })

        results[pair_key] = {
            "source_rule": src_rule,
            "target_rule": tgt_rule,
            "src_disjoint": aggregate_results([r["src_disjoint"] for r in runs]),
            "tgt_train": aggregate_results([r["tgt_train"] for r in runs]),
            "tgt_disjoint": aggregate_results([r["tgt_disjoint"] for r in runs]),
            "runs": runs,
        }
        print(
            f"    Source disjoint={results[pair_key]['src_disjoint']['mean']*100:.2f}%, "
            f"Target train={results[pair_key]['tgt_train']['mean']*100:.2f}%, "
            f"Target disjoint={results[pair_key]['tgt_disjoint']['mean']*100:.2f}%"
        )

    return results


def run_experiment_f(db: V10_7_DataBuilder) -> Dict[str, Any]:
    print("\n--- Running Experiment F: Permutation-Intensity Ablation ---")
    intensity_levels = {
        "F0_none": 0.0,
        "F1_low": 0.25,
        "F2_med": 0.50,
        "F3_heavy": 0.75,
        "F4_full": 1.0,
    }
    results: Dict[str, Any] = {}
    known_rules = ["copy", "increment", "fixed_shift", "reverse"]
    held_out_rule = "double_step"

    for label, prob in intensity_levels.items():
        print(f"  Intensity {label} (prob={prob})")
        runs = []
        for seed in SEEDS:
            model = train_model(known_rules, steps=250, seed=seed, perm_prob=prob)
            model.eval()

            # Train accuracy
            train_accs = [
                evaluate_seq_acc(model, db.make_batch(r, TRAIN_VOCAB, BS, seed=seed + 10), DEVICE)
                for r in known_rules
            ]
            # Known-rule disjoint OOD
            ood_accs = [
                evaluate_seq_acc(model, db.make_batch(r, DISJOINT_VOCAB, BS, seed=seed + 20), DEVICE)
                for r in known_rules
            ]
            # Held-out rule OOD
            held_acc = evaluate_seq_acc(model, db.make_batch(held_out_rule, DISJOINT_VOCAB, BS, seed=seed + 30), DEVICE)

            runs.append({
                "seed": seed,
                "train_acc": float(np.mean(train_accs)),
                "known_disjoint_ood": float(np.mean(ood_accs)),
                "held_out_ood": held_acc,
            })

        results[label] = {
            "perm_prob": prob,
            "train_acc": aggregate_results([r["train_acc"] for r in runs]),
            "known_disjoint_ood": aggregate_results([r["known_disjoint_ood"] for r in runs]),
            "held_out_ood": aggregate_results([r["held_out_ood"] for r in runs]),
            "runs": runs,
        }
        print(
            f"    Train={results[label]['train_acc']['mean']*100:.2f}%, "
            f"Known OOD={results[label]['known_disjoint_ood']['mean']*100:.2f}%, "
            f"Held-out OOD={results[label]['held_out_ood']['mean']*100:.2f}%"
        )

    return results


def run_experiment_g(db: V10_7_DataBuilder) -> Dict[str, Any]:
    print("\n--- Running Experiment G: Representation Diagnostics ---")
    seed_diags = []
    for seed in SEEDS:
        model = train_model(ALL_RULES, steps=300, seed=seed, perm_prob=1.0)
        diag = compute_representation_diagnostics(model, db, DEVICE, seed=seed)
        seed_diags.append(diag)

    agg_diag = {
        "d_same": aggregate_results([d["d_same"] for d in seed_diags]),
        "d_diff": aggregate_results([d["d_diff"] for d in seed_diags]),
        "invariance_gap": aggregate_results([d["invariance_gap"] for d in seed_diags]),
        "ratio": aggregate_results([d["ratio"] for d in seed_diags]),
        "raw": seed_diags,
    }
    print(
        f"  d_same={agg_diag['d_same']['mean']:.4f}, "
        f"d_diff={agg_diag['d_diff']['mean']:.4f}, "
        f"invariance_gap={agg_diag['invariance_gap']['mean']:.4f}"
    )
    return agg_diag


def run_experiment_h(db: V10_7_DataBuilder) -> Dict[str, Any]:
    print("\n--- Running Experiment H: Catastrophic Forgetting & Retention ---")
    stages = [
        ["copy"],
        ["copy", "increment"],
        ["copy", "increment", "fixed_shift"],
        ALL_RULES,
    ]
    stage_names = ["Stage 1 (Copy)", "Stage 2 (+Incr)", "Stage 3 (+Shift)", "Stage 4 (All)"]

    seed_histories = []
    for seed in SEEDS:
        torch.manual_seed(seed)
        model = CapacityBuilder.build(LEVEL, vocab=VOCAB_SIZE).to(DEVICE)
        opt = torch.optim.AdamW(model.parameters(), lr=5e-3, weight_decay=1e-4)
        aug = PermutationAugmentor(rng_seed=seed)

        stage_matrix = []
        for s_idx, stage_rules in enumerate(stages):
            # Train on this stage
            for step in range(150):
                model.train()
                opt.zero_grad()
                rule = stage_rules[step % len(stage_rules)]
                batch = db.make_batch(rule, TRAIN_VOCAB, BS, seed=seed + s_idx * 500 + step).to(DEVICE)
                loss = model(input_ids=batch, labels=batch).loss
                perm_b = aug.maybe_remap(batch, rule, prob=1.0, target_vocab=DISJOINT_VOCAB).to(DEVICE)
                loss = loss + model(input_ids=perm_b, labels=perm_b).loss
                loss.backward()
                torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
                opt.step()

            # Evaluate all 6 rules at this stage
            model.eval()
            rule_accs = {}
            for r in ALL_RULES:
                eval_batch = db.make_batch(r, TRAIN_VOCAB, BS, seed=seed + 999)
                rule_accs[r] = evaluate_seq_acc(model, eval_batch, DEVICE)
            stage_matrix.append(rule_accs)

        seed_histories.append(stage_matrix)

    # Average matrix across seeds
    avg_matrix = []
    for s_idx in range(len(stages)):
        stage_avg = {}
        for r in ALL_RULES:
            stage_avg[r] = float(np.mean([hist[s_idx][r] for hist in seed_histories]))
        avg_matrix.append(stage_avg)

    rules_first_introduced = ["copy", "increment", "fixed_shift", "double_step"]
    retention_metrics = compute_retention_metrics(avg_matrix, rules_first_introduced)

    print(f"  Avg Forgetting: {retention_metrics['avg_forgetting']*100:.2f}%")
    print(f"  Avg Final Retention: {retention_metrics['avg_final_retention']*100:.2f}%")

    return {
        "stage_names": stage_names,
        "avg_matrix": avg_matrix,
        "metrics": retention_metrics,
    }


def main():
    print("=== Nirmal-1 V10.7 — Rule Generalization & Algorithm Transfer Study ===")
    print(f"Device: {DEVICE}, Model Scale: {LEVEL}, Seeds: {SEEDS}")

    db = V10_7_DataBuilder(VOCAB_SIZE)

    # 1. Leakage certificate
    ref_train = db.make_batch("increment", TRAIN_VOCAB, BS, 42)
    ref_ood = db.make_batch("increment", DISJOINT_VOCAB, BS, 42)
    cert = db.leakage_certificate(ref_train, ref_ood)
    print(f"Leakage Certificate: {cert}")
    assert cert["valid"], "Leakage audit failed!"

    # 2. Run Experiments A & B
    exp_ab = run_experiment_a_and_b(db)

    # 3. Run Experiments C & D
    exp_c, exp_d = run_experiment_c_and_d(db)

    # 4. Run Experiment E
    exp_e = run_experiment_e(db)

    # 5. Run Experiment F
    exp_f = run_experiment_f(db)

    # 6. Run Experiment G
    exp_g = run_experiment_g(db)

    # 7. Run Experiment H
    exp_h = run_experiment_h(db)

    # 8. Classify results
    level1_ood = exp_ab["overall_disjoint"]["mean"]
    # Level 2 is held-out rule on known vocab (C1)
    level2_gen = float(np.mean([exp_c[h]["c1_known_vocab"]["mean"] for h in exp_c]))
    # Level 3 is held-out rule on disjoint vocab (C2)
    level3_comp = float(np.mean([exp_c[h]["c2_disjoint_vocab"]["mean"] for h in exp_c]))
    avg_forgetting = exp_h["metrics"]["avg_forgetting"]

    classification = classify_generalization(level1_ood, level2_gen, level3_comp, avg_forgetting)
    print(f"\nFinal Classification: {classification}")
    print(f"Level 1 Rule Transfer (Disjoint OOD): {level1_ood*100:.2f}%")
    print(f"Level 2 Rule Generalization (Held-out Known Vocab): {level2_gen*100:.2f}%")
    print(f"Level 3 Compositional Generalization (Held-out Disjoint): {level3_comp*100:.2f}%")

    all_data = {
        "device": str(DEVICE),
        "scale": LEVEL,
        "seeds": SEEDS,
        "leakage": cert,
        "exp_a_multi_rule": exp_ab["overall_same"],
        "exp_b_rule_transfer": exp_ab,
        "exp_c_held_out": exp_c,
        "exp_d_few_shot": exp_d,
        "exp_e_cross_rule": exp_e,
        "exp_f_intensity": exp_f,
        "exp_g_diagnostics": exp_g,
        "exp_h_retention": exp_h,
        "levels": {
            "level1_rule_transfer": level1_ood,
            "level2_rule_generalization": level2_gen,
            "level3_compositional": level3_comp,
        },
        "classification": classification,
    }

    ts = int(time.time())
    out_file = OUT / f"v10_7_results_{ts}.json"
    save_manifest(out_file, all_data)
    print(f"\nV10.7 Results saved to: {out_file}")


if __name__ == "__main__":
    main()
