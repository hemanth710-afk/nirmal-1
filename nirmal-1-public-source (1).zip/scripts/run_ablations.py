"""
Nirmal-1 Systematic Ablation Benchmarking Script.
Evaluates the empirical contribution of the 4 cognitive architectural axes:
1. Memory: ON vs OFF
2. Planner: ON (DAG decomposition) vs OFF (Direct single-step)
3. Verification: ON (Deterministic checking) vs OFF (Bypassed)
4. Replanning: ON (Dynamic failure recovery) vs OFF (Terminal failure)
"""

import sys
import time
from typing import Any, Dict, List, NamedTuple

from nirmal.tools import ToolRegistry, MockEnvironmentTool
from nirmal.agent.verification import DeterministicVerifier
from nirmal.agent.memory.semantic import SemanticMemory
from nirmal.agent.memory.episodic import EpisodicMemory
from nirmal.agent.memory.procedural import ProceduralMemory
from nirmal.agent.controller import CognitiveController, Goal, ControllerState


class BenchmarkTask(NamedTuple):
    task_id: str
    goal_description: str
    criteria: Any
    category: str  # "memory", "tool_arithmetic", "error_detection", "perturbation_recovery", "composition"
    inject_perturbation: bool = False


BENCHMARK_TASKS = [
    BenchmarkTask(
        task_id="mem_recall_1",
        goal_description="What is the secret_access_code?",
        criteria="omega-42",
        category="memory",
    ),
    BenchmarkTask(
        task_id="mem_recall_2",
        goal_description="What is the capital_of_france?",
        criteria="Paris",
        category="memory",
    ),
    BenchmarkTask(
        task_id="arithmetic_1",
        goal_description="Calculate 15 * 12 + 45",
        criteria=225.0,
        category="tool_arithmetic",
    ),
    BenchmarkTask(
        task_id="arithmetic_2",
        goal_description="Calculate 50 * 4",
        criteria=200.0,
        category="tool_arithmetic",
    ),
    BenchmarkTask(
        task_id="perturb_1",
        goal_description="Initialize sensor port COM3",
        criteria="COM3",
        category="perturbation_recovery",
        inject_perturbation=True,
    ),
    BenchmarkTask(
        task_id="verif_1",
        goal_description="Compute 100 * 2",
        criteria=200.0,
        category="error_detection",
    ),
]


def create_seeded_controller(
    enable_memory: bool = True,
    enable_planning: bool = True,
    enable_verification: bool = True,
    enable_replanning: bool = True,
) -> tuple[CognitiveController, MockEnvironmentTool]:
    mock_env = MockEnvironmentTool()
    tool_reg = ToolRegistry()
    tool_reg.register(mock_env)

    sem_mem = SemanticMemory()
    sem_mem.store_fact("secret_access_code", "omega-42")
    sem_mem.store_fact("capital_of_france", "Paris")
    sem_mem.store_fact("system_status", "nominal")

    ep_mem = EpisodicMemory()
    proc_mem = ProceduralMemory()
    verif = DeterministicVerifier()

    ctrl = CognitiveController(
        tool_registry=tool_reg,
        semantic_memory=sem_mem,
        episodic_memory=ep_mem,
        procedural_memory=proc_mem,
        verifier=verif,
        enable_memory=enable_memory,
        enable_planning=enable_planning,
        enable_verification=enable_verification,
        enable_replanning=enable_replanning,
    )
    return ctrl, mock_env


def run_single_task(ctrl: CognitiveController, mock_env: MockEnvironmentTool, task: BenchmarkTask) -> Dict[str, Any]:
    if task.inject_perturbation:
        # Build custom recovery plan for mock environment
        plan = ctrl.planner.create_linear_plan(
            goal=task.goal_description,
            steps=[
                {
                    "id": "write_step",
                    "description": "Write sensor port",
                    "tool_name": "mock_env",
                    "tool_args": {"action": "write", "key": "sensor_port", "value": "COM3"},
                },
                {
                    "id": "read_step",
                    "description": "Verify sensor port",
                    "tool_name": "mock_env",
                    "tool_args": {"action": "read", "key": "sensor_port", "expected": "COM3"},
                    "dependencies": ["write_step"],
                },
            ],
        )
        mock_env.set_fail_next(True, message="Transient interface timeout")
        ctrl.reset()
        ctrl.current_goal = Goal(goal_id=task.task_id, description=task.goal_description, criteria=task.criteria)
        from nirmal.agent.world_state import WorldState
        from nirmal.memory import WorkingMemory

        ctrl.world_state = WorldState(goal_description=task.goal_description)
        ctrl.working_memory = WorkingMemory(max_token_budget=1024)
        ctrl.active_plan = plan
        ctrl.state = ControllerState.PLAN

        start_t = time.time()
        while ctrl.state not in (ControllerState.DONE, ControllerState.FAILED) and ctrl.step_counter < 30:
            ctrl.step()
        duration = time.time() - start_t

        success = (ctrl.state == ControllerState.DONE and mock_env.state.get("sensor_port") == "COM3")
        return {
            "success": success,
            "steps": ctrl.step_counter,
            "duration": duration,
            "replans": ctrl.replan_count,
            "final_state": ctrl.state.value,
        }
    else:
        goal = Goal(goal_id=task.task_id, description=task.goal_description, criteria=task.criteria)
        res = ctrl.run(goal)
        # Check verified correctness
        is_correct = res.success
        if task.criteria is not None and res.final_output is not None:
            try:
                if isinstance(task.criteria, (int, float)):
                    is_correct = is_correct and (abs(float(res.final_output) - float(task.criteria)) < 1e-4)
                elif isinstance(task.criteria, str):
                    is_correct = is_correct and (str(res.final_output).strip().lower() == task.criteria.strip().lower())
            except (ValueError, TypeError):
                is_correct = False

        return {
            "success": is_correct,
            "steps": res.total_steps,
            "duration": res.duration_sec,
            "replans": ctrl.replan_count,
            "final_state": res.state.value,
        }


def run_ablation_benchmarks() -> None:
    print("=" * 80)
    print("NIRMAL-1 EMPIRICAL COGNITIVE ABLATION BENCHMARK")
    print("Systematic evaluation across 4 architectural axes")
    print("=" * 80)

    configs = {
        "Baseline (Full System)": {
            "enable_memory": True,
            "enable_planning": True,
            "enable_verification": True,
            "enable_replanning": True,
        },
        "Ablation: Memory OFF": {
            "enable_memory": False,
            "enable_planning": True,
            "enable_verification": True,
            "enable_replanning": True,
        },
        "Ablation: Planner OFF (Direct)": {
            "enable_memory": True,
            "enable_planning": False,
            "enable_verification": True,
            "enable_replanning": True,
        },
        "Ablation: Verification OFF": {
            "enable_memory": True,
            "enable_planning": True,
            "enable_verification": False,
            "enable_replanning": True,
        },
        "Ablation: Replanning OFF": {
            "enable_memory": True,
            "enable_planning": True,
            "enable_verification": True,
            "enable_replanning": False,
        },
    }

    results_table = []

    for cfg_name, cfg_kwargs in configs.items():
        print(f"\nEvaluating: {cfg_name}...")
        total_tasks = len(BENCHMARK_TASKS)
        passed_count = 0
        total_steps = 0
        total_duration = 0.0
        recovery_successes = 0
        recovery_attempts = 0

        for task in BENCHMARK_TASKS:
            ctrl, mock_env = create_seeded_controller(**cfg_kwargs)
            res = run_single_task(ctrl, mock_env, task)

            if res["success"]:
                passed_count += 1
            total_steps += res["steps"]
            total_duration += res["duration"]

            if task.inject_perturbation:
                recovery_attempts += 1
                if res["success"]:
                    recovery_successes += 1

            status_glyph = "[PASS]" if res["success"] else "[FAIL]"
            print(f"  {status_glyph} {task.task_id:<16} ({task.category:<22}): state={res['final_state']}, steps={res['steps']}, replans={res['replans']}")

        success_rate = (passed_count / total_tasks) * 100.0
        avg_steps = total_steps / total_tasks
        recovery_rate = (recovery_successes / recovery_attempts * 100.0) if recovery_attempts > 0 else 0.0

        results_table.append({
            "Configuration": cfg_name,
            "Tasks Passed": f"{passed_count}/{total_tasks}",
            "Success Rate": f"{success_rate:.1f}%",
            "Avg Steps": f"{avg_steps:.1f}",
            "Recovery Rate": f"{recovery_rate:.1f}%",
            "Total Time (s)": f"{total_duration:.4f}",
        })

    print("\n" + "=" * 80)
    print("ABLATION BENCHMARK SUMMARY TABLE")
    print("=" * 80)
    header = f"{'Configuration':<32} | {'Passed':<8} | {'Success':<10} | {'Avg Steps':<10} | {'Recovery':<10}"
    print(header)
    print("-" * len(header))
    for row in results_table:
        print(f"{row['Configuration']:<32} | {row['Tasks Passed']:<8} | {row['Success Rate']:<10} | {row['Avg Steps']:<10} | {row['Recovery Rate']:<10}")

    print("\nMarkdown Format for Documentation / Reports:")
    print("| Configuration | Tasks Passed | Success Rate | Avg Steps | Recovery Rate |")
    print("|---|---|---|---|---|")
    for row in results_table:
        print(f"| {row['Configuration']} | {row['Tasks Passed']} | {row['Success Rate']} | {row['Avg Steps']} | {row['Recovery Rate']} |")
    print("\nBenchmark completed successfully.")


if __name__ == "__main__":
    run_ablation_benchmarks()
