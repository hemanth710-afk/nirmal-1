"""
Blind Neural & Hybrid Evaluation Runner for Nirmal-1 V5.
Generates dynamically randomized neural evaluation trials at runtime:
1. Fully randomized entity and variable names (zero hardcoded strings)
2. Dynamic transition topology graphs
3. Neural dense retrieval and semantic matching under blinded keys
4. Hybrid state transition prediction and confidence calibration
5. Verification of randomized execution states
6. AST source scan verifying zero tokens from the blind suite exist in src/nirmal
"""

import ast
import json
from pathlib import Path
import random
import secrets
import statistics
import sys
import time
from typing import Any, Dict, List
import torch

ROOT_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT_DIR))
sys.path.insert(0, str(ROOT_DIR / "src"))

from nirmal.agent.neural_bridge import NeuralBridge
from nirmal.agent.world_model import WorldModel, CausalRule


def audit_anti_leakage(generated_tokens: List[str]) -> bool:
    """Scan all Python files in src/nirmal to ensure zero runtime-generated tokens appear in source."""
    src_dir = ROOT_DIR / "src" / "nirmal"
    source_files = list(src_dir.rglob("*.py"))
    forbidden = {tok.lower() for tok in generated_tokens if len(tok) > 3}

    for fpath in source_files:
        content = fpath.read_text(encoding="utf-8").lower()
        for tok in forbidden:
            if tok in content:
                raise RuntimeError(f"LEAKAGE DETECTED: Token '{tok}' from blind eval found in {fpath.name}")
    return True


def run_neural_blind_eval(num_trials: int = 30, base_seed: int = 9000) -> Dict[str, Any]:
    """Execute dynamic randomized blind evaluation trials."""
    rng = random.Random(base_seed + int(time.time() % 10000))
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    bridge = NeuralBridge(device=device)

    all_generated_tokens = []
    trial_results = []
    retrieval_successes = 0
    state_prediction_accuracies = []
    verification_accuracies = []

    for t in range(num_trials):
        nonce = secrets.token_hex(3)
        var_a = f"entity_{nonce}_alpha"
        var_b = f"entity_{nonce}_beta"
        act_1 = f"action_{nonce}_phase1"
        act_2 = f"action_{nonce}_phase2"
        val_target = rng.randint(100, 999)

        all_generated_tokens.extend([var_a, var_b, act_1, act_2, nonce])

        # 1. Blind Dense Retrieval Needle Test
        haystack = [
            f"telemetry packet status {nonce}_chk=0",
            f"auxiliary channel idle {nonce}_chk=1",
            f"target information: {var_a} value is {val_target}",
            f"system temperature nominal {nonce}_chk=3",
        ]
        query = f"What is {var_a} value?"
        ranked = bridge.rank_memories_by_relevance(query, haystack, top_k=2)
        retrieval_hit = any(var_a in item for item in ranked)
        if retrieval_hit:
            retrieval_successes += 1

        # 2. Blind World Model Hybrid Prediction
        wm = WorldModel(neural_bridge=bridge)
        # Register rule with blinded names
        rule = CausalRule(
            rule_id=f"r_{nonce}",
            action_name=act_1,
            effects={var_b: val_target},
            confidence=0.95,
        )
        wm.register_rule(rule)

        init_state = {var_a: 0, var_b: 0}
        # In-distribution known blinded action
        pred_known = wm.predict_hybrid(init_state, act_1)
        pred_acc_known = 1.0 if pred_known.get(var_b) == val_target else 0.0

        # Novel unobserved blinded action -> neural fallback
        pred_novel = wm.predict_hybrid(init_state, act_2)
        neural_fallback_active = len(pred_novel.predicted_state) > 0

        trial_pred_acc = 1.0 if (pred_acc_known == 1.0 and neural_fallback_active) else 0.0
        state_prediction_accuracies.append(trial_pred_acc)

        # 3. Blind Semantic Verification
        # Check correct matching on blinded state
        observed_valid = {var_b: val_target}
        observed_faulty = {var_b: 0}

        score_valid = bridge.score_verification(observed_valid, {var_b: val_target})
        score_faulty = bridge.score_verification(observed_faulty, {var_b: val_target})

        verif_pass = (score_valid >= 0.5 and score_valid > score_faulty)
        if verif_pass:
            verification_accuracies.append(1.0)
        else:
            verification_accuracies.append(0.0)

        trial_results.append({
            "trial": t + 1,
            "nonce": nonce,
            "retrieval_success": retrieval_hit,
            "prediction_accuracy": trial_pred_acc,
            "verification_success": verif_pass,
        })

    # AST anti-leakage audit
    leakage_free = audit_anti_leakage(all_generated_tokens)

    mean_retrieval = retrieval_successes / max(1, num_trials)
    mean_prediction = statistics.mean(state_prediction_accuracies)
    mean_verification = statistics.mean(verification_accuracies)

    return {
        "milestone": "NIRMAL-1 V5 BLIND NEURAL EVALUATION",
        "timestamp": time.time(),
        "num_trials": num_trials,
        "anti_leakage_audit_passed": leakage_free,
        "blind_dense_retrieval_rate": round(mean_retrieval, 4),
        "blind_state_prediction_accuracy": round(mean_prediction, 4),
        "blind_semantic_verification_rate": round(mean_verification, 4),
        "trials": trial_results,
    }


def main():
    print("=" * 80)
    print("NIRMAL-1 V5: RUNTIME RANDOMIZED BLIND EVALUATION")
    print("=" * 80)

    res = run_neural_blind_eval(num_trials=25)
    print(f"\nCompleted {res['num_trials']} runtime randomized blind trials:")
    print(f"  Anti-Leakage AST Scan:         Passed={res['anti_leakage_audit_passed']} (0 tokens in source)")
    print(f"  Blind Dense Retrieval Rate:    {res['blind_dense_retrieval_rate'] * 100:.1f}%")
    print(f"  Blind State Prediction Acc:    {res['blind_state_prediction_accuracy'] * 100:.1f}%")
    print(f"  Blind Verification Rate:       {res['blind_semantic_verification_rate'] * 100:.1f}%")

    out_file = ROOT_DIR / "experiments" / "neural_blind_eval_results.json"
    out_file.write_text(json.dumps(res, indent=2), encoding="utf-8")
    print(f"\n[OK] Results saved to: {out_file}")
    print("=" * 80)


if __name__ == "__main__":
    main()
