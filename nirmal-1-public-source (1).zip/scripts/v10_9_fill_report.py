"""Auto-populates docs/V10_9_FOUNDATIONAL_EPISODIC_LEARNING.md from JSON results."""

import json
from pathlib import Path

STAGE0_JSON = Path("experiments/v10_9/stage0/stage0_results.json")
STAGE1_JSON = Path("experiments/v10_9/stage1/stage1_results.json")
REPORT_PATH = Path("docs/V10_9_FOUNDATIONAL_EPISODIC_LEARNING.md")


def fill():
    if not STAGE0_JSON.exists() or not STAGE1_JSON.exists():
        raise FileNotFoundError("Stage 0 or Stage 1 JSON results missing.")

    d0 = json.loads(STAGE0_JSON.read_text(encoding="utf-8"))
    d1 = json.loads(STAGE1_JSON.read_text(encoding="utf-8"))
    text = REPORT_PATH.read_text(encoding="utf-8")

    # 1. Throughput Table
    p = d0["throughput_pilot"]
    tp_str = (
        f"- **Device:** `{p['device']}`\n"
        f"- **Speed:** `{p['episodes_per_sec']} episodes/sec` (`{p['tokens_per_sec']} tokens/sec`)\n"
        f"- **1,000-Step Wall Clock:** `{p['wall_clock_s']}s`\n"
        f"- **Peak VRAM Memory:** `{p['peak_memory_mb']} MB`"
    )
    text = text.replace("{THROUGHPUT_STATS}", tp_str)

    # 2. Stage 0 Sanity Table
    s0 = d0["stage0_sanitizers"]
    ob = s0["one_batch_overfit"]
    lp = s0["label_permutation_null"]
    ds = s0["direct_label_sanity"]
    nu = s0["no_update_control"]

    s0_rows = [
        "| Check | Model | Condition | Result | Verdict |",
        "|---|---|---|---|---|",
        f"| One-Batch Overfit | L0 | 128 fixed episodes | {ob['L0']['final_accuracy']*100:.1f}% (step {ob['L0']['reached_step']}) | `{'PASS' if ob['L0']['passed'] else 'FAIL'}` |",
        f"| One-Batch Overfit | L1 | 128 fixed episodes | {ob['L1']['final_accuracy']*100:.1f}% (step {ob['L1']['reached_step']}) | `{'PASS' if ob['L1']['passed'] else 'FAIL'}` |",
        f"| Label-Permutation Null | L0 | Shuffled labels | Val Acc = {lp['val_accuracy']*100:.1f}% (chance = {lp['chance_rate']*100:.1f}%) | `{'PASS' if lp['passed'] else 'FAIL'}` |",
        f"| Direct-Label Control | L0 | Answer in support | Val Acc = {ds['final_accuracy']*100:.1f}% | `{'PASS' if ds['passed'] else 'FAIL'}` |",
        f"| No-Update Control | L0 | Frozen parameters | Pre = {nu['pre_checksum']:.4f}, Post = {nu['post_checksum']:.4f} | `{'PASS' if nu['passed'] else 'FAIL'}` |",
    ]
    text = text.replace("{STAGE0_TABLE}", "\n".join(s0_rows))

    # 3. Factorial Calibration Table
    fac = d1["factorial_results"]
    fac_rows = [
        "| Cell | Model | LR | Batch Size | Steps | Val Correct Acc | Val Random Acc | Correct - Random |",
        "|---|---|---|---|---|---|---|---|",
    ]
    for cid, cdata in fac.items():
        fac_rows.append(
            f"| **{cid}** | {cdata['scale']} | {cdata['lr']} | {cdata['batch_size']} | {cdata['steps']} "
            f"| {cdata['val_correct_acc']*100:.1f}% | {cdata['val_random_acc']*100:.1f}% | {cdata['correct_minus_random']*100:+.1f}% |"
        )
    text = text.replace("{FACTORIAL_TABLE}", "\n".join(fac_rows))

    # 4. Confirmation Table across Seeds
    conf = d1["confirmation_results"]
    conf_rows = [
        "| Cell | Seed | Stage 1A Val Acc | Stage 1B Correct Acc | Stage 1B Random Acc | Stage 1B Wrong Acc | Stage 1B Absent Acc | Support Utility |",
        "|---|---|---|---|---|---|---|---|",
    ]
    for cid, cdata in conf.items():
        for s in [42, 43, 44]:
            r1a = cdata["runs_1a"][str(s)]
            r1b = cdata["runs_1b"][str(s)]
            conf_rows.append(
                f"| **{cid}** | {s} | {r1a['val_acc']*100:.1f}% | {r1b['val_correct_acc']*100:.1f}% "
                f"| {r1b['val_random_acc']*100:.1f}% | {r1b['val_wrong_acc']*100:.1f}% | {r1b['val_absent_acc']*100:.1f}% | {r1b['correct_minus_random']*100:+.1f}% |"
            )
    text = text.replace("{CONFIRMATION_TABLE}", "\n".join(conf_rows))

    # 5. Readiness Gates Summary
    gate_lines = []
    any_authorized = False
    for cid, cdata in conf.items():
        g1a = cdata["gate_1a"]
        g1b = cdata["gate_1b"]
        auth = cdata["stage1_authorized"]
        if auth:
            any_authorized = True
        gate_lines.append(f"### Configuration `{cid}`:")
        gate_lines.append(f"- **Stage 1A Gates:** Gate1={g1a['gate1_train_mastery']}, Gate2={g1a['gate2_val_generalization']}, Gate4={g1a['gate4_seed_stability']}, Gate5={g1a['gate5_integrity']} -> All Passed: **`{g1a['all_passed']}`**")
        gate_lines.append(f"- **Stage 1B Gates:** Gate1={g1b['gate1_train_mastery']}, Gate2={g1b['gate2_val_generalization']}, Gate3={g1b['gate3_causal_utility']}, Gate4={g1b['gate4_seed_stability']}, Gate5={g1b['gate5_integrity']} -> All Passed: **`{g1b['all_passed']}`**")
        gate_lines.append(f"- **Stage 2 Authorization:** **`{'AUTHORIZED' if auth else 'BLOCKED'}`**\n")
    text = text.replace("{READINESS_GATES_SUMMARY}", "\n".join(gate_lines))

    # Final verdict
    auth_str = "**NO — STOPPING AS DIRECTED FOR SCIENTIFIC REVIEW**" if any_authorized else "**BLOCKED — GATES NOT SATISFIED**"
    text = text.replace("{STAGE2_AUTHORIZATION}", auth_str)

    REPORT_PATH.write_text(text, encoding="utf-8")
    print(f"Report successfully updated: {REPORT_PATH}")


if __name__ == "__main__":
    fill()
