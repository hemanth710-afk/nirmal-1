"""Auto-fills docs/V10_6_SYMBOL_RELATION_DECOUPLING_STUDY.md from experiment results."""

import json
import time
from pathlib import Path

OUT    = Path("experiments/v10_6")
REPORT = Path("docs/V10_6_SYMBOL_RELATION_DECOUPLING_STUDY.md")


def wait() -> dict:
    while True:
        fs = sorted(OUT.glob("v10_6_results_*.json"))
        if fs:
            return json.loads(fs[-1].read_text())
        print("Waiting for results...", flush=True)
        time.sleep(3)


def pct(d, key="mean") -> str:
    if not isinstance(d, dict): return "N/A"
    return f"{d[key]*100:.2f}%"


def row(d) -> str:
    if not isinstance(d, dict): return "N/A"
    return f"{d['mean']*100:.2f}% ± {d['ci95']*100:.2f}%"


def fill():
    data = wait()
    text = REPORT.read_text(encoding="utf-8")

    ablations = ["A0", "A1", "A2", "A3", "A4", "A5", "A6"]
    labels = {
        "A0": "Identity Only (Baseline)",
        "A1": "Identity + Pairwise Relation",
        "A2": "Identity + Random Frozen Relation (Control)",
        "A3": "Identity + Perm Augmentation",
        "A4": "Identity + Relation + Perm Aug",
        "A5": "Identity + Relation + Perm Aug + Consistency",
        "A6": "Full (Scaffold Removed at Eval)",
    }

    # --- Main OOD table ---
    table_lines = [
        "| Ablation | Description | Params | Train Acc | OOD Acc | Held-Out OOD | OOD Gain |",
        "|---|---|---|---|---|---|---|",
    ]
    a0_ood = data["A0"]["mean_ood"]["mean"]
    for ab in ablations:
        d = data[ab]
        gain = d.get("ood_gain_over_a0", 0.0)
        table_lines.append(
            f"| **{ab}** | {labels[ab]} | {d['param_count']:,} "
            f"| {row(d['mean_train'])} | {row(d['mean_ood'])} "
            f"| {row(d['held_out_mean_ood'])} | {gain*100:+.2f}% |"
        )
    text = text.replace("{MAIN_TABLE}", "\n".join(table_lines))

    # --- Per-rule OOD table ---
    from training.evaluation.v10_6_harness import ALL_RULES
    rule_lines = ["| Rule | " + " | ".join([f"{ab} OOD" for ab in ablations]) + " |",
                  "|---| " + " | ".join(["---"] * len(ablations)) + " |"]
    for rule in ALL_RULES:
        cells = [row(data[ab][f"{rule}_ood"]) if ab in data else "N/A" for ab in ablations]
        rule_lines.append(f"| **{rule}** | " + " | ".join(cells) + " |")
    text = text.replace("{RULE_TABLE}", "\n".join(rule_lines))

    # --- Invariance diagnostics ---
    inv_lines = ["| Ablation | d_same | d_diff | Invariance Gap |",
                 "|---|---|---|---|"]
    for ab in ["A1", "A4", "A5"]:
        if ab in data and data[ab].get("d_same") is not None:
            inv_lines.append(f"| {ab} | {data[ab]['d_same']:.4f} | {data[ab]['d_diff']:.4f} | {data[ab]['invariance_gap']:.4f} |")
    text = text.replace("{INV_TABLE}", "\n".join(inv_lines))

    # --- Leakage cert ---
    cert = data.get("leakage", {})
    cert_str = (
        f"- vocab_disjoint: `{cert.get('vocab_disjoint', '?')}`\n"
        f"- no_row_overlap: `{cert.get('no_row_overlap', '?')}`\n"
        f"- no_subseq_leak: `{cert.get('no_subseq_leak', '?')}`\n"
        f"- valid: `{cert.get('valid', '?')}`"
    )
    text = text.replace("{LEAKAGE_CERT}", cert_str)

    # --- Classification ---
    a5_ood = data.get("A5", {}).get("mean_ood", {}).get("mean", 0.0)
    a6_ood = data.get("A6", {}).get("mean_ood", {}).get("mean", 0.0)
    best_ood = max(a5_ood, a6_ood)
    gain_a5  = data.get("A5", {}).get("ood_gain_over_a0", 0.0)

    if best_ood >= 0.80:
        cls = "INTERNALIZED_RELATION"
        desc = f"The model achieved ≥80% fully-disjoint OOD ({best_ood*100:.2f}%). This constitutes a **breakthrough** result."
        rec  = "Advance to production-scale evaluation with learned relation channel."
    elif gain_a5 >= 0.20:
        cls = "PARTIAL_INTERNALIZATION"
        desc = f"Meaningful generalization signal: +{gain_a5*100:.2f}% OOD gain over the identity baseline."
        rec  = "Scale capacity (L0→L2) and training steps to consolidate the signal."
    elif best_ood > 0.00 or gain_a5 > 0.00:
        cls = "SCAFFOLD_DEPENDENT"
        desc = f"Marginal improvement ({gain_a5*100:.2f}% gain) that did not survive scaffold removal."
        rec  = "Investigate stronger equivariance constraints or symbolic token decoupling."
    else:
        cls = "NO_INTERNALIZATION"
        desc = "All ablations, including full decoupling with permutation consistency, yielded 0.00% fully-disjoint OOD. The representation bottleneck persists."
        rec  = "Investigate equivariant embedding projectors that decouple token integer ID from relation rank."

    text = text.replace("{CLASSIFICATION}", f"**Classification:** `{cls}`\n\n{desc}")
    text = text.replace("{RECOMMENDATION}", f"**Recommendation for V10.7:** {rec}")

    REPORT.write_text(text, encoding="utf-8")
    print("Report populated successfully.")


if __name__ == "__main__":
    fill()
