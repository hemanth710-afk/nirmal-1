"""Builds the Immutable V10.8 Learning-to-Learn Benchmark.

Constructs standardized, leakage-audited evaluation episodes for:
- Levels L1 to L5
- Demonstration Curves (k in {0, 1, 2, 4, 8, 16})
- Control Conditions (Correct, Random, Wrong-Rule, Distractor, Length-Matched, Position-Matched, Label-Noise)

Saves immutable benchmark artifacts to experiments/v10_8/benchmark/ and computes MANIFEST.sha256.
"""

import hashlib
import json
import os
import sys
from pathlib import Path
from typing import Any, Dict, List

import torch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from training.evaluation.v10_8_harness import (
    DEFAULT_VOCAB_SIZE,
    HELD_OUT_TRANSLATE_C,
    P_FIELD,
    Episode,
    EpisodeBuilder,
    LeakageAuditor,
    RuleDefinition,
    RuleSampler,
    collate_episodes,
)

BENCHMARK_DIR = Path("experiments/v10_8/benchmark")
BENCHMARK_DIR.mkdir(parents=True, exist_ok=True)

SEED = 108000
EPISODES_PER_CONDITION = 100
K_EVAL_DEFAULT = 4


def generate_benchmark() -> Dict[str, Any]:
    print("=== Building Immutable V10.8 Benchmark ===")
    g = torch.Generator().manual_seed(SEED)
    builder = EpisodeBuilder(p=P_FIELD)
    sampler = RuleSampler(p=P_FIELD, held_out_c=HELD_OUT_TRANSLATE_C)

    benchmark_data: Dict[str, Any] = {}
    all_episodes_for_audit: List[Episode] = []

    # ── Level 1: Known Rule + Unseen Symbols ──────────────────────────────────
    print("Generating Level 1: Known Rule + Unseen Symbols...")
    l1_episodes = []
    for _ in range(EPISODES_PER_CONDITION):
        rule = sampler.sample_seen_rule(g)
        ep = builder.build_episode(rule, k=K_EVAL_DEFAULT, symbol_regime="V-A", is_unseen_symbol=True, g=g)
        l1_episodes.append(ep)
    benchmark_data["L1_known_rule_unseen_symbols"] = l1_episodes
    all_episodes_for_audit.extend(l1_episodes)

    # ── Level 2: Known Family + Unseen Parameter (c*) ────────────────────────
    print("Generating Level 2: Known Family + Unseen Parameter...")
    l2_episodes = []
    rule_c_star = sampler.sample_held_out_parameter_rule()
    for _ in range(EPISODES_PER_CONDITION):
        ep = builder.build_episode(rule_c_star, k=K_EVAL_DEFAULT, symbol_regime="V-A", is_unseen_symbol=False, g=g)
        l2_episodes.append(ep)
    benchmark_data["L2_known_family_unseen_parameter"] = l2_episodes
    all_episodes_for_audit.extend(l2_episodes)

    # ── Level 3: Held-Out Family + Known Symbols ─────────────────────────────
    print("Generating Level 3: Held-Out Family + Known Symbols...")
    l3_episodes = []
    for _ in range(EPISODES_PER_CONDITION):
        fam = "power" if (_ % 2 == 0) else "threshold"
        rule = sampler.sample_held_out_family_rule(fam, g=g)
        ep = builder.build_episode(rule, k=K_EVAL_DEFAULT, symbol_regime="V-A", is_unseen_symbol=False, g=g)
        l3_episodes.append(ep)
    benchmark_data["L3_held_out_family_known_symbols"] = l3_episodes
    all_episodes_for_audit.extend(l3_episodes)

    # ── Level 4: Held-Out Family + Unseen Symbols ────────────────────────────
    print("Generating Level 4: Held-Out Family + Unseen Symbols...")
    l4_episodes = []
    for _ in range(EPISODES_PER_CONDITION):
        fam = "power" if (_ % 2 == 0) else "threshold"
        rule = sampler.sample_held_out_family_rule(fam, g=g)
        ep = builder.build_episode(rule, k=K_EVAL_DEFAULT, symbol_regime="V-A", is_unseen_symbol=True, g=g)
        l4_episodes.append(ep)
    benchmark_data["L4_held_out_family_unseen_symbols"] = l4_episodes
    all_episodes_for_audit.extend(l4_episodes)

    # ── Level 5: Composed Held-Out Rule (Affine) + Unseen Symbols ────────────
    print("Generating Level 5: Composed Rule (Affine) + Unseen Symbols...")
    l5_episodes = []
    for _ in range(EPISODES_PER_CONDITION):
        rule = sampler.sample_held_out_family_rule("affine", g=g)
        ep = builder.build_episode(rule, k=K_EVAL_DEFAULT, symbol_regime="V-A", is_unseen_symbol=True, g=g)
        l5_episodes.append(ep)
    benchmark_data["L5_composed_rule_unseen_symbols"] = l5_episodes
    all_episodes_for_audit.extend(l5_episodes)

    # ── Demonstration Curves (k in {0, 1, 2, 4, 8, 16}) ───────────────────────
    print("Generating Demonstration Curves...")
    demo_curves: Dict[str, Dict[int, List[Episode]]] = {
        "correct": {},
        "random": {},
        "wrong_rule": {},
    }
    k_vals = [0, 1, 2, 4, 8, 16]

    for k in k_vals:
        correct_eps = []
        random_eps = []
        wrong_eps = []

        for _ in range(EPISODES_PER_CONDITION):
            rule = sampler.sample_seen_rule(g)
            wrong_r = sampler.sample_seen_rule(g)
            while wrong_r == rule:
                wrong_r = sampler.sample_seen_rule(g)

            # Correct support
            ep_c = builder.build_episode(rule, k=k, symbol_regime="V-A", is_unseen_symbol=True, g=g, control="correct")
            correct_eps.append(ep_c)

            # Random support (only if k > 0, else identical to k=0)
            if k > 0:
                ep_r = builder.build_episode(rule, k=k, symbol_regime="V-A", is_unseen_symbol=True, g=g, control="random")
                ep_w = builder.build_episode(rule, k=k, symbol_regime="V-A", is_unseen_symbol=True, g=g, control="wrong_rule", wrong_rule=wrong_r)
            else:
                ep_r = ep_c
                ep_w = ep_c

            random_eps.append(ep_r)
            wrong_eps.append(ep_w)

        demo_curves["correct"][k] = correct_eps
        demo_curves["random"][k] = random_eps
        demo_curves["wrong_rule"][k] = wrong_eps
        all_episodes_for_audit.extend(correct_eps)

    benchmark_data["demonstration_curves"] = demo_curves

    # ── Controls Matrix (Matched k=4) ─────────────────────────────────────────
    print("Generating Controls Matrix...")
    controls_matrix: Dict[str, List[Episode]] = {}
    control_types = ["correct", "random", "wrong_rule", "label_noise"]

    for c_type in control_types:
        c_eps = []
        for _ in range(EPISODES_PER_CONDITION):
            rule = sampler.sample_seen_rule(g)
            wrong_r = sampler.sample_seen_rule(g)
            ep = builder.build_episode(
                rule, k=K_EVAL_DEFAULT, symbol_regime="V-A", is_unseen_symbol=True, g=g,
                control=c_type, wrong_rule=wrong_r
            )
            c_eps.append(ep)
        controls_matrix[c_type] = c_eps
        all_episodes_for_audit.extend(c_eps)

    benchmark_data["controls"] = controls_matrix

    # ── Strict Leakage Audit ──────────────────────────────────────────────────
    print("Auditing all benchmark episodes for leakage...")
    for ep in all_episodes_for_audit:
        res = LeakageAuditor.audit_episode(ep)
        assert res["valid"], f"Leakage detected in episode: {res}"

    # Serialize tensors and ground-truth metadata
    serialized_data = {}
    metadata = {
        "version": "10.8",
        "p_field": P_FIELD,
        "seed": SEED,
        "episodes_per_condition": EPISODES_PER_CONDITION,
        "k_eval_default": K_EVAL_DEFAULT,
        "total_episodes": len(all_episodes_for_audit),
        "conditions": list(benchmark_data.keys()),
    }

    # Convert Episode objects to serializable form
    for section, ep_list in benchmark_data.items():
        if isinstance(ep_list, list):
            serialized_data[section] = [
                {
                    "input_ids": ep.input_ids.tolist(),
                    "target": int(ep.target),
                    "k": ep.k,
                    "rule_family": ep.rule.family,
                    "rule_params": list(ep.rule.params),
                    "symbol_regime": ep.symbol_regime,
                    "is_unseen_symbol": ep.is_unseen_symbol,
                    "qx_val": ep.qx_val,
                    "qy_val": ep.qy_val,
                }
                for ep in ep_list
            ]
        elif isinstance(ep_list, dict):
            # Nested dictionary for demo curves / controls
            sub_dict = {}
            for sub_k, sub_v in ep_list.items():
                if isinstance(sub_v, dict):
                    sub_sub = {}
                    for k_shot, eps in sub_v.items():
                        sub_sub[str(k_shot)] = [
                            {
                                "input_ids": ep.input_ids.tolist(),
                                "target": int(ep.target),
                                "k": ep.k,
                                "rule_family": ep.rule.family,
                                "rule_params": list(ep.rule.params),
                                "symbol_regime": ep.symbol_regime,
                                "is_unseen_symbol": ep.is_unseen_symbol,
                                "qx_val": ep.qx_val,
                                "qy_val": ep.qy_val,
                            }
                            for ep in eps
                        ]
                    sub_dict[sub_k] = sub_sub
                elif isinstance(sub_v, list):
                    sub_dict[sub_k] = [
                        {
                            "input_ids": ep.input_ids.tolist(),
                            "target": int(ep.target),
                            "k": ep.k,
                            "rule_family": ep.rule.family,
                            "rule_params": list(ep.rule.params),
                            "symbol_regime": ep.symbol_regime,
                            "is_unseen_symbol": ep.is_unseen_symbol,
                            "qx_val": ep.qx_val,
                            "qy_val": ep.qy_val,
                        }
                        for ep in sub_v
                    ]
            serialized_data[section] = sub_dict

    # Save data.pt and metadata.json
    torch_file = BENCHMARK_DIR / "benchmark_data.pt"
    meta_file = BENCHMARK_DIR / "metadata.json"

    torch.save(serialized_data, torch_file)
    with open(meta_file, "w", encoding="utf-8") as f:
        json.dump(metadata, f, indent=2)

    # Compute MANIFEST.sha256
    manifest_file = BENCHMARK_DIR / "MANIFEST.sha256"
    hashes = {}
    for target_file in sorted([torch_file, meta_file, Path(__file__)]):
        h = hashlib.sha256(target_file.read_bytes()).hexdigest()
        hashes[target_file.name] = h

    with open(manifest_file, "w", encoding="utf-8") as f:
        for fname, h in hashes.items():
            f.write(f"{h}  {fname}\n")

    print(f"Benchmark saved to: {BENCHMARK_DIR}")
    print(f"Benchmark Manifest:\n{manifest_file.read_text(encoding='utf-8')}")
    return metadata


if __name__ == "__main__":
    generate_benchmark()
