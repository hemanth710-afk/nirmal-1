"""
Production Dataset Manifest, Provenance, and Versioning System for Nirmal-1 V8.4.

Features:
- Immutable dataset version tracking: NIRMAL-DATA-V8.4-001, NIRMAL-DATA-V8.4-002, etc.
- Strict provenance metadata: source name, URL, license, timestamp, sizes, token counts, SHA-256.
- License validation: strictly rejects unclear, non-commercial, or proprietary sources.
- Strict token categorization: LOCAL VERIFIED, REMOTE VERIFIED, PLANNED, ESTIMATED (never combined).
- Shard manifest indexing and cryptographic verification.
"""

from dataclasses import dataclass, field, asdict
import hashlib
import json
import os
from pathlib import Path
import time
from typing import Any, Dict, List, Optional, Set, Tuple

REPO_ROOT = Path(__file__).resolve().parent.parent

# Permissive Open-Source & Open-Science Licenses Allowed
ALLOWED_LICENSES = {
    "Apache-2.0",
    "MIT",
    "BSD-2-Clause",
    "BSD-3-Clause",
    "CC-BY-4.0",
    "CC0-1.0",
    "Open-Data-Commons-Attribution",
    "ODC-By",
    "ODC-By-1.0",
}

REJECTED_LICENSE_PATTERNS = [
    "non-commercial",
    "nc",
    "proprietary",
    "unknown",
    "restricted",
    "gpl",
    "agpl",
    "all-rights-reserved",
]


class LicenseProvenanceViolationError(Exception):
    """Raised when a dataset source fails license or provenance verification."""
    pass


class ManifestIntegrityError(ValueError):
    """Raised when a dataset manifest fails cryptographic signature or tamper verification."""
    pass


@dataclass
class SourceProvenanceRecord:
    source_name: str
    source_identifier: str  # URL or persistent DOI/ID
    license: str
    provenance_details: str
    acquisition_timestamp: str
    original_size_bytes: int
    processed_size_bytes: int
    measured_token_count: int
    source_sha256: str
    preprocessing_version: str

    def validate_license(self) -> bool:
        """Check license permissiveness and reject unclear or restricted licenses."""
        lic_norm = self.license.strip()
        lic_lower = lic_norm.lower()

        for pattern in REJECTED_LICENSE_PATTERNS:
            if pattern in lic_lower:
                return False

        if lic_norm in ALLOWED_LICENSES or any(al.lower() in lic_lower for al in ALLOWED_LICENSES):
            return True
        return False

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class TokenAccountingCategories:
    local_verified_tokens: int = 0
    remote_verified_tokens: int = 0
    planned_tokens: int = 200_000_000_000
    estimated_tokens: int = 0

    def to_dict(self) -> Dict[str, Any]:
        # Never combine into a single ambiguous number
        return {
            "LOCAL_VERIFIED": self.local_verified_tokens,
            "REMOTE_VERIFIED": self.remote_verified_tokens,
            "PLANNED": self.planned_tokens,
            "ESTIMATED": self.estimated_tokens,
            "category_policy": "STRICT_SEPARATION_ENFORCED (Never combined)",
        }


@dataclass
class ShardManifestEntry:
    shard_id: str
    filename: str
    token_count: int
    document_count: int
    byte_size: int
    sha256_checksum: str
    domain_distribution: Dict[str, int]
    tokenizer_version: str
    dataset_version: str

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


class DatasetManifestManager:
    """
    Manages production dataset manifests, version progression, and cryptographic auditing.
    """

    def __init__(self, dataset_version: str = "NIRMAL-DATA-V8.4-001", manifest_dir: Optional[Path] = None):
        self.dataset_version = dataset_version
        self.manifest_dir = manifest_dir or (REPO_ROOT / "data")
        self.manifest_dir.mkdir(parents=True, exist_ok=True)
        self.manifest_path = self.manifest_dir / f"{dataset_version}.manifest.json"

        self.sources: List[SourceProvenanceRecord] = []
        self.shards: List[ShardManifestEntry] = []
        self.token_accounting = TokenAccountingCategories()
        self.domain_token_counts: Dict[str, int] = {}
        self.tokenizer_metadata: Dict[str, Any] = {
            "type": "ByteLevelBPETokenizer",
            "vocab_size": 32000,
            "checksum": "21e5e370e3e1c0e396f65d19925e851e540ca17e70d4236763326def714251cf",
            "version": "bpe_32k_v1",
        }

    def register_source(self, source: SourceProvenanceRecord) -> None:
        """Register and validate a data source."""
        if not source.validate_license():
            raise LicenseProvenanceViolationError(
                f"Source '{source.source_name}' rejected due to non-permissive or unclear license: '{source.license}'"
            )
        self.sources.append(source)

    def register_shard(self, shard: ShardManifestEntry) -> None:
        """Register a verified shard into the manifest."""
        self.shards.append(shard)
        for dom, count in shard.domain_distribution.items():
            self.domain_token_counts[dom] = self.domain_token_counts.get(dom, 0) + count

    def update_token_accounting(self, local_verified: int, remote_verified: int = 0, estimated: int = 0) -> None:
        self.token_accounting.local_verified_tokens = local_verified
        self.token_accounting.remote_verified_tokens = remote_verified
        self.token_accounting.estimated_tokens = estimated

    def compute_dataset_fingerprint(
        self,
        dedup_config: Optional[Dict[str, Any]] = None,
        split_config: Optional[Dict[str, Any]] = None,
    ) -> str:
        """
        Computes a deterministic dataset configuration fingerprint based on:
        - Dataset version
        - Tokenizer checksum
        - Sources (identities and content hashes)
        - Deduplication parameters
        - Split assignments
        """
        components = {
            "dataset_version": self.dataset_version,
            "tokenizer_checksum": self.tokenizer_metadata.get("checksum"),
            "sources": sorted([f"{s.source_identifier}:{s.source_sha256}" for s in self.sources]),
            "dedup_config": dedup_config or {"exact_dedup": True, "num_perm": 64, "jaccard_threshold": 0.85},
            "split_config": split_config or {"train_ratio": 0.80, "val_ratio": 0.10, "test_ratio": 0.10},
        }
        payload = json.dumps(components, sort_keys=True).encode("utf-8")
        return hashlib.sha256(payload).hexdigest()

    def generate_authoritative_accounting_report(
        self,
        target_production_tokens: int = 200_000_000_000,
    ) -> Dict[str, Any]:
        """
        Generates single authoritative token accounting report strictly separating
        physically verified tokens from remote, planned, or estimated values.
        """
        # Sum physically verified tokens from registered shards
        shard_tokens = sum(s.token_count for s in self.shards)
        local_verified = max(self.token_accounting.local_verified_tokens, shard_tokens)
        remote_verified = self.token_accounting.remote_verified_tokens
        planned = self.token_accounting.planned_tokens
        estimated = self.token_accounting.estimated_tokens

        deficit = max(0, target_production_tokens - local_verified)
        pct = (local_verified / target_production_tokens * 100.0) if target_production_tokens > 0 else 0.0

        return {
            "target_production_tokens": target_production_tokens,
            "categories": {
                "LOCAL_VERIFIED": local_verified,
                "REMOTE_VERIFIED": remote_verified,
                "PLANNED": planned,
                "ESTIMATED": estimated,
            },
            "token_deficit": deficit,
            "completion_percentage": round(pct, 6),
            "production_launch_gate_passed": (local_verified >= target_production_tokens),
            "gate_verdict": "GO" if local_verified >= target_production_tokens else "NO-GO",
            "policy": "STRICT_SEPARATION_ENFORCED: Only LOCAL_VERIFIED counts toward launch gate.",
        }

    def save_manifest(self) -> Path:
        """Serializes manifest to disk atomically with cryptographic self-signature."""
        manifest_content = {
            "dataset_version": self.dataset_version,
            "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "status": "IMMUTABLE_FREEZE",
            "token_accounting": self.token_accounting.to_dict(),
            "tokenizer": self.tokenizer_metadata,
            "total_shards": len(self.shards),
            "domain_token_counts": self.domain_token_counts,
            "dataset_fingerprint": self.compute_dataset_fingerprint(),
            "sources": [s.to_dict() for s in self.sources],
            "shards": [s.to_dict() for s in self.shards],
        }

        # Compute payload hash
        payload_bytes = json.dumps(manifest_content, sort_keys=True, indent=2).encode("utf-8")
        manifest_signature = hashlib.sha256(payload_bytes).hexdigest()
        manifest_content["manifest_sha256_signature"] = manifest_signature

        tmp_path = self.manifest_path.with_suffix(".tmp")
        try:
            with open(tmp_path, "w", encoding="utf-8") as f:
                json.dump(manifest_content, f, indent=2)
            os.replace(tmp_path, self.manifest_path)
        finally:
            if tmp_path.exists():
                try:
                    tmp_path.unlink()
                except OSError:
                    pass

        return self.manifest_path

    @classmethod
    def load_and_verify_manifest(cls, manifest_path: Path) -> Dict[str, Any]:
        """Loads manifest and validates cryptographic signature."""
        if not manifest_path.exists():
            raise FileNotFoundError(f"Manifest not found at {manifest_path}")

        with open(manifest_path, "r", encoding="utf-8") as f:
            data = json.load(f)

        sig = data.pop("manifest_sha256_signature", None)
        payload_bytes = json.dumps(data, sort_keys=True, indent=2).encode("utf-8")
        computed_sig = hashlib.sha256(payload_bytes).hexdigest()

        if sig is not None and sig != computed_sig:
            raise ManifestIntegrityError(
                f"Manifest signature mismatch! Manifest has been altered or corrupted. Stored: {sig}, Computed: {computed_sig}"
            )

        data["manifest_sha256_signature"] = sig
        return data
