"""
Standalone training script for Nirmal-1.
Supports gradient accumulation, gradient clipping, AdamW optimizer,
cosine learning rate scheduling, and automated checkpointing.
"""

import argparse
from pathlib import Path
import sys
import time
import torch
from torch.utils.data import DataLoader

# Add src and root to path for imports
root_dir = Path(__file__).parent.parent
sys.path.insert(0, str(root_dir / "src"))
sys.path.insert(0, str(root_dir))

from nirmal.configuration_nirmal import NirmalConfig
from nirmal.model import NirmalForCausalLM
from training.dataset import SyntheticTokenDataset
from training.checkpoint import CheckpointManager


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Train Nirmal-1 model prototype.")
    parser.add_argument("--num_steps", type=int, default=10, help="Number of training steps to execute.")
    parser.add_argument("--batch_size", type=int, default=2, help="Batch size per training step.")
    parser.add_argument("--seq_len", type=int, default=64, help="Sequence length for inputs.")
    parser.add_argument("--lr", type=float, default=1e-3, help="Peak learning rate.")
    parser.add_argument("--weight_decay", type=float, default=0.01, help="AdamW weight decay.")
    parser.add_argument("--max_grad_norm", type=float, default=1.0, help="Gradient clipping norm.")
    parser.add_argument("--save_dir", type=str, default="checkpoints", help="Directory to save checkpoints.")
    parser.add_argument("--save_interval", type=int, default=5, help="Save checkpoint every N steps.")
    parser.add_argument("--hidden_size", type=int, default=256, help="Model hidden size.")
    parser.add_argument("--num_layers", type=int, default=4, help="Number of decoder layers.")
    parser.add_argument("--num_heads", type=int, default=4, help="Number of attention heads.")
    parser.add_argument("--num_kv_heads", type=int, default=2, help="Number of KV heads.")
    parser.add_argument("--head_dim", type=int, default=64, help="Dimension per head.")
    parser.add_argument("--num_experts", type=int, default=4, help="Number of MoE experts.")
    parser.add_argument("--num_experts_per_tok", type=int, default=2, help="Active experts per token.")
    parser.add_argument("--vocab_size", type=int, default=1000, help="Vocabulary size.")
    return parser.parse_args()


def train(args: argparse.Namespace) -> None:
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"=== Nirmal-1 Prototype Training Initialized on {device} ===")

    # Configure model
    config = NirmalConfig(
        vocab_size=args.vocab_size,
        hidden_size=args.hidden_size,
        num_hidden_layers=args.num_layers,
        num_attention_heads=args.num_heads,
        num_key_value_heads=args.num_kv_heads,
        head_dim=args.head_dim,
        context_length=args.seq_len * 2,
        num_experts=args.num_experts,
        num_experts_per_tok=args.num_experts_per_tok,
        full_attention_interval=2,  # Alternates DeltaNet and GQA
    )

    model = NirmalForCausalLM(config).to(device)
    param_counts = model.count_parameters()
    print(f"Total Parameters: {param_counts['total']:,} (Trainable: {param_counts['trainable']:,})")
    print(f"Layer Layout: {config.layer_types}")

    # Dataset & DataLoader
    dataset = SyntheticTokenDataset(
        num_samples=max(100, args.num_steps * args.batch_size),
        seq_len=args.seq_len,
        vocab_size=args.vocab_size,
        seed=1337,
    )
    dataloader = DataLoader(dataset, batch_size=args.batch_size, shuffle=True)

    optimizer = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=args.num_steps, eta_min=1e-5)
    ckpt_manager = CheckpointManager(save_dir=args.save_dir, max_to_keep=3)

    model.train()
    step = 0
    start_time = time.time()
    data_iter = iter(dataloader)

    print("-" * 65)
    print(f"{'Step':<8} | {'Total Loss':<12} | {'Router Loss':<12} | {'LR':<10} | {'Time/step'}")
    print("-" * 65)

    while step < args.num_steps:
        step_start = time.time()
        try:
            batch = next(data_iter)
        except StopIteration:
            data_iter = iter(dataloader)
            batch = next(data_iter)

        input_ids = batch["input_ids"].to(device)
        labels = batch["labels"].to(device)

        optimizer.zero_grad()
        outputs = model(input_ids=input_ids, labels=labels)
        loss = outputs.loss
        router_loss = outputs.router_loss

        loss.backward()
        grad_norm = torch.nn.utils.clip_grad_norm_(model.parameters(), args.max_grad_norm)
        optimizer.step()
        scheduler.step()

        step += 1
        elapsed = time.time() - step_start

        current_lr = scheduler.get_last_lr()[0]
        r_loss_val = router_loss.item() if router_loss is not None else 0.0
        print(f"{step:<8} | {loss.item():<12.4f} | {r_loss_val:<12.5f} | {current_lr:<10.2e} | {elapsed*1000:.1f}ms")

        if step % args.save_interval == 0 or step == args.num_steps:
            saved_path = ckpt_manager.save(
                model=model,
                optimizer=optimizer,
                scheduler=scheduler,
                step=step,
                loss=loss.item(),
            )
            print(f"  --> Saved Checkpoint to {saved_path.name}")

    total_time = time.time() - start_time
    print("-" * 65)
    print(f"Training completed successfully in {total_time:.2f}s ({step} steps).")


if __name__ == "__main__":
    train(parse_args())
