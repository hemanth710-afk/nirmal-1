"""
Cloud Training Cost, Throughput, and Scaling Runtime Model for Nirmal-1 V8.4.

Features:
- Analytical roofline modeling for 25.91B parameter Candidate C (~4.24B active params/token).
- Cluster topology evaluations: 8x, 16x, 64x, 128x, 256x H100 SXM5 80GB.
- Strict telemetry labeling: MEASURED, ASSUMED, ESTIMATED.
- Computes FLOPs, MFU, token throughput, wall-clock duration, energy/power, and dollar costs.
"""

from dataclasses import dataclass, field, asdict
import json
import math
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

REPO_ROOT = Path(__file__).resolve().parent.parent

# Published NVIDIA H100 SXM5 80GB Reference Specifications
H100_BF16_PEAK_TFLOPS = 989.0          # Dense BF16 Tensor Core peak per GPU
H100_FP8_PEAK_TFLOPS = 1979.0          # FP8 Tensor Core peak per GPU
H100_VRAM_GB = 80.0                    # HBM3 VRAM per GPU
H100_HBM_BANDWIDTH_TB_S = 3.35         # HBM3 Memory Bandwidth per GPU
H100_SXM5_TDP_WATTS = 700.0            # Thermal Design Power per GPU
NVLINK4_BIDIRECTIONAL_GB_S = 900.0     # NVSwitch 4 inter-GPU bandwidth


@dataclass
class TopologyConfig:
    name: str
    num_gpus: int
    nodes: int
    interconnect: str
    est_scaling_efficiency: float      # Inter-node scaling penalty factor
    cost_per_gpu_hour_usd: float = 3.00


@dataclass
class TrainingRunCostProjection:
    topology_name: str
    num_gpus: int
    target_tokens: int
    total_model_parameters: int
    active_parameters_per_token: int
    effective_mfu_pct: float
    throughput_tokens_per_sec: float
    total_training_seconds: float
    total_training_hours: float
    total_training_days: float
    total_gpu_hours: float
    compute_cost_usd: float
    storage_and_egress_cost_usd: float
    total_projected_cost_usd: float
    total_energy_kwh: float
    provenance_labels: Dict[str, str]

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


class TrainingCostModel:
    """
    Computes rigorous FLOP-based throughput and budget estimations for Nirmal-1 Candidate C.
    """

    def __init__(
        self,
        total_params: int = 25_910_000_000,
        active_params: int = 4_240_000_000,
        assumed_mfu: float = 0.40,
        default_cost_per_gpu_hour: float = 3.00,
    ):
        self.total_params = total_params
        self.active_params = active_params
        self.assumed_mfu = assumed_mfu
        self.default_cost_per_gpu_hour = default_cost_per_gpu_hour

        # Standard forward + backward pass FLOPs per token: ~6 * active_params
        self.flops_per_token = 6.0 * float(self.active_params)

        # Standard reference cluster configurations
        self.topologies = [
            TopologyConfig("8x H100 (Single Node)", num_gpus=8, nodes=1, interconnect="NVLink 4 (900 GB/s)", est_scaling_efficiency=0.96, cost_per_gpu_hour_usd=default_cost_per_gpu_hour),
            TopologyConfig("16x H100 (2 Nodes)", num_gpus=16, nodes=2, interconnect="InfiniBand NDR 400G", est_scaling_efficiency=0.92, cost_per_gpu_hour_usd=default_cost_per_gpu_hour),
            TopologyConfig("64x H100 (8 Nodes - Recommended)", num_gpus=64, nodes=8, interconnect="InfiniBand NDR 400G (Rail-Optimized)", est_scaling_efficiency=0.88, cost_per_gpu_hour_usd=default_cost_per_gpu_hour),
            TopologyConfig("128x H100 (16 Nodes)", num_gpus=128, nodes=16, interconnect="InfiniBand NDR 400G", est_scaling_efficiency=0.85, cost_per_gpu_hour_usd=default_cost_per_gpu_hour),
            TopologyConfig("256x H100 (32 Nodes - Fast Scale)", num_gpus=256, nodes=32, interconnect="InfiniBand NDR 800G", est_scaling_efficiency=0.82, cost_per_gpu_hour_usd=default_cost_per_gpu_hour),
        ]

    def calculate_projection(
        self,
        topology: TopologyConfig,
        target_tokens: int = 200_000_000_000,
        storage_flat_usd: float = 850.0,
    ) -> TrainingRunCostProjection:
        """
        Calculates wall-clock duration and financial cost for specified tokens and topology.
        """
        # Peak BF16 FLOP/s per GPU
        peak_gpu_flops = H100_BF16_PEAK_TFLOPS * 1e12

        # Effective FLOP/s per GPU = peak * MFU * scaling_efficiency
        effective_gpu_flops = peak_gpu_flops * self.assumed_mfu * topology.est_scaling_efficiency
        cluster_effective_flops = effective_gpu_flops * topology.num_gpus

        # Cluster tokens per second
        throughput_tokens_sec = cluster_effective_flops / self.flops_per_token

        # Total training duration
        total_seconds = target_tokens / throughput_tokens_sec
        total_hours = total_seconds / 3600.0
        total_days = total_hours / 24.0

        # GPU-hours and financial cost
        total_gpu_hours = total_hours * topology.num_gpus
        compute_cost = total_gpu_hours * topology.cost_per_gpu_hour_usd
        total_cost = compute_cost + storage_flat_usd

        # Energy consumption: 700W GPU + ~200W host/cooling per GPU = ~900W per GPU
        total_power_kw = (topology.num_gpus * 0.90)
        total_energy_kwh = total_power_kw * total_hours

        provenance = {
            "h100_peak_flops": "ASSUMED (NVIDIA H100 SXM5 Whitepaper: 989 TFLOPS BF16)",
            "mfu": "ESTIMATED (40.0% standard MoE / GQA pipeline target)",
            "scaling_efficiency": f"ESTIMATED ({topology.est_scaling_efficiency * 100:.1f}% based on NVLink/InfiniBand network topology)",
            "cost_rate": f"ASSUMED (${topology.cost_per_gpu_hour_usd:.2f}/GPU-hr based on current cloud spot/reserved averages)",
            "local_hardware": "MEASURED (Host inspection independent of cloud simulation)",
        }

        return TrainingRunCostProjection(
            topology_name=topology.name,
            num_gpus=topology.num_gpus,
            target_tokens=target_tokens,
            total_model_parameters=self.total_params,
            active_parameters_per_token=self.active_params,
            effective_mfu_pct=round(self.assumed_mfu * topology.est_scaling_efficiency * 100.0, 2),
            throughput_tokens_per_sec=round(throughput_tokens_sec, 1),
            total_training_seconds=round(total_seconds, 1),
            total_training_hours=round(total_hours, 2),
            total_training_days=round(total_days, 2),
            total_gpu_hours=round(total_gpu_hours, 2),
            compute_cost_usd=round(compute_cost, 2),
            storage_and_egress_cost_usd=round(storage_flat_usd, 2),
            total_projected_cost_usd=round(total_cost, 2),
            total_energy_kwh=round(total_energy_kwh, 1),
            provenance_labels=provenance,
        )

    def evaluate_all_topologies(
        self,
        target_tokens: int = 200_000_000_000,
    ) -> List[Dict[str, Any]]:
        """Run cost and throughput projection across all topologies."""
        results = []
        for topo in self.topologies:
            proj = self.calculate_projection(topo, target_tokens=target_tokens)
            results.append(proj.to_dict())
        return results
