"""
Distributed Training & Parallelism Topology Manager for Nirmal-1 V8.
Supports:
1. ZeRO-3 / PyTorch Fully Sharded Data Parallel (FSDP)
2. Platform & OS distributed backend audit (Linux/NCCL vs Windows/Gloo)
3. Sharding strategies: FULL_SHARD (ZeRO-3), SHARD_GRAD_OP (ZeRO-2), NO_SHARD (DDP)
4. Mixed precision (BF16, FP16, FP32)
5. Activation checkpointing integration (NO_REENTRANT)
6. Parameter CPU offloading
7. Full & Sharded checkpoint state dict extraction and atomic persistence
8. Communication volume calculations across multi-GPU / multi-node topologies
"""

from dataclasses import dataclass, asdict, field
import functools
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys
import tempfile
import time
from typing import Any, Callable, Dict, List, Optional, Set, Tuple, Type, Union

import torch
import torch.nn as nn
import torch.distributed as dist

# PyTorch FSDP imports
from torch.distributed.fsdp import (
    FullyShardedDataParallel as FSDP,
    ShardingStrategy,
    MixedPrecision,
    BackwardPrefetch,
    CPUOffload,
    StateDictType,
    FullStateDictConfig,
    FullOptimStateDictConfig,
    ShardedStateDictConfig,
    ShardedOptimStateDictConfig,
)
from torch.distributed.fsdp.wrap import (
    transformer_auto_wrap_policy,
    size_based_auto_wrap_policy,
)
from torch.distributed.algorithms._checkpoint.checkpoint_wrapper import (
    checkpoint_wrapper,
    CheckpointImpl,
    apply_activation_checkpointing,
)


class PlatformBackendError(RuntimeError):
    """Raised when distributed training is attempted with an unsupported platform/backend combination."""
    pass


class PlatformDistributedBackend:
    """
    Detects hardware, operating system, and PyTorch distributed backend capabilities.
    Enforces platform safety boundaries (e.g. Linux NCCL vs Windows Gloo).
    """

    @staticmethod
    def get_platform_info() -> Dict[str, Any]:
        """Returns comprehensive diagnostic information about the local host environment."""
        cuda_avail = torch.cuda.is_available()
        cuda_count = torch.cuda.device_count() if cuda_avail else 0
        device_name = torch.cuda.get_device_name(0) if cuda_avail and cuda_count > 0 else "None"

        dist_avail = dist.is_available()
        nccl_avail = dist.is_nccl_available() if dist_avail else False
        gloo_avail = dist.is_gloo_available() if dist_avail else False
        mpi_avail = dist.is_mpi_available() if dist_avail else False

        return {
            "platform": sys.platform,
            "os_name": os.name,
            "python_version": sys.version.split()[0],
            "torch_version": torch.__version__,
            "cuda_available": cuda_avail,
            "cuda_device_count": cuda_count,
            "cuda_device_name": device_name,
            "dist_available": dist_avail,
            "nccl_available": nccl_avail,
            "gloo_available": gloo_avail,
            "mpi_available": mpi_avail,
            "is_linux": sys.platform.startswith("linux"),
            "is_windows": sys.platform == "win32",
        }

    @classmethod
    def supports_cuda_fsdp_backward(cls) -> bool:
        """
        Determines whether the current platform supports FSDP backward gradient reduction on CUDA.
        PyTorch FSDP CUDA backward collectives require NCCL, which is only supported on Linux.
        On Windows, Gloo cannot perform CUDA reduce-scatter collectives, triggering a C++ abort.
        """
        info = cls.get_platform_info()
        return info["cuda_available"] and info["nccl_available"] and info["is_linux"]

    @classmethod
    def get_recommended_backend(cls, device: Optional[Union[str, torch.device]] = None) -> str:
        """
        Selects the safest distributed communication backend for the current environment.
        - Linux with CUDA: 'nccl'
        - Windows or CPU-only: 'gloo'
        """
        info = cls.get_platform_info()
        target_device = str(device).lower() if device is not None else ("cuda" if info["cuda_available"] else "cpu")

        if "cuda" in target_device and info["nccl_available"] and info["is_linux"]:
            return "nccl"
        if info["gloo_available"]:
            return "gloo"
        if info["nccl_available"]:
            return "nccl"
        raise PlatformBackendError("No supported PyTorch distributed backend available (neither Gloo nor NCCL).")

    @classmethod
    def check_backward_safety(cls, device: torch.device) -> Tuple[bool, str]:
        """
        Checks whether running FSDP loss.backward() on the given device is safe on this platform.
        Returns (is_safe, explanation_message).
        """
        if device.type == "cuda" and not cls.supports_cuda_fsdp_backward():
            msg = (
                "Production multi-GPU FSDP backward training requires Linux with NCCL support. "
                "Current platform is Windows/win32 without NCCL. "
                "While Gloo supports FSDP initialization, forward pass, and state dict export on CUDA, "
                "Gloo lacks CUDA reduce-scatter collectives needed for backward gradient synchronization."
            )
            return False, msg
        return True, "Platform backend is compatible with FSDP backward pass."


@dataclass
class FSDPConfig:
    """
    Configuration parameters for PyTorch Fully Sharded Data Parallel (FSDP / ZeRO-3).
    """
    sharding_strategy: str = "FULL_SHARD"  # FULL_SHARD (ZeRO-3), SHARD_GRAD_OP (ZeRO-2), NO_SHARD (DDP), HYBRID_SHARD
    mixed_precision: str = "bf16"          # bf16, fp16, fp32, none
    cpu_offload: bool = False
    activation_checkpointing: bool = True
    backward_prefetch: str = "BACKWARD_PRE"  # BACKWARD_PRE, BACKWARD_POST, NONE
    forward_prefetch: bool = True
    limit_all_gathers: bool = True
    sync_module_states: bool = True
    use_orig_params: bool = False

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    def get_sharding_strategy(self) -> ShardingStrategy:
        strat = self.sharding_strategy.upper()
        if strat in ("FULL_SHARD", "ZERO-3", "ZERO3"):
            return ShardingStrategy.FULL_SHARD
        elif strat in ("SHARD_GRAD_OP", "ZERO-2", "ZERO2"):
            return ShardingStrategy.SHARD_GRAD_OP
        elif strat in ("NO_SHARD", "DDP"):
            return ShardingStrategy.NO_SHARD
        elif strat in ("HYBRID_SHARD", "HYBRID"):
            return ShardingStrategy.HYBRID_SHARD
        raise ValueError(f"Unknown sharding strategy: '{self.sharding_strategy}'. Expected FULL_SHARD, SHARD_GRAD_OP, NO_SHARD, or HYBRID_SHARD.")

    def get_mixed_precision(self) -> Optional[MixedPrecision]:
        prec = self.mixed_precision.lower()
        if prec == "bf16":
            dtype = torch.bfloat16
            return MixedPrecision(param_dtype=dtype, reduce_dtype=dtype, buffer_dtype=dtype)
        elif prec == "fp16":
            dtype = torch.float16
            return MixedPrecision(param_dtype=dtype, reduce_dtype=dtype, buffer_dtype=dtype)
        elif prec in ("fp32", "none"):
            return None
        raise ValueError(f"Unknown mixed precision: '{self.mixed_precision}'. Expected 'bf16', 'fp16', 'fp32', or 'none'.")

    def get_backward_prefetch(self) -> Optional[BackwardPrefetch]:
        bp = self.backward_prefetch.upper()
        if bp == "BACKWARD_PRE":
            return BackwardPrefetch.BACKWARD_PRE
        elif bp == "BACKWARD_POST":
            return BackwardPrefetch.BACKWARD_POST
        elif bp in ("NONE", "DISABLED"):
            return None
        raise ValueError(f"Unknown backward prefetch: '{self.backward_prefetch}'. Expected BACKWARD_PRE, BACKWARD_POST, or NONE.")

    def get_cpu_offload(self) -> CPUOffload:
        return CPUOffload(offload_params=self.cpu_offload)


@dataclass
class ParallelismConfig:
    """Legacy / general parallelism configuration for Nirmal-1."""
    data_parallel_size: int = 1
    tensor_parallel_size: int = 1
    pipeline_parallel_size: int = 1
    expert_parallel_size: int = 1
    zero_stage: int = 3  # ZeRO-3 / FSDP
    world_size: int = 1
    rank: int = 0
    local_rank: int = 0
    is_distributed: bool = False

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


class DistributedTopologyManager:
    """
    Manages communication groups, sharding, and cluster layout for large-scale training.
    """

    def __init__(self, config: Optional[ParallelismConfig] = None):
        if config is None:
            self.config = self._detect_environment()
        else:
            self.config = config

    def _detect_environment(self) -> ParallelismConfig:
        """Auto-detect distributed environment from standard environment variables."""
        world_size = int(os.environ.get("WORLD_SIZE", "1"))
        rank = int(os.environ.get("RANK", "0"))
        local_rank = int(os.environ.get("LOCAL_RANK", "0"))
        is_dist = world_size > 1 and dist.is_available() and dist.is_initialized()

        return ParallelismConfig(
            data_parallel_size=world_size,
            tensor_parallel_size=1,
            pipeline_parallel_size=1,
            expert_parallel_size=min(world_size, 8),
            zero_stage=3 if world_size > 1 else 0,
            world_size=world_size,
            rank=rank,
            local_rank=local_rank,
            is_distributed=is_dist,
        )

    def calculate_communication_volume(
        self,
        active_params: int,
        hidden_size: int,
        num_tokens_per_batch: int,
        num_layers: int,
    ) -> Dict[str, float]:
        """
        Calculates communication overhead per training step across parallelism topologies.
        Returns bytes per step for All-Gather, Reduce-Scatter, and MoE All-to-All.
        """
        ws = max(1, self.config.world_size)

        # 1. ZeRO-3 / FSDP: All-Gather weights in forward + backward, Reduce-Scatter gradients
        fsdp_allgather_bytes = 2.0 * float(active_params) * ((ws - 1) / ws)
        fsdp_reducescatter_bytes = 2.0 * float(active_params) * ((ws - 1) / ws)
        total_fsdp_bytes = 2 * fsdp_allgather_bytes + fsdp_reducescatter_bytes

        # 2. Expert Parallelism: All-to-All communication for routing token activations to experts
        tokens_bytes_per_layer = 2.0 * float(num_tokens_per_batch) * float(hidden_size) * 2.0
        alltoall_bytes = float(num_layers) * tokens_bytes_per_layer * ((ws - 1) / ws)

        return {
            "world_size": ws,
            "fsdp_total_comm_mb_per_step": round(total_fsdp_bytes / (1024 * 1024), 2),
            "moe_alltoall_comm_mb_per_step": round(alltoall_bytes / (1024 * 1024), 2),
            "total_step_comm_mb": round((total_fsdp_bytes + alltoall_bytes) / (1024 * 1024), 2),
        }

    def barrier(self) -> None:
        """Synchronize across distributed workers if distributed is initialized."""
        if self.config.is_distributed:
            dist.barrier()


def _get_default_transformer_layer_cls() -> Optional[Type[nn.Module]]:
    """Dynamically resolves NirmalDecoderLayer to avoid hard-coded static dependencies."""
    try:
        from nirmal.model import NirmalDecoderLayer
        return NirmalDecoderLayer
    except ImportError:
        return None


class NirmalFSDPManager:
    """
    Manages PyTorch Fully Sharded Data Parallel (FSDP / ZeRO-3) lifecycle for Nirmal-1.
    Handles process initialization, device assignment, layer auto-wrapping,
    activation checkpointing, full/sharded checkpoint saving and reloading.
    """

    def __init__(
        self,
        fsdp_config: Optional[FSDPConfig] = None,
        topology: Optional[DistributedTopologyManager] = None,
    ):
        self.fsdp_config = fsdp_config or FSDPConfig()
        self.topology = topology or DistributedTopologyManager()
        self._wrapped_model: Optional[FSDP] = None
        self._init_file: Optional[str] = None

    def init_distributed(
        self,
        backend: Optional[str] = None,
        init_method: Optional[str] = None,
        rank: Optional[int] = None,
        world_size: Optional[int] = None,
    ) -> Dict[str, Any]:
        """
        Initializes the PyTorch distributed process group.
        Auto-configures temporary file initialization if MASTER_ADDR / MASTER_PORT are absent.
        """
        if dist.is_available() and dist.is_initialized():
            return {
                "initialized": True,
                "rank": dist.get_rank(),
                "world_size": dist.get_world_size(),
                "backend": dist.get_backend(),
                "init_method": "already_initialized",
            }

        resolved_world_size = world_size if world_size is not None else int(os.environ.get("WORLD_SIZE", "1"))
        resolved_rank = rank if rank is not None else int(os.environ.get("RANK", "0"))
        resolved_backend = backend or PlatformDistributedBackend.get_recommended_backend()

        if init_method is None:
            if "MASTER_ADDR" in os.environ and "MASTER_PORT" in os.environ:
                resolved_init_method = "env://"
            else:
                # File-based initialization for single-node / local smoke testing
                tf = tempfile.NamedTemporaryFile(delete=False, prefix="nirmal_fsdp_pg_")
                self._init_file = tf.name
                tf.close()
                resolved_init_method = f"file:///{self._init_file.replace(os.sep, '/')}"
        else:
            resolved_init_method = init_method

        dist.init_process_group(
            backend=resolved_backend,
            init_method=resolved_init_method,
            rank=resolved_rank,
            world_size=resolved_world_size,
        )

        return {
            "initialized": dist.is_initialized(),
            "rank": dist.get_rank(),
            "world_size": dist.get_world_size(),
            "backend": dist.get_backend(),
            "init_method": resolved_init_method,
        }

    def assign_device(self, local_rank: Optional[int] = None) -> torch.device:
        """
        Resolves and configures the target hardware device for the current rank.
        """
        if torch.cuda.is_available():
            lr = local_rank if local_rank is not None else int(os.environ.get("LOCAL_RANK", "0"))
            dev_count = torch.cuda.device_count()
            dev_idx = lr % max(1, dev_count)
            device = torch.device(f"cuda:{dev_idx}")
            torch.cuda.set_device(device)
            return device
        return torch.device("cpu")

    def wrap_model(
        self,
        model: nn.Module,
        auto_wrap_layer_cls: Optional[Any] = None,
        device_id: Optional[torch.device] = None,
        apply_activation_checkpointing_flag: Optional[bool] = None,
    ) -> FSDP:
        """
        Wraps a Nirmal model in PyTorch Fully Sharded Data Parallel (FSDP).
        Applies layer-wise transformer auto-wrap policy on NirmalDecoderLayer.
        """
        target_device = device_id if device_id is not None else self.assign_device()

        # Move model to target device if not CPU offloading
        if target_device.type == "cuda" and not self.fsdp_config.cpu_offload:
            model = model.to(target_device)

        # Resolve decoder layer class for transformer auto-wrap
        target_layer_cls = auto_wrap_layer_cls or _get_default_transformer_layer_cls()
        if target_layer_cls is None:
            # Search model hierarchy for decoder layer candidate
            for mod in model.modules():
                cname = mod.__class__.__name__
                if "DecoderLayer" in cname or "Block" in cname:
                    target_layer_cls = mod.__class__
                    break

        auto_wrap_policy = None
        if target_layer_cls is not None:
            auto_wrap_policy = functools.partial(
                transformer_auto_wrap_policy,
                transformer_layer_cls={target_layer_cls},
            )

        # Construct FSDP instance
        fsdp_model = FSDP(
            model,
            auto_wrap_policy=auto_wrap_policy,
            sharding_strategy=self.fsdp_config.get_sharding_strategy(),
            mixed_precision=self.fsdp_config.get_mixed_precision(),
            cpu_offload=self.fsdp_config.get_cpu_offload(),
            backward_prefetch=self.fsdp_config.get_backward_prefetch(),
            forward_prefetch=self.fsdp_config.forward_prefetch,
            limit_all_gathers=self.fsdp_config.limit_all_gathers,
            sync_module_states=self.fsdp_config.sync_module_states,
            use_orig_params=self.fsdp_config.use_orig_params,
            device_id=target_device if target_device.type == "cuda" else None,
        )

        # Configure activation checkpointing if requested
        should_ckpt = (
            apply_activation_checkpointing_flag
            if apply_activation_checkpointing_flag is not None
            else self.fsdp_config.activation_checkpointing
        )
        if should_ckpt and target_layer_cls is not None:
            self.configure_activation_checkpointing(
                fsdp_model,
                check_fn=lambda submodule: isinstance(submodule, target_layer_cls),
            )

        self._wrapped_model = fsdp_model
        return fsdp_model

    def configure_activation_checkpointing(
        self,
        fsdp_model: nn.Module,
        check_fn: Optional[Callable[[nn.Module], bool]] = None,
    ) -> None:
        """
        Applies PyTorch activation checkpointing wrapper using non-reentrant implementation.
        """
        if check_fn is None:
            target_layer_cls = _get_default_transformer_layer_cls()
            if target_layer_cls is not None:
                check_fn = lambda sm: isinstance(sm, target_layer_cls)
            else:
                check_fn = lambda sm: "DecoderLayer" in sm.__class__.__name__

        apply_activation_checkpointing(
            fsdp_model,
            checkpoint_wrapper_fn=functools.partial(
                checkpoint_wrapper,
                checkpoint_impl=CheckpointImpl.NO_REENTRANT,
            ),
            check_fn=check_fn,
        )

    def save_checkpoint(
        self,
        model: nn.Module,
        optimizer: Optional[torch.optim.Optimizer] = None,
        output_dir: Union[str, Path] = "checkpoints",
        step: int = 0,
        state_dict_type: str = "full",
        rank0_only: bool = True,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Path:
        """
        Atomically extracts and saves FSDP model weights, optimizer states, and metadata.
        Supports FULL_STATE_DICT (consolidated) and SHARDED_STATE_DICT.
        """
        rank = dist.get_rank() if dist.is_available() and dist.is_initialized() else 0
        root_dir = Path(output_dir)
        root_dir.mkdir(parents=True, exist_ok=True)
        final_dir = root_dir / f"checkpoint_{step}"
        tmp_dir = root_dir / f".tmp_ckpt_{step}_{os.getpid()}_{rank}"

        if tmp_dir.exists():
            shutil.rmtree(tmp_dir, ignore_errors=True)
        tmp_dir.mkdir(parents=True, exist_ok=True)

        is_fsdp = isinstance(model, FSDP)
        model_state: Dict[str, Any] = {}
        optim_state: Optional[Dict[str, Any]] = None

        if is_fsdp:
            if state_dict_type.lower() == "full":
                save_cfg = FullStateDictConfig(offload_to_cpu=True, rank0_only=rank0_only)
                optim_cfg = FullOptimStateDictConfig(offload_to_cpu=True, rank0_only=rank0_only)
                with FSDP.state_dict_type(model, StateDictType.FULL_STATE_DICT, save_cfg, optim_cfg):
                    model_state = model.state_dict()
                    if optimizer is not None:
                        try:
                            optim_state = FSDP.optim_state_dict(model, optimizer)
                        except Exception:
                            optim_state = None
            else:
                sharded_cfg = ShardedStateDictConfig(offload_to_cpu=True)
                sharded_opt_cfg = ShardedOptimStateDictConfig(offload_to_cpu=True)
                with FSDP.state_dict_type(model, StateDictType.SHARDED_STATE_DICT, sharded_cfg, sharded_opt_cfg):
                    model_state = model.state_dict()
                    if optimizer is not None:
                        try:
                            optim_state = FSDP.optim_state_dict(model, optimizer)
                        except Exception:
                            optim_state = None
        else:
            model_state = model.state_dict()
            if optimizer is not None:
                optim_state = optimizer.state_dict()

        # Save files on rank 0 (or all ranks if not rank0_only)
        should_save = (rank == 0) or (not rank0_only and state_dict_type.lower() != "full")
        if should_save:
            model_file = tmp_dir / ("model.pt" if state_dict_type.lower() == "full" else f"model_rank_{rank}.pt")
            if model_state:
                torch.save(model_state, model_file)

            if optim_state is not None and len(optim_state) > 0:
                optim_file = tmp_dir / ("optimizer.pt" if state_dict_type.lower() == "full" else f"optimizer_rank_{rank}.pt")
                torch.save(optim_state, optim_file)

            meta_data = dict(metadata or {})
            meta_data.update({
                "step": step,
                "rank": rank,
                "state_dict_type": state_dict_type,
                "timestamp": time.strftime("%Y-%m-%d %H:%M:%S UTC", time.gmtime()),
                "sharding_strategy": self.fsdp_config.sharding_strategy,
                "mixed_precision": self.fsdp_config.mixed_precision,
            })
            with open(tmp_dir / "metadata.json", "w", encoding="utf-8") as mf:
                json.dump(meta_data, mf, indent=2)

            # Atomic move / replace
            if rank == 0:
                if final_dir.exists():
                    shutil.rmtree(final_dir, ignore_errors=True)
                tmp_dir.rename(final_dir)
            else:
                # Merge rank file into existing final directory
                final_dir.mkdir(parents=True, exist_ok=True)
                for f in tmp_dir.iterdir():
                    shutil.move(str(f), str(final_dir / f.name))
                shutil.rmtree(tmp_dir, ignore_errors=True)

        self.barrier()
        return final_dir

    def load_checkpoint(
        self,
        model: nn.Module,
        checkpoint_dir: Union[str, Path],
        optimizer: Optional[torch.optim.Optimizer] = None,
        state_dict_type: str = "full",
    ) -> Dict[str, Any]:
        """
        Loads saved weights and optimizer state into an FSDP or non-FSDP model.
        """
        ckpt_dir = Path(checkpoint_dir)
        meta_file = ckpt_dir / "metadata.json"
        meta: Dict[str, Any] = {}
        if meta_file.exists():
            with open(meta_file, "r", encoding="utf-8") as mf:
                meta = json.load(mf)

        model_file = ckpt_dir / "model.pt"
        if not model_file.exists():
            rank = dist.get_rank() if dist.is_available() and dist.is_initialized() else 0
            model_file = ckpt_dir / f"model_rank_{rank}.pt"

        if not model_file.exists():
            raise FileNotFoundError(f"No valid checkpoint weights found in {checkpoint_dir}")

        state_dict = torch.load(model_file, map_location="cpu", weights_only=True)

        if isinstance(model, FSDP):
            if state_dict_type.lower() == "full":
                load_cfg = FullStateDictConfig(offload_to_cpu=True, rank0_only=False)
                load_opt_cfg = FullOptimStateDictConfig(offload_to_cpu=True, rank0_only=False)
                with FSDP.state_dict_type(model, StateDictType.FULL_STATE_DICT, load_cfg, load_opt_cfg):
                    model.load_state_dict(state_dict)
                    opt_file = ckpt_dir / "optimizer.pt"
                    if optimizer is not None and opt_file.exists():
                        opt_state = torch.load(opt_file, map_location="cpu", weights_only=True)
                        try:
                            sharded_opt_state = FSDP.optim_state_dict_to_load(model, optimizer, opt_state)
                            optimizer.load_state_dict(sharded_opt_state)
                        except Exception:
                            pass
            else:
                sharded_cfg = ShardedStateDictConfig(offload_to_cpu=True)
                sharded_opt_cfg = ShardedOptimStateDictConfig(offload_to_cpu=True)
                with FSDP.state_dict_type(model, StateDictType.SHARDED_STATE_DICT, sharded_cfg, sharded_opt_cfg):
                    model.load_state_dict(state_dict)
        else:
            model.load_state_dict(state_dict)
            opt_file = ckpt_dir / "optimizer.pt"
            if optimizer is not None and opt_file.exists():
                opt_state = torch.load(opt_file, map_location="cpu", weights_only=True)
                optimizer.load_state_dict(opt_state)

        return meta

    def barrier(self) -> None:
        """Synchronizes all distributed processes across the active process group."""
        if dist.is_available() and dist.is_initialized():
            dist.barrier()

    def destroy_distributed(self) -> None:
        """Tears down the active distributed process group and cleans temporary files."""
        if dist.is_available() and dist.is_initialized():
            dist.destroy_process_group()
        if self._init_file and os.path.exists(self._init_file):
            try:
                os.remove(self._init_file)
            except OSError:
                pass
            self._init_file = None
