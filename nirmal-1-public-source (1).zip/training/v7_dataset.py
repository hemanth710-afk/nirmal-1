"""
Clean Multi-Domain Synthetic Dataset V7 for Nirmal-1.
Covers 11 distinct domains:
1. Natural Language
2. Code Generation & Transformation
3. Mathematics (Arithmetic & Algebra)
4. Logic & Deduction (Transitive Chains & Modus Ponens)
5. Structured Reasoning (JSON & Key-Value Trees)
6. Planning (Action Sequences & Dependency DAGs)
7. Tool Use (Structured Sandboxed API Traces)
8. State Transitions (Physical Dynamics & Latent States)
9. Causal Reasoning (Interventions & Counterfactuals)
10. Instruction Following (System Directives & Constraints)
11. Error Correction (Fault Diagnostics & Recovery)

Enforces:
- 0.00% internal duplicates in Train, Val, and Test
- Hard cryptographic split isolation:
  TRAIN ∩ VAL = 0, TRAIN ∩ TEST = 0, VAL ∩ TEST = 0
- Raises DataLeakageError if any collision is detected.
"""

import hashlib
from pathlib import Path
import random
from typing import Any, Dict, List, Optional, Tuple

from training.data_pipeline import DataExample, DataPipeline, DataLeakageError


class V7DatasetGenerator:
    """
    Procedural dataset generator producing strictly isolated, leak-free splits
    across all 11 domains for Milestone V7.
    """

    def __init__(self, seed: int = 42, version: str = "v7.0"):
        self.seed = seed
        self.version = version
        self.pipeline = DataPipeline(seed=seed, generator_version=version)

    # 1. Natural Language
    def _gen_natural_language(self, split: str, count: int) -> List[DataExample]:
        systems = {
            "train": ["Cryogenic cooling system", "Superconducting bus", "Primary turbine", "Telemetry relay"],
            "val": ["Auxiliary fuel regulator", "Optical transceiver", "Thermal radiator", "Power distributor"],
            "test": ["Plasma containment ring", "Magnetic diverter", "Ionization chamber", "Quantum clock"],
        }[split]
        examples = []
        for i in range(count):
            sys_name = systems[i % len(systems)]
            v_val = 100 + (i * 13) % 80
            text = (
                f"Technical Telemetry [{split.upper()} #{i+1}]: {sys_name} operates at {v_val}% capacity. "
                f"Thermal gradient is within permissible safety bounds."
            )
            examples.append(self.pipeline.create_example(
                domain="1_natural_language",
                text=text,
                source="V7DatasetGenerator.natural_language",
                split=split,
                metadata={"index": i + 1, "system": sys_name},
            ))
        return examples

    # 2. Code Generation & Transformation
    def _gen_code(self, split: str, count: int) -> List[DataExample]:
        func_prefixes = {"train": "calc_norm", "val": "filter_bounds", "test": "verify_checksum"}[split]
        examples = []
        for i in range(count):
            val = (i + 1) * 7
            text = (
                f"Python Module [{split.upper()} #{i+1}]: "
                f"def {func_prefixes}_{i}(x: int) -> int:\n"
                f"    \"\"\"Return scaled value with constant offset {val}.\"\"\"\n"
                f"    return (x * 2) + {val}"
            )
            examples.append(self.pipeline.create_example(
                domain="2_code",
                text=text,
                source="V7DatasetGenerator.code",
                split=split,
                metadata={"func": f"{func_prefixes}_{i}", "offset": val},
            ))
        return examples

    # 3. Mathematics
    def _gen_mathematics(self, split: str, count: int) -> List[DataExample]:
        num_ranges = {"train": (20, 99), "val": (100, 199), "test": (200, 299)}[split]
        low, high = num_ranges
        examples = []
        for i in range(count):
            a = low + (i * 5) % (high - low + 1)
            b = low + ((i + 3) * 4) % (high - low + 1)
            multiplier = (i % 6) + 2
            sum_val = a + b
            product = sum_val * multiplier
            text = (
                f"Mathematical Evaluation [{split.upper()} #{i+1}]: "
                f"Evaluate ({a} + {b}) * {multiplier}. "
                f"Step 1: {a} + {b} = {sum_val}. "
                f"Step 2: {sum_val} * {multiplier} = {product}. "
                f"Final Answer: {product}"
            )
            examples.append(self.pipeline.create_example(
                domain="3_mathematics",
                text=text,
                source="V7DatasetGenerator.mathematics",
                split=split,
                metadata={"a": a, "b": b, "m": multiplier, "ans": product},
            ))
        return examples

    # 4. Logic & Deduction
    def _gen_logic(self, split: str, count: int) -> List[DataExample]:
        entity_sets = {
            "train": ["Entity_Alpha", "Entity_Beta", "Entity_Gamma", "Entity_Delta"],
            "val": ["Node_Sigma", "Node_Tau", "Node_Upsilon", "Node_Phi"],
            "test": ["Core_Zeta", "Core_Eta", "Core_Theta", "Core_Iota"],
        }[split]
        examples = []
        for i in range(count):
            e1 = entity_sets[i % len(entity_sets)]
            e2 = entity_sets[(i + 1) % len(entity_sets)]
            e3 = entity_sets[(i + 2) % len(entity_sets)]
            text = (
                f"Logic Syllogism [{split.upper()} #{i+1}]: "
                f"Premise 1: Every {e1} implies {e2}. "
                f"Premise 2: Every {e2} implies {e3}. "
                f"Fact: Subject X is an instance of {e1}. "
                f"Conclusion: Subject X is an instance of {e3}."
            )
            examples.append(self.pipeline.create_example(
                domain="4_logic",
                text=text,
                source="V7DatasetGenerator.logic",
                split=split,
                metadata={"chain": [e1, e2, e3]},
            ))
        return examples

    # 5. Structured Reasoning
    def _gen_structured(self, split: str, count: int) -> List[DataExample]:
        schemas = {"train": "HardwareRegistry", "val": "ChemicalInventory", "test": "OrbitalCatalog"}[split]
        examples = []
        for i in range(count):
            item_id = f"{split[:2].upper()}_{1000 + i}"
            level = 10 + (i * 9) % 90
            status = "ACTIVE" if (i % 2 == 0) else "STANDBY"
            text = (
                f"Structured Database Record [{split.upper()} #{i+1}] in [{schemas}]: "
                f'{{"id": "{item_id}", "priority": {level}, "state": "{status}"}} | '
                f"Query(priority >= 50) -> {'True' if level >= 50 else 'False'}"
            )
            examples.append(self.pipeline.create_example(
                domain="5_structured_reasoning",
                text=text,
                source="V7DatasetGenerator.structured",
                split=split,
                metadata={"schema": schemas, "id": item_id, "priority": level},
            ))
        return examples

    # 6. Planning
    def _gen_planning(self, split: str, count: int) -> List[DataExample]:
        goals = {
            "train": ("purge_coolant_loop", ["close_intake", "vent_chamber", "flush_solvent", "reseal_valves"]),
            "val": ("recalibrate_sensors", ["ground_reference", "inject_bias", "read_response", "apply_trim"]),
            "test": ("initiate_core_burn", ["preheat_chamber", "inject_fuel", "spark_igniter", "verify_thrust"]),
        }[split]
        g_name, steps = goals
        examples = []
        for i in range(count):
            plan_str = ", ".join(f"[{j+1}] {step}" for j, step in enumerate(steps))
            text = (
                f"Hierarchical Plan [{split.upper()} #{i+1}] for Goal: {g_name}. "
                f"Sequence: {plan_str}. Status: Verified Valid."
            )
            examples.append(self.pipeline.create_example(
                domain="6_planning",
                text=text,
                source="V7DatasetGenerator.planning",
                split=split,
                metadata={"goal": g_name, "steps": steps},
            ))
        return examples

    # 7. Tool Use
    def _gen_tool_use(self, split: str, count: int) -> List[DataExample]:
        tool = {"train": "calculator", "val": "math_engine", "test": "eval_sandbox"}[split]
        examples = []
        for i in range(count):
            x = 15 + (i * 6) % 50
            y = 8 + (i * 3) % 30
            ans = x + y
            text = f"Tool Execution [{split.upper()} #{i+1}]: invoke {tool}(op='add', arg1={x}, arg2={y}) -> Result: {ans}"
            examples.append(self.pipeline.create_example(
                domain="7_tool_use",
                text=text,
                source="V7DatasetGenerator.tool_use",
                split=split,
                metadata={"tool": tool, "x": x, "y": y, "ans": ans},
            ))
        return examples

    # 8. State Transitions
    def _gen_state_transitions(self, split: str, count: int) -> List[DataExample]:
        vars_pool = {
            "train": ["primary_pressure", "reactor_temp", "buffer_fill"],
            "val": ["bias_voltage", "exhaust_speed", "cryo_level"],
            "test": ["plasma_density", "rotor_flux", "grid_potential"],
        }[split]
        examples = []
        for i in range(count):
            var = vars_pool[i % len(vars_pool)]
            cur_val = 30 + (i * 7) % 50
            delta = 10 if (i % 2 == 0) else -5
            next_val = cur_val + delta
            act = f"increment_{var}_{delta}" if delta > 0 else f"decrement_{var}_{abs(delta)}"
            text = (
                f"State Transition [{split.upper()} #{i+1}]: "
                f"Current: {{{var}: {cur_val}}}. Action: {act}. Next: {{{var}: {next_val}}}."
            )
            examples.append(self.pipeline.create_example(
                domain="8_state_transitions",
                text=text,
                source="V7DatasetGenerator.state_transitions",
                split=split,
                metadata={"var": var, "cur": cur_val, "next": next_val},
            ))
        return examples

    # 9. Causal Reasoning
    def _gen_causal(self, split: str, count: int) -> List[DataExample]:
        triplets = {
            "train": ("valve_clog", "pressure_buildup", "relief_burst"),
            "val": ("short_circuit", "fuse_melting", "subsystem_offline"),
            "test": ("coolant_depletion", "core_overheat", "emergency_scram"),
        }[split]
        c, m, e = triplets
        examples = []
        for i in range(count):
            text = (
                f"Causal Graph Assertion [{split.upper()} #{i+1}]: "
                f"Cause {c} causes mediator {m} causes effect {e}. "
                f"Intervention do({c}=False) prevents {e}."
            )
            examples.append(self.pipeline.create_example(
                domain="9_causal_reasoning",
                text=text,
                source="V7DatasetGenerator.causal",
                split=split,
                metadata={"cause": c, "mediator": m, "effect": e},
            ))
        return examples

    # 10. Instruction Following
    def _gen_instruction(self, split: str, count: int) -> List[DataExample]:
        directives = {
            "train": "Always format numerical output inside square brackets.",
            "val": "Always prepend response with [SYSTEM_OK].",
            "test": "Always output key-value pairs separated by double colons.",
        }[split]
        examples = []
        for i in range(count):
            val = (i + 1) * 11
            ans = f"[{val}]" if split == "train" else (f"[SYSTEM_OK] {val}" if split == "val" else f"val :: {val}")
            text = (
                f"Instruction Directive [{split.upper()} #{i+1}]: Rule: '{directives}' "
                f"Input value: {val}. Compliant Response: {ans}"
            )
            examples.append(self.pipeline.create_example(
                domain="10_instruction_following",
                text=text,
                source="V7DatasetGenerator.instruction",
                split=split,
                metadata={"rule": directives, "val": val, "ans": ans},
            ))
        return examples

    # 11. Error Correction
    def _gen_error_correction(self, split: str, count: int) -> List[DataExample]:
        errors = {
            "train": ("Sensor parity error on bus 1", "Reset bus controller and request parity retransmit"),
            "val": ("Buffer capacity saturated at 100%", "Flush secondary ring cache and drop stale frames"),
            "test": ("Voltage excursion above threshold 30V", "Clamp zener diode rail and switch to battery bank"),
        }[split]
        err, fix = errors
        examples = []
        for i in range(count):
            text = (
                f"Error Diagnostic Log [{split.upper()} #{i+1}]: Anomaly detected: '{err}'. "
                f"Prescribed recovery procedure: '{fix}'."
            )
            examples.append(self.pipeline.create_example(
                domain="11_error_correction",
                text=text,
                source="V7DatasetGenerator.error_correction",
                split=split,
                metadata={"error": err, "fix": fix},
            ))
        return examples

    # Unified Split Generation
    def generate_split(self, split: str, count_per_domain: int = 50) -> List[DataExample]:
        """Generate all 11 domains for a split with guaranteed 0% internal duplication."""
        all_ex: List[DataExample] = []
        all_ex.extend(self._gen_natural_language(split, count_per_domain))
        all_ex.extend(self._gen_code(split, count_per_domain))
        all_ex.extend(self._gen_mathematics(split, count_per_domain))
        all_ex.extend(self._gen_logic(split, count_per_domain))
        all_ex.extend(self._gen_structured(split, count_per_domain))
        all_ex.extend(self._gen_planning(split, count_per_domain))
        all_ex.extend(self._gen_tool_use(split, count_per_domain))
        all_ex.extend(self._gen_state_transitions(split, count_per_domain))
        all_ex.extend(self._gen_causal(split, count_per_domain))
        all_ex.extend(self._gen_instruction(split, count_per_domain))
        all_ex.extend(self._gen_error_correction(split, count_per_domain))

        # Strict internal deduplication
        unique, dups = self.pipeline.deduplicate(all_ex)
        if dups > 0:
            raise ValueError(f"Internal duplicate detected in V7 generator for split '{split}'! Dups: {dups}")

        return unique

    def generate_full_clean_dataset(
        self,
        train_count_per_domain: int = 50,
        val_count_per_domain: int = 15,
        test_count_per_domain: int = 15,
    ) -> Tuple[List[DataExample], List[DataExample], List[DataExample]]:
        """Generate complete V7 dataset and verify zero-leakage invariant."""
        train_set = self.generate_split("train", train_count_per_domain)
        val_set = self.generate_split("val", val_count_per_domain)
        test_set = self.generate_split("test", test_count_per_domain)

        # Enforce hard zero-leakage invariant
        self.pipeline.verify_split_isolation(train_set, val_set, test_set)

        return train_set, val_set, test_set
