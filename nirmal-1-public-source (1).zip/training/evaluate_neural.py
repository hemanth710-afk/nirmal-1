"""
Neural Model Evaluation Engine for Nirmal-1 V5.
Provides comprehensive metrics:
- Split Loss & Perplexity
- Next-Token Prediction Accuracy
- Per-Domain Curriculum Breakdown (Categories A-H)
- Section 21 Tokenization Stress Tests:
    - Vocabulary Coverage
    - Sequence Expansion Ratio
    - Rare Token / OOV Handling
    - Numerical Representation Fidelity
"""

from dataclasses import dataclass, field
import math
from typing import Any, Dict, List, Optional, Tuple
import torch
from torch.utils.data import DataLoader

from nirmal.model import NirmalForCausalLM
from training.dataset import CharTokenizer
from training.neural_curriculum import (
    CurriculumItem,
    CurriculumDataset,
    NeuralCurriculum,
    create_curriculum_splits,
)


@dataclass
class TokenizationTestReport:
    """Report evaluating tokenizer properties and robustness."""
    vocab_size: int
    vocab_coverage_percent: float
    sequence_expansion_ratio: float
    rare_token_handling_passed: bool
    oov_substitutions_detected: int
    numerical_fidelity_passed: bool
    details: Dict[str, Any] = field(default_factory=dict)


@dataclass
class CategoryEvaluationMetric:
    """Evaluation metrics for a single curriculum domain."""
    category_id: str
    category_name: str
    num_samples: int
    loss: float
    perplexity: float
    token_accuracy: float


@dataclass
class NeuralEvaluationReport:
    """Full neural evaluation results across splits, domains, and tokenizer tests."""
    train_loss: float
    train_perplexity: float
    train_accuracy: float
    val_loss: float
    val_perplexity: float
    val_accuracy: float
    test_loss: float
    test_perplexity: float
    test_accuracy: float
    category_metrics: Dict[str, CategoryEvaluationMetric] = field(default_factory=dict)
    tokenization_report: Optional[TokenizationTestReport] = None


def evaluate_split(
    model: NirmalForCausalLM,
    dataloader: DataLoader,
    device: torch.device,
) -> Tuple[float, float, float]:
    """
    Compute loss, perplexity, and token-level accuracy on a DataLoader.
    Returns: (loss, perplexity, token_accuracy)
    """
    model.eval()
    total_loss = 0.0
    total_tokens = 0
    correct_tokens = 0

    with torch.no_grad():
        for batch in dataloader:
            input_ids = batch["input_ids"].to(device)
            labels = batch["labels"].to(device)
            outputs = model(input_ids=input_ids, labels=labels)
            
            logits = outputs.logits
            if logits is not None and labels is not None:
                # Next token prediction accuracy: shift logits & labels
                shift_logits = logits[:, :-1, :].contiguous()
                shift_labels = labels[:, 1:].contiguous()
                
                preds = shift_logits.argmax(dim=-1)
                valid_mask = (shift_labels != -100)
                
                num_valid = valid_mask.sum().item()
                if num_valid > 0:
                    correct = ((preds == shift_labels) & valid_mask).sum().item()
                    correct_tokens += correct
                    total_tokens += num_valid

            if outputs.loss is not None and num_valid > 0:
                total_loss += outputs.loss.item() * num_valid

    avg_loss = (total_loss / max(1, total_tokens)) if total_tokens > 0 else 0.0
    perplexity = math.exp(min(avg_loss, 20.0))
    accuracy = (correct_tokens / max(1, total_tokens)) if total_tokens > 0 else 0.0
    return round(avg_loss, 4), round(perplexity, 4), round(accuracy, 4)


def evaluate_categories(
    model: NirmalForCausalLM,
    tokenizer: CharTokenizer,
    items: List[CurriculumItem],
    device: torch.device,
    seq_len: int = 64,
    batch_size: int = 4,
) -> Dict[str, CategoryEvaluationMetric]:
    """Evaluate performance partitioned by curriculum category (A through H)."""
    # Group items by category
    by_cat: Dict[str, List[CurriculumItem]] = {}
    for item in items:
        by_cat.setdefault(item.category, []).append(item)

    results: Dict[str, CategoryEvaluationMetric] = {}
    for cat_id, cat_items in sorted(by_cat.items()):
        dataset = CurriculumDataset(cat_items, tokenizer=tokenizer, seq_len=seq_len)
        loader = DataLoader(dataset, batch_size=batch_size, shuffle=False)
        loss, ppl, acc = evaluate_split(model, loader, device)
        cat_name = cat_id.replace("_", " ").title()
        results[cat_id] = CategoryEvaluationMetric(
            category_id=cat_id,
            category_name=cat_name,
            num_samples=len(cat_items),
            loss=loss,
            perplexity=ppl,
            token_accuracy=acc,
        )

    return results


def run_tokenization_stress_test(
    tokenizer: CharTokenizer,
    reference_texts: Optional[List[str]] = None,
) -> TokenizationTestReport:
    """
    Section 21 Tokenization Test:
    - Vocabulary coverage
    - Sequence expansion ratio
    - Rare token / OOV handling
    - Numerical representations
    """
    sample_corpus = reference_texts or [
        "The quick brown fox jumps over the lazy dog.",
        "def solve_equation(x, y):\n    return x ** 2 + 3 * y - 42",
        "action: set_temperature(sensor_12, 98.6)",
        "state: [alpha: 10, beta: 250, flag: True]",
        "step_1 -> step_2 -> step_3; consequence: positive",
    ]

    all_chars = set("".join(sample_corpus))
    in_vocab = sum(1 for c in all_chars if c in tokenizer.char_to_id)
    vocab_coverage = (in_vocab / max(1, len(all_chars))) * 100.0

    # Expansion ratio
    total_chars = sum(len(t) for t in sample_corpus)
    total_tokens = sum(len(tokenizer.encode(t, add_special_tokens=False)) for t in sample_corpus)
    expansion_ratio = round(total_tokens / max(1, total_chars), 4)

    # Rare token handling
    rare_inputs = [
        "Unseen Unicode: \u0394 \u03a9 \u03c0",
        "Emoji test: \U0001F680 \U0001F916",
        "Non-standard control: \x00 \x07",
    ]
    oov_count = 0
    rare_passed = True
    for text in rare_inputs:
        try:
            enc = tokenizer.encode(text, add_special_tokens=False)
            dec = tokenizer.decode(enc)
            # Should not crash; unknown chars mapped to unk_token_id
            oov_count += sum(1 for tok in enc if tok == tokenizer.unk_token_id)
        except Exception:
            rare_passed = False

    # Numerical representations
    numbers = ["0", "1", "42", "-105", "3.14159", "1000000", "0.0001"]
    num_passed = True
    for num_str in numbers:
        enc = tokenizer.encode(num_str, add_special_tokens=False)
        dec = tokenizer.decode(enc)
        if dec != num_str:
            num_passed = False
            break

    return TokenizationTestReport(
        vocab_size=tokenizer.vocab_size,
        vocab_coverage_percent=round(vocab_coverage, 2),
        sequence_expansion_ratio=expansion_ratio,
        rare_token_handling_passed=rare_passed,
        oov_substitutions_detected=oov_count,
        numerical_fidelity_passed=num_passed,
        details={
            "num_tested_numbers": len(numbers),
            "sample_corpus_size": len(sample_corpus),
        },
    )


def evaluate_neural_full(
    model: NirmalForCausalLM,
    tokenizer: CharTokenizer,
    curriculum_items: List[CurriculumItem],
    device: Optional[torch.device] = None,
    seq_len: int = 64,
    batch_size: int = 4,
    seed: int = 42,
) -> NeuralEvaluationReport:
    """
    Run the complete evaluation workflow:
    - Splits: Train (70%), Val (15%), Test (15%)
    - Category-wise evaluation on test split
    - Tokenization stress tests
    """
    dev = device or torch.device("cuda" if torch.cuda.is_available() else "cpu")
    train_items, val_items, test_items = create_curriculum_splits(curriculum_items, seed=seed)

    train_ds = CurriculumDataset(train_items, tokenizer=tokenizer, seq_len=seq_len)
    val_ds = CurriculumDataset(val_items, tokenizer=tokenizer, seq_len=seq_len)
    test_ds = CurriculumDataset(test_items, tokenizer=tokenizer, seq_len=seq_len)

    train_loader = DataLoader(train_ds, batch_size=batch_size, shuffle=False)
    val_loader = DataLoader(val_ds, batch_size=batch_size, shuffle=False)
    test_loader = DataLoader(test_ds, batch_size=batch_size, shuffle=False)

    train_loss, train_ppl, train_acc = evaluate_split(model, train_loader, dev)
    val_loss, val_ppl, val_acc = evaluate_split(model, val_loader, dev)
    test_loss, test_ppl, test_acc = evaluate_split(model, test_loader, dev)

    cat_metrics = evaluate_categories(
        model=model,
        tokenizer=tokenizer,
        items=test_items,
        device=dev,
        seq_len=seq_len,
        batch_size=batch_size,
    )

    sample_texts = [item.full_text for item in curriculum_items[:20]]
    tok_report = run_tokenization_stress_test(tokenizer, reference_texts=sample_texts)

    return NeuralEvaluationReport(
        train_loss=train_loss,
        train_perplexity=train_ppl,
        train_accuracy=train_acc,
        val_loss=val_loss,
        val_perplexity=val_ppl,
        val_accuracy=val_acc,
        test_loss=test_loss,
        test_perplexity=test_ppl,
        test_accuracy=test_acc,
        category_metrics=cat_metrics,
        tokenization_report=tok_report,
    )
