"""
Dataset utilities for Nirmal-1 training:
- SyntheticTokenDataset: Deterministic synthetic dataset for local tests and training validation.
- TextTokenDataset: Tokenizer-agnostic chunked sequence dataset.
- CharTokenizer: Self-contained character-level tokenizer for standalone training experiments.
"""

from typing import Callable, Dict, List, Optional
import torch
from torch.utils.data import Dataset


class SyntheticTokenDataset(Dataset):
    """Deterministic synthetic dataset generating token sequences for debugging and local testing."""

    def __init__(self, num_samples: int = 100, seq_len: int = 64, vocab_size: int = 1000, seed: int = 42):
        self.num_samples = num_samples
        self.seq_len = seq_len
        self.vocab_size = vocab_size

        generator = torch.Generator().manual_seed(seed)
        # Generate random integer tokens in [1, vocab_size - 1] (reserving 0 for pad if needed)
        self.data = torch.randint(
            1, vocab_size, (num_samples, seq_len), generator=generator, dtype=torch.long
        )

    def __len__(self) -> int:
        return self.num_samples

    def __getitem__(self, idx: int) -> Dict[str, torch.Tensor]:
        tokens = self.data[idx]
        return {
            "input_ids": tokens,
            "labels": tokens.clone(),
        }


class CharTokenizer:
    """Minimal character-level tokenizer for self-contained prototyping."""

    def __init__(self, text: Optional[str] = None):
        self.pad_token_id = 0
        self.unk_token_id = 1
        self.bos_token_id = 2
        self.eos_token_id = 3
        self.special_tokens = ["<pad>", "<unk>", "<bos>", "<eos>"]

        if text is not None:
            unique_chars = sorted(list(set([chr(i) for i in range(32, 127)] + list(text))))
        else:
            unique_chars = [chr(i) for i in range(32, 127)]

        self.char_to_id = {tok: idx for idx, tok in enumerate(self.special_tokens)}
        for c in unique_chars:
            if c not in self.char_to_id:
                self.char_to_id[c] = len(self.char_to_id)

        self.id_to_char = {idx: tok for tok, idx in self.char_to_id.items()}

    @property
    def vocab_size(self) -> int:
        return len(self.char_to_id)

    def encode(self, text: str, add_special_tokens: bool = True) -> List[int]:
        ids = []
        if add_special_tokens:
            ids.append(self.bos_token_id)
        for char in text:
            ids.append(self.char_to_id.get(char, self.unk_token_id))
        if add_special_tokens:
            ids.append(self.eos_token_id)
        return ids

    def decode(self, ids: List[int]) -> str:
        chars = []
        for i in ids:
            if i in (self.pad_token_id, self.bos_token_id, self.eos_token_id):
                continue
            chars.append(self.id_to_char.get(i, ""))
        return "".join(chars)


class TextTokenDataset(Dataset):
    """Chunked token dataset from raw text using any encode function."""

    def __init__(self, text: str, encode_fn: Callable[[str], List[int]], seq_len: int = 64):
        tokens = encode_fn(text)
        self.seq_len = seq_len
        num_chunks = len(tokens) // seq_len

        if num_chunks == 0:
            # Pad to seq_len
            tokens = tokens + [0] * (seq_len - len(tokens))
            num_chunks = 1

        self.chunks = [
            torch.tensor(tokens[i * seq_len : (i + 1) * seq_len], dtype=torch.long)
            for i in range(num_chunks)
        ]

    def __len__(self) -> int:
        return len(self.chunks)

    def __getitem__(self, idx: int) -> Dict[str, torch.Tensor]:
        chunk = self.chunks[idx]
        return {
            "input_ids": chunk,
            "labels": chunk.clone(),
        }
