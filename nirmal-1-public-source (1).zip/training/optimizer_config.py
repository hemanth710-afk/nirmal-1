"""
Optimizer Configuration & Parameter Grouping for Nirmal-1 V8.
Implements decoupled AdamW with standard pretraining hyperparameters:
- Decoupled weight decay (0.01) on 2D+ weight tensors
- Zero weight decay on 1D normalization scales and biases
- Betas: (0.9, 0.95), eps: 1e-8
- Gradient norm clipping (1.0)
"""

from dataclasses import dataclass, asdict
from typing import Any, Dict, List, Optional, Tuple
import torch
import torch.nn as nn


@dataclass
class OptimizerConfig:
    learning_rate: float = 3e-4
    weight_decay: float = 0.01
    beta1: float = 0.9
    beta2: float = 0.95
    eps: float = 1e-8
    max_grad_norm: float = 1.0

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


def create_optimizer(
    model: nn.Module,
    config: Optional[OptimizerConfig] = None,
) -> torch.optim.AdamW:
    """
    Constructs AdamW optimizer with distinct parameter groups:
    - Group 1: 2D+ weight matrices (Linear, Attention, MoE, DeltaNet) -> weight decay
    - Group 2: 1D tensors (RMSNorm gains, biases) -> no weight decay
    """
    cfg = config or OptimizerConfig()

    decay_params = []
    no_decay_params = []

    for name, param in model.named_parameters():
        if not param.requires_grad:
            continue
        # 1D params (norms, biases) get zero weight decay
        if param.dim() < 2 or "norm" in name.lower() or "bias" in name.lower():
            no_decay_params.append(param)
        else:
            decay_params.append(param)

    param_groups = [
        {"params": decay_params, "weight_decay": cfg.weight_decay},
        {"params": no_decay_params, "weight_decay": 0.0},
    ]

    return torch.optim.AdamW(
        param_groups,
        lr=cfg.learning_rate,
        betas=(cfg.beta1, cfg.beta2),
        eps=cfg.eps,
    )


def clip_gradients(model: nn.Module, max_grad_norm: float = 1.0) -> float:
    """
    Clips model gradient norm and returns total gradient norm before clipping.
    """
    parameters = [p for p in model.parameters() if p.grad is not None]
    if not parameters:
        return 0.0
    total_norm = torch.nn.utils.clip_grad_norm_(parameters, max_grad_norm)
    return float(total_norm.item()) if isinstance(total_norm, torch.Tensor) else float(total_norm)
