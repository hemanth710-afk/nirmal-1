"""
Final Model Size & Memory Budget Calculator for Nirmal-1 V8.
Enforces the hard invariant:
    45.0 GB <= Final Model Artifact <= 50.0 GB (Target: 47.0 - 49.5 GB)

Calculates:
- Precise parameter counts across all modules (embeddings, attention, DeltaNet, MoE, norms, LM head)
- Exact file artifact sizing across precisions (BF16, FP16, INT8, INT4) including SafeTensors metadata
- Training memory breakdown (weights, gradients, optimizer states, activations, temporary buffers)
- Inference memory and KV-cache footprints across context lengths (8K, 16K, 32K, 64K)
- Distributed sharding memory (ZeRO-1, ZeRO-2, ZeRO-3 / FSDP)
"""

from dataclasses import dataclass, asdict
import math
from typing import Any, Dict, List, Optional, Tuple


class ArtifactSizeViolationError(Exception):
    """Raised when the calculated model artifact size violates the 45.0 GB - 50.0 GB invariant."""
    pass


@dataclass
class ArchitectureBreakdown:
    name: str
    architecture_type: str  # "dense", "moe", "hybrid"
    precision: str          # "BF16", "FP16", "INT8", "INT4"
    bytes_per_param: float
    vocab_size: int
    hidden_size: int
    num_layers: int
    num_attention_heads: int
    num_kv_heads: int
    head_dim: int
    intermediate_size: int
    num_experts: int
    num_experts_per_tok: int
    full_attention_interval: int
    context_length: int

    # Parameter counts
    embedding_params: int
    attention_params: int
    deltanet_params: int
    moe_router_params: int
    moe_expert_params: int
    norm_params: int
    lm_head_params: int
    total_parameters: int
    active_parameters: int

    # Physical Artifact Size
    raw_weight_bytes: int
    metadata_header_bytes: int
    sharding_overhead_bytes: int
    total_artifact_bytes: int
    artifact_size_gb: float
    is_valid_size: bool

    # Inference & Compute
    inference_flops_per_token: float
    kv_cache_mb_per_batch: float

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


def calculate_architecture_breakdown(
    name: str,
    architecture_type: str,
    hidden_size: int,
    num_layers: int,
    num_attention_heads: int,
    num_kv_heads: int,
    head_dim: int,
    intermediate_size: Optional[int] = None,
    num_experts: int = 1,
    num_experts_per_tok: int = 1,
    full_attention_interval: int = 4,
    vocab_size: int = 32000,
    context_length: int = 8192,
    precision: str = "BF16",
    tie_word_embeddings: bool = False,
    validate_size_constraint: bool = True,
) -> ArchitectureBreakdown:
    """
    Computes rigorous parameter and artifact sizing for a candidate architecture.
    """
    prec = precision.upper()
    prec_map = {"FP32": 4.0, "BF16": 2.0, "FP16": 2.0, "INT8": 1.0, "INT4": 0.5}
    if prec not in prec_map:
        raise ValueError(f"Unsupported precision: {precision}")
    bytes_per_p = prec_map[prec]

    if intermediate_size is None:
        intermediate_size = int(2 * hidden_size * 4 / 3)
        intermediate_size = ((intermediate_size + 63) // 64) * 64

    # 1. Embeddings
    emb_p = vocab_size * hidden_size

    # 2. Per-layer modules
    attn_p = 0
    delta_p = 0
    router_p = 0
    expert_p = 0
    norm_p = 0

    active_layer_p = 0

    for layer_idx in range(num_layers):
        # 2 RMSNorms per decoder layer (input_layernorm, post_attention_layernorm)
        layer_norm = 2 * hidden_size
        norm_p += layer_norm

        is_gqa = (full_attention_interval > 0 and (layer_idx + 1) % full_attention_interval == 0)

        if architecture_type == "dense":
            # Pure GQA on all layers
            q_p = hidden_size * (num_attention_heads * head_dim)
            k_p = hidden_size * (num_kv_heads * head_dim)
            v_p = hidden_size * (num_kv_heads * head_dim)
            o_p = (num_attention_heads * head_dim) * hidden_size
            block_attn = q_p + k_p + v_p + o_p
            attn_p += block_attn

            # Standard SwiGLU FFN (gate, up, down)
            dense_ffn = 3 * hidden_size * intermediate_size
            expert_p += dense_ffn

            active_layer_p += layer_norm + block_attn + dense_ffn

        elif architecture_type == "moe":
            # Pure GQA + Sparse MoE on all layers
            q_p = hidden_size * (num_attention_heads * head_dim)
            k_p = hidden_size * (num_kv_heads * head_dim)
            v_p = hidden_size * (num_kv_heads * head_dim)
            o_p = (num_attention_heads * head_dim) * hidden_size
            block_attn = q_p + k_p + v_p + o_p
            attn_p += block_attn

            r_p = hidden_size * num_experts
            router_p += r_p
            single_expert = 3 * hidden_size * intermediate_size
            expert_p += num_experts * single_expert

            active_layer_p += layer_norm + block_attn + r_p + (num_experts_per_tok * single_expert)

        elif architecture_type == "hybrid":
            # Hybrid DeltaNet + periodic GQA + Sparse MoE
            if is_gqa:
                q_p = hidden_size * (num_attention_heads * head_dim)
                k_p = hidden_size * (num_kv_heads * head_dim)
                v_p = hidden_size * (num_kv_heads * head_dim)
                o_p = (num_attention_heads * head_dim) * hidden_size
                block_attn = q_p + k_p + v_p + o_p
                attn_p += block_attn
                active_attn = block_attn
            else:
                # Exact DeltaNet architecture (NirmalDeltaNet):
                # q_proj, k_proj, v_proj, g_proj (output gate), beta_proj (to num_heads with bias),
                # head RMSNorm, out_proj
                q_p = hidden_size * (num_attention_heads * head_dim)
                k_p = hidden_size * (num_attention_heads * head_dim)
                v_p = hidden_size * (num_attention_heads * head_dim)
                g_p = hidden_size * hidden_size
                beta_p = (hidden_size * num_attention_heads) + num_attention_heads
                delta_norm = head_dim
                o_p = (num_attention_heads * head_dim) * hidden_size
                block_delta = q_p + k_p + v_p + g_p + beta_p + delta_norm + o_p
                delta_p += block_delta
                active_attn = block_delta

            r_p = hidden_size * num_experts
            router_p += r_p
            single_expert = 3 * hidden_size * intermediate_size
            expert_p += num_experts * single_expert

            active_layer_p += layer_norm + active_attn + r_p + (num_experts_per_tok * single_expert)

        else:
            raise ValueError(f"Unknown architecture type: {architecture_type}")

    # 3. Final Norm & LM Head
    final_norm = hidden_size
    norm_p += final_norm
    lm_head_p = 0 if tie_word_embeddings else (hidden_size * vocab_size)

    total_params = emb_p + attn_p + delta_p + router_p + expert_p + norm_p + lm_head_p
    active_params = emb_p + active_layer_p + final_norm + lm_head_p

    # 4. Artifact Byte Accounting
    raw_weight_bytes = int(total_params * bytes_per_p)
    # SafeTensors metadata header overhead (~16 MB)
    metadata_bytes = 16 * 1024 * 1024
    # Multi-file sharding manifest & alignment overhead (~32 MB)
    sharding_bytes = 32 * 1024 * 1024
    total_artifact_bytes = raw_weight_bytes + metadata_bytes + sharding_bytes
    artifact_gb = round(total_artifact_bytes / (1024 ** 3), 4)

    is_valid = (45.0 <= artifact_gb <= 50.0)
    if validate_size_constraint and not is_valid:
        raise ArtifactSizeViolationError(
            f"Candidate '{name}' artifact size {artifact_gb:.2f} GB violates the "
            f"45.0 GB <= size <= 50.0 GB requirement!"
        )

    # 5. Inference FLOPs (2 * active_params per token)
    inf_flops = 2.0 * float(active_params)

    # 6. KV Cache memory (only for layers using GQA)
    gqa_layers = sum(1 for l in range(num_layers) if (full_attention_interval > 0 and (l + 1) % full_attention_interval == 0))
    if architecture_type in ("dense", "moe"):
        gqa_layers = num_layers
    kv_cache_bytes = 2 * gqa_layers * num_kv_heads * head_dim * context_length * bytes_per_p
    kv_cache_mb = round(kv_cache_bytes / (1024 * 1024), 2)

    return ArchitectureBreakdown(
        name=name,
        architecture_type=architecture_type,
        precision=prec,
        bytes_per_param=bytes_per_p,
        vocab_size=vocab_size,
        hidden_size=hidden_size,
        num_layers=num_layers,
        num_attention_heads=num_attention_heads,
        num_kv_heads=num_kv_heads,
        head_dim=head_dim,
        intermediate_size=intermediate_size,
        num_experts=num_experts,
        num_experts_per_tok=num_experts_per_tok,
        full_attention_interval=full_attention_interval,
        context_length=context_length,
        embedding_params=emb_p,
        attention_params=attn_p,
        deltanet_params=delta_p,
        moe_router_params=router_p,
        moe_expert_params=expert_p,
        norm_params=norm_p,
        lm_head_params=lm_head_p,
        total_parameters=total_params,
        active_parameters=active_params,
        raw_weight_bytes=raw_weight_bytes,
        metadata_header_bytes=metadata_bytes,
        sharding_overhead_bytes=sharding_bytes,
        total_artifact_bytes=total_artifact_bytes,
        artifact_size_gb=artifact_gb,
        is_valid_size=is_valid,
        inference_flops_per_token=inf_flops,
        kv_cache_mb_per_batch=kv_cache_mb,
    )


@dataclass
class TrainingMemoryBudget:
    model_name: str
    precision: str
    total_params: int
    model_weights_gb: float
    gradients_gb: float
    optimizer_states_gb: float
    activations_without_checkpointing_gb: float
    activations_with_checkpointing_gb: float
    kv_cache_gb: float
    temporary_buffers_gb: float
    total_single_gpu_training_gb: float
    fsdp_sharded_8_gpu_per_device_gb: float
    fsdp_sharded_16_gpu_per_device_gb: float
    recommended_gpu_type: str

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


def calculate_training_memory_budget(
    arch: ArchitectureBreakdown,
    batch_size: int = 1,
    use_activation_checkpointing: bool = True,
) -> TrainingMemoryBudget:
    """
    Computes rigorous training memory requirements across single and multi-GPU topologies.
    """
    # Weights: BF16 (2 bytes / param)
    weights_gb = round((arch.total_parameters * 2.0) / (1024 ** 3), 2)

    # Gradients: BF16 (2 bytes / param)
    grads_gb = weights_gb

    # AdamW Optimizer states:
    # - FP32 master weights (4 bytes)
    # - FP32 first momentum (4 bytes)
    # - FP32 second variance (4 bytes)
    # Total optimizer state = 12 bytes / parameter
    optim_gb = round((arch.total_parameters * 12.0) / (1024 ** 3), 2)

    # Activations per token:
    # Full uncheckpointed activation memory: ~34 * b * s * h * L bytes
    # Selective activation checkpointing reduces activation footprint by ~72%
    b = batch_size
    s = arch.context_length
    h = arch.hidden_size
    l = arch.num_layers

    raw_act_bytes = 34 * b * s * h * l * 2.0
    act_no_ckpt_gb = round(raw_act_bytes / (1024 ** 3), 2)
    act_with_ckpt_gb = round((raw_act_bytes * 0.28) / (1024 ** 3), 2)

    # KV Cache
    kv_cache_gb = round(arch.kv_cache_mb_per_batch * batch_size / 1024, 2)

    # Temporary communication / all-reduce buffers
    temp_gb = 8.0

    act_used = act_with_ckpt_gb if use_activation_checkpointing else act_no_ckpt_gb
    total_single_gpu = weights_gb + grads_gb + optim_gb + act_used + kv_cache_gb + temp_gb

    # Under ZeRO-3 / FSDP (Full Sharding across N GPUs):
    # Weights, Gradients, and Optimizer states are sharded 1/N.
    # Activations and temporary buffers remain per GPU.
    sharded_state_8 = (weights_gb + grads_gb + optim_gb) / 8.0
    fsdp_8 = round(sharded_state_8 + act_used + kv_cache_gb + temp_gb, 2)

    sharded_state_16 = (weights_gb + grads_gb + optim_gb) / 16.0
    fsdp_16 = round(sharded_state_16 + act_used + kv_cache_gb + temp_gb, 2)

    return TrainingMemoryBudget(
        model_name=arch.name,
        precision=arch.precision,
        total_params=arch.total_parameters,
        model_weights_gb=weights_gb,
        gradients_gb=grads_gb,
        optimizer_states_gb=optim_gb,
        activations_without_checkpointing_gb=act_no_ckpt_gb,
        activations_with_checkpointing_gb=act_with_ckpt_gb,
        kv_cache_gb=kv_cache_gb,
        temporary_buffers_gb=temp_gb,
        total_single_gpu_training_gb=round(total_single_gpu, 2),
        fsdp_sharded_8_gpu_per_device_gb=fsdp_8,
        fsdp_sharded_16_gpu_per_device_gb=fsdp_16,
        recommended_gpu_type="8x NVIDIA H100 (80GB) SXM5 with NVLink",
    )


@dataclass
class ActivationBreakdown:
    seq_len: int
    batch_size: int
    precision: str
    uncheckpointed_gib: float
    checkpointed_gib: float
    reduction_pct: float
    recurrent_history_gib: float
    gqa_attention_matrices_gib: float
    moe_experts_gib: float
    residuals_norms_loss_gib: float

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


def calculate_first_principles_activations(
    batch_size: int = 1,
    seq_len: int = 8192,
    hidden_size: int = 4096,
    num_layers: int = 12,
    num_attention_heads: int = 32,
    num_kv_heads: int = 8,
    head_dim: int = 128,
    intermediate_size: int = 10496,
    num_experts: int = 16,
    num_experts_per_tok: int = 2,
    full_attention_interval: int = 4,
    vocab_size: int = 32000,
    precision_bytes: float = 2.0,
) -> ActivationBreakdown:
    """
    Computes first-principles activation memory accounting for:
    - DeltaNet recurrent state history (S_t per token across sequence)
    - GQA attention matrices (score + softmax matrices)
    - Sparse MoE intermediate SwiGLU activations (top-k active tokens only)
    - Residual streams, layer norms, and vocabulary loss projections
    """
    b = batch_size
    s = seq_len
    h = hidden_size
    prec = precision_bytes

    gqa_count = sum(1 for l in range(num_layers) if full_attention_interval > 0 and (l + 1) % full_attention_interval == 0)
    deltanet_count = num_layers - gqa_count

    # 1. Residual Streams & RMSNorms (4 tensors per block: input norm, pre-attn res, post-attn norm, pre-moe res)
    res_norm_per_block = 4 * b * s * h * prec

    # 2. DeltaNet per block
    # Linear projections (q, k, v, g, beta) + normalized k + out_proj
    delta_proj_per_block = (7 * b * s * h + b * s * num_attention_heads) * prec
    # Recurrent associative memory states S_t across time: s * (b * heads * head_dim * head_dim * prec)
    delta_rec_per_block = s * b * num_attention_heads * head_dim * head_dim * prec
    delta_total_per_block = delta_proj_per_block + delta_rec_per_block

    # 3. GQA per block
    gqa_qkv = (b * s * h + 2 * b * s * (num_kv_heads * head_dim)) * prec * 2  # Projections + RoPE
    gqa_attn_mats = 2 * (b * num_attention_heads * s * s * prec)  # Raw score matrix + softmax weights
    gqa_out = 2 * b * s * h * prec  # Context tokens + out_proj input
    gqa_total_per_block = gqa_qkv + gqa_attn_mats + gqa_out

    # 4. Sparse MoE channel mixer per block
    moe_router = (s * num_experts + 2 * s * num_experts_per_tok) * prec
    # Top-k active tokens evaluated: gate, up, silu product, down
    moe_expert_tokens = (3 * num_experts_per_tok * s * intermediate_size * prec) + (num_experts_per_tok * s * h * prec)
    moe_total_per_block = moe_router + moe_expert_tokens

    # 5. Final Norm & LM Head / Cross-Entropy Loss
    head_loss_bytes = (b * s * h + b * s * vocab_size) * prec

    total_uncheckpointed_bytes = (
        (num_layers * res_norm_per_block) +
        (deltanet_count * delta_total_per_block) +
        (gqa_count * gqa_total_per_block) +
        (num_layers * moe_total_per_block) +
        head_loss_bytes
    )

    # With Selective Activation Checkpointing:
    # Retains block input boundary states (num_layers * b * s * h * prec)
    # plus maximum single-block recomputation working buffer
    max_block_recompute = res_norm_per_block + max(delta_total_per_block, gqa_total_per_block) + moe_total_per_block
    total_checkpointed_bytes = (num_layers * b * s * h * prec) + max_block_recompute + head_loss_bytes

    gib = 1024 ** 3
    unckpt_gib = round(total_uncheckpointed_bytes / gib, 2)
    ckpt_gib = round(total_checkpointed_bytes / gib, 2)
    reduc_pct = round((1.0 - (ckpt_gib / max(1e-4, unckpt_gib))) * 100.0, 1)

    return ActivationBreakdown(
        seq_len=s,
        batch_size=b,
        precision="BF16" if prec == 2.0 else f"{prec*8:.0f}-bit",
        uncheckpointed_gib=unckpt_gib,
        checkpointed_gib=ckpt_gib,
        reduction_pct=reduc_pct,
        recurrent_history_gib=round((deltanet_count * delta_rec_per_block) / gib, 2),
        gqa_attention_matrices_gib=round((gqa_count * gqa_attn_mats) / gib, 2),
        moe_experts_gib=round((num_layers * moe_total_per_block) / gib, 2),
        residuals_norms_loss_gib=round(((num_layers * res_norm_per_block) + head_loss_bytes) / gib, 2),
    )


@dataclass
class StorageModelBreakdown:
    # Weights & Checkpoints (Binary GiB vs Decimal GB)
    weights_bf16_gib: float
    weights_bf16_gb: float
    weights_fp32_gib: float
    weights_fp32_gb: float
    single_full_checkpoint_gib: float
    single_full_checkpoint_gb: float
    optimizer_checkpoint_gib: float
    optimizer_checkpoint_gb: float
    retained_checkpoints_6x_tib: float
    retained_checkpoints_6x_tb: float

    # Dataset Accounting
    dataset_200b_tokens_gib: float
    dataset_200b_tokens_gb: float
    dataset_210b_tokens_gib: float
    dataset_210b_tokens_gb: float
    temp_preprocessing_scratch_gib: float
    temp_preprocessing_scratch_gb: float

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


def calculate_storage_breakdown(total_parameters: int = 25908188576) -> StorageModelBreakdown:
    """
    Computes rigorous storage requirements separating binary (GiB/TiB) from decimal (GB/TB).
    """
    P = total_parameters
    gib = 1024 ** 3
    tib = 1024 ** 4
    gb = 10 ** 9
    tb = 10 ** 12

    b_bf16 = P * 2
    b_fp32 = P * 4
    b_opt = P * 12
    b_full_ckpt = b_bf16 + b_opt
    b_retained_6x = 6 * b_full_ckpt

    b_200b = 200_000_000_000 * 2
    b_210b = 210_000_000_000 * 2
    b_scratch = (200_000_000_000 * 4) + (100 * 10**9) + (400 * 10**9)

    return StorageModelBreakdown(
        weights_bf16_gib=round(b_bf16 / gib, 2),
        weights_bf16_gb=round(b_bf16 / gb, 2),
        weights_fp32_gib=round(b_fp32 / gib, 2),
        weights_fp32_gb=round(b_fp32 / gb, 2),
        single_full_checkpoint_gib=round(b_full_ckpt / gib, 2),
        single_full_checkpoint_gb=round(b_full_ckpt / gb, 2),
        optimizer_checkpoint_gib=round(b_opt / gib, 2),
        optimizer_checkpoint_gb=round(b_opt / gb, 2),
        retained_checkpoints_6x_tib=round(b_retained_6x / tib, 3),
        retained_checkpoints_6x_tb=round(b_retained_6x / tb, 3),
        dataset_200b_tokens_gib=round(b_200b / gib, 2),
        dataset_200b_tokens_gb=round(b_200b / gb, 2),
        dataset_210b_tokens_gib=round(b_210b / gib, 2),
        dataset_210b_tokens_gb=round(b_210b / gb, 2),
        temp_preprocessing_scratch_gib=round(b_scratch / gib, 2),
        temp_preprocessing_scratch_gb=round(b_scratch / gb, 2),
    )


def calculate_multi_gpu_sharding_table(
    total_parameters: int = 25908188576,
    gpu_counts: Optional[List[int]] = None,
    seq_len: int = 8192,
) -> List[Dict[str, Any]]:
    """
    Computes rigorous per-GPU memory breakdown across topologies (1 to 64 GPUs).
    Separates:
    - Sharded static model state (parameters, gradients, optimizer states)
    - First-principles selective checkpointed activations
    - Dynamic un-sharded layer execution buffer (MoE block)
    - Working autograd and gradient accumulation buffers
    - Communication and MoE routing buffers
    - CUDA runtime overhead
    """
    if gpu_counts is None:
        gpu_counts = [1, 2, 4, 8, 16, 32, 64]

    P = total_parameters
    gib = 1024 ** 3

    static_bytes = P * 16  # BF16 weights (2) + BF16 grads (2) + FP32 AdamW (12)
    tot_static_gib = static_bytes / gib

    # Dynamic working buffers
    act_breakdown = calculate_first_principles_activations(seq_len=seq_len)
    act_gib = act_breakdown.checkpointed_gib

    # Largest single block gathered in ZeRO-3: MoE block (2.15B params in BF16 = 4.00 GiB)
    unsharded_layer_gib = 4.00
    autograd_grad_gib = 4.00
    comm_and_moe_gib = 4.00
    cuda_runtime_gib = 2.00
    total_dynamic_gib = act_gib + unsharded_layer_gib + autograd_grad_gib + comm_and_moe_gib + cuda_runtime_gib

    rows = []
    for n in gpu_counts:
        # Replicated DDP: static state completely replicated
        ddp_peak = tot_static_gib + total_dynamic_gib
        # ZeRO-1: Optimizer partitioned 1/n
        w_g_gib = (P * 4) / gib
        opt_gib = (P * 12) / gib
        z1_peak = w_g_gib + (opt_gib / n) + total_dynamic_gib
        # ZeRO-2: Optimizer + Grads partitioned 1/n
        w_gib = (P * 2) / gib
        z2_peak = w_gib + ((P * 14) / gib / n) + total_dynamic_gib
        # ZeRO-3 / FSDP: Full sharding of static state 1/n
        z3_static_per_gpu = tot_static_gib / n
        z3_peak_vram = z3_static_per_gpu + total_dynamic_gib

        rows.append({
            "gpu_count": n,
            "zero3_static_per_gpu_gib": round(z3_static_per_gpu, 2),
            "dynamic_working_gib": round(total_dynamic_gib, 2),
            "zero3_peak_vram_gib": round(z3_peak_vram, 2),
            "zero2_peak_vram_gib": round(z2_peak, 2),
            "zero1_peak_vram_gib": round(z1_peak, 2),
            "replicated_ddp_peak_vram_gib": round(ddp_peak, 2),
            "fits_in_24gb": z3_peak_vram <= 24.0,
            "fits_in_40gb": z3_peak_vram <= 40.0,
            "fits_in_48gb": z3_peak_vram <= 48.0,
            "fits_in_80gb": z3_peak_vram <= 80.0,
            "fits_in_96gb": z3_peak_vram <= 96.0,
            "fits_in_141gb": z3_peak_vram <= 141.0,
        })
    return rows
