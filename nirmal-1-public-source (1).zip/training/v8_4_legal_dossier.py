"""
Legal Evidence Dossier System for Nirmal-1 V8.4.

Maintains structured, tamper-evident legal records for all candidate pretraining sources.
Enforces the invariant: External sources MUST NOT be approved without explicit on-disk
legal evidence dossiers.
"""

from dataclasses import dataclass, asdict
from enum import Enum
import hashlib
import json
from pathlib import Path
import time
from typing import Any, Dict, List, Optional

REPO_ROOT = Path(__file__).resolve().parent.parent
LEGAL_EVIDENCE_DIR = REPO_ROOT / "data" / "legal_evidence"


class ReviewerStatus(str, Enum):
    MISSING = "MISSING"
    UNDER_REVIEW = "UNDER_REVIEW"
    APPROVED = "APPROVED"
    REJECTED = "REJECTED"


@dataclass
class LegalDossier:
    source_id: str
    official_url: str
    official_license_text_reference: str
    version: str
    retrieval_timestamp: str
    checksum: str
    reviewer_status: ReviewerStatus
    notes: str

    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        d["reviewer_status"] = self.reviewer_status.value
        return d

    def validate(self) -> None:
        if not self.source_id:
            raise ValueError("source_id cannot be empty")
        if not self.official_url:
            raise ValueError("official_url cannot be empty")
        if not isinstance(self.reviewer_status, ReviewerStatus):
            raise ValueError(f"Invalid reviewer_status: {self.reviewer_status}")


class LegalDossierManager:
    """Manages creation, loading, and validation of dataset legal dossiers."""

    def __init__(self, dossier_dir: Optional[Path] = None):
        self.dossier_dir = dossier_dir or LEGAL_EVIDENCE_DIR
        self.dossier_dir.mkdir(parents=True, exist_ok=True)

    def get_dossier_path(self, source_id: str) -> Path:
        return self.dossier_dir / f"{source_id}.json"

    def save_dossier(self, dossier: LegalDossier) -> Path:
        dossier.validate()
        p = self.get_dossier_path(dossier.source_id)
        with open(p, "w", encoding="utf-8") as f:
            json.dump(dossier.to_dict(), f, indent=2)
        return p

    def load_dossier(self, source_id: str) -> Optional[LegalDossier]:
        p = self.get_dossier_path(source_id)
        if not p.exists():
            return None
        with open(p, "r", encoding="utf-8") as f:
            d = json.load(f)
        d["reviewer_status"] = ReviewerStatus(d["reviewer_status"])
        return LegalDossier(**d)

    def load_all_dossiers(self) -> Dict[str, LegalDossier]:
        dossiers: Dict[str, LegalDossier] = {}
        for p in self.dossier_dir.glob("*.json"):
            try:
                with open(p, "r", encoding="utf-8") as f:
                    d = json.load(f)
                if "source_id" in d and "reviewer_status" in d:
                    d["reviewer_status"] = ReviewerStatus(d["reviewer_status"])
                    dossiers[d["source_id"]] = LegalDossier(**d)
            except Exception:
                continue
        return dossiers

    def audit_all_sources(self) -> Dict[str, Any]:
        """Audits all dossiers and checks approval status."""
        dossiers = self.load_all_dossiers()
        approved = [s for s, d in dossiers.items() if d.reviewer_status == ReviewerStatus.APPROVED]
        under_review = [s for s, d in dossiers.items() if d.reviewer_status == ReviewerStatus.UNDER_REVIEW]
        rejected = [s for s, d in dossiers.items() if d.reviewer_status == ReviewerStatus.REJECTED]
        missing = [s for s, d in dossiers.items() if d.reviewer_status == ReviewerStatus.MISSING]

        return {
            "total_dossiers": len(dossiers),
            "approved_sources": approved,
            "under_review_sources": under_review,
            "rejected_sources": rejected,
            "missing_sources": missing,
            "is_acquisition_ready": len(under_review) == 0 and len(approved) > 0,
        }
