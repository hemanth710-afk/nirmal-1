"""V10.7 Rule Generalization and Algorithm Transfer Harness.

Implements evaluation protocols for:
- Experiment A: Multi-rule training with permutation augmentation
- Experiment B: Known rule / new symbol transfer (same, partial, disjoint vocabularies)
- Experiment C: Held-out rule generalization (known vocab vs disjoint vocab)
- Experiment D: Few-shot in-context rule discovery for held-out rules
- Experiment E: Cross-rule inductive transfer across structurally related rules
- Experiment F: Permutation-intensity ablation (F0 to F4)
- Experiment G: Representation diagnostics (same-rule vs diff-rule distance)
- Experiment H: Catastrophic forgetting / retention curves in progressive training
"""

import hashlib
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

from nirmal.configuration_nirmal import NirmalConfig
from nirmal.model import NirmalForCausalLM
from training.evaluation.v10_2_harness import CapacityBuilder, aggregate_results

SEP_TOKEN = 1
PAD_TOKEN = 0

ALL_RULES = [
    "copy",
    "increment",
    "fixed_shift",
    "double_step",
    "reverse",
    "simple_composition",
]

TRAIN_VOCAB = (10, 110)
PARTIAL_VOCAB = (70, 170)
DISJOINT_VOCAB = (130, 230)


def apply_rule(base: torch.Tensor, rule: str) -> torch.Tensor:
    """Apply deterministic rule transformation to base integer tensor -> (B, 3)."""
    if base.dim() == 1:
        base = base.unsqueeze(1)
    b = base[:, 0:1]
    if rule == "copy":
        return torch.cat([b, b, b], dim=1)
    elif rule == "increment":
        return torch.cat([b, b + 1, b + 2], dim=1)
    elif rule == "double_step":
        return torch.cat([b, b + 2, b + 4], dim=1)
    elif rule == "reverse":
        return torch.cat([b + 2, b + 1, b], dim=1)
    elif rule == "fixed_shift":
        return torch.cat([b, b + 3, b + 6], dim=1)
    elif rule == "simple_composition":
        return torch.cat([b, b + 1, b + 3], dim=1)
    else:
        raise ValueError(f"Unknown rule: {rule}")


class PermutationAugmentor:
    """Remaps surface token IDs while strictly preserving the underlying rule."""

    def __init__(self, rng_seed: int = 0):
        self._g = torch.Generator()
        self._g.manual_seed(rng_seed)

    def remap(
        self,
        seq: torch.Tensor,
        new_v_lo: int,
        new_v_hi: int,
        rule: str,
        g: Optional[torch.Generator] = None,
    ) -> torch.Tensor:
        """Returns structurally isomorphic sequence in the target vocabulary range."""
        if g is None:
            g = self._g
        B = seq.size(0)
        max_base = max(new_v_lo + 1, new_v_hi - 8)
        new_bases = torch.randint(new_v_lo, max_base, (B, 1), generator=g)
        return apply_rule(new_bases, rule)

    def maybe_remap(
        self,
        batch: torch.Tensor,
        rule: str,
        prob: float,
        target_vocab: Tuple[int, int] = DISJOINT_VOCAB,
        g: Optional[torch.Generator] = None,
    ) -> torch.Tensor:
        """Conditionally remaps with given probability for intensity ablation."""
        if prob <= 0.0:
            return batch
        if prob >= 1.0 or torch.rand(1, generator=g).item() < prob:
            return self.remap(batch, target_vocab[0], target_vocab[1], rule, g=g)
        return batch


class V10_7_DataBuilder:
    """Generates standard and few-shot evaluation batches with leakage auditing."""

    def __init__(self, vocab_size: int = 250):
        self.V = vocab_size

    def _rng(self, seed: int) -> torch.Generator:
        g = torch.Generator()
        g.manual_seed(seed)
        return g

    def make_batch(
        self,
        rule: str,
        vocab_range: Tuple[int, int],
        batch_size: int,
        seed: int,
    ) -> torch.Tensor:
        """Sample deterministic batch of rule sequences (B, 3)."""
        g = self._rng(seed)
        v_lo, v_hi = vocab_range
        max_base = max(v_lo + 1, v_hi - 8)
        bases = torch.randint(v_lo, max_base, (batch_size, 1), generator=g)
        return apply_rule(bases, rule)

    def make_few_shot_batch(
        self,
        rule: str,
        vocab_range: Tuple[int, int],
        k_shots: int,
        batch_size: int,
        seed: int,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """Constructs prompt batches with k demonstrations followed by query.

        Format: [d1_0, d1_1, d1_2, SEP, ..., query_0, query_1]
        Target token is query_2.
        Returns:
            input_ids: (B, total_len)
            targets: (B,)
        """
        g = self._rng(seed)
        v_lo, v_hi = vocab_range
        max_base = max(v_lo + 1, v_hi - 8)

        input_rows = []
        target_tokens = []

        for b_idx in range(batch_size):
            tokens = []
            if k_shots > 0:
                demo_bases = torch.randint(v_lo, max_base, (k_shots, 1), generator=g)
                demos = apply_rule(demo_bases, rule)
                for d in range(k_shots):
                    tokens.extend(demos[d].tolist())
                    tokens.append(SEP_TOKEN)

            q_base = torch.randint(v_lo, max_base, (1, 1), generator=g)
            q_seq = apply_rule(q_base, rule)[0].tolist()
            tokens.extend(q_seq[:2])  # query input
            target_tokens.append(q_seq[2])  # query target
            input_rows.append(tokens)

        # Pad to max length if necessary
        max_len = max(len(r) for r in input_rows)
        padded = []
        for r in input_rows:
            pad_len = max_len - len(r)
            padded.append(r + [PAD_TOKEN] * pad_len)

        return (
            torch.tensor(padded, dtype=torch.long),
            torch.tensor(target_tokens, dtype=torch.long),
        )

    def leakage_certificate(
        self,
        train: torch.Tensor,
        ood: torch.Tensor,
    ) -> Dict[str, bool]:
        """Audits token disjointness, exact row overlap, and sub-sequence leakage."""
        train_tok = set(train.flatten().tolist())
        ood_tok = set(ood.flatten().tolist())
        train_rows = {tuple(r) for r in train.tolist()}
        ood_rows = {tuple(r) for r in ood.tolist()}

        vocab_disjoint = len(train_tok & ood_tok) == 0
        no_row_overlap = len(train_rows & ood_rows) == 0

        train_3g = set()
        for row in train_rows:
            for i in range(len(row) - 2):
                train_3g.add(row[i : i + 3])

        sub_leak = any(
            row[i : i + 3] in train_3g
            for row in ood_rows
            for i in range(len(row) - 2)
        )

        return {
            "vocab_disjoint": vocab_disjoint,
            "no_row_overlap": no_row_overlap,
            "no_subseq_leak": not sub_leak,
            "valid": vocab_disjoint and no_row_overlap and not sub_leak,
        }

    def hash_dataset(self, t: torch.Tensor) -> str:
        return hashlib.sha256(t.cpu().numpy().tobytes()).hexdigest()


@torch.no_grad()
def evaluate_seq_acc(
    model: nn.Module,
    batch: torch.Tensor,
    device: torch.device,
) -> float:
    """Evaluates exact autoregressive match on standard sequence (B, 3)."""
    model.eval()
    x = batch.to(device)
    out = model(input_ids=x)
    logits = out.logits
    preds = torch.argmax(logits[:, :-1, :], dim=-1)
    target = x[:, 1:]
    return (preds == target).all(dim=1).float().mean().item()


@torch.no_grad()
def evaluate_few_shot_acc(
    model: nn.Module,
    input_ids: torch.Tensor,
    targets: torch.Tensor,
    device: torch.device,
) -> float:
    """Evaluates whether model predicts the correct target token from context."""
    model.eval()
    x = input_ids.to(device)
    y = targets.to(device)
    out = model(input_ids=x)
    logits = out.logits
    # Last token of query input is at index -1
    preds = torch.argmax(logits[:, -1, :], dim=-1)
    return (preds == y).float().mean().item()


@torch.no_grad()
def compute_representation_diagnostics(
    model: nn.Module,
    db: V10_7_DataBuilder,
    device: torch.device,
    seed: int = 42,
) -> Dict[str, float]:
    """Measures representation distance within same rule vs across different rules."""
    model.eval()
    same_dists = []
    diff_dists = []

    for rule in ALL_RULES:
        # Same rule, different vocabularies
        b_train = db.make_batch(rule, TRAIN_VOCAB, 16, seed=seed + 10).to(device)
        b_ood = db.make_batch(rule, DISJOINT_VOCAB, 16, seed=seed + 20).to(device)

        h_train = model.model(input_ids=b_train)[0].mean(dim=(0, 1))
        h_ood = model.model(input_ids=b_ood)[0].mean(dim=(0, 1))
        same_dists.append(torch.norm(h_train - h_ood).item())

    # Across different rules in same vocabulary
    for i, r1 in enumerate(ALL_RULES):
        for j, r2 in enumerate(ALL_RULES):
            if i < j:
                b1 = db.make_batch(r1, TRAIN_VOCAB, 16, seed=seed + 30).to(device)
                b2 = db.make_batch(r2, TRAIN_VOCAB, 16, seed=seed + 40).to(device)
                h1 = model.model(input_ids=b1)[0].mean(dim=(0, 1))
                h2 = model.model(input_ids=b2)[0].mean(dim=(0, 1))
                diff_dists.append(torch.norm(h1 - h2).item())

    d_same = float(np.mean(same_dists)) if same_dists else 0.0
    d_diff = float(np.mean(diff_dists)) if diff_dists else 0.0
    invariance_gap = d_diff - d_same
    ratio = d_same / max(d_diff, 1e-8)

    return {
        "d_same": d_same,
        "d_diff": d_diff,
        "invariance_gap": invariance_gap,
        "ratio": ratio,
    }


def compute_retention_metrics(
    eval_matrix: List[Dict[str, float]],
    rules_order: List[str],
) -> Dict[str, Any]:
    """Computes retention and catastrophic forgetting from stage evaluation history.

    eval_matrix[stage_idx][rule] = accuracy
    """
    num_stages = len(eval_matrix)
    initial_accs = {}
    final_accs = {}
    forgetting_per_rule = {}

    for stage_idx, rule in enumerate(rules_order):
        if stage_idx < num_stages and rule in eval_matrix[stage_idx]:
            init_val = eval_matrix[stage_idx][rule]
            fin_val = eval_matrix[-1].get(rule, 0.0)
            initial_accs[rule] = init_val
            final_accs[rule] = fin_val
            forgetting_per_rule[rule] = max(0.0, init_val - fin_val)

    avg_forgetting = float(np.mean(list(forgetting_per_rule.values()))) if forgetting_per_rule else 0.0
    avg_final_retention = float(np.mean(list(final_accs.values()))) if final_accs else 0.0

    return {
        "initial_accs": initial_accs,
        "final_accs": final_accs,
        "forgetting_per_rule": forgetting_per_rule,
        "avg_forgetting": avg_forgetting,
        "avg_final_retention": avg_final_retention,
    }


def classify_generalization(
    level1_ood: float,
    level2_gen: float,
    level3_comp: float,
    avg_forgetting: float,
) -> List[str]:
    """Classifies model behavior based on the primary success criteria."""
    tags = []

    # Level 1: Known Rule Transfer (Target >= 80% strong, >= 15% partial)
    if level1_ood >= 0.80:
        tags.append("KNOWN_RULE_TRANSFER")
    elif level1_ood >= 0.15:
        tags.append("PARTIAL_RULE_TRANSFER")
    else:
        tags.append("VOCABULARY_DEPENDENT")

    # Level 2: Rule Generalization (Unseen rule + known vocab: >= 50% meaningful)
    if level2_gen >= 0.50:
        tags.append("RULE_GENERALIZATION_SIGNAL")
    else:
        tags.append("NO_RULE_GENERALIZATION")

    # Interference check
    if avg_forgetting >= 0.40:
        tags.append("CATASTROPHIC_INTERFERENCE")

    # Check whether rule-specific memorization is active (no positive generalization signal)
    if "RULE_GENERALIZATION_SIGNAL" not in tags and level1_ood < 0.80:
        tags.append("RULE_SPECIFIC_MEMORIZATION")

    return tags
