"""V10.9 Foundational Episodic Learning Harness.

Implements Stage 0 (instrumentation, null calibration, gradient health)
and Stage 1 (1A Identity Copy, 1B Associative Retrieval with 4 matched controls).
Includes readiness gates 1-5, paired bootstrap statistics, and leakage auditing.
"""

import hashlib
import json
import math
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Set, Tuple

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

from nirmal.configuration_nirmal import NirmalConfig
from nirmal.model import NirmalForCausalLM
from training.evaluation.v10_2_harness import CapacityBuilder

# Dedicated Structural Tokens
PAD_TOKEN = 0
EP_TOKEN = 1
SUP_TOKEN = 2
MAP_TOKEN = 3
QRY_TOKEN = 4
ANS_TOKEN = 5
PLACEHOLDER_TOKEN = 6
MIN_DATA_TOKEN = 10
DEFAULT_VOCAB_SIZE = 256


# ─── Episode Structures ───────────────────────────────────────────────────────

class FoundationEpisode:
    def __init__(
        self,
        input_ids: torch.Tensor,
        target: int,
        task_type: str,
        control_type: str,
        keys: List[int],
        values: List[int],
        query_key: int,
        fingerprint: str = "",
    ):
        self.input_ids = input_ids
        self.target = target
        self.task_type = task_type
        self.control_type = control_type
        self.keys = keys
        self.values = values
        self.query_key = query_key
        self._fingerprint = fingerprint

    @property
    def fingerprint(self) -> str:
        if not self._fingerprint:
            s = f"{self.task_type}|{self.control_type}|{self.input_ids.tolist()}|{self.target}"
            self._fingerprint = hashlib.sha256(s.encode("utf-8")).hexdigest()
        return self._fingerprint

    @fingerprint.setter
    def fingerprint(self, val: str):
        self._fingerprint = val

    def compute_fingerprint(self) -> str:
        return self.fingerprint


def collate_foundation_episodes(
    episodes: List[FoundationEpisode],
    max_len: Optional[int] = None,
) -> Tuple[torch.Tensor, torch.Tensor]:
    """Collates episodes with left-padding to max_len."""
    batch_size = len(episodes)
    lens = [len(ep.input_ids) for ep in episodes]
    target_len = max_len or max(lens)

    padded = torch.full((batch_size, target_len), PAD_TOKEN, dtype=torch.long)
    targets = torch.tensor([ep.target for ep in episodes], dtype=torch.long)

    for i, ep in enumerate(episodes):
        seq = ep.input_ids
        padded[i, target_len - len(seq):] = seq

    return padded, targets


# ─── Stage 1A: Identity Copy Generator ────────────────────────────────────────

class Stage1AGenerator:
    """Generates Identity Copy episodes.

    Domain |D| = 8.
    Support: 3 distinct symbol -> symbol pairs.
    Query: 4th distinct symbol -> that same symbol.
    Target: query symbol. Chance = 1/8 = 12.5%.
    """

    def __init__(self, vocab_start: int = MIN_DATA_TOKEN, domain_size: int = 8):
        self.vocab_start = vocab_start
        self.domain_size = domain_size

    def generate_episode(self, g: torch.Generator) -> FoundationEpisode:
        # Sample 4 distinct symbols from domain |D| = 8
        base_pool = list(range(self.vocab_start, self.vocab_start + self.domain_size))
        perm = torch.randperm(self.domain_size, generator=g).tolist()
        chosen = [base_pool[i] for i in perm[:4]]

        s1, s2, s3, qx = chosen[0], chosen[1], chosen[2], chosen[3]

        tokens = [
            EP_TOKEN,
            SUP_TOKEN, s1, MAP_TOKEN, s1,
            SUP_TOKEN, s2, MAP_TOKEN, s2,
            SUP_TOKEN, s3, MAP_TOKEN, s3,
            QRY_TOKEN, qx, MAP_TOKEN, ANS_TOKEN,
        ]

        return FoundationEpisode(
            input_ids=torch.tensor(tokens, dtype=torch.long),
            target=qx,
            task_type="stage1a_identity",
            control_type="correct",
            keys=[s1, s2, s3],
            values=[s1, s2, s3],
            query_key=qx,
        )

    def generate_batch_tensor(
        self,
        batch_size: int,
        device: torch.device,
        g: Optional[torch.Generator] = None,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """Vectorized tensor batch generation directly on target device."""
        gen = g if (g is not None and str(getattr(g, 'device', 'cpu')) == str(device)) else None
        perms = torch.rand(batch_size, self.domain_size, device=device, generator=gen).argsort(dim=-1)[:, :4] + self.vocab_start
        s1 = perms[:, 0]
        s2 = perms[:, 1]
        s3 = perms[:, 2]
        qx = perms[:, 3]

        batch = torch.empty((batch_size, 17), dtype=torch.long, device=device)
        batch[:, 0] = EP_TOKEN
        batch[:, 1] = SUP_TOKEN
        batch[:, 2] = s1
        batch[:, 3] = MAP_TOKEN
        batch[:, 4] = s1
        batch[:, 5] = SUP_TOKEN
        batch[:, 6] = s2
        batch[:, 7] = MAP_TOKEN
        batch[:, 8] = s2
        batch[:, 9] = SUP_TOKEN
        batch[:, 10] = s3
        batch[:, 11] = MAP_TOKEN
        batch[:, 12] = s3
        batch[:, 13] = QRY_TOKEN
        batch[:, 14] = qx
        batch[:, 15] = MAP_TOKEN
        batch[:, 16] = ANS_TOKEN

        return batch, qx


# ─── Stage 1B: Associative Retrieval Generator ────────────────────────────────

class Stage1BGenerator:
    """Generates Associative Retrieval episodes with 4 matched controls.

    4 random keys and 4 random values.
    Support contains all 4 pairs in permuted order.
    Query repeats one support key at a different position.
    Target is that key's associated value.
    Chance = 1/4 = 25%.

    Controls:
    1. 'correct': support is consistent with query.
    2. 'random': support values randomly shuffled (reject accidental match with target!).
    3. 'wrong': key is paired with a strictly different value.
    4. 'absent': support content replaced with neutral PLACEHOLDER_TOKEN.
    All 4 have identical length, token count, delimiter layout.
    """

    def __init__(self, vocab_start: int = MIN_DATA_TOKEN, vocab_size: int = 64):
        self.vocab_start = vocab_start
        self.vocab_size = vocab_size

    def generate_correct(self, g: torch.Generator) -> FoundationEpisode:
        """Generates only a single correct episode directly for fast training."""
        pool = list(range(self.vocab_start, self.vocab_start + self.vocab_size))
        perm = torch.randperm(len(pool), generator=g).tolist()
        keys = [pool[perm[i]] for i in range(4)]
        values = [pool[perm[i + 4]] for i in range(4)]

        q_idx = torch.randint(0, 4, (1,), generator=g).item()
        qx = keys[q_idx]
        qy = values[q_idx]

        sup_order = torch.randperm(4, generator=g).tolist()
        ordered_keys = [keys[i] for i in sup_order]
        ordered_values = [values[i] for i in sup_order]

        tokens = [EP_TOKEN]
        for k, v in zip(ordered_keys, ordered_values):
            tokens.extend([SUP_TOKEN, k, MAP_TOKEN, v])
        tokens.extend([QRY_TOKEN, qx, MAP_TOKEN, ANS_TOKEN])

        return FoundationEpisode(
            input_ids=torch.tensor(tokens, dtype=torch.long),
            target=qy,
            task_type="stage1b_retrieval",
            control_type="correct",
            keys=keys,
            values=values,
            query_key=qx,
        )

    def generate_batch_tensor(
        self,
        batch_size: int,
        device: torch.device,
        g: Optional[torch.Generator] = None,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """Pure GPU vectorized tensor batch generation directly on device."""
        gen = g if (g is not None and str(getattr(g, 'device', 'cpu')) == str(device)) else None
        perms = torch.rand(batch_size, self.vocab_size, device=device, generator=gen).argsort(dim=-1)[:, :8] + self.vocab_start
        keys = perms[:, :4]
        values = perms[:, 4:]

        q_idx = torch.randint(0, 4, (batch_size, 1), device=device, generator=gen)
        qx = torch.gather(keys, 1, q_idx).squeeze(1)
        qy = torch.gather(values, 1, q_idx).squeeze(1)

        sup_perms = torch.rand(batch_size, 4, device=device, generator=gen).argsort(dim=-1)
        ordered_keys = torch.gather(keys, 1, sup_perms)
        ordered_values = torch.gather(values, 1, sup_perms)

        batch = torch.empty((batch_size, 21), dtype=torch.long, device=device)
        batch[:, 0] = EP_TOKEN
        for i in range(4):
            batch[:, 1 + i * 4] = SUP_TOKEN
            batch[:, 2 + i * 4] = ordered_keys[:, i]
            batch[:, 3 + i * 4] = MAP_TOKEN
            batch[:, 4 + i * 4] = ordered_values[:, i]
        batch[:, 17] = QRY_TOKEN
        batch[:, 18] = qx
        batch[:, 19] = MAP_TOKEN
        batch[:, 20] = ANS_TOKEN

        return batch, qy

    def generate_quartet(self, g: torch.Generator) -> Dict[str, FoundationEpisode]:
        """Generates a matched quartet of all 4 controls from the same underlying keys/query."""
        pool = list(range(self.vocab_start, self.vocab_start + self.vocab_size))
        perm = torch.randperm(len(pool), generator=g).tolist()

        # 4 distinct keys, 4 distinct values (no key == value)
        keys = [pool[perm[i]] for i in range(4)]
        values = [pool[perm[i + 4]] for i in range(4)]

        # Select query key index
        q_idx = torch.randint(0, 4, (1,), generator=g).item()
        qx = keys[q_idx]
        qy = values[q_idx]

        # Randomize support order
        sup_order = torch.randperm(4, generator=g).tolist()
        ordered_keys = [keys[i] for i in sup_order]
        ordered_values = [values[i] for i in sup_order]

        # 1. Correct
        correct_tokens = [EP_TOKEN]
        for k, v in zip(ordered_keys, ordered_values):
            correct_tokens.extend([SUP_TOKEN, k, MAP_TOKEN, v])
        correct_tokens.extend([QRY_TOKEN, qx, MAP_TOKEN, ANS_TOKEN])

        ep_correct = FoundationEpisode(
            input_ids=torch.tensor(correct_tokens, dtype=torch.long),
            target=qy,
            task_type="stage1b_retrieval",
            control_type="correct",
            keys=keys,
            values=values,
            query_key=qx,
        )

        # 2. Random: support values permuted; reject if query key maps to qy accidentally!
        max_tries = 100
        rand_values = ordered_values[:]
        for _ in range(max_tries):
            val_perm = torch.randperm(4, generator=g).tolist()
            candidate = [ordered_values[i] for i in val_perm]
            # Find the position where ordered_keys has qx
            qx_pos = ordered_keys.index(qx)
            if candidate[qx_pos] != qy:  # accidental match rejected!
                rand_values = candidate
                break

        random_tokens = [EP_TOKEN]
        for k, v in zip(ordered_keys, rand_values):
            random_tokens.extend([SUP_TOKEN, k, MAP_TOKEN, v])
        random_tokens.extend([QRY_TOKEN, qx, MAP_TOKEN, ANS_TOKEN])

        ep_random = FoundationEpisode(
            input_ids=torch.tensor(random_tokens, dtype=torch.long),
            target=qy,
            task_type="stage1b_retrieval",
            control_type="random",
            keys=keys,
            values=values,
            query_key=qx,
        )

        # 3. Wrong: cycle values by +1 so that qx maps to values[(q_idx+1)%4] != qy
        wrong_values = ordered_values[1:] + ordered_values[:1]
        wrong_tokens = [EP_TOKEN]
        for k, v in zip(ordered_keys, wrong_values):
            wrong_tokens.extend([SUP_TOKEN, k, MAP_TOKEN, v])
        wrong_tokens.extend([QRY_TOKEN, qx, MAP_TOKEN, ANS_TOKEN])

        ep_wrong = FoundationEpisode(
            input_ids=torch.tensor(wrong_tokens, dtype=torch.long),
            target=qy,
            task_type="stage1b_retrieval",
            control_type="wrong",
            keys=keys,
            values=values,
            query_key=qx,
        )

        # 4. Absent: replace support tokens with neutral PLACEHOLDER_TOKEN
        absent_tokens = [EP_TOKEN]
        for _ in range(4):
            absent_tokens.extend([SUP_TOKEN, PLACEHOLDER_TOKEN, MAP_TOKEN, PLACEHOLDER_TOKEN])
        absent_tokens.extend([QRY_TOKEN, qx, MAP_TOKEN, ANS_TOKEN])

        ep_absent = FoundationEpisode(
            input_ids=torch.tensor(absent_tokens, dtype=torch.long),
            target=qy,
            task_type="stage1b_retrieval",
            control_type="absent",
            keys=keys,
            values=values,
            query_key=qx,
        )

        return {
            "correct": ep_correct,
            "random": ep_random,
            "wrong": ep_wrong,
            "absent": ep_absent,
        }


# ─── Stage 0 Sanitizers ───────────────────────────────────────────────────────

class Stage0Sanitizer:
    """Stage 0 fixtures and null calibrations."""

    @staticmethod
    def make_one_batch_overfit_set(size: int = 128, seed: int = 999) -> List[FoundationEpisode]:
        """Creates fixed 128 episodes for overfit verification."""
        g = torch.Generator().manual_seed(seed)
        gen = Stage1BGenerator()
        episodes = []
        for _ in range(size):
            quartet = gen.generate_quartet(g)
            episodes.append(quartet["correct"])
        return episodes

    @staticmethod
    def make_direct_label_control_set(size: int = 64, seed: int = 888) -> List[FoundationEpisode]:
        """Direct-label sanity control: support explicitly contains [QRY, qx, MAP, qy]."""
        g = torch.Generator().manual_seed(seed)
        episodes = []
        for _ in range(size):
            qx = torch.randint(10, 50, (1,), generator=g).item()
            qy = torch.randint(51, 90, (1,), generator=g).item()
            # Explicit support slot contains direct answer
            tokens = [
                EP_TOKEN,
                SUP_TOKEN, qx, MAP_TOKEN, qy,
                QRY_TOKEN, qx, MAP_TOKEN, ANS_TOKEN,
            ]
            episodes.append(FoundationEpisode(
                input_ids=torch.tensor(tokens, dtype=torch.long),
                target=qy,
                task_type="stage0_direct_label",
                control_type="direct",
                keys=[qx],
                values=[qy],
                query_key=qx,
            ))
        return episodes


# ─── Gradient Health Logger ───────────────────────────────────────────────────

@dataclass
class GradientHealthLog:
    step: int
    global_grad_norm: float
    param_update_norm: float
    update_ratio: float
    is_clipped: bool
    nan_inf_count: int
    collapsed_prediction: bool

    @staticmethod
    def inspect(
        model: nn.Module,
        pre_params: Dict[str, torch.Tensor],
        step: int,
        max_norm: float = 1.0,
        predictions: Optional[List[int]] = None,
    ) -> "GradientHealthLog":
        # Global gradient norm
        total_sq = 0.0
        nan_inf = 0
        for p in model.parameters():
            if p.grad is not None:
                g = p.grad.data
                if torch.isnan(g).any() or torch.isinf(g).any():
                    nan_inf += 1
                total_sq += g.norm(2).item() ** 2
        grad_norm = math.sqrt(total_sq)

        # Update norm and ratio
        up_norm_sq = 0.0
        p_norm_sq = 0.0
        for name, p in model.named_parameters():
            if name in pre_params:
                diff = p.data - pre_params[name]
                up_norm_sq += diff.norm(2).item() ** 2
                p_norm_sq += p.data.norm(2).item() ** 2

        up_norm = math.sqrt(up_norm_sq)
        p_norm = math.sqrt(p_norm_sq)
        ratio = up_norm / max(p_norm, 1e-10)
        is_clipped = grad_norm > max_norm

        collapsed = False
        if predictions and len(predictions) > 10:
            from collections import Counter
            counts = Counter(predictions)
            most_common_cnt = counts.most_common(1)[0][1]
            if (most_common_cnt / len(predictions)) > 0.90:
                collapsed = True

        return GradientHealthLog(
            step=step,
            global_grad_norm=grad_norm,
            param_update_norm=up_norm,
            update_ratio=ratio,
            is_clipped=is_clipped,
            nan_inf_count=nan_inf,
            collapsed_prediction=collapsed,
        )


# ─── Paired Bootstrap & Wilson Statistics ──────────────────────────────────────

def paired_bootstrap_ci(
    acc_a: np.ndarray,
    acc_b: np.ndarray,
    n_resamples: int = 1000,
    confidence: float = 0.95,
    seed: int = 42,
) -> Tuple[float, float]:
    """Computes paired bootstrap confidence interval for difference (acc_a - acc_b)."""
    assert len(acc_a) == len(acc_b), "Paired arrays must be of equal length."
    diffs = acc_a - acc_b
    n = len(diffs)
    rng = np.random.default_rng(seed)

    boot_means = []
    for _ in range(n_resamples):
        sample = rng.choice(diffs, size=n, replace=True)
        boot_means.append(float(np.mean(sample)))

    alpha = (1.0 - confidence) / 2.0
    low = float(np.percentile(boot_means, alpha * 100))
    high = float(np.percentile(boot_means, (1.0 - alpha) * 100))
    return round(low, 4), round(high, 4)


def wilson_ci(correct: int, total: int, confidence: float = 0.95) -> Tuple[float, float]:
    """Wilson 95% score confidence interval."""
    if total == 0:
        return 0.0, 0.0
    z = 1.95996
    p_hat = correct / total
    denom = 1.0 + (z ** 2) / total
    center = (p_hat + (z ** 2) / (2 * total)) / denom
    margin = (z / denom) * math.sqrt((p_hat * (1 - p_hat) / total) + (z ** 2) / (4 * (total ** 2)))
    return round(max(0.0, center - margin), 4), round(min(1.0, center + margin), 4)


# ─── Readiness Gates Evaluation ────────────────────────────────────────────────

@dataclass
class ReadinessGateReport:
    stage: str
    gate1_train_mastery: bool
    gate2_val_generalization: bool
    gate3_causal_utility: bool
    gate4_seed_stability: bool
    gate5_integrity: bool
    all_passed: bool
    details: Dict[str, Any]

    @staticmethod
    def evaluate(
        stage: str,
        train_accs_final3: List[float],
        val_accs_per_seed: Dict[int, float],
        seed_control_gains: Dict[int, Dict[str, float]],
        bootstrap_ci_low: float,
        integrity_ok: bool,
    ) -> "ReadinessGateReport":
        # Gate 1: Train mastery (>= 90% query accuracy across final 3 evals)
        g1 = all(acc >= 0.90 for acc in train_accs_final3) if train_accs_final3 else False

        # Gate 2: Val generalization (median val >= 80%)
        val_vals = list(val_accs_per_seed.values())
        median_val = float(np.median(val_vals)) if val_vals else 0.0
        g2 = median_val >= 0.80

        # Gate 3: Causal utility (for 1B: Correct - Random >= 10pp, Correct - Wrong >= 10pp, Correct - Absent >= 10pp, bootstrap low > 0)
        if stage == "stage1a":
            g3 = True  # Not required for 1A
        else:
            mean_c_rand = float(np.mean([g["correct_minus_random"] for g in seed_control_gains.values()]))
            mean_c_wrong = float(np.mean([g["correct_minus_wrong"] for g in seed_control_gains.values()]))
            mean_c_absent = float(np.mean([g["correct_minus_absent"] for g in seed_control_gains.values()]))
            g3 = (mean_c_rand >= 0.10) and (mean_c_wrong >= 0.10) and (mean_c_absent >= 0.10) and (bootstrap_ci_low > 0.0)

        # Gate 4: Seed stability (median >= 80%, every seed >= 75%, std <= 5pp)
        min_seed = min(val_vals) if val_vals else 0.0
        std_seed = float(np.std(val_vals)) if val_vals else 1.0
        g4 = (median_val >= 0.80) and (min_seed >= 0.75) and (std_seed <= 0.05)

        # Gate 5: Integrity
        g5 = integrity_ok

        all_pass = g1 and g2 and g3 and g4 and g5
        return ReadinessGateReport(
            stage=stage,
            gate1_train_mastery=g1,
            gate2_val_generalization=g2,
            gate3_causal_utility=g3,
            gate4_seed_stability=g4,
            gate5_integrity=g5,
            all_passed=all_pass,
            details={
                "median_val": median_val,
                "min_seed_val": min_seed,
                "std_seed_val": std_seed,
                "train_final3": train_accs_final3,
                "bootstrap_ci_low": bootstrap_ci_low,
            },
        )


# ─── Model Evaluation Function ────────────────────────────────────────────────

@torch.no_grad()
def evaluate_foundation_model(
    model: nn.Module,
    episodes: List[FoundationEpisode],
    device: torch.device,
    batch_size: int = 64,
) -> Tuple[float, np.ndarray, np.ndarray]:
    """Returns accuracy, binary correct array, predictions array."""
    model.eval()
    all_preds = []
    all_targets = []

    for i in range(0, len(episodes), batch_size):
        batch_eps = episodes[i : i + batch_size]
        padded, targets = collate_foundation_episodes(batch_eps)
        padded = padded.to(device)

        out = model(input_ids=padded)
        logits = out.logits
        preds = torch.argmax(logits[:, -1, :], dim=-1).cpu().numpy()

        all_preds.extend(preds.tolist())
        all_targets.extend(targets.numpy().tolist())

    preds_arr = np.array(all_preds)
    targets_arr = np.array(all_targets)
    correct_arr = (preds_arr == targets_arr).astype(np.float32)
    acc = float(np.mean(correct_arr)) if len(correct_arr) > 0 else 0.0
    return acc, correct_arr, preds_arr
