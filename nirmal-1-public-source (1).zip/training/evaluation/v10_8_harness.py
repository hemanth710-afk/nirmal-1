"""V10.8 Learning-to-Learn Rule Induction Harness.

Implements:
- Finite Field Z_p arithmetic rule space (translate, scale, power, threshold, affine)
- Per-episode symbolization regimes (V-A Offset, V-B Affine-rank, V-C Arbitrary permutation)
- Canonical episodic token formatting: x1 y1 SEP ... xk yk SEP QST qx -> qy
- Reserved tokens: PAD=0, SEP=1, QST=2; data tokens >= 3
- Evaluation levels L1 through L5
- Demonstration curve evaluation (k in {0, 1, 2, 4, 8, 16})
- Control conditions: Correct, Random, Wrong-rule, Distractor-heavy, Length-matched, Position-matched, Label-noise
- Wilson 95% score confidence intervals and comprehensive metrics
- Leakage auditing and immutable benchmark validation
"""

import hashlib
import json
import math
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Set, Tuple

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

from nirmal.configuration_nirmal import NirmalConfig
from nirmal.model import NirmalForCausalLM
from training.evaluation.v10_2_harness import CapacityBuilder

# Reserved Tokens
PAD_TOKEN = 0
SEP_TOKEN = 1
QST_TOKEN = 2
MIN_DATA_TOKEN = 3

# Field Prime
P_FIELD = 97
DEFAULT_VOCAB_SIZE = 512

# Vocabulary Partitions for Symbolization
SEEN_BASE_RANGE = (3, 100)
UNSEEN_BASE_RANGE = (200, 300)
HELD_OUT_TRANSLATE_C = 47


# ─── Finite Field Rule Space ──────────────────────────────────────────────────

@dataclass(frozen=True)
class RuleDefinition:
    family: str
    params: Tuple[int, ...]

    def apply(self, x: int, p: int = P_FIELD) -> int:
        if self.family == "translate":
            c = self.params[0]
            return (x + c) % p
        elif self.family == "scale":
            a = self.params[0]
            return (a * x) % p
        elif self.family == "power":
            return (x * x) % p
        elif self.family == "threshold":
            c = self.params[0]
            return 1 if x < c else 0
        elif self.family == "affine":
            a, b = self.params[0], self.params[1]
            return (a * x + b) % p
        else:
            raise ValueError(f"Unknown rule family: {self.family}")


class RuleSampler:
    """Samples mathematical rules over Z_p partitioned into seen and held-out."""

    def __init__(self, p: int = P_FIELD, held_out_c: int = HELD_OUT_TRANSLATE_C):
        self.p = p
        self.held_out_c = held_out_c

    def sample_seen_rule(self, g: torch.Generator, broad_diversity: bool = False) -> RuleDefinition:
        """Sample from seen families: translate (c != held_out_c) and scale."""
        choice = torch.randint(0, 2, (1,), generator=g).item()
        if choice == 0:
            # translate: c in [1, p-1] excluding held_out_c
            candidates = [c for c in range(1, self.p) if c != self.held_out_c]
            c_idx = torch.randint(0, len(candidates), (1,), generator=g).item()
            return RuleDefinition(family="translate", params=(candidates[c_idx],))
        else:
            # scale: a in [2, p-1]
            a = torch.randint(2, self.p, (1,), generator=g).item()
            return RuleDefinition(family="scale", params=(a,))

    def sample_held_out_parameter_rule(self) -> RuleDefinition:
        """Translate with strictly held-out parameter c*."""
        return RuleDefinition(family="translate", params=(self.held_out_c,))

    def sample_held_out_family_rule(self, family: str, g: Optional[torch.Generator] = None) -> RuleDefinition:
        if family == "power":
            return RuleDefinition(family="power", params=())
        elif family == "threshold":
            c = self.p // 2 if g is None else torch.randint(20, self.p - 20, (1,), generator=g).item()
            return RuleDefinition(family="threshold", params=(c,))
        elif family == "affine":
            g = g or torch.Generator()
            a = torch.randint(2, self.p, (1,), generator=g).item()
            b = torch.randint(1, self.p, (1,), generator=g).item()
            return RuleDefinition(family="affine", params=(a, b))
        else:
            raise ValueError(f"Family {family} is not a valid held-out family.")


# ─── Symbolization Regimes ────────────────────────────────────────────────────

class Symbolizer:
    """Implements V-A Offset, V-B Affine-rank, and V-C Arbitrary permutation."""

    @staticmethod
    def apply_va_offset(val: int, base: int) -> int:
        return base + val

    @staticmethod
    def apply_vb_affine(val: int, base: int, stride: int) -> int:
        return base + stride * val

    @staticmethod
    def sample_symbolization(
        regime: str,
        is_unseen: bool,
        g: torch.Generator,
        p: int = P_FIELD,
    ) -> Callable[[int], int]:
        """Returns a mapping function pi(v) mapping Z_p value to data token ID >= 3."""
        base_range = UNSEEN_BASE_RANGE if is_unseen else SEEN_BASE_RANGE

        if regime == "V-A":
            base = torch.randint(base_range[0], base_range[1] + 1, (1,), generator=g).item()
            return lambda v: base + v
        elif regime == "V-B":
            base = torch.randint(base_range[0], base_range[1] + 1, (1,), generator=g).item()
            strides = [2, 3] if is_unseen else [1, 2]
            stride = strides[torch.randint(0, len(strides), (1,), generator=g).item()]
            return lambda v: base + stride * v
        elif regime == "V-C":
            # Diagnostic only: random bijection
            base = torch.randint(base_range[0], base_range[1] + 1, (1,), generator=g).item()
            perm = torch.randperm(p, generator=g).tolist()
            return lambda v: base + perm[v % p]
        else:
            raise ValueError(f"Unknown symbolization regime: {regime}")


# ─── Episode Construction ─────────────────────────────────────────────────────

@dataclass
class Episode:
    input_ids: torch.Tensor       # Shape: (seq_len,)
    target: int                   # Ground-truth qy token ID
    k: int                        # Number of support examples
    rule: RuleDefinition          # Rule definition (for auditing, not tokenized)
    symbol_regime: str            # Regime name
    is_unseen_symbol: bool        # Unseen symbol partition flag
    qx_val: int                   # Raw mathematical query x
    qy_val: int                   # Raw mathematical query y
    support_xs: List[int]         # Raw support x values


class EpisodeBuilder:
    """Constructs canonical support/query episodes with strict validation."""

    def __init__(self, p: int = P_FIELD):
        self.p = p

    def build_episode(
        self,
        rule: RuleDefinition,
        k: int,
        symbol_regime: str,
        is_unseen_symbol: bool,
        g: torch.Generator,
        control: str = "correct",
        wrong_rule: Optional[RuleDefinition] = None,
    ) -> Episode:
        """Constructs a single episode.

        Controls:
        - "correct": standard support
        - "random": support y replaced with random Z_p values
        - "wrong_rule": support y generated from wrong_rule
        - "label_noise": 20% of support labels permuted
        - "distractor": noisy support pairs included
        """
        assert k >= 0, "k must be non-negative."
        # Total distinct x required: k + 1 (support + query)
        total_needed = k + 1
        assert total_needed <= self.p, f"Cannot sample {total_needed} distinct inputs from Z_{self.p}"

        # Sample distinct x values from Z_p
        perm_x = torch.randperm(self.p, generator=g).tolist()
        support_xs = perm_x[:k]
        qx = perm_x[k]
        assert qx not in support_xs, "Query input leaked into support!"

        # Randomize support order
        if k > 1:
            support_order = torch.randperm(k, generator=g).tolist()
            support_xs = [support_xs[i] for i in support_order]

        # Compute y values
        qy = rule.apply(qx, self.p)

        support_ys = []
        for sx in support_xs:
            if control == "correct":
                sy = rule.apply(sx, self.p)
            elif control == "random":
                sy = torch.randint(0, self.p, (1,), generator=g).item()
            elif control == "wrong_rule":
                assert wrong_rule is not None, "wrong_rule required for wrong_rule control"
                sy = wrong_rule.apply(sx, self.p)
            elif control == "label_noise":
                if torch.rand(1, generator=g).item() < 0.20:
                    sy = (rule.apply(sx, self.p) + torch.randint(1, self.p, (1,), generator=g).item()) % self.p
                else:
                    sy = rule.apply(sx, self.p)
            else:
                sy = rule.apply(sx, self.p)
            support_ys.append(sy)

        # Get symbolization mapping pi
        pi = Symbolizer.sample_symbolization(symbol_regime, is_unseen_symbol, g, self.p)

        # Build token stream: x1 y1 SEP ... xk yk SEP QST qx
        tokens: List[int] = []
        for sx, sy in zip(support_xs, support_ys):
            tx = pi(sx)
            ty = pi(sy)
            assert tx >= MIN_DATA_TOKEN and ty >= MIN_DATA_TOKEN, "Data token below reserved threshold!"
            tokens.extend([tx, ty, SEP_TOKEN])

        # Query segment
        t_qx = pi(qx)
        t_qy = pi(qy)
        assert t_qx >= MIN_DATA_TOKEN and t_qy >= MIN_DATA_TOKEN, "Query token below reserved threshold!"
        tokens.extend([QST_TOKEN, t_qx])

        return Episode(
            input_ids=torch.tensor(tokens, dtype=torch.long),
            target=t_qy,
            k=k,
            rule=rule,
            symbol_regime=symbol_regime,
            is_unseen_symbol=is_unseen_symbol,
            qx_val=qx,
            qy_val=qy,
            support_xs=support_xs,
        )


def collate_episodes(episodes: List[Episode], max_len: Optional[int] = None) -> Tuple[torch.Tensor, torch.Tensor]:
    """Collates variable-length episodes with left-padding."""
    batch_size = len(episodes)
    lens = [len(ep.input_ids) for ep in episodes]
    target_len = max_len or max(lens)

    padded = torch.full((batch_size, target_len), PAD_TOKEN, dtype=torch.long)
    targets = torch.tensor([ep.target for ep in episodes], dtype=torch.long)

    for i, ep in enumerate(episodes):
        seq = ep.input_ids
        padded[i, target_len - len(seq):] = seq

    return padded, targets


# ─── Metrics and Statistics ───────────────────────────────────────────────────

def wilson_score_interval(correct: int, total: int, confidence: float = 0.95) -> Tuple[float, float]:
    """Computes exact Wilson score 95% confidence interval."""
    if total == 0:
        return 0.0, 0.0
    z = 1.95996  # 95% confidence
    p_hat = correct / total
    denom = 1.0 + (z ** 2) / total
    center = (p_hat + (z ** 2) / (2 * total)) / denom
    margin = (z / denom) * math.sqrt((p_hat * (1 - p_hat) / total) + (z ** 2) / (4 * (total ** 2)))
    lower = max(0.0, center - margin)
    upper = min(1.0, center + margin)
    return round(lower, 4), round(upper, 4)


def compute_metrics(
    predictions: np.ndarray,
    targets: np.ndarray,
    chance_p: float = 1.0 / P_FIELD,
) -> Dict[str, Any]:
    """Computes exact-match accuracy, Wilson 95% CI, and chance baseline."""
    total = len(targets)
    correct = int(np.sum(predictions == targets))
    acc = float(correct / total) if total > 0 else 0.0
    ci_low, ci_high = wilson_score_interval(correct, total)

    return {
        "total": total,
        "correct": correct,
        "accuracy": round(acc, 4),
        "ci95": [ci_low, ci_high],
        "chance_rate": round(chance_p, 4),
        "above_chance": acc > chance_p,
    }


# ─── Leakage and Auditing ─────────────────────────────────────────────────────

class LeakageAuditor:
    """Verifies strict leakage separation, held-out isolation, and token integrity."""

    @staticmethod
    def audit_episode(ep: Episode) -> Dict[str, bool]:
        """Audits single episode for support-query disjointness and token bounds."""
        tokens = ep.input_ids.tolist()
        data_tokens = [t for t in tokens if t not in (PAD_TOKEN, SEP_TOKEN, QST_TOKEN)]

        no_reserved_in_data = all(t >= MIN_DATA_TOKEN for t in data_tokens)
        query_not_in_support = ep.qx_val not in ep.support_xs

        return {
            "no_reserved_in_data": no_reserved_in_data,
            "query_not_in_support": query_not_in_support,
            "valid": no_reserved_in_data and query_not_in_support,
        }

    @staticmethod
    def audit_benchmark_isolation(
        train_rules: List[RuleDefinition],
        eval_episodes: List[Episode],
        held_out_c: int = HELD_OUT_TRANSLATE_C,
        held_out_families: Tuple[str, ...] = ("power", "threshold", "affine"),
    ) -> Dict[str, bool]:
        """Audits that train rules do not contain any held-out family or held-out parameter."""
        train_families = {r.family for r in train_rules}
        held_out_fam_violation = any(f in train_families for f in held_out_families)

        train_translate_cs = {r.params[0] for r in train_rules if r.family == "translate"}
        held_out_param_violation = held_out_c in train_translate_cs

        # Verify all eval episodes have non-leaking query
        query_violations = sum(ep.qx_val in ep.support_xs for ep in eval_episodes)

        valid = (not held_out_fam_violation) and (not held_out_param_violation) and (query_violations == 0)

        return {
            "held_out_family_excluded": not held_out_fam_violation,
            "held_out_parameter_excluded": not held_out_param_violation,
            "query_disjointness_verified": query_violations == 0,
            "valid": valid,
        }


# ─── Evaluation Model Evaluation ──────────────────────────────────────────────

@torch.no_grad()
def evaluate_model_on_episodes(
    model: nn.Module,
    episodes: List[Episode],
    device: torch.device,
    batch_size: int = 32,
) -> Dict[str, Any]:
    """Evaluates an autoregressive causal LM on a list of episodes."""
    model.eval()
    all_preds = []
    all_targets = []

    for i in range(0, len(episodes), batch_size):
        batch_eps = episodes[i : i + batch_size]
        padded, targets = collate_episodes(batch_eps)
        padded = padded.to(device)

        out = model(input_ids=padded)
        logits = out.logits  # (B, T, V)
        # Prediction at position of qx (index -1)
        preds = torch.argmax(logits[:, -1, :], dim=-1).cpu().numpy()

        all_preds.extend(preds.tolist())
        all_targets.extend(targets.numpy().tolist())

    return compute_metrics(np.array(all_preds), np.array(all_targets))


# ─── Scientific Classifications ───────────────────────────────────────────────

def classify_v10_8_study(
    l1_acc: float,
    l2_acc: float,
    l3_acc: float,
    l4_acc: float,
    l5_acc: float,
    k16_vs_k0_gain: float,
    correct_vs_random_gain: float,
    train_acc: float,
) -> List[str]:
    """Assigns unambiguous scientific tags based on empirical evidence."""
    tags = []

    if train_acc < 0.10:
        tags.append("OPTIMIZATION_FAILURE")
        return tags

    # Meta-learning signal requires: correct > random and k16 > k0
    if correct_vs_random_gain >= 0.15 and k16_vs_k0_gain >= 0.15:
        if l1_acc >= 0.50:
            tags.append("META_LEARNING_SIGNAL")
        else:
            tags.append("META_LEARNING_WITHOUT_VOCAB_GENERALIZATION")
    else:
        tags.append("NO_CONTEXT_USE")

    # Vocabulary dependence
    if l1_acc < 0.20 and train_acc >= 0.40:
        tags.append("VOCABULARY_DEPENDENCE")

    # Parameter memorization
    if l2_acc < 0.15 and train_acc >= 0.40:
        tags.append("PARAMETER_MEMORIZATION")

    # Rule specific memorization
    if l3_acc < 0.10 and l4_acc < 0.10:
        tags.append("RULE_SPECIFIC_MEMORIZATION")

    # Capacity limits
    if train_acc < 0.35:
        tags.append("CAPACITY_LIMIT")

    return tags
