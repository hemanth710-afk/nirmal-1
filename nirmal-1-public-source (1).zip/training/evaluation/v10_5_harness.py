"""V10.5 Few-Shot Rule Induction Evaluation Harness.

Provides deterministic few-shot task generation, context demonstration formatting,
controls, order permutations, and leakage-audited evaluation.
"""

import hashlib
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Any

import numpy as np
import torch
import torch.nn.functional as F

from nirmal.configuration_nirmal import NirmalConfig
from nirmal.model import NirmalForCausalLM
from training.evaluation.v10_2_harness import CapacityBuilder, aggregate_results

SEP_TOKEN = 1
PAD_TOKEN = 0

ALL_RULES = [
    "copy",
    "increment",
    "double_step",
    "reverse",
    "fixed_shift",
    "simple_composition",
]

TRAIN_RULES = ["copy", "increment", "fixed_shift", "simple_composition"]
HELD_OUT_RULES = ["double_step", "reverse"]

TRAIN_VOCAB = (10, 110)
VAL_VOCAB = (10, 110)
DISJOINT_OOD_VOCAB = (130, 230)


class FewShotRuleFamily:
    """Deterministic generator of rule instances."""

    @staticmethod
    def apply(base: torch.Tensor, rule: str) -> torch.Tensor:
        """Applies transformation to base integer tensor of shape (B, 1) or (B,)."""
        if base.dim() == 1:
            base = base.unsqueeze(1)
        b = base[:, 0:1]

        if rule == "copy":
            return torch.cat([b, b, b], dim=1)
        elif rule == "increment":
            return torch.cat([b, b + 1, b + 2], dim=1)
        elif rule == "double_step":
            return torch.cat([b, b + 2, b + 4], dim=1)
        elif rule == "reverse":
            return torch.cat([b + 2, b + 1, b], dim=1)
        elif rule == "fixed_shift":
            return torch.cat([b, b + 3, b + 6], dim=1)
        elif rule == "simple_composition":
            return torch.cat([b, b + 1, b + 3], dim=1)
        else:
            raise ValueError(f"Unknown rule: {rule}")


class FewShotTaskGenerator:
    """Generates prompt sequences containing k demonstrations followed by a query."""

    def __init__(self, vocab_size: int = 250):
        self.vocab_size = vocab_size

    def _make_rng(self, seed: int) -> torch.Generator:
        g = torch.Generator()
        g.manual_seed(seed)
        return g

    def sample_instances(
        self, rule: str, vocab_range: Tuple[int, int], count: int, seed: int
    ) -> torch.Tensor:
        """Samples count instances of a rule in the specified vocabulary range."""
        g = self._make_rng(seed)
        v_lo, v_hi = vocab_range
        # Ensure room for offsets (max offset is 6 for fixed_shift)
        max_base = max(v_lo + 1, v_hi - 8)
        bases = torch.randint(v_lo, max_base, (count, 1), generator=g)
        return FewShotRuleFamily.apply(bases, rule)

    def format_sequence(
        self,
        demos: Optional[torch.Tensor],
        query: torch.Tensor,
        order: str = "original",
        distractor: bool = False,
    ) -> torch.Tensor:
        """Combines demonstrations and query into a 1D token tensor.

        demos: (k, 3) or None
        query: (3,)
        order: 'original', 'reversed', 'permuted'
        distractor: if True, inserts a random distractor token before each demo
        """
        parts: List[torch.Tensor] = []
        if demos is not None and demos.shape[0] > 0:
            k = demos.shape[0]
            indices = list(range(k))
            if order == "reversed":
                indices = indices[::-1]
            elif order == "permuted":
                # Deterministic permutation for reproducibility
                indices = [(i * 3 + 1) % k for i in range(k)]

            for idx in indices:
                d = demos[idx]
                if distractor:
                    # Distractor token 2 (reserved marker)
                    parts.append(torch.tensor([2]))
                parts.append(d)
                parts.append(torch.tensor([SEP_TOKEN]))

        parts.append(query)
        return torch.cat(parts, dim=0)

    def build_batch(
        self,
        rule: str,
        vocab_range: Tuple[int, int],
        num_demos: int,
        batch_size: int,
        seed: int,
        demo_rule: Optional[str] = None,
        order: str = "original",
        distractor: bool = False,
        random_demos: bool = False,
    ) -> Dict[str, torch.Tensor]:
        """Builds a batch of few-shot sequences with identical structure."""
        g = self._make_rng(seed)
        v_lo, v_hi = vocab_range
        max_base = max(v_lo + 1, v_hi - 8)

        effective_demo_rule = demo_rule if demo_rule is not None else rule

        sequences: List[torch.Tensor] = []
        target_tokens: List[int] = []

        for b in range(batch_size):
            # Query instance
            q_base = torch.randint(v_lo, max_base, (1, 1), generator=g)
            q_inst = FewShotRuleFamily.apply(q_base, rule)[0]
            target_tokens.append(q_inst[2].item())

            if num_demos > 0:
                if random_demos:
                    # Random noise demonstrations (Control 1)
                    d_tokens = torch.randint(v_lo, v_hi, (num_demos, 3), generator=g)
                    demos = d_tokens
                else:
                    d_bases = torch.randint(v_lo, max_base, (num_demos, 1), generator=g)
                    demos = FewShotRuleFamily.apply(d_bases, effective_demo_rule)
            else:
                demos = None

            seq = self.format_sequence(demos, q_inst, order=order, distractor=distractor)
            sequences.append(seq)

        batch_tensor = torch.stack(sequences, dim=0)
        targets_tensor = torch.tensor(target_tokens, dtype=torch.long)

        return {
            "input_ids": batch_tensor,
            "target": targets_tensor,
        }

    def leakage_certificate(
        self, train_batch: torch.Tensor, eval_batch: torch.Tensor
    ) -> Dict[str, bool]:
        """Verifies vocabulary disjointness, row isolation, and n-gram separation."""
        train_tokens = set(train_batch.flatten().tolist()) - {PAD_TOKEN, SEP_TOKEN, 2}
        eval_tokens = set(eval_batch.flatten().tolist()) - {PAD_TOKEN, SEP_TOKEN, 2}

        train_rows = {tuple(r) for r in train_batch.tolist()}
        eval_rows = {tuple(r) for r in eval_batch.tolist()}

        vocab_disjoint = len(train_tokens & eval_tokens) == 0
        no_row_overlap = len(train_rows & eval_rows) == 0

        # Subsequence / 3-gram check
        train_subs = set()
        for row in train_rows:
            for i in range(len(row) - 2):
                train_subs.add(row[i : i + 3])
        sub_leak = False
        for row in eval_rows:
            for i in range(len(row) - 2):
                if row[i : i + 3] in train_subs:
                    sub_leak = True
                    break

        return {
            "vocab_disjoint": vocab_disjoint,
            "no_row_overlap": no_row_overlap,
            "no_subseq_leak": not sub_leak,
            "valid": vocab_disjoint and no_row_overlap and not sub_leak,
        }

    def hash_dataset(self, tensor: torch.Tensor) -> str:
        """Immutable SHA-256 hash of dataset tensor."""
        return hashlib.sha256(tensor.numpy().tobytes()).hexdigest()


def evaluate_few_shot_acc(
    model: NirmalForCausalLM, batch: Dict[str, torch.Tensor], device: torch.device
) -> float:
    """Evaluates top-1 accuracy on predicting the final query token q2 given all preceding tokens."""
    model.eval()
    input_ids = batch["input_ids"].to(device)
    target = batch["target"].to(device)

    with torch.no_grad():
        out = model(input_ids=input_ids)
        logits = out.logits
        # Logits at position -2 predict token at position -1 (which is q2)
        pred_token = torch.argmax(logits[:, -2, :], dim=-1)
        acc = (pred_token == target).float().mean().item()
    return acc
