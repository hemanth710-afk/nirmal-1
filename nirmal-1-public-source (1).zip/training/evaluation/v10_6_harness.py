"""V10.6 Symbol/Relation Decoupling Harness.

Implements dual-channel (identity + relation) representation with:
- PairwiseRelationEncoder: encodes sequential token differences as learned features
- RelativeProjectionEncoder: coordinate-style learned relational embedding
- PermutationAugmentor: random surface remapping while preserving rule structure
- PermutationConsistencyLoss: encourages relation-channel stability across isomorphic tasks
- ScaffoldRemovalEval: verifies ordinary-token-only inference path
"""

import hashlib
from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

from nirmal.configuration_nirmal import NirmalConfig
from nirmal.model import NirmalForCausalLM
from training.evaluation.v10_2_harness import CapacityBuilder, aggregate_results

# ── Rule families ───────────────────────────────────────────────────────────
TRAIN_RULES = ["copy", "increment", "fixed_shift", "simple_composition"]
HOLDOUT_RULES = ["double_step", "reverse"]
ALL_RULES = TRAIN_RULES + HOLDOUT_RULES

TRAIN_VOCAB   = (10,  110)
DISJOINT_OOD  = (130, 230)


def apply_rule(base: torch.Tensor, rule: str) -> torch.Tensor:
    """Apply a rule to a (B,1) base tensor -> (B,3) output."""
    if base.dim() == 1:
        base = base.unsqueeze(1)
    b = base[:, 0:1]
    if rule == "copy":             return torch.cat([b, b, b], 1)
    if rule == "increment":        return torch.cat([b, b+1, b+2], 1)
    if rule == "double_step":      return torch.cat([b, b+2, b+4], 1)
    if rule == "reverse":          return torch.cat([b+2, b+1, b], 1)
    if rule == "fixed_shift":      return torch.cat([b, b+3, b+6], 1)
    if rule == "simple_composition": return torch.cat([b, b+1, b+3], 1)
    raise ValueError(f"Unknown rule: {rule}")


# ── Permutation Augmentor ────────────────────────────────────────────────────
class PermutationAugmentor:
    """Randomly remaps surface token ids while preserving rule structure.

    Given an input sequence [t0, t1, t2] and a new random vocab range,
    returns a structurally isomorphic sequence over a different symbol set.
    """

    def __init__(self, rng_seed: int = 0):
        self._g = torch.Generator()
        self._g.manual_seed(rng_seed)

    def remap(
        self,
        seq: torch.Tensor,       # (B, T) original tokens in [v_lo, v_hi)
        new_v_lo: int,
        new_v_hi: int,
        rule: str,
        g: Optional[torch.Generator] = None,
    ) -> torch.Tensor:
        """Returns a structurally identical sequence in the new vocab range."""
        if g is None:
            g = self._g
        B = seq.size(0)
        max_base = max(new_v_lo + 1, new_v_hi - 8)
        new_bases = torch.randint(new_v_lo, max_base, (B, 1), generator=g)
        return apply_rule(new_bases, rule)


# ── Relation Encoders ────────────────────────────────────────────────────────
class PairwiseRelationEncoder(nn.Module):
    """Encodes sequential token differences into a learned relational embedding.

    At inference: only receives ordinary token ids.
    Internal differences are computed from input positions (no external labels).
    """

    def __init__(self, vocab_size: int, rel_dim: int, hidden_size: int):
        super().__init__()
        # Difference lives in [-vocab_size+1, vocab_size-1]; we shift to [0, 2*V-2]
        self.V = vocab_size
        self.rel_emb = nn.Embedding(2 * vocab_size, rel_dim)
        self.proj = nn.Linear(rel_dim, hidden_size)

    def forward(self, input_ids: torch.Tensor) -> torch.Tensor:
        """input_ids: (B, T) → (B, T, hidden_size) relational features."""
        B, T = input_ids.shape
        # Pad left with first token to keep shape (B, T)
        left = torch.cat([input_ids[:, :1], input_ids[:, :-1]], dim=1)
        diff = (input_ids - left + self.V).clamp(0, 2 * self.V - 2)  # (B,T)
        rel = self.rel_emb(diff)      # (B, T, rel_dim)
        return self.proj(rel)         # (B, T, hidden_size)


class RelativeProjectionEncoder(nn.Module):
    """Coordinate-style: maps token id rank (position within its local batch range)
    to a learned relational vector. Rank is computed at runtime without external labels.
    """

    def __init__(self, vocab_size: int, rel_dim: int, hidden_size: int):
        super().__init__()
        self.V = vocab_size
        # Token id -> learned coord-style embedding
        self.coord_emb = nn.Embedding(vocab_size, rel_dim)
        self.proj = nn.Linear(rel_dim, hidden_size)

    def forward(self, input_ids: torch.Tensor) -> torch.Tensor:
        coord = self.coord_emb(input_ids)   # (B, T, rel_dim)
        return self.proj(coord)             # (B, T, hidden_size)


class RandomRelationEncoder(nn.Module):
    """Control: frozen random projection (should NOT help). """

    def __init__(self, vocab_size: int, rel_dim: int, hidden_size: int):
        super().__init__()
        self.rel_emb = nn.Embedding(vocab_size, rel_dim)
        # Freeze weights
        for p in self.rel_emb.parameters():
            p.requires_grad_(False)
        self.proj = nn.Linear(rel_dim, hidden_size)

    def forward(self, input_ids: torch.Tensor) -> torch.Tensor:
        with torch.no_grad():
            r = self.rel_emb(input_ids)
        return self.proj(r)


# ── Dual-Channel Model Wrapper ────────────────────────────────────────────────
class DualChannelWrapper(nn.Module):
    """Wraps a NirmalForCausalLM with an optional learned relation encoder.

    At inference ordinary tokens are passed in; the relation encoder computes
    its features purely from input_ids (no auxiliary label required).
    """

    def __init__(
        self,
        base_model: NirmalForCausalLM,
        relation_encoder: Optional[nn.Module] = None,
        use_relation: bool = True,
    ):
        super().__init__()
        self.base = base_model
        self.relation_encoder = relation_encoder
        self.use_relation = use_relation and (relation_encoder is not None)

    @property
    def parameters_list(self):
        params = list(self.base.parameters())
        if self.relation_encoder is not None:
            params += list(self.relation_encoder.parameters())
        return params

    def get_hidden(self, input_ids: torch.Tensor) -> torch.Tensor:
        """Extract hidden states for diagnostic probing."""
        hidden = self.base.model(input_ids=input_ids)[0]
        if self.use_relation and self.relation_encoder is not None:
            rel = self.relation_encoder(input_ids)
            hidden = hidden + rel
        return hidden

    def forward(self, input_ids: torch.Tensor, labels: Optional[torch.Tensor] = None):
        """Standard forward. The relation encoder augments the base logits."""
        out = self.base(input_ids=input_ids, labels=labels)
        if self.use_relation and self.relation_encoder is not None:
            rel = self.relation_encoder(input_ids)          # (B, T, H)
            # Additive residual into logits via the lm_head projection
            extra_logits = self.base.lm_head(rel)           # (B, T, V)
            if hasattr(out, 'logits') and out.logits is not None:
                new_logits = out.logits + extra_logits
                # Recompute loss if labels provided
                if labels is not None:
                    shift_logits = new_logits[..., :-1, :].contiguous()
                    shift_labels = labels[..., 1:].contiguous()
                    new_loss = F.cross_entropy(
                        shift_logits.view(-1, shift_logits.size(-1)),
                        shift_labels.view(-1),
                    )
                    # Reconstruct output as a simple namespace
                    return type(out)(loss=new_loss, logits=new_logits)
        return out


# ── Permutation Consistency Loss ─────────────────────────────────────────────
def permutation_consistency_loss(
    model: DualChannelWrapper,
    seq_a: torch.Tensor,
    seq_b: torch.Tensor,
) -> torch.Tensor:
    """MSE on mean-pooled relation representations of two isomorphic sequences.

    Encourages the relation channel to be stable across surface remappings.
    Operates only on the relation encoder's output (NOT the base model weights).
    """
    if model.relation_encoder is None:
        return torch.tensor(0.0, requires_grad=False)

    rel_a = model.relation_encoder(seq_a).mean(dim=1)  # (B, H)
    rel_b = model.relation_encoder(seq_b).mean(dim=1)  # (B, H)
    return F.mse_loss(rel_a, rel_b.detach())


# ── Relation Invariance Diagnostic ────────────────────────────────────────────
@torch.no_grad()
def relation_invariance_score(
    model: DualChannelWrapper,
    same_rule_pairs: List[Tuple[torch.Tensor, torch.Tensor]],
    diff_rule_pairs: List[Tuple[torch.Tensor, torch.Tensor]],
) -> Dict[str, float]:
    """Measures whether relation channel is more similar within rule than across rules.

    Returns: {"d_same": float, "d_diff": float, "invariance_gap": float}
    """
    model.eval()
    same_dists, diff_dists = [], []
    for (a, b) in same_rule_pairs:
        if model.relation_encoder is not None:
            ra = model.relation_encoder(a).mean(dim=1)
            rb = model.relation_encoder(b).mean(dim=1)
        else:
            ra = model.get_hidden(a).mean(dim=1)
            rb = model.get_hidden(b).mean(dim=1)
        same_dists.append(F.pairwise_distance(ra, rb).mean().item())
    for (a, b) in diff_rule_pairs:
        if model.relation_encoder is not None:
            ra = model.relation_encoder(a).mean(dim=1)
            rb = model.relation_encoder(b).mean(dim=1)
        else:
            ra = model.get_hidden(a).mean(dim=1)
            rb = model.get_hidden(b).mean(dim=1)
        diff_dists.append(F.pairwise_distance(ra, rb).mean().item())
    d_s = float(np.mean(same_dists)) if same_dists else 0.0
    d_d = float(np.mean(diff_dists)) if diff_dists else 0.0
    return {"d_same": d_s, "d_diff": d_d, "invariance_gap": d_d - d_s}


# ── Scaffold-Off Evaluator ────────────────────────────────────────────────────
@torch.no_grad()
def scaffold_off_acc(
    model: DualChannelWrapper,
    input_ids: torch.Tensor,
    labels: torch.Tensor,
    device: torch.device,
) -> float:
    """Evaluates accuracy using ONLY ordinary token inputs (no auxiliary signals)."""
    model.eval()
    x = input_ids.to(device)
    y = labels.to(device)
    out = model(input_ids=x)
    logits = out.logits
    preds = torch.argmax(logits[:, :-1, :], dim=-1)
    target = y[:, 1:]
    return (preds == target).all(dim=1).float().mean().item()


# ── Dataset builder ────────────────────────────────────────────────────────────
class V10_6_DataBuilder:
    """Deterministic batch generation for V10.6 ablations."""

    def __init__(self, vocab_size: int = 250):
        self.V = vocab_size

    def _rng(self, seed: int) -> torch.Generator:
        g = torch.Generator()
        g.manual_seed(seed)
        return g

    def make_batch(
        self,
        rule: str,
        vocab_range: Tuple[int, int],
        batch_size: int,
        seed: int,
    ) -> torch.Tensor:
        g = self._rng(seed)
        v_lo, v_hi = vocab_range
        max_base = max(v_lo + 1, v_hi - 8)
        bases = torch.randint(v_lo, max_base, (batch_size, 1), generator=g)
        return apply_rule(bases, rule)

    def leakage_certificate(
        self,
        train: torch.Tensor,
        ood: torch.Tensor,
    ) -> Dict[str, bool]:
        train_tok = set(train.flatten().tolist())
        ood_tok   = set(ood.flatten().tolist())
        train_rows = {tuple(r) for r in train.tolist()}
        ood_rows   = {tuple(r) for r in ood.tolist()}
        vocab_disjoint  = len(train_tok & ood_tok) == 0
        no_row_overlap  = len(train_rows & ood_rows) == 0
        # 3-gram check
        train_3g = set()
        for row in train_rows:
            for i in range(len(row) - 2):
                train_3g.add(row[i: i+3])
        sub_leak = any(
            row[i: i+3] in train_3g
            for row in ood_rows
            for i in range(len(row) - 2)
        )
        return {
            "vocab_disjoint":  vocab_disjoint,
            "no_row_overlap":  no_row_overlap,
            "no_subseq_leak":  not sub_leak,
            "valid":           vocab_disjoint and no_row_overlap and not sub_leak,
        }

    def hash_dataset(self, t: torch.Tensor) -> str:
        return hashlib.sha256(t.numpy().tobytes()).hexdigest()


# ── Model factory ──────────────────────────────────────────────────────────────
def build_ablation_model(
    ablation: str,
    vocab_size: int = 250,
    level: str = "L0",
    rel_dim: int = 16,
) -> DualChannelWrapper:
    """Builds the correct model configuration for each ablation label."""
    base = CapacityBuilder.build(level, vocab=vocab_size)
    h = base.config.hidden_size

    if ablation == "A0":
        # Identity only baseline
        return DualChannelWrapper(base, relation_encoder=None, use_relation=False)
    elif ablation == "A1":
        # Identity + pairwise learned relation
        enc = PairwiseRelationEncoder(vocab_size, rel_dim, h)
        return DualChannelWrapper(base, enc, use_relation=True)
    elif ablation == "A2":
        # Identity + random (frozen) relation (control)
        enc = RandomRelationEncoder(vocab_size, rel_dim, h)
        return DualChannelWrapper(base, enc, use_relation=True)
    elif ablation in ("A3", "A4", "A5", "A6"):
        # All include pairwise learned relation encoder
        enc = PairwiseRelationEncoder(vocab_size, rel_dim, h)
        return DualChannelWrapper(base, enc, use_relation=True)
    else:
        raise ValueError(f"Unknown ablation: {ablation}")
