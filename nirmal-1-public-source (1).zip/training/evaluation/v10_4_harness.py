"""V10.4 Inductive Bias Harness."""
import torch
import torch.nn as nn
import torch.nn.functional as F
from dataclasses import dataclass
from typing import Dict, List, Tuple
from training.evaluation.v10_2_harness import CapacityBuilder

class ContinuousRelationWrapper(nn.Module):
    """Experiment B: Adds a learned continuous transition mechanism."""
    def __init__(self, base_model, hidden_size=32):
        super().__init__()
        self.base = base_model
        # Simple transition mechanism: a small MLP to model continuous shifts
        self.transition = nn.Sequential(
            nn.Linear(hidden_size, hidden_size),
            nn.GELU(),
            nn.Linear(hidden_size, hidden_size)
        )
        
    def forward(self, input_ids, labels=None):
        out = self.base(input_ids=input_ids, labels=labels)
        return out
        
    def get_hidden(self, input_ids):
        return self.base.model(input_ids=input_ids)[0]
        
    def forward_with_transition(self, input_ids):
        # We apply the transition to the embeddings manually
        embeds = self.base.model.embed_tokens(input_ids)
        shifted = embeds + self.transition(embeds)
        # Pass through layers (mock approach for experimental bias)
        x = shifted
        for layer in self.base.model.layers:
            x = layer(x)[0]
        x = self.base.model.norm(x)
        logits = self.base.lm_head(x)
        return logits

class WeightBindingWrapper(nn.Module):
    """Experiment C: Weight-binding / hypernetwork mechanism."""
    def __init__(self, base_model, hidden_size=32):
        super().__init__()
        self.base = base_model
        self.rule_extractor = nn.Linear(hidden_size, hidden_size)
        # Hypernetwork generating a hidden_size x hidden_size weight matrix
        self.hyper = nn.Linear(hidden_size, hidden_size * hidden_size)
        self.hidden_size = hidden_size
        
    def forward(self, input_ids, labels=None):
        return self.base(input_ids=input_ids, labels=labels)

    def get_hidden(self, input_ids):
        return self.base.model(input_ids=input_ids)[0]
        
    def forward_bound(self, input_ids):
        out = self.base.model(input_ids=input_ids)[0]
        # Pool to extract 'rule' context
        ctx = out.mean(dim=1)
        # Generate weights
        W = self.hyper(self.rule_extractor(ctx)).view(-1, self.hidden_size, self.hidden_size)
        # Apply bound weights W to out
        # out: [B, T, H], W: [B, H, H]
        bound_out = torch.bmm(out, W)
        logits = self.base.lm_head(bound_out)
        return logits

class RecurrentWrapper(nn.Module):
    """Experiment D: Recurrent state-transition path."""
    def __init__(self, base_model, hidden_size=32):
        super().__init__()
        self.base = base_model
        self.rnn = nn.GRU(hidden_size, hidden_size, batch_first=True)
        
    def forward(self, input_ids, labels=None):
        return self.base(input_ids=input_ids, labels=labels)

    def get_hidden(self, input_ids):
        return self.base.model(input_ids=input_ids)[0]
        
    def forward_recurrent(self, input_ids):
        out = self.base.model(input_ids=input_ids)[0]
        # Apply recurrence over the sequence
        rnn_out, _ = self.rnn(out)
        logits = self.base.lm_head(rnn_out)
        return logits

class LatentRuleSupervisor(nn.Module):
    """Experiment E: Latent rule discovery probe."""
    def __init__(self, base_model, hidden_size=32, num_rules=2):
        super().__init__()
        self.base = base_model
        self.rule_head = nn.Linear(hidden_size, num_rules)
        
    def forward(self, input_ids, labels=None):
        return self.base(input_ids=input_ids, labels=labels)

    def get_hidden(self, input_ids):
        return self.base.model(input_ids=input_ids)[0]
        
    def supervise(self, input_ids, rule_labels):
        out = self.base.model(input_ids=input_ids)[0]
        # Predict rule from pooled state
        ctx = out.mean(dim=1)
        rule_logits = self.rule_head(ctx)
        loss = F.cross_entropy(rule_logits, rule_labels)
        return loss

def isomorphic_representation_probe(model, x_a, x_b, x_c):
    """Experiment F: Distance diagnostic. A & B are isomorphic. C is different."""
    model.eval()
    with torch.no_grad():
        out_a = model.get_hidden(x_a).mean(dim=1)
        out_b = model.get_hidden(x_b).mean(dim=1)
        out_c = model.get_hidden(x_c).mean(dim=1)
        
        d_ab = F.pairwise_distance(out_a, out_b).mean().item()
        d_ac = F.pairwise_distance(out_a, out_c).mean().item()
        
    return d_ab < d_ac, d_ab, d_ac

def check_ordinary_inference(model, input_ids, labels=None):
    """Decorator or check ensuring NO scaffold at inference."""
    with torch.no_grad():
        if isinstance(model, ContinuousRelationWrapper):
            logits = model.forward_with_transition(input_ids)
        elif isinstance(model, WeightBindingWrapper):
            logits = model.forward_bound(input_ids)
        elif isinstance(model, RecurrentWrapper):
            logits = model.forward_recurrent(input_ids)
        else:
            # Baseline or Latent (Scaffold-off means just standard base forward)
            logits = model.base(input_ids=input_ids).logits
            
        if labels is not None:
            shift_logits = logits[..., :-1, :].contiguous()
            shift_labels = labels[..., 1:].contiguous()
            loss = F.cross_entropy(shift_logits.view(-1, shift_logits.size(-1)), shift_labels.view(-1))
            preds = torch.argmax(shift_logits, dim=-1)
            correct = (preds == shift_labels).all(dim=-1).float().mean().item()
            return correct, loss.item()
        return logits
