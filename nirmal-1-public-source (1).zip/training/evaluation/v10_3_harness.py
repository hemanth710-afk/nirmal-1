"""V10.3 Algorithmic Representation Discovery Harness."""

import hashlib
import json
import torch
import torch.nn.functional as F
from dataclasses import dataclass
from typing import Dict, List, Tuple, Any
import numpy as np

# Inherit baseline features from v10.2
from training.evaluation.v10_2_harness import (
    TaskConfig, TaskGenerator, CapacityBuilder, acc
)

@dataclass
class IsomorphicPair:
    surface_a: torch.Tensor
    surface_b: torch.Tensor
    rule: str
    
class V10_3_TaskGenerator(TaskGenerator):
    def generate_diversity(self, rule: str, num_surfaces: int, seq_len: int, batch_size: int, seed: int) -> Dict[str, torch.Tensor]:
        """Generates multiple non-overlapping surface domains for the same rule."""
        rng = torch.Generator().manual_seed(seed)
        surfaces = []
        
        # We will map each surface to a distinct vocabulary block of size 15
        # Total vocab is e.g. 150. Max surfaces = 8
        for i in range(num_surfaces):
            lo = i * 15
            hi = lo + 10
            base = torch.randint(lo, hi, (batch_size, seq_len), generator=rng)
            surfaces.append(self._apply_rule(base, rule))
            
        return {"train_surfaces": surfaces}
    
    def generate_contrastive_pairs(self, batch_size: int, seq_len: int, seed: int) -> Dict[str, torch.Tensor]:
        """
        Positive pair: same rule ('increment'), different surface.
        Negative pair: different rule ('increment' vs 'double_step'), same surface.
        """
        rng = torch.Generator().manual_seed(seed)
        
        # Surface 1
        lo1, hi1 = 10, 20
        base1 = torch.randint(lo1, hi1, (batch_size, seq_len), generator=rng)
        
        # Surface 2
        lo2, hi2 = 40, 50
        base2 = torch.randint(lo2, hi2, (batch_size, seq_len), generator=rng)
        
        # Positive pair (Isomorphic)
        pos_a = self._apply_rule(base1, "increment")
        pos_b = self._apply_rule(base2, "increment")
        
        # Negative pair (Same surface, different rule)
        neg_a = self._apply_rule(base1, "increment")
        neg_b = self._apply_rule(base1, "double_step")
        
        return {
            "pos_a": pos_a, "pos_b": pos_b,
            "neg_a": neg_a, "neg_b": neg_b
        }

    def generate_curriculum(self, batch_size: int, seed: int) -> List[torch.Tensor]:
        rng = torch.Generator().manual_seed(seed)
        base = torch.randint(10, 20, (batch_size, 3), generator=rng)
        
        return [
            self._apply_rule(base, "copy"),
            self._apply_rule(base, "increment"), # acts as single step here
            self._apply_rule(base, "double_step")
        ]
        

def relational_consistency_loss(model, x_a: torch.Tensor, x_b: torch.Tensor) -> torch.Tensor:
    """MSE between the latent states of isomorphic pairs."""
    # We extract the last hidden state before the LM head
    out_a = model.model(input_ids=x_a)[0]
    out_b = model.model(input_ids=x_b)[0]
    
    return F.mse_loss(out_a, out_b)

def contrastive_isomorphic_loss(model, pos_a, pos_b, neg_a, neg_b, margin=1.0) -> torch.Tensor:
    """Pull pos_a and pos_b together; push neg_a and neg_b apart."""
    out_pa = model.model(input_ids=pos_a)[0]
    out_pb = model.model(input_ids=pos_b)[0]
    
    out_na = model.model(input_ids=neg_a)[0]
    out_nb = model.model(input_ids=neg_b)[0]
    
    # Distance
    d_pos = F.pairwise_distance(out_pa.view(out_pa.shape[0], -1), out_pb.view(out_pb.shape[0], -1))
    d_neg = F.pairwise_distance(out_na.view(out_na.shape[0], -1), out_nb.view(out_nb.shape[0], -1))
    
    loss_pos = d_pos.pow(2).mean()
    loss_neg = F.relu(margin - d_neg).pow(2).mean()
    
    return loss_pos + loss_neg

def check_scaffold_off(func):
    """Decorator or check to ensure ordinary tokens only during inference."""
    def wrapper(model, data, *args, **kwargs):
        # Scaffold Off: NO auxiliary loss, NO numerical manipulation.
        return acc(model, data)
    return wrapper
