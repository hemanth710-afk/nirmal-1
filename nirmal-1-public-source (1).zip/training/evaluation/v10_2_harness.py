"""
V10.2 Capacity-Scale Systematic Generalization Evaluation Harness.
Provides reusable components for machine-certified OOD evaluation.
"""

import hashlib
import json
import time
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Any

import numpy as np
import torch
import torch.nn.functional as F

from nirmal.configuration_nirmal import NirmalConfig
from nirmal.model import NirmalForCausalLM
import psutil

# 1. Deterministic Task Generation
@dataclass
class TaskConfig:
    rule: str
    seq_len: int
    train_vocab: Tuple[int, int]
    val_vocab: Tuple[int, int]
    ood_vocab: Tuple[int, int]
    batch_size: int
    seed: int


class TaskGenerator:
    def _make_rng(self, seed: int) -> torch.Generator:
        g = torch.Generator()
        g.manual_seed(seed)
        return g

    def _apply_rule(self, base: torch.Tensor, rule: str) -> torch.Tensor:
        if rule == "copy":
            return torch.cat([base, base], dim=1)
        elif rule == "increment":
            start = base[:, :1]
            offsets = torch.arange(base.shape[1]).unsqueeze(0).expand(base.shape[0], -1)
            return start + offsets
        elif rule == "double_step":
            start = base[:, :1]
            offsets = (torch.arange(base.shape[1]) * 2).unsqueeze(0).expand(base.shape[0], -1)
            return start + offsets
        elif rule == "reverse":
            return torch.flip(base, dims=[1])
        else:
            raise ValueError(f"Unknown rule: {rule}")

    def generate(self, cfg: TaskConfig) -> Dict[str, torch.Tensor]:
        g_train = self._make_rng(cfg.seed)
        g_val   = self._make_rng(cfg.seed + 1000)
        g_ood   = self._make_rng(cfg.seed + 2000)

        tlo, thi = cfg.train_vocab
        vlo, vhi = cfg.val_vocab
        olo, ohi = cfg.ood_vocab
        half = cfg.seq_len

        safe_thi = thi - half * 3
        safe_vhi = vhi - half * 3
        safe_ohi = ohi - half * 3

        train_base = torch.randint(tlo, max(tlo + 1, safe_thi), (cfg.batch_size, half), generator=g_train)
        val_base   = torch.randint(vlo, max(vlo + 1, safe_vhi), (cfg.batch_size, half), generator=g_val)
        ood_base   = torch.randint(olo, max(olo + 1, safe_ohi), (cfg.batch_size, half), generator=g_ood)

        # 2. Deterministic Partitions
        return {
            "train": self._apply_rule(train_base, cfg.rule),
            "val":   self._apply_rule(val_base,   cfg.rule),
            "ood":   self._apply_rule(ood_base,   cfg.rule),
        }

    # 3-5. Leakage Detection (Vocabulary, Exact Match, Subsequence)
    def leakage_certificate(self, splits: Dict[str, torch.Tensor]) -> Dict[str, bool]:
        train_tokens = set(splits["train"].flatten().tolist())
        ood_tokens   = set(splits["ood"].flatten().tolist())
        train_rows   = {tuple(r) for r in splits["train"].tolist()}
        ood_rows     = {tuple(r) for r in splits["ood"].tolist()}

        vocab_disjoint = len(train_tokens & ood_tokens) == 0
        no_row_overlap = len(train_rows & ood_rows) == 0

        train_subs = set()
        for row in train_rows:
            for i in range(len(row) - 2):
                train_subs.add(row[i:i+3])
        sub_leak = False
        for row in ood_rows:
            for i in range(len(row) - 2):
                if row[i:i+3] in train_subs:
                    sub_leak = True
                    break

        return {
            "vocab_disjoint": vocab_disjoint,
            "no_row_overlap": no_row_overlap,
            "no_subseq_leak": not sub_leak,
            "valid": vocab_disjoint and no_row_overlap and not sub_leak,
        }

    # 14. Immutable Eval Set Hashes
    def hash_dataset(self, tensor: torch.Tensor) -> str:
        return hashlib.sha256(tensor.numpy().tobytes()).hexdigest()


# 6. Isomorphic Task Construction
# Built-in via rule application with disjoint vocab ranges (e.g. rule="increment" on different domains)

# 7. Positional Perturbation
def apply_repr(x: torch.Tensor, mode: str, lo: int = 0, vocab: int = 100) -> torch.Tensor:
    if mode == "value_relative":
        return (x - lo).clamp(0, vocab - 1)
    if mode == "modular":
        return x % vocab
    if mode == "reversed":
        return torch.flip(x, dims=[1])
    return x  # identity


# 8. Checkpoint Evaluation
def acc(model: NirmalForCausalLM, data: torch.Tensor) -> float:
    model.eval()
    with torch.no_grad():
        out = model(input_ids=data, labels=data)
        p = torch.argmax(out.logits, dim=-1)
        return (p[:, :-1] == data[:, 1:]).float().mean().item()


# 9-11. Multi-seed Aggregation & CI
def aggregate_results(results: List[float]) -> Dict[str, float]:
    mean = float(np.mean(results))
    std = float(np.std(results))
    # 95% CI roughly 1.96 * std / sqrt(n)
    ci = 1.96 * std / np.sqrt(len(results)) if len(results) > 0 else 0.0
    return {
        "mean": round(mean, 4),
        "std": round(std, 4),
        "ci95": round(ci, 4),
        "min": round(float(np.min(results)), 4),
        "max": round(float(np.max(results)), 4),
    }

# 12-13. Reproducibility Metadata & Machine Readable Manifests
def save_manifest(path: Path, data: Dict[str, Any]):
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w") as f:
        json.dump(data, f, indent=2)


class CapacityBuilder:
    @staticmethod
    def build(level: str, vocab: int = 100) -> NirmalForCausalLM:
        cfgs = {
            "L0": (32, 2),    # ~0.08M
            "L1": (64, 2),    # ~0.16M
            "L2": (64, 4),    # ~0.33M
            "L3": (128, 4),   # ~1.0M
            "L4": (256, 6),   # ~5.1M
        }
        h, l = cfgs[level]
        cfg = NirmalConfig(
            vocab_size=vocab, hidden_size=h,
            num_hidden_layers=l, num_attention_heads=2,
            head_dim=h // 2, num_key_value_heads=1,
            num_experts=2, num_experts_per_tok=1, full_attention_interval=2,
            intermediate_size=None,
        )
        return NirmalForCausalLM(cfg)

    @staticmethod
    def count_params(model: NirmalForCausalLM) -> int:
        return sum(p.numel() for p in model.parameters())

class ResourceGuard:
    @staticmethod
    def check(est_ram_mb: int, est_time_s: int) -> bool:
        free = psutil.virtual_memory().available / (1024 ** 2)
        return free >= 200 and est_ram_mb <= 3000 and est_time_s <= 300
