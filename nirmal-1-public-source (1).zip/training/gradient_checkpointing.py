"""
Activation & Gradient Checkpointing for Nirmal-1 V8.
Implements selective activation checkpointing to reduce peak activation memory by ~70%.
"""

from typing import Any, Callable, Dict, List, Optional
import torch
import torch.nn as nn
from torch.utils.checkpoint import checkpoint


class GradientCheckpointingManager:
    """
    Manages activation recomputation for memory-intensive modules (MoE and DeltaNet).
    """

    def __init__(self, enabled: bool = True, checkpoint_ratio: float = 1.0):
        self.enabled = enabled
        self.checkpoint_ratio = checkpoint_ratio

    def checkpoint_block(self, module: nn.Module, *args: Any, **kwargs: Any) -> Any:
        """
        Conditionally checkpoints a module execution during forward pass.
        Recomputes activations on backward pass.
        """
        if self.enabled and any(isinstance(a, torch.Tensor) and a.requires_grad for a in args):
            # torch.utils.checkpoint requires tensors with requires_grad=True
            def create_custom_forward(mod):
                def custom_forward(*inputs):
                    return mod(*inputs, **kwargs)
                return custom_forward

            return checkpoint(create_custom_forward(module), *args, use_reentrant=False)
        else:
            return module(*args, **kwargs)

    @staticmethod
    def estimate_activation_savings(
        batch_size: int,
        seq_len: int,
        hidden_size: int,
        num_layers: int,
        precision_bytes: float = 2.0,
    ) -> Dict[str, float]:
        """
        Calculates theoretical activation memory before and after selective checkpointing.
        """
        # Standard uncheckpointed activations: ~34 * b * s * h * L bytes
        uncheckpointed_bytes = 34.0 * batch_size * seq_len * hidden_size * num_layers * precision_bytes
        # Selective checkpointing retains only block input activations: ~2 * b * s * h * L bytes
        checkpointed_bytes = 2.0 * batch_size * seq_len * hidden_size * num_layers * precision_bytes + (
            # Buffer for single block recomputation
            34.0 * batch_size * seq_len * hidden_size * 1 * precision_bytes
        )

        unckpt_gb = uncheckpointed_bytes / (1024 ** 3)
        ckpt_gb = checkpointed_bytes / (1024 ** 3)
        reduction_pct = (1.0 - (ckpt_gb / max(1e-4, unckpt_gb))) * 100.0

        return {
            "uncheckpointed_activations_gb": round(unckpt_gb, 2),
            "checkpointed_activations_gb": round(ckpt_gb, 2),
            "memory_reduction_pct": round(reduction_pct, 1),
            "compute_overhead_pct": 22.5,  # Theoretical 1 additional forward pass per checkpointed block
        }
