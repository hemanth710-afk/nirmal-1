"""
Atomic Checkpoint Manager & Interruption Recovery for Nirmal-1 V8.
Guarantees:
1. Atomic file writes (write-to-tmp then atomic directory replace) to prevent corruption.
2. Full state persistence: Model, Optimizer, Scheduler, Step, Telemetry, and RNG states.
3. Checkpoint verification and state hash validation.
4. Seamless recovery from simulated interruptions.
"""

from dataclasses import dataclass, asdict
import hashlib
import json
import os
from pathlib import Path
import random
import shutil
import tempfile
from typing import Any, Dict, List, Optional, Tuple, Union
import numpy as np
import torch
import torch.nn as nn


@dataclass
class CheckpointMetadata:
    step: int
    total_tokens: int
    train_loss: float
    val_loss: float
    val_perplexity: float
    learning_rate: float
    model_name: str
    model_state_hash: str
    timestamp: str

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


class AtomicCheckpointManager:
    """
    Manages fault-tolerant atomic checkpoint saving and resumption.
    """

    def __init__(self, checkpoint_dir: Union[str, Path]):
        self.checkpoint_dir = Path(checkpoint_dir)
        self.checkpoint_dir.mkdir(parents=True, exist_ok=True)

    @staticmethod
    def _compute_tensor_hash(state_dict: Dict[str, torch.Tensor]) -> str:
        """Compute SHA-256 fingerprint across model weights for integrity verification."""
        hasher = hashlib.sha256()
        for k in sorted(state_dict.keys()):
            hasher.update(k.encode("utf-8"))
            t = state_dict[k].cpu()
            hasher.update(t.numpy().tobytes()[:2048])  # Sample first 2KB per tensor for speed
        return hasher.hexdigest()

    def save_checkpoint(
        self,
        step: int,
        model: nn.Module,
        optimizer: Optional[torch.optim.Optimizer] = None,
        scheduler: Optional[Any] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Path:
        """
        Atomically saves complete training state to checkpoint_dir / f"checkpoint_{step}".
        """
        target_dir = self.checkpoint_dir / f"checkpoint_{step}"
        tmp_dir = self.checkpoint_dir / f".tmp_checkpoint_{step}_{os.getpid()}"
        if tmp_dir.exists():
            shutil.rmtree(tmp_dir)
        tmp_dir.mkdir(parents=True, exist_ok=True)

        try:
            # 1. Save Model Weights
            model_state = model.state_dict()
            model_hash = self._compute_tensor_hash(model_state)
            torch.save(model_state, tmp_dir / "model.pt")

            # 2. Save Optimizer State
            if optimizer is not None:
                torch.save(optimizer.state_dict(), tmp_dir / "optimizer.pt")

            # 3. Save Scheduler State
            if scheduler is not None:
                sched_state = scheduler.state_dict() if hasattr(scheduler, "state_dict") else {}
                torch.save(sched_state, tmp_dir / "scheduler.pt")

            # 4. Save RNG States
            rng_states = {
                "python": random.getstate(),
                "numpy": np.random.get_state(),
                "torch_cpu": torch.get_rng_state(),
                "torch_cuda": torch.cuda.get_rng_state_all() if torch.cuda.is_available() else None,
            }
            torch.save(rng_states, tmp_dir / "rng_state.pt")

            # 5. Save Metadata
            meta = metadata or {}
            meta.update({
                "step": step,
                "model_state_hash": model_hash,
            })
            with open(tmp_dir / "metadata.json", "w", encoding="utf-8") as f:
                json.dump(meta, f, indent=2)

            # Atomic directory replace
            if target_dir.exists():
                shutil.rmtree(target_dir)
            tmp_dir.rename(target_dir)

            return target_dir
        except Exception as e:
            if tmp_dir.exists():
                shutil.rmtree(tmp_dir)
            raise e

    def load_checkpoint(
        self,
        checkpoint_path: Union[str, Path],
        model: nn.Module,
        optimizer: Optional[torch.optim.Optimizer] = None,
        scheduler: Optional[Any] = None,
        restore_rng: bool = True,
    ) -> Dict[str, Any]:
        """
        Loads training state from checkpoint_path and verifies weight hash integrity.
        """
        ckpt_dir = Path(checkpoint_path)
        if not ckpt_dir.exists():
            raise FileNotFoundError(f"Checkpoint directory {ckpt_dir} does not exist!")

        # 1. Load Metadata
        meta_file = ckpt_dir / "metadata.json"
        if not meta_file.exists():
            raise FileNotFoundError(f"Corrupt checkpoint: metadata.json missing in {ckpt_dir}")
        with open(meta_file, "r", encoding="utf-8") as f:
            metadata = json.load(f)

        # 2. Load and verify Model State
        model_file = ckpt_dir / "model.pt"
        if not model_file.exists():
            raise FileNotFoundError(f"Corrupt checkpoint: model.pt missing in {ckpt_dir}")
        loaded_state = torch.load(model_file, map_location="cpu", weights_only=True)
        loaded_hash = self._compute_tensor_hash(loaded_state)

        expected_hash = metadata.get("model_state_hash")
        if expected_hash and loaded_hash != expected_hash:
            raise ValueError(f"Checkpoint hash mismatch! Expected {expected_hash}, got {loaded_hash}")

        model.load_state_dict(loaded_state)

        # 3. Load Optimizer State
        optim_file = ckpt_dir / "optimizer.pt"
        if optimizer is not None and optim_file.exists():
            optim_state = torch.load(optim_file, map_location="cpu", weights_only=False)
            optimizer.load_state_dict(optim_state)

        # 4. Load Scheduler State
        sched_file = ckpt_dir / "scheduler.pt"
        if scheduler is not None and sched_file.exists():
            sched_state = torch.load(sched_file, map_location="cpu", weights_only=False)
            if hasattr(scheduler, "load_state_dict"):
                scheduler.load_state_dict(sched_state)

        # 5. Restore RNG States
        rng_file = ckpt_dir / "rng_state.pt"
        if restore_rng and rng_file.exists():
            rng_states = torch.load(rng_file, weights_only=False)
            random.setstate(rng_states["python"])
            np.random.set_state(rng_states["numpy"])
            torch.set_rng_state(rng_states["torch_cpu"])
            if torch.cuda.is_available() and rng_states.get("torch_cuda") is not None:
                torch.cuda.set_rng_state_all(rng_states["torch_cuda"])

        return metadata

    def get_latest_checkpoint(self) -> Optional[Path]:
        """Returns the most recent checkpoint path by step number."""
        ckpts = [p for p in self.checkpoint_dir.iterdir() if p.is_dir() and p.name.startswith("checkpoint_")]
        if not ckpts:
            return None

        def extract_step(path: Path) -> int:
            try:
                return int(path.name.split("_")[-1])
            except (ValueError, IndexError):
                return -1

        sorted_ckpts = sorted(ckpts, key=extract_step)
        return sorted_ckpts[-1] if sorted_ckpts else None
