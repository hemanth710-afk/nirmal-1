"""
Production Streaming Ingestion & Preprocessing Engine for Nirmal-1 V8.4.

Features:
- Streaming ingestion supporting chunked, multi-source ingestion without memory bloat.
- Resumable download/ingestion checkpoints with line & byte offsets.
- Multi-format streaming decompression (gzip, plain text, chunked streams).
- Deterministic preprocessing (Unicode NFC, CRLF, control char stripping, repetition limits).
- Telemetry tracking: documents ingested, rejected, tokens before/after, removal reasons.
"""

from dataclasses import dataclass, field, asdict
from enum import Enum
import gzip
import hashlib
import json
import os
from pathlib import Path
import re
import tarfile
import time
from typing import Any, Dict, Generator, Iterable, Iterator, List, Optional, Tuple, Union
import unicodedata
import zipfile

REPO_ROOT = Path(__file__).resolve().parent.parent

from training.v8_2_data_engine import ProductionDocument
from training.v8_4_manifest import SourceProvenanceRecord, LicenseProvenanceViolationError
from training.v8_4_code_safety import CodeSafetyScanner, CodeSafetyConfig, ScannerAction
from training.v8_4_decontamination import NgramDecontaminationEngine, ContaminationSplit


class SourceType(str, Enum):
    LOCAL_FILE = "local_file"
    LOCAL_DIR = "local_dir"
    REMOTE_URL = "remote_url"
    ARCHIVE = "archive"
    STREAM = "stream"


class CorruptRecordPolicy(str, Enum):
    ISOLATE_AND_LOG = "isolate_and_log"
    FAIL_CLOSED = "fail_closed"


class CorruptedRecordError(Exception):
    """Raised when a corrupted or unparseable record is encountered under fail-closed policy."""
    pass


@dataclass
class SourceDescriptor:
    source_identifier: str
    source_type: SourceType
    location: str
    license: str
    provenance_details: str
    extra_metadata: Dict[str, Any] = field(default_factory=dict)

    def to_provenance_record(self, initial_size_bytes: int = 0) -> SourceProvenanceRecord:
        return SourceProvenanceRecord(
            source_name=Path(self.location).name if self.location else self.source_identifier,
            source_identifier=self.source_identifier,
            license=self.license,
            provenance_details=self.provenance_details,
            acquisition_timestamp=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            original_size_bytes=initial_size_bytes,
            processed_size_bytes=0,
            measured_token_count=0,
            source_sha256="",
            preprocessing_version="v8.4.0",
        )


@dataclass
class IngestionCheckpoint:
    source_identifier: str
    last_processed_line: int
    last_processed_bytes: int
    documents_ingested: int
    documents_rejected: int
    timestamp: str
    corrupted_records: int = 0
    current_file_idx: int = 0

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


class StreamingIngestionEngine:
    """
    Enterprise-scale streaming ingestion with resume checkpoints and telemetry.
    """

    def __init__(
        self,
        checkpoint_dir: Optional[Path] = None,
        min_doc_length: int = 20,
        max_doc_length: int = 500_000,
        corrupt_policy: CorruptRecordPolicy = CorruptRecordPolicy.ISOLATE_AND_LOG,
        code_safety_scanner: Optional[CodeSafetyScanner] = None,
        decontamination_engine: Optional[NgramDecontaminationEngine] = None,
    ):
        self.checkpoint_dir = checkpoint_dir or (REPO_ROOT / "experiments" / ".ingestion_checkpoints")
        self.checkpoint_dir.mkdir(parents=True, exist_ok=True)
        self.min_doc_length = min_doc_length
        self.max_doc_length = max_doc_length
        self.corrupt_policy = corrupt_policy
        self.code_safety_scanner = code_safety_scanner if code_safety_scanner is not None else CodeSafetyScanner()
        self.decontamination_engine = decontamination_engine

        # Telemetry
        self.total_ingested = 0
        self.total_retained = 0
        self.total_rejected = 0
        self.total_corrupted = 0
        self.rejection_reasons = {
            "empty_or_too_short": 0,
            "too_long": 0,
            "contains_null_bytes": 0,
            "excessive_unprintable_chars": 0,
            "invalid_unicode_replacement": 0,
            "excessive_char_repetition": 0,
            "excessive_line_repetition": 0,
            "spam_or_high_punctuation": 0,
            "corrupted_record_syntax": 0,
            "credential_secret_detected": 0,
            "benchmark_contamination_detected": 0,
        }

    def normalize_text(self, text: str) -> str:
        """Standardizes Unicode NFC and whitespace."""
        # 1. Unicode NFC
        t = unicodedata.normalize("NFC", text)
        # 2. Line endings to LF
        t = t.replace("\r\n", "\n").replace("\r", "\n")
        # 3. Strip trailing whitespace per line
        lines = [line.rstrip() for line in t.split("\n")]
        # 4. Collapse multiple blank lines
        collapsed = []
        blank_run = 0
        for l in lines:
            if not l:
                blank_run += 1
                if blank_run <= 1:
                    collapsed.append("")
            else:
                blank_run = 0
                collapsed.append(l)
        return "\n".join(collapsed).strip()

    def filter_document(self, text: str) -> Tuple[bool, Optional[str]]:
        """Applies deterministic quality rejection filters."""
        if len(text) < self.min_doc_length:
            self.rejection_reasons["empty_or_too_short"] += 1
            return False, "empty_or_too_short"

        if len(text) > self.max_doc_length:
            self.rejection_reasons["too_long"] += 1
            return False, "too_long"

        # Check for null bytes (binary content)
        if "\x00" in text:
            self.rejection_reasons["contains_null_bytes"] += 1
            return False, "contains_null_bytes"

        # Check for unprintable control characters (excluding \n, \t, \r)
        unprintable_count = sum(1 for c in text if ord(c) < 32 and c not in "\n\t\r")
        if len(text) > 0 and (unprintable_count / len(text)) > 0.05:
            self.rejection_reasons["excessive_unprintable_chars"] += 1
            return False, "excessive_unprintable_chars"

        # Check for Unicode replacement char '\ufffd'
        if "\ufffd" in text:
            self.rejection_reasons["invalid_unicode_replacement"] += 1
            return False, "invalid_unicode_replacement"

        # Excessive character repetition (e.g. 'aaaaa...' > 30)
        if re.search(r"(.)\1{30,}", text):
            self.rejection_reasons["excessive_char_repetition"] += 1
            return False, "excessive_char_repetition"

        # Excessive line repetition
        lines = [l.strip() for l in text.split("\n") if l.strip()]
        if len(lines) >= 5:
            unique_lines = set(lines)
            dup_ratio = 1.0 - (len(unique_lines) / len(lines))
            if dup_ratio > 0.40:
                self.rejection_reasons["excessive_line_repetition"] += 1
                return False, "excessive_line_repetition"

        # High punctuation / symbol ratio (spam / non-text delimiter dumps)
        if len(text) >= 40:
            punct_count = sum(1 for c in text if not c.isalnum() and not c.isspace())
            if (punct_count / len(text)) > 0.60:
                self.rejection_reasons["spam_or_high_punctuation"] += 1
                return False, "spam_or_high_punctuation"

        # Code safety & credential scanning
        if self.code_safety_scanner is not None:
            safety_res = self.code_safety_scanner.scan_text(text)
            if not safety_res.is_safe:
                self.rejection_reasons["credential_secret_detected"] += 1
                return False, "credential_secret_detected"

        # Benchmark decontamination scanning
        if self.decontamination_engine is not None:
            decontam_res = self.decontamination_engine.query_document(text, split=ContaminationSplit.TRAIN)
            if not decontam_res.is_clean:
                self.rejection_reasons["benchmark_contamination_detected"] += 1
                return False, "benchmark_contamination_detected"

        return True, None

    def get_checkpoint_path(self, source_id: str) -> Path:
        safe_id = re.sub(r"[^a-zA-Z0-9_\-]", "_", source_id)
        return self.checkpoint_dir / f"ckpt_{safe_id}.json"

    def save_checkpoint(self, checkpoint: IngestionCheckpoint) -> None:
        p = self.get_checkpoint_path(checkpoint.source_identifier)
        with open(p, "w", encoding="utf-8") as f:
            json.dump(checkpoint.to_dict(), f, indent=2)

    def load_checkpoint(self, source_id: str) -> Optional[IngestionCheckpoint]:
        p = self.get_checkpoint_path(source_id)
        if p.exists():
            with open(p, "r", encoding="utf-8") as f:
                d = json.load(f)
            return IngestionCheckpoint(**d)
        return None

    def stream_records_from_file(
        self,
        filepath: Union[str, Path],
        source_record: SourceProvenanceRecord,
        resume: bool = True,
        save_interval: int = 100,
    ) -> Generator[ProductionDocument, None, None]:
        """
        Streams documents from JSONL or raw text file (supports .gz),
        resuming from checkpoint if available.
        """
        path = Path(filepath)
        if not path.exists():
            raise FileNotFoundError(f"File not found: {path}")

        # Validate license before reading
        if not source_record.validate_license():
            raise LicenseProvenanceViolationError(
                f"Cannot ingest {path}: rejected license '{source_record.license}'"
            )

        ckpt = self.load_checkpoint(source_record.source_identifier) if resume else None
        start_line = ckpt.last_processed_line if ckpt else 0

        is_gzip = path.suffix == ".gz"
        open_fn = gzip.open if is_gzip else open

        current_line = 0
        current_bytes = 0

        with open_fn(path, "rt", encoding="utf-8", errors="replace") as f:
            for line_idx, line in enumerate(f):
                current_bytes += len(line.encode("utf-8"))
                if line_idx < start_line:
                    continue  # Skip already processed lines

                current_line = line_idx + 1
                self.total_ingested += 1

                # Parse JSONL or treat line as raw text
                line_str = line.strip()
                if not line_str:
                    continue

                raw_text = ""
                doc_id = f"{source_record.source_name}_{current_line}"
                domain = "1_general_natural_language"

                is_jsonl = (
                    path.name.endswith(".jsonl")
                    or path.name.endswith(".jsonl.gz")
                    or path.name.endswith(".json")
                    or line_str.startswith("{")
                )

                if is_jsonl:
                    try:
                        data = json.loads(line_str)
                        raw_text = data.get("text", data.get("content", ""))
                        doc_id = data.get("id", doc_id)
                        domain = data.get("domain", domain)
                    except Exception as e:
                        self.total_corrupted += 1
                        self.total_rejected += 1
                        self.rejection_reasons["corrupted_record_syntax"] += 1
                        if self.corrupt_policy == CorruptRecordPolicy.FAIL_CLOSED:
                            raise CorruptedRecordError(
                                f"Corrupted record syntax at line {current_line} in {path}: {e}"
                            )
                        continue
                else:
                    raw_text = line_str

                # Normalize and Filter
                clean_text = self.normalize_text(raw_text)
                is_valid, reason = self.filter_document(clean_text)

                if is_valid:
                    self.total_retained += 1
                    # Update provenance metadata
                    doc_prov = SourceProvenanceRecord(
                        source_name=source_record.source_name,
                        source_identifier=source_record.source_identifier,
                        license=source_record.license,
                        provenance_details=source_record.provenance_details,
                        acquisition_timestamp=source_record.acquisition_timestamp,
                        original_size_bytes=len(raw_text.encode("utf-8")),
                        processed_size_bytes=len(clean_text.encode("utf-8")),
                        measured_token_count=0,  # Updated during tokenization
                        source_sha256=hashlib.sha256(clean_text.encode("utf-8")).hexdigest(),
                        preprocessing_version="v8.4.0",
                    )
                    doc = ProductionDocument(
                        id=doc_id,
                        domain=domain,
                        raw_text=raw_text,
                        clean_text=clean_text,
                        provenance=doc_prov,
                        split="train",
                    )
                    yield doc
                else:
                    self.total_rejected += 1

                if current_line % save_interval == 0:
                    self.save_checkpoint(
                        IngestionCheckpoint(
                            source_identifier=source_record.source_identifier,
                            last_processed_line=current_line,
                            last_processed_bytes=current_bytes,
                            documents_ingested=self.total_ingested,
                            documents_rejected=self.total_rejected,
                            corrupted_records=self.total_corrupted,
                            timestamp=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                        )
                    )

        # Final checkpoint save
        self.save_checkpoint(
            IngestionCheckpoint(
                source_identifier=source_record.source_identifier,
                last_processed_line=current_line,
                last_processed_bytes=current_bytes,
                documents_ingested=self.total_ingested,
                documents_rejected=self.total_rejected,
                corrupted_records=self.total_corrupted,
                timestamp=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            )
        )

    def stream_records_from_directory(
        self,
        dir_path: Union[str, Path],
        source_record: SourceProvenanceRecord,
        resume: bool = True,
        save_interval: int = 100,
    ) -> Generator[ProductionDocument, None, None]:
        """
        Deterministically streams documents from all text/jsonl files in a directory.
        """
        base_dir = Path(dir_path)
        if not base_dir.exists() or not base_dir.is_dir():
            raise NotADirectoryError(f"Directory not found: {base_dir}")

        if not source_record.validate_license():
            raise LicenseProvenanceViolationError(
                f"Cannot ingest directory {base_dir}: rejected license '{source_record.license}'"
            )

        # Deterministic sorting of files
        valid_extensions = {".txt", ".jsonl", ".gz"}
        files = sorted([p for p in base_dir.rglob("*") if p.is_file() and p.suffix in valid_extensions])

        ckpt = self.load_checkpoint(source_record.source_identifier) if resume else None
        start_file_idx = ckpt.current_file_idx if ckpt else 0

        for file_idx, fpath in enumerate(files):
            if file_idx < start_file_idx:
                continue

            file_sub_record = SourceProvenanceRecord(
                source_name=f"{source_record.source_name}/{fpath.name}",
                source_identifier=f"{source_record.source_identifier}::{fpath.name}",
                license=source_record.license,
                provenance_details=source_record.provenance_details,
                acquisition_timestamp=source_record.acquisition_timestamp,
                original_size_bytes=fpath.stat().st_size,
                processed_size_bytes=0,
                measured_token_count=0,
                source_sha256="",
                preprocessing_version=source_record.preprocessing_version,
            )

            # Stream through file
            for doc in self.stream_records_from_file(
                fpath, source_record=file_sub_record, resume=(file_idx == start_file_idx and resume), save_interval=save_interval
            ):
                yield doc

            # Update checkpoint with file index
            self.save_checkpoint(
                IngestionCheckpoint(
                    source_identifier=source_record.source_identifier,
                    last_processed_line=0,
                    last_processed_bytes=0,
                    documents_ingested=self.total_ingested,
                    documents_rejected=self.total_rejected,
                    corrupted_records=self.total_corrupted,
                    current_file_idx=file_idx + 1,
                    timestamp=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                )
            )

    def stream_records_from_archive(
        self,
        archive_path: Union[str, Path],
        source_record: SourceProvenanceRecord,
        resume: bool = True,
        save_interval: int = 100,
    ) -> Generator[ProductionDocument, None, None]:
        """
        Streams documents from an archive (.zip or .tar / .tar.gz / .tgz).
        """
        path = Path(archive_path)
        if not path.exists():
            raise FileNotFoundError(f"Archive not found: {path}")

        if not source_record.validate_license():
            raise LicenseProvenanceViolationError(
                f"Cannot ingest archive {path}: rejected license '{source_record.license}'"
            )

        if zipfile.is_zipfile(path):
            with zipfile.ZipFile(path, "r") as zf:
                for name in sorted(zf.namelist()):
                    if name.endswith("/") or name.startswith("__MACOSX"):
                        continue
                    with zf.open(name, "r") as member_file:
                        content = member_file.read().decode("utf-8", errors="replace")
                        clean = self.normalize_text(content)
                        is_valid, _ = self.filter_document(clean)
                        self.total_ingested += 1
                        if is_valid:
                            self.total_retained += 1
                            yield ProductionDocument(
                                id=f"{source_record.source_name}_{name}",
                                domain="1_general_natural_language",
                                raw_text=content,
                                clean_text=clean,
                                provenance=source_record,
                                split="train",
                            )
                        else:
                            self.total_rejected += 1
        elif tarfile.is_tarfile(path):
            with tarfile.open(path, "r:*") as tf:
                for member in tf.getmembers():
                    if not member.isfile():
                        continue
                    f = tf.extractfile(member)
                    if f is not None:
                        content = f.read().decode("utf-8", errors="replace")
                        clean = self.normalize_text(content)
                        is_valid, _ = self.filter_document(clean)
                        self.total_ingested += 1
                        if is_valid:
                            self.total_retained += 1
                            yield ProductionDocument(
                                id=f"{source_record.source_name}_{member.name}",
                                domain="1_general_natural_language",
                                raw_text=content,
                                clean_text=clean,
                                provenance=source_record,
                                split="train",
                            )
                        else:
                            self.total_rejected += 1
        else:
            raise ValueError(f"Unsupported archive format: {path}")

    def stream_records_from_source(
        self,
        source_desc: SourceDescriptor,
        resume: bool = True,
        save_interval: int = 100,
    ) -> Generator[ProductionDocument, None, None]:
        """
        Unified source dispatcher supporting local files, directories, archives, and remote descriptors.
        """
        prov = source_desc.to_provenance_record()
        if source_desc.source_type == SourceType.LOCAL_FILE:
            return self.stream_records_from_file(
                source_desc.location, source_record=prov, resume=resume, save_interval=save_interval
            )
        elif source_desc.source_type == SourceType.LOCAL_DIR:
            return self.stream_records_from_directory(
                source_desc.location, source_record=prov, resume=resume, save_interval=save_interval
            )
        elif source_desc.source_type == SourceType.ARCHIVE:
            return self.stream_records_from_archive(
                source_desc.location, source_record=prov, resume=resume, save_interval=save_interval
            )
        elif source_desc.source_type == SourceType.REMOTE_URL:
            # Remote ingestion check: validate URL scheme and license
            if not (source_desc.location.startswith("http://") or source_desc.location.startswith("https://") or source_desc.location.startswith("s3://")):
                raise ValueError(f"Invalid remote URL scheme: {source_desc.location}")
            if not prov.validate_license():
                raise LicenseProvenanceViolationError(f"Rejected remote license: {prov.license}")
            raise NotImplementedError(
                f"Production Rule: Direct automatic bulk downloading of remote data '{source_desc.location}' is prohibited. "
                "Download and stage artifacts deliberately, then ingest via LOCAL_FILE or ARCHIVE."
            )
        else:
            raise ValueError(f"Unsupported SourceType: {source_desc.source_type}")

    def get_telemetry_report(self) -> Dict[str, Any]:
        return {
            "documents_ingested": self.total_ingested,
            "documents_retained": self.total_retained,
            "documents_rejected": self.total_rejected,
            "corrupted_records": self.total_corrupted,
            "retention_rate_pct": round((self.total_retained / self.total_ingested * 100.0), 2) if self.total_ingested > 0 else 0.0,
            "rejection_reasons_breakdown": self.rejection_reasons,
        }
