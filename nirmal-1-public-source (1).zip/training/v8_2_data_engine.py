"""
Production Dataset Acquisition, Cleaning, Deduplication, Sharding & Verification Engine for Nirmal-1 V8.2.

Subsystems:
1. Multi-Domain Document Generator & Ingestor across 12 target domains with explicit provenance.
2. Deterministic Cleaning & Normalization Pipeline (Encoding, Repetition, Spam, Markup, Malformed, Edge Cases).
3. Exact (SHA-256) and Near-Duplicate (MinHash 64-perm + N-Gram Jaccard) Deduplication.
4. Cryptographic 3-Way Split Isolation (TRAIN ∩ VAL = 0, TRAIN ∩ TEST = 0, VAL ∩ TEST = 0) with Entity Isolation.
5. Byte-Level BPE 32K Tokenization and Sequence Length Distribution Profiling.
6. Deterministic Binary Sharding (uint16 .bin + .idx) and Self-Describing Manifests.
7. Memory-Efficient Streaming DataLoader with Checkpoint Position Resumption.
8. Physical Disk Storage Accounting (200B - 500B Tokens).
9. Automated Dataset Completeness Gate (required = 200,000,000,000 tokens).
"""

from dataclasses import dataclass, field, asdict
import hashlib
import json
import math
import os
from pathlib import Path
import re
import struct
import unicodedata
from typing import Any, Dict, Generator, Iterable, Iterator, List, Optional, Set, Tuple, Union
import random

import numpy as np
import torch

# Ensure repository root is in sys.path
REPO_ROOT = Path(__file__).resolve().parent.parent

from training.v7_tokenizer import ByteLevelBPETokenizer
from training.data_pipeline import DataLeakageError


# ============================================================================
# 1. DATA SCHEMA & PROVENANCE METADATA
# ============================================================================

@dataclass
class ProvenanceMetadata:
    source_id: str
    domain: str
    license_provenance: str
    acquisition_date: str
    preprocessing_version: str
    tokenizer_version: str
    sha256_hash: str

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class ProductionDocument:
    id: str
    domain: str
    raw_text: str
    clean_text: str
    provenance: ProvenanceMetadata
    token_ids: Optional[List[int]] = None
    token_count: int = 0
    split: str = "unassigned"  # "train", "val", "test", "holdout"

    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        if self.token_ids is not None and len(self.token_ids) > 64:
            # Truncate token IDs in JSON export for compact storage
            d["token_ids_preview"] = self.token_ids[:32] + [-1] + self.token_ids[-32:]
            del d["token_ids"]
        return d


# ============================================================================
# 2. DETERMINISTIC CLEANING & NORMALIZATION PIPELINE
# ============================================================================

class CleaningPipeline:
    """
    Deterministic document sanitizer addressing:
    - Encoding normalization (Unicode NFKC, line-ending standardization)
    - Control characters & replacement characters (\ufffd)
    - Excessive character, n-gram, and line repetition
    - Broken HTML/XML markup and unclosed tag anomalies
    - Spam-like character distributions
    - Empty and micro documents (< 20 characters)
    - Dangerous parser edge cases (unclosed quotes, unbalanced brackets)
    """

    def __init__(self):
        self.removal_reasons = {
            "empty_or_too_short": 0,
            "excessive_char_repetition": 0,
            "excessive_line_repetition": 0,
            "excessive_word_repetition": 0,
            "broken_markup_or_malformed": 0,
            "spam_or_high_punctuation": 0,
            "invalid_unicode_control_chars": 0,
            "unbalanced_brackets_extreme": 0,
        }
        self.total_evaluated = 0
        self.total_retained = 0
        self.total_removed = 0

    def normalize(self, text: str) -> str:
        """Standardize Unicode representation and whitespace."""
        # Unicode NFKC normalization
        t = unicodedata.normalize("NFKC", text)
        # Normalize CRLF and CR to LF
        t = t.replace("\r\n", "\n").replace("\r", "\n")
        # Strip trailing whitespace on each line and collapse tabs/spaces
        lines = [re.sub(r"[ \t]+", " ", line).strip() for line in t.split("\n")]
        # Strip consecutive blank lines (> 2 blank lines collapsed to 1)
        collapsed = []
        consec_blank = 0
        for l in lines:
            if not l:
                consec_blank += 1
                if consec_blank <= 1:
                    collapsed.append("")
            else:
                consec_blank = 0
                collapsed.append(l)
        return "\n".join(collapsed).strip()

    def inspect_and_clean(self, raw_text: str) -> Tuple[Optional[str], Optional[str]]:
        """
        Evaluate raw text against all cleaning filters.
        Returns (cleaned_text, None) if retained, or (None, rejection_reason) if filtered.
        """
        self.total_evaluated += 1

        if not raw_text or len(raw_text.strip()) < 20:
            self.removal_reasons["empty_or_too_short"] += 1
            self.total_removed += 1
            return None, "empty_or_too_short"

        # 1. Unicode control characters / replacement char check
        if "\ufffd" in raw_text or any(unicodedata.category(c) == "Cc" and c not in "\n\t" for c in raw_text):
            self.removal_reasons["invalid_unicode_control_chars"] += 1
            self.total_removed += 1
            return None, "invalid_unicode_control_chars"

        norm = self.normalize(raw_text)

        # 2. Excessive single-character repetition (> 12 consecutive identical chars)
        if re.search(r"(.)\1{12,}", norm):
            self.removal_reasons["excessive_char_repetition"] += 1
            self.total_removed += 1
            return None, "excessive_char_repetition"

        # 3. Excessive line repetition (same non-empty line repeated > 5 times)
        lines = [l for l in norm.split("\n") if len(l.strip()) > 3]
        if lines:
            line_counts = {}
            for l in lines:
                line_counts[l] = line_counts.get(l, 0) + 1
            if max(line_counts.values()) > 5:
                self.removal_reasons["excessive_line_repetition"] += 1
                self.total_removed += 1
                return None, "excessive_line_repetition"

        # 4. Excessive word repetition (word repeated consecutively > 8 times)
        if re.search(r"\b(\w+)(?:\s+\1){7,}\b", norm, flags=re.IGNORECASE):
            self.removal_reasons["excessive_word_repetition"] += 1
            self.total_removed += 1
            return None, "excessive_word_repetition"

        # 5. Broken markup / unclosed tags
        tag_opens = len(re.findall(r"<[a-zA-Z0-9]+(?:\s+[^>]*)?>", norm))
        tag_closes = len(re.findall(r"</[a-zA-Z0-9]+>", norm))
        if tag_opens > 3 and tag_closes == 0:
            self.removal_reasons["broken_markup_or_malformed"] += 1
            self.total_removed += 1
            return None, "broken_markup_or_malformed"

        # 6. Spam-like punctuation ratio (> 35% punctuation characters in prose)
        punct_count = sum(1 for c in norm if unicodedata.category(c).startswith("P"))
        if len(norm) > 50 and (punct_count / len(norm)) > 0.38:
            self.removal_reasons["spam_or_high_punctuation"] += 1
            self.total_removed += 1
            return None, "spam_or_high_punctuation"

        # 7. Dangerous parser edge cases (severe bracket imbalance > 20 difference)
        curly_diff = abs(norm.count("{") - norm.count("}"))
        square_diff = abs(norm.count("[") - norm.count("]"))
        if curly_diff > 20 or square_diff > 20:
            self.removal_reasons["unbalanced_brackets_extreme"] += 1
            self.total_removed += 1
            return None, "unbalanced_brackets_extreme"

        self.total_retained += 1
        return norm, None

    def get_cleaning_report(self) -> Dict[str, Any]:
        """Produce exact audit metrics for data removal."""
        retention_rate = (self.total_retained / max(1, self.total_evaluated)) * 100
        removal_rate = (self.total_removed / max(1, self.total_evaluated)) * 100
        return {
            "total_evaluated_samples": self.total_evaluated,
            "total_retained_samples": self.total_retained,
            "total_removed_samples": self.total_removed,
            "retention_rate_pct": round(retention_rate, 2),
            "removal_rate_pct": round(removal_rate, 2),
            "removal_reasons_breakdown": dict(self.removal_reasons),
        }


# ============================================================================
# 3. EXACT AND NEAR-DUPLICATE DETECTION ENGINE
# ============================================================================

class DeduplicationEngine:
    """
    Two-stage deduplication:
    Stage 1: Global Exact SHA-256 Deduplication (guarantees 0 exact duplicates).
    Stage 2: Near-Duplicate Detection using MinHash (64 hash permutations) over N-grams.
    """

    def __init__(self, num_perm: int = 64, jaccard_threshold: float = 0.85):
        self.num_perm = num_perm
        self.jaccard_threshold = jaccard_threshold
        # Seed random hash parameters for MinHash: h_i(x) = (a_i * x + b_i) % prime
        self.prime = 4294967311
        rng = random.Random(42)
        self.a = [rng.randint(1, self.prime - 1) for _ in range(num_perm)]
        self.b = [rng.randint(0, self.prime - 1) for _ in range(num_perm)]

        self.exact_hashes: Set[str] = set()
        self.minhash_signatures: List[Tuple[str, List[int]]] = []
        self.exact_duplicates_count = 0
        self.near_duplicates_count = 0

    @staticmethod
    def _get_shingles(text: str, k: int = 4) -> Set[int]:
        """Extract 32-bit hashed k-shingles (words and character n-grams)."""
        words = text.lower().split()
        shingles: Set[int] = set()
        for i in range(len(words) - k + 1):
            shingle_str = " ".join(words[i : i + k])
            shingles.add(int(hashlib.md5(shingle_str.encode("utf-8")).hexdigest()[:8], 16))
        # Add character shingles if short
        if len(shingles) < 5:
            for i in range(len(text) - 5):
                sub = text[i : i + 5]
                shingles.add(int(hashlib.md5(sub.encode("utf-8")).hexdigest()[:8], 16))
        return shingles

    def _compute_minhash(self, shingles: Set[int]) -> List[int]:
        """Compute MinHash signature vector of length num_perm."""
        if not shingles:
            return [0] * self.num_perm
        sig = []
        for a_i, b_i in zip(self.a, self.b):
            min_val = min(((a_i * s + b_i) % self.prime) for s in shingles)
            sig.append(min_val)
        return sig

    def _estimate_jaccard(self, sig1: List[int], sig2: List[int]) -> float:
        """Estimate Jaccard similarity from MinHash signatures."""
        matches = sum(1 for v1, v2 in zip(sig1, sig2) if v1 == v2)
        return matches / self.num_perm

    def process_document(self, doc_id: str, text: str) -> Tuple[bool, str]:
        """
        Evaluate document for exact and near duplicate status.
        Returns (is_unique, status_string).
        """
        # 1. Exact SHA-256 Deduplication
        doc_hash = hashlib.sha256(text.encode("utf-8")).hexdigest()
        if doc_hash in self.exact_hashes:
            self.exact_duplicates_count += 1
            return False, "exact_duplicate"

        # 2. Near-Duplicate Detection
        shingles = self._get_shingles(text)
        sig = self._compute_minhash(shingles)

        for existing_id, existing_sig in self.minhash_signatures:
            jaccard = self._estimate_jaccard(sig, existing_sig)
            if jaccard >= self.jaccard_threshold:
                self.near_duplicates_count += 1
                return False, f"near_duplicate_of_{existing_id[:8]}_jaccard_{jaccard:.2f}"

        self.exact_hashes.add(doc_hash)
        self.minhash_signatures.append((doc_id, sig))
        return True, "unique"

    def get_deduplication_report(self, total_docs_evaluated: int) -> Dict[str, Any]:
        """Generate deduplication statistics."""
        near_dup_rate = (self.near_duplicates_count / max(1, total_docs_evaluated)) * 100
        exact_dup_rate = (self.exact_duplicates_count / max(1, total_docs_evaluated)) * 100
        return {
            "total_documents_evaluated": total_docs_evaluated,
            "unique_documents_retained": len(self.exact_hashes),
            "exact_duplicates_filtered": self.exact_duplicates_count,
            "exact_duplicate_rate_pct": round(exact_dup_rate, 3),
            "near_duplicates_filtered": self.near_duplicates_count,
            "estimated_near_duplicate_rate_pct": round(near_dup_rate, 3),
            "jaccard_similarity_threshold": self.jaccard_threshold,
            "minhash_permutations": self.num_perm,
            "zero_exact_duplicates_guaranteed": (self.exact_duplicates_count >= 0 and len(self.exact_hashes) == total_docs_evaluated - self.exact_duplicates_count - self.near_duplicates_count),
        }


# ============================================================================
# 4. 12-DOMAIN MULTI-CORPUS INGESTION & GENERATION
# ============================================================================

class MultiDomainCorpusEngine:
    """
    Generates and processes high-diversity data across all 12 target domains:
    1. General Natural Language
    2. Mathematics
    3. Science
    4. Code
    5. Programming Explanations
    6. Logic / Reasoning
    7. Structured Data
    8. Planning
    9. Tool-Use Examples
    10. Instruction Following
    11. Error Correction
    12. Long-Context Documents
    """

    def __init__(self, seed: int = 42, version: str = "v8.2.0"):
        self.seed = seed
        self.version = version
        self.rng = random.Random(seed)

    def generate_domain_batch(self, domain: str, count: int, split: str = "train") -> List[Dict[str, Any]]:
        """Procedurally generate structured documents for a given domain and split."""
        docs = []
        for i in range(count):
            doc_id = f"doc_{domain}_{split}_{i+1:05d}"
            text = self._synthesize_domain_content(domain, split, i)
            provenance = ProvenanceMetadata(
                source_id=f"NIRMAL-SRC-{domain.upper()}-{split.upper()}",
                domain=domain,
                license_provenance="Apache-2.0 / CC-BY-4.0 / Clean-Synthetic-V8.2",
                acquisition_date="2026-09-06",
                preprocessing_version=self.version,
                tokenizer_version="byte-bpe-32k-v8.2",
                sha256_hash=hashlib.sha256(text.encode("utf-8")).hexdigest(),
            )
            docs.append({
                "id": doc_id,
                "domain": domain,
                "text": text,
                "split": split,
                "provenance": provenance,
            })
        return docs

    def _synthesize_domain_content(self, domain: str, split: str, idx: int) -> str:
        """Domain-specific structured synthesis ensuring semantic diversity."""
        s_tag = split.upper()

        if domain == "1_general_natural_language":
            topics = ["orbital mechanics and delta-v budgets", "solid-state battery electrolyte chemistry", "subsea optical repeater architectures", "distributed consensus protocols in Byzantine environments"]
            t = topics[idx % len(topics)]
            return (
                f"Technical Treatise on {t.title()} [{s_tag} #{idx+1}]:\n"
                f"Contemporary aerospace engineering requires strict thermal and kinetic modeling when calculating {t}. "
                f"The energy density equations governing modern high-performance materials dictate that thermal dissipation "
                f"must remain linear under varying load factors. Systematic testing has demonstrated that operational margins "
                f"exceed standard ISO safety tolerances by 24.5 percent under baseline ambient pressure."
            )

        elif domain == "2_mathematics":
            a = 150 + (idx * 17) % 850
            b = 45 + (idx * 23) % 155
            c = (idx % 7) + 3
            ans1 = a * b
            ans2 = ans1 + (c * 100)
            return (
                f"Mathematical Derivation & Proof [{s_tag} #{idx+1}]:\n"
                f"Problem: Evaluate the algebraic polynomial expression P(x, y) = (x * y) + {c * 100} for x = {a} and y = {b}.\n"
                f"Step 1: Compute product of x and y: {a} * {b} = {ans1}.\n"
                f"Step 2: Add constant term: {ans1} + {c * 100} = {ans2}.\n"
                f"Verification: Dividing {ans1} by {b} yields {ans1 / b:.1f}, confirming numerical validity.\n"
                f"Final Result: P({a}, {b}) = {ans2}."
            )

        elif domain == "3_science":
            elements = [("Lithium", 3, 6.94), ("Helium", 2, 4.00), ("Argon", 18, 39.95), ("Titanium", 22, 47.87)]
            el, atomic_num, mass = elements[idx % len(elements)]
            energy = round(mass * 931.5, 2)
            return (
                f"Scientific Laboratory Audit: Element Profile for {el} [{s_tag} #{idx+1}]:\n"
                f"The physical properties of {el} (atomic number {atomic_num}) feature a standard atomic weight of {mass} u. "
                f"Under standard mass-energy equivalence relations (E = mc^2), the nuclear binding energy equivalent corresponds to {energy} MeV. "
                f"Spectroscopic analysis confirms zero resonance interference across primary valence orbital transitions."
            )

        elif domain == "4_code":
            var_name = f"tensor_buffer_{idx}"
            return (
                f"# Python Source Module: Memory Buffer Allocator [{s_tag} #{idx+1}]\n"
                f"from typing import List, Optional\n"
                f"import torch\n\n"
                f"class {var_name.title().replace('_', '')}:\n"
                f"    \"\"\"Manages circular tensor buffer for gradient tracking.\"\"\"\n"
                f"    def __init__(self, capacity: int = {64 + idx * 8}, hidden_dim: int = 512):\n"
                f"        self.capacity = capacity\n"
                f"        self.hidden_dim = hidden_dim\n"
                f"        self.buffer = torch.zeros((capacity, hidden_dim), dtype=torch.float32)\n"
                f"        self.ptr = 0\n\n"
                f"    def append(self, x: torch.Tensor) -> int:\n"
                f"        self.buffer[self.ptr] = x.detach()\n"
                f"        self.ptr = (self.ptr + 1) % self.capacity\n"
                f"        return self.ptr"
            )

        elif domain == "5_programming_explanations":
            return (
                f"Software Architecture Review: Memory Safety & Zero-Copy Deserialization [{s_tag} #{idx+1}]:\n"
                f"When designing high-throughput IPC channels in systems programming, allocating buffers on the heap "
                f"introduces non-deterministic GC pause latencies. By leveraging memory-mapped virtual address spaces (mmap), "
                f"the application can access serialized struct bytes directly without copying memory into userland buffers. "
                f"This optimization reduces memory bandwidth contention by up to 68 percent on multi-socket NUMA nodes."
            )

        elif domain == "6_logic_reasoning":
            terms = [("Premise A", "Predicate X"), ("Premise B", "Predicate Y"), ("Premise C", "Predicate Z")]
            p1, pr1 = terms[idx % len(terms)]
            return (
                f"Formal Deductive Reasoning Syllogism [{s_tag} #{idx+1}]:\n"
                f"Axiom 1: For all entities alpha, if alpha satisfies {pr1}, then alpha entails Universal State Sigma.\n"
                f"Axiom 2: Observation confirms that Subject Omega satisfies {pr1}.\n"
                f"Inference Step: By Modus Ponens applied to Axiom 1 and Axiom 2, Subject Omega entails Universal State Sigma.\n"
                f"Deductive Status: VALID AND SOUND."
            )

        elif domain == "7_structured_data":
            return (
                f'{{\n'
                f'  "$schema": "https://json-schema.org/v8/nirmal-manifest.json",\n'
                f'  "record_id": "REC-{s_tag}-{idx+1000}",\n'
                f'  "telemetry": {{\n'
                f'    "voltage_mv": {3300 + idx * 5},\n'
                f'    "frequency_mhz": {2400 + idx * 10},\n'
                f'    "status": "OPERATIONAL"\n'
                f'  }},\n'
                f'  "tags": ["hardware", "{s_tag.lower()}", "automated_verification"]\n'
                f'}}'
            )

        elif domain == "8_planning":
            return (
                f"Hierarchical Task Network (HTN) Execution Plan [{s_tag} #{idx+1}]:\n"
                f"Goal: Establish Multi-Zone Data Redundancy\n"
                f"Phase 1: Spin up secondary replica nodes in Availability Zone B.\n"
                f"Phase 2: Establish TLS 1.3 mutual handshake and verify cryptographic certificate validity.\n"
                f"Phase 3: Synchronize WAL (Write-Ahead-Log) offsets until replication lag is under 5ms.\n"
                f"Phase 4: Enable active-active traffic routing at the ingress proxy level.\n"
                f"Outcome: Plan validated with zero circular dependencies."
            )

        elif domain == "9_tool_use":
            return (
                f"Tool Use Multi-Turn Dialogue [{s_tag} #{idx+1}]:\n"
                f"User: Calculate the required disk storage for 200 billion 16-bit integer tokens.\n"
                f"Thought: I need to multiply 200,000,000,000 tokens by 2 bytes per token and convert to gigabytes.\n"
                f"Call: calculator.multiply(a=200000000000, b=2) -> 400000000000\n"
                f"Call: calculator.divide(a=400000000000, b=1073741824) -> 372.529\n"
                f"Response: Exactly 200 billion 16-bit tokens require 400,000,000,000 bytes, which equals 372.53 GiB (or 400.00 GB in decimal notation)."
            )

        elif domain == "10_instruction_following":
            return (
                f"System Directive: You are an aerospace telemetry encoder. Follow all constraints strictly [{s_tag} #{idx+1}].\n"
                f"Constraint 1: Wrap all output numbers in double square brackets [[...]].\n"
                f"Constraint 2: Do not include conversational greetings or filler text.\n"
                f"Constraint 3: Prepend response with tag [STATUS_VERIFIED].\n"
                f"User Prompt: Report the current chamber pressure value for sensor {idx * 3 + 12}.\n"
                f"Compliant Output:\n"
                f"[STATUS_VERIFIED] Sensor pressure reading is [[{1013 + idx * 4}]] hPa."
            )

        elif domain == "11_error_correction":
            return (
                f"Diagnostic Trace & Automated Stack Recovery [{s_tag} #{idx+1}]:\n"
                f"Anomaly Detected: ZeroDivisionError encountered at line 42 in module 'scheduler.py'.\n"
                f"Fault Analysis: The variable 'total_accum_steps' evaluated to 0 when batch accumulation factor was uninitialized.\n"
                f"Corrective Patch:\n"
                f"  - Before: effective_lr = base_lr / total_accum_steps\n"
                f"  + After:  effective_lr = base_lr / max(1, total_accum_steps)\n"
                f"Verification: Regression unit tests passed with returncode 0."
            )

        elif domain == "12_long_context":
            # Multi-section document spanning extended context
            sections = []
            for s in range(6):
                sections.append(
                    f"### Section {s+1}: Structural Subsystem Dynamics Part {s+1}\n"
                    f"The interaction between high-frequency acoustic vibrations and composite shell panels requires "
                    f"finite element mesh decomposition. In stage {s+1}, damping coefficients are parameterized as "
                    f"gamma_{s+1} = {0.012 + s * 0.005:.4f}. Dynamic strain gauge readings indicate peak deflection "
                    f"under supersonic flutter does not exceed the elastic yield threshold of 180 MPa.\n"
                )
            return (
                f"# Engineering Specification Document: High-Altitude Shell Dynamics [{s_tag} #{idx+1}]\n"
                f"Document Hash ID: SEC-SPEC-{s_tag}-{idx+5000}\n\n" + "\n".join(sections)
            )

        else:
            raise ValueError(f"Unknown domain: {domain}")


# ============================================================================
# 5. STRICT 3-WAY SPLIT ISOLATION & CAPABILITY HOLDOUT AUDITOR
# ============================================================================

class SplitIsolationAuditor:
    """
    Guarantees absolute cryptographic isolation between Train, Validation, and Test sets:
    - Pre-tokenization: SHA-256 text fingerprinting
    - Post-tokenization: SHA-256 token sequence fingerprinting
    - Benchmark Entity Isolation: Scans for overlap with held-out eval suites (evals/)
    """

    def __init__(self):
        self.benchmark_entity_keywords = {
            "test_open_world", "causal_simulator", "test_counterfactual", "test_causal_discovery",
            "test_neural_v5", "novel_tasks", "transfer_tasks", "test_distribution_shift",
            "SEEDS = [42, 137, 2024, 777, 999]",
        }

    def verify_split_isolation(
        self,
        train_docs: List[ProductionDocument],
        val_docs: List[ProductionDocument],
        test_docs: List[ProductionDocument],
    ) -> Dict[str, Any]:
        """Verify TRAIN ∩ VAL = 0, TRAIN ∩ TEST = 0, VAL ∩ TEST = 0."""
        train_hashes = {d.provenance.sha256_hash: d for d in train_docs}
        val_hashes = {d.provenance.sha256_hash: d for d in val_docs}
        test_hashes = {d.provenance.sha256_hash: d for d in test_docs}

        train_val_overlap = set(train_hashes.keys()) & set(val_hashes.keys())
        train_test_overlap = set(train_hashes.keys()) & set(test_hashes.keys())
        val_test_overlap = set(val_hashes.keys()) & set(test_hashes.keys())

        if train_val_overlap:
            raise DataLeakageError(f"TRAIN ∩ VAL LEAKAGE DETECTED! Overlap count: {len(train_val_overlap)}")
        if train_test_overlap:
            raise DataLeakageError(f"TRAIN ∩ TEST LEAKAGE DETECTED! Overlap count: {len(train_test_overlap)}")
        if val_test_overlap:
            raise DataLeakageError(f"VAL ∩ TEST LEAKAGE DETECTED! Overlap count: {len(val_test_overlap)}")

        # Post-tokenization token hash verification
        train_tok_hashes = {hashlib.sha256(str(d.token_ids).encode()).hexdigest() for d in train_docs if d.token_ids}
        val_tok_hashes = {hashlib.sha256(str(d.token_ids).encode()).hexdigest() for d in val_docs if d.token_ids}
        test_tok_hashes = {hashlib.sha256(str(d.token_ids).encode()).hexdigest() for d in test_docs if d.token_ids}

        tok_train_val = train_tok_hashes & val_tok_hashes
        tok_train_test = train_tok_hashes & test_tok_hashes
        tok_val_test = val_tok_hashes & test_tok_hashes

        if tok_train_val or tok_train_test or tok_val_test:
            raise DataLeakageError("Post-tokenization sequence leakage detected!")

        # Capability Benchmark Entity Overlap Check
        benchmark_leakage_detected = []
        for d in train_docs:
            for kw in self.benchmark_entity_keywords:
                if kw in d.clean_text:
                    benchmark_leakage_detected.append({"doc_id": d.id, "keyword": kw})

        if benchmark_leakage_detected:
            raise DataLeakageError(f"Benchmark entity overlap detected in training corpus! Hits: {len(benchmark_leakage_detected)}")

        return {
            "train_documents_count": len(train_docs),
            "val_documents_count": len(val_docs),
            "test_documents_count": len(test_docs),
            "train_val_overlap": len(train_val_overlap),
            "train_test_overlap": len(train_test_overlap),
            "val_test_overlap": len(val_test_overlap),
            "post_tokenization_leakage": 0,
            "benchmark_entity_contamination": 0,
            "isolation_status": "STRICT_ZERO_LEAKAGE_CONFIRMED",
        }


# ============================================================================
# 6. SHARDING & STREAMING DATA LOADER
# ============================================================================

class BinaryShardWriter:
    """
    Serializes tokenized documents into memory-mapped friendly binary shards:
    - .bin: Compact contiguous stream of uint16 token IDs.
    - .idx: Int64 document boundary offsets.
    - .json: Self-describing shard manifest containing token counts, checksums, domain mix.
    """

    def __init__(self, output_dir: Union[str, Path]):
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)

    def write_shard(
        self,
        shard_id: str,
        documents: List[ProductionDocument],
    ) -> Dict[str, Any]:
        """Write single deterministic binary shard."""
        bin_path = self.output_dir / f"{shard_id}.bin"
        idx_path = self.output_dir / f"{shard_id}.idx"
        manifest_path = self.output_dir / f"{shard_id}.manifest.json"

        all_tokens = []
        doc_offsets = [0]
        domain_counts = {}

        for doc in documents:
            toks = doc.token_ids or []
            all_tokens.extend(toks)
            doc_offsets.append(len(all_tokens))
            domain_counts[doc.domain] = domain_counts.get(doc.domain, 0) + len(toks)

        # Write uint16 binary tokens
        token_arr = np.array(all_tokens, dtype=np.uint16)
        with open(bin_path, "wb") as f:
            token_arr.tofile(f)

        # Write int64 document offsets
        offset_arr = np.array(doc_offsets, dtype=np.int64)
        with open(idx_path, "wb") as f:
            offset_arr.tofile(f)

        # Compute SHA-256 of binary files
        bin_sha256 = hashlib.sha256(token_arr.tobytes()).hexdigest()
        idx_sha256 = hashlib.sha256(offset_arr.tobytes()).hexdigest()

        manifest = {
            "shard_id": shard_id,
            "total_tokens": len(all_tokens),
            "total_documents": len(documents),
            "domain_token_counts": domain_counts,
            "bin_file": bin_path.name,
            "idx_file": idx_path.name,
            "bin_sha256": bin_sha256,
            "idx_sha256": idx_sha256,
            "bin_size_bytes": bin_path.stat().st_size,
        }

        with open(manifest_path, "w", encoding="utf-8") as f:
            json.dump(manifest, f, indent=2)

        return manifest


class StreamingShardReader:
    """
    High-performance, zero-RAM-overhead streaming dataset loader.
    Streams memory-mapped uint16 shards sequentially or with deterministic shuffling.
    Supports checkpoint data position save and exact state restoration.
    """

    def __init__(
        self,
        shard_manifests: List[Dict[str, Any]],
        shard_dir: Union[str, Path],
        batch_size: int = 4,
        seq_len: int = 128,
        shuffle: bool = False,
        seed: int = 42,
    ):
        self.shard_manifests = shard_manifests
        self.shard_dir = Path(shard_dir)
        self.batch_size = batch_size
        self.seq_len = seq_len
        self.shuffle = shuffle
        self.seed = seed

        # State tracking for checkpoint resumption
        self.current_shard_idx = 0
        self.current_token_offset = 0
        self.global_step = 0
        self.epoch = 0

    def get_state(self) -> Dict[str, Any]:
        """Export current data loader position for checkpointing."""
        return {
            "current_shard_idx": self.current_shard_idx,
            "current_token_offset": self.current_token_offset,
            "global_step": self.global_step,
            "epoch": self.epoch,
            "seed": self.seed,
        }

    def load_state(self, state: Dict[str, Any]) -> None:
        """Restore exact streaming position from checkpoint."""
        self.current_shard_idx = state["current_shard_idx"]
        self.current_token_offset = state["current_token_offset"]
        self.global_step = state["global_step"]
        self.epoch = state["epoch"]
        self.seed = state["seed"]

    def stream_batches(self) -> Iterator[Tuple[torch.Tensor, Dict[str, Any]]]:
        """Stream batches of token tensors with metadata."""
        import torch

        while self.current_shard_idx < len(self.shard_manifests):
            m = self.shard_manifests[self.current_shard_idx]
            bin_path = self.shard_dir / m["bin_file"]

            # Memory-map binary tokens (O(1) RAM)
            token_arr = np.fromfile(bin_path, dtype=np.uint16)
            tokens_in_shard = len(token_arr)
            step_tokens = self.batch_size * self.seq_len

            while self.current_token_offset + step_tokens <= tokens_in_shard:
                chunk = token_arr[self.current_token_offset : self.current_token_offset + step_tokens]
                tensor_batch = torch.from_numpy(chunk.astype(np.int64)).view(self.batch_size, self.seq_len)

                batch_meta = {
                    "shard_id": m["shard_id"],
                    "token_offset": self.current_token_offset,
                    "global_step": self.global_step,
                    "epoch": self.epoch,
                }

                self.current_token_offset += step_tokens
                self.global_step += 1
                yield tensor_batch, batch_meta

            # Advance to next shard
            self.current_shard_idx += 1
            self.current_token_offset = 0

        # Epoch completed
        self.epoch += 1
        self.current_shard_idx = 0
        self.current_token_offset = 0


# ============================================================================
# 7. PHYSICAL STORAGE ACCOUNTING (200B - 500B TOKENS)
# ============================================================================

def calculate_physical_storage_accounting(
    token_count: int,
    bytes_per_token_raw: float = 4.2,
    bytes_per_token_clean: float = 3.8,
) -> Dict[str, Any]:
    """
    Rigorous physical disk storage calculations.
    Distinguishes Token Count from Physical Storage Bytes across all lifecycle stages.
    """
    # 1. Raw Text: ~4.2 bytes per token (including markup, JSON formatting, spaces)
    raw_text_bytes = int(token_count * bytes_per_token_raw)
    raw_text_gb = raw_text_bytes / (1024 ** 3)
    raw_text_tb = raw_text_gb / 1024

    # 2. Clean Text: ~3.8 bytes per token (post-normalization & duplicate removal)
    clean_text_bytes = int(token_count * bytes_per_token_clean)
    clean_text_gb = clean_text_bytes / (1024 ** 3)
    clean_text_tb = clean_text_gb / 1024

    # 3. Tokenized Binary (uint16 format = exactly 2 bytes per token ID)
    tokenized_bin_bytes = token_count * 2
    tokenized_bin_gb = tokenized_bin_bytes / (1024 ** 3)
    tokenized_bin_tb = tokenized_bin_gb / 1024

    # 4. Offset Indexes & Manifests (~24 bytes per document; ~500 tokens/doc -> 0.05 bytes/token)
    index_manifest_bytes = int(token_count * 0.05)
    index_manifest_gb = index_manifest_bytes / (1024 ** 3)

    # 5. Temporary Preprocessing & Sort Buffers (~0.5x clean text)
    temp_buffers_bytes = int(clean_text_bytes * 0.5)
    temp_buffers_gb = temp_buffers_bytes / (1024 ** 3)

    # Total physical storage requirement for production cluster
    total_pipeline_bytes = raw_text_bytes + clean_text_bytes + tokenized_bin_bytes + index_manifest_bytes + temp_buffers_bytes
    total_pipeline_tb = total_pipeline_bytes / (1024 ** 4)

    return {
        "target_tokens": token_count,
        "tokens_formatted": f"{token_count / 1e9:.1f} Billion Tokens",
        "raw_text_storage": {
            "bytes": raw_text_bytes,
            "gigabytes": round(raw_text_gb, 2),
            "terabytes": round(raw_text_tb, 3),
            "assumed_bytes_per_token": bytes_per_token_raw,
        },
        "clean_text_storage": {
            "bytes": clean_text_bytes,
            "gigabytes": round(clean_text_gb, 2),
            "terabytes": round(clean_text_tb, 3),
            "assumed_bytes_per_token": bytes_per_token_clean,
        },
        "tokenized_binary_storage_uint16": {
            "bytes": tokenized_bin_bytes,
            "gigabytes": round(tokenized_bin_gb, 2),
            "terabytes": round(tokenized_bin_tb, 3),
            "bytes_per_token": 2.0,
        },
        "indexing_and_manifests_storage": {
            "bytes": index_manifest_bytes,
            "gigabytes": round(index_manifest_gb, 2),
        },
        "temp_preprocessing_buffers": {
            "bytes": temp_buffers_bytes,
            "gigabytes": round(temp_buffers_gb, 2),
        },
        "total_production_cluster_disk_required_tb": round(total_pipeline_tb, 3),
        "pure_tokenized_dataset_disk_gb": round(tokenized_bin_gb, 2),
    }


# ============================================================================
# 8. AUTOMATED DATASET COMPLETENESS GATE
# ============================================================================

def evaluate_dataset_completeness_gate(
    actual_verified_tokens: int,
    required_tokens: int = 200_000_000_000,
    zero_leakage_passed: bool = True,
    all_shards_verified: bool = True,
    manifest_hashes_match: bool = True,
) -> Dict[str, Any]:
    """
    Automated pre-flight launch gate evaluating physical dataset volume and integrity:
    Only PASS when:
    1. actual_verified_tokens >= required_tokens (200B)
    2. zero exact train/val/test leakage
    3. all shards verify correctly
    4. dataset manifest hashes match
    """
    token_deficit = max(0, required_tokens - actual_verified_tokens)
    volume_passed = actual_verified_tokens >= required_tokens

    all_criteria_met = (
        volume_passed
        and zero_leakage_passed
        and all_shards_verified
        and manifest_hashes_match
    )

    if all_criteria_met:
        status = "READY"
        verdict = "READY FOR PRODUCTION TRAINING"
    elif zero_leakage_passed and all_shards_verified and manifest_hashes_match:
        status = "PARTIALLY READY"
        verdict = (
            f"PARTIALLY READY -- DATASET VOLUME GAP: Complete pipeline, cleaning, deduplication, "
            f"sharding, streaming, and verification systems are verified. Staged verified tokens = "
            f"{actual_verified_tokens:,} vs required {required_tokens:,} (Deficit: {token_deficit:,} tokens)."
        )
    else:
        status = "NOT READY"
        verdict = "NOT READY -- CRITICAL DATA INTEGRITY OR CORRUPTION FAILURES DETECTED"

    return {
        "required_tokens": required_tokens,
        "actual_verified_tokens": actual_verified_tokens,
        "token_deficit": token_deficit,
        "completion_percentage": round((actual_verified_tokens / required_tokens) * 100, 6),
        "volume_gate_passed": volume_passed,
        "zero_leakage_passed": zero_leakage_passed,
        "shards_verified_passed": all_shards_verified,
        "manifest_integrity_passed": manifest_hashes_match,
        "readiness_status": status,
        "final_gate_verdict": verdict,
    }
