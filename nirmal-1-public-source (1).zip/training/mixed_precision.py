"""
Mixed Precision Training Manager for Nirmal-1 V8.
Supports:
1. Native BF16 autocast (recommended for modern accelerators: H100, A100)
2. FP16 autocast with dynamic GradScaler
3. FP32 master weight updates
4. Automatic NaN / Inf gradient detection and step suppression
"""

from contextlib import nullcontext
from typing import Any, Dict, Optional, Tuple
import torch
from torch.cuda.amp import GradScaler


class MixedPrecisionManager:
    """
    Orchestrates precision casting and gradient scaling for large-scale training.
    """

    def __init__(
        self,
        precision: str = "bf16",
        device_type: str = "cpu",
        init_scale: float = 65536.0,
        growth_factor: float = 2.0,
        backoff_factor: float = 0.5,
        growth_interval: int = 2000,
    ):
        self.precision = precision.lower()
        self.device_type = device_type

        # Configure autocast dtype
        if self.precision == "bf16":
            self.autocast_dtype = torch.bfloat16
            self.use_scaler = False
            self.scaler = None
        elif self.precision == "fp16":
            self.autocast_dtype = torch.float16
            self.use_scaler = (device_type == "cuda")
            self.scaler = GradScaler(
                init_scale=init_scale,
                growth_factor=growth_factor,
                backoff_factor=backoff_factor,
                growth_interval=growth_interval,
            ) if self.use_scaler else None
        elif self.precision == "fp32":
            self.autocast_dtype = torch.float32
            self.use_scaler = False
            self.scaler = None
        else:
            raise ValueError(f"Unknown precision: {precision}. Choose 'bf16', 'fp16', or 'fp32'.")

    def autocast(self):
        """Returns the appropriate autocast context manager."""
        if self.precision in ("bf16", "fp16") and self.device_type in ("cuda", "cpu"):
            return torch.autocast(device_type=self.device_type, dtype=self.autocast_dtype)
        return nullcontext()

    def backward(self, loss: torch.Tensor) -> None:
        """Executes backward pass with gradient scaling if applicable."""
        if self.use_scaler and self.scaler is not None:
            self.scaler.scale(loss).backward()
        else:
            loss.backward()

    def step(self, optimizer: torch.optim.Optimizer, max_grad_norm: Optional[float] = 1.0) -> bool:
        """
        Executes optimizer step with unscaling, gradient clipping, and NaN/Inf detection.
        Returns True if step was successfully taken, False if skipped due to Inf/NaN.
        """
        if self.use_scaler and self.scaler is not None:
            if max_grad_norm is not None:
                self.scaler.unscale_(optimizer)
                # Check for NaNs/Infs in parameters
                has_nan_or_inf = False
                for group in optimizer.param_groups:
                    for p in group["params"]:
                        if p.grad is not None:
                            if torch.isnan(p.grad).any() or torch.isinf(p.grad).any():
                                has_nan_or_inf = True
                                break
                    if has_nan_or_inf:
                        break

                if has_nan_or_inf:
                    self.scaler.update()
                    optimizer.zero_grad(set_to_none=True)
                    return False

                torch.nn.utils.clip_grad_norm_(
                    [p for group in optimizer.param_groups for p in group["params"] if p.grad is not None],
                    max_grad_norm,
                )

            self.scaler.step(optimizer)
            self.scaler.update()
            return True
        else:
            if max_grad_norm is not None:
                params = [p for group in optimizer.param_groups for p in group["params"] if p.grad is not None]
                if params:
                    # Check for NaNs/Infs
                    for p in params:
                        if torch.isnan(p.grad).any() or torch.isinf(p.grad).any():
                            optimizer.zero_grad(set_to_none=True)
                            return False
                    torch.nn.utils.clip_grad_norm_(params, max_grad_norm)

            optimizer.step()
            return True
