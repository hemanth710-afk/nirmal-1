"""
Checkpointing management system for Nirmal-1:
- Atomic save operations
- Automatic checkpoint rotation
- Complete state restoration (model, optimizer, scheduler, RNG, configuration)
"""

import json
from pathlib import Path
import shutil
import time
from typing import Any, Dict, List, Optional, Union
import torch

from nirmal.configuration_nirmal import NirmalConfig
from nirmal.model import NirmalForCausalLM


class CheckpointManager:
    """Manages saving, rotating, and loading model training checkpoints."""

    def __init__(self, save_dir: Union[str, Path], max_to_keep: int = 3):
        self.save_dir = Path(save_dir)
        self.save_dir.mkdir(parents=True, exist_ok=True)
        self.max_to_keep = max_to_keep

    def save(
        self,
        model: NirmalForCausalLM,
        optimizer: Optional[torch.optim.Optimizer] = None,
        scheduler: Optional[Any] = None,
        step: int = 0,
        epoch: int = 0,
        loss: float = 0.0,
        prefix: str = "checkpoint",
    ) -> Path:
        """Atomically saves checkpoint and updates metadata."""
        ckpt_name = f"{prefix}_step_{step}"
        ckpt_dir = self.save_dir / ckpt_name
        tmp_dir = self.save_dir / f".tmp_{ckpt_name}_{int(time.time())}"
        tmp_dir.mkdir(parents=True, exist_ok=True)

        try:
            # 1. Save model weights
            torch.save(model.state_dict(), tmp_dir / "model.pt")

            # 2. Save optimizer & scheduler state if present
            training_state = {
                "step": step,
                "epoch": epoch,
                "loss": loss,
                "rng_state": torch.get_rng_state(),
            }
            if optimizer is not None:
                training_state["optimizer"] = optimizer.state_dict()
            if scheduler is not None:
                training_state["scheduler"] = scheduler.state_dict()
            torch.save(training_state, tmp_dir / "training_state.pt")

            # 3. Save model configuration as readable JSON
            model.config.to_json_file(tmp_dir / "config.json")

            # Move temp directory to final destination atomically
            if ckpt_dir.exists():
                shutil.rmtree(ckpt_dir)
            tmp_dir.rename(ckpt_dir)

            # 4. Rotate old checkpoints
            self._rotate_checkpoints(prefix)

            return ckpt_dir
        except Exception:
            if tmp_dir.exists():
                shutil.rmtree(tmp_dir)
            raise

    def _rotate_checkpoints(self, prefix: str) -> None:
        """Prunes checkpoints exceeding max_to_keep."""
        ckpts = sorted(
            [d for d in self.save_dir.iterdir() if d.is_dir() and d.name.startswith(f"{prefix}_step_")],
            key=lambda d: d.stat().st_mtime,
        )
        while len(ckpts) > self.max_to_keep:
            oldest = ckpts.pop(0)
            shutil.rmtree(oldest, ignore_errors=True)

    def get_latest_checkpoint(self, prefix: str = "checkpoint") -> Optional[Path]:
        """Returns path to the newest checkpoint."""
        ckpts = sorted(
            [d for d in self.save_dir.iterdir() if d.is_dir() and d.name.startswith(f"{prefix}_step_")],
            key=lambda d: d.stat().st_mtime,
        )
        return ckpts[-1] if ckpts else None

    def load(
        self,
        checkpoint_dir: Union[str, Path],
        model: NirmalForCausalLM,
        optimizer: Optional[torch.optim.Optimizer] = None,
        scheduler: Optional[Any] = None,
    ) -> Dict[str, Any]:
        """Restores model and optional training state from a checkpoint directory."""
        ckpt_dir = Path(checkpoint_dir)
        if not ckpt_dir.exists():
            raise FileNotFoundError(f"Checkpoint directory {ckpt_dir} does not exist.")

        # Load weights
        model_path = ckpt_dir / "model.pt"
        state_dict = torch.load(model_path, map_location="cpu")
        model.load_state_dict(state_dict)

        meta = {}
        state_path = ckpt_dir / "training_state.pt"
        if state_path.exists():
            training_state = torch.load(state_path, map_location="cpu")
            if optimizer is not None and "optimizer" in training_state:
                optimizer.load_state_dict(training_state["optimizer"])
            if scheduler is not None and "scheduler" in training_state:
                scheduler.load_state_dict(training_state["scheduler"])
            if "rng_state" in training_state:
                torch.set_rng_state(training_state["rng_state"])
            meta = {
                "step": training_state.get("step", 0),
                "epoch": training_state.get("epoch", 0),
                "loss": training_state.get("loss", 0.0),
            }

        return meta
