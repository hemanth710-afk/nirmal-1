"""
NIRMAL-1 V8.8 PILOT SOURCE ADAPTER CONTRACT & PIPELINE WITH PROVENANCE TRUTH

Defines the common interface for bounded acquisition pilots:
  - inspect()
  - prepare_pilot()
  - acquire_pilot()
  - verify_pilot()
  - finalize_pilot()

And implements the complete multi-stage pipeline:
  SOURCE -> Bounded Acquisition -> Provenance -> Normalization -> Quality Filter
         -> CodeSafetyScanner -> Exact Dedup -> Near Dedup -> Decontamination
         -> Split Isolation -> Tokenizer -> Binary Shard -> Manifest -> Accounting
         -> Cryptographic Trace -> Safe Provenance Storage

Hard Safety Limits Enforced:
  - max_documents: 100 (Remote bounded default: 5)
  - max_download_bytes: 1,048,576 (1 MB; Remote bounded limit: 512 KB)
  - max_accepted_tokens: 100,000
  - max_temp_disk_bytes: 104,857,600 (100 MB)
  - Absolute prohibition on production directory writes (data/shards)
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field, asdict
import hashlib
import json
import os
from pathlib import Path
import shutil
import time
from typing import Any, Dict, Generator, List, Optional, Tuple

import numpy as np

from training.v8_2_data_engine import ProductionDocument, ProvenanceMetadata
from training.v8_4_code_safety import CodeSafetyScanner, CodeSafetyConfig, ScannerAction
from training.v8_4_decontamination import NgramDecontaminationEngine
from training.v8_4_global_dedup import ProductionDeduplicationPipeline
from training.v8_4_ingestion import StreamingIngestionEngine
from training.v8_4_tokenization import ProductionTokenizationPipeline, EXPECTED_TOKENIZER_CHECKSUM
from training.acquisition.pilot_accounting import PilotAccountingTracker, AccountingConservationError
from training.acquisition.pilot_manifest import PilotManifestManager, DocumentProvenanceEntry
from training.acquisition.safe_network_client import (
    SafeBoundedNetworkClient,
    SafeFetchResult,
    NetworkSecurityError,
    BoundedPayloadError,
)
from training.acquisition.pilot_provenance_audit import (
    PilotProvenanceClass,
    PilotProvenanceAuditor,
    PilotDocumentAuditEntry,
    DocumentTraceStep,
    ProvenanceVerificationError,
    PROVENANCE_DIR,
)

REPO_ROOT = Path(__file__).resolve().parent.parent.parent
PILOT_DIR = REPO_ROOT / "data" / "pilot"
PILOT_STAGING_DIR = PILOT_DIR / "staging"
PILOT_SHARDS_DIR = PILOT_DIR / "shards"
PILOT_MANIFESTS_DIR = PILOT_DIR / "manifests"
PILOT_PROVENANCE_DIR = PILOT_DIR / "provenance"
CONFIG_PATH = PILOT_DIR / "acquisition_pilot_config.json"
ELIGIBILITY_PATH = REPO_ROOT / "data" / "source_evidence" / "source_eligibility_matrix.json"

FORBIDDEN_DIRS = [
    REPO_ROOT / "data" / "shards",
    REPO_ROOT / "src" / "nirmal",
]


class PilotLimitExceededError(Exception):
    """Raised when any hard pilot resource ceiling is breached."""
    pass


class PilotSecurityError(Exception):
    """Raised when an unauthorized source or illegal operation is attempted."""
    pass


class PilotIntegrityError(Exception):
    """Raised when a checksum or content validation fails."""
    pass


@dataclass
class PilotResult:
    source_id: str
    version: str
    revision: str
    bytes_downloaded: int = 0
    documents_discovered: int = 0
    documents_accepted: int = 0
    documents_rejected: int = 0
    tokens_before_filter: int = 0
    tokens_after_filter: int = 0
    dedup_removed: int = 0
    contamination_removed: int = 0
    security_removed: int = 0
    quality_removed: int = 0
    checksum: str = ""
    manifest_path: str = ""
    status: str = "PENDING"
    error_message: Optional[str] = None
    provenance_class: str = "UNKNOWN"
    is_genuine_remote: bool = False
    provenance_path: str = ""
    trace_path: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


class PilotSourceAdapter(ABC):
    """Abstract base contract for all bounded source acquisition adapters."""

    def __init__(
        self,
        source_id: str,
        config_path: Optional[Path] = None,
        staging_dir: Optional[Path] = None,
        shards_dir: Optional[Path] = None,
        manifests_dir: Optional[Path] = None,
        provenance_dir: Optional[Path] = None,
    ):
        self.source_id = source_id
        self.config_path = config_path or CONFIG_PATH
        self.staging_dir = staging_dir or PILOT_STAGING_DIR
        self.shards_dir = shards_dir or PILOT_SHARDS_DIR
        self.manifests_dir = manifests_dir or PILOT_MANIFESTS_DIR
        self.provenance_dir = provenance_dir or PILOT_PROVENANCE_DIR

        # Load limits
        self._load_config()

        # Initialize pipeline components
        self.code_safety_scanner = CodeSafetyScanner()
        self.decontamination_engine = NgramDecontaminationEngine()
        self.dedup_pipeline = ProductionDeduplicationPipeline(jaccard_threshold=0.85)
        self.ingestion_engine = StreamingIngestionEngine(
            code_safety_scanner=self.code_safety_scanner,
            decontamination_engine=self.decontamination_engine,
        )
        self.tokenization_pipeline = ProductionTokenizationPipeline(enforce_checksum=True)
        self.manifest_manager = PilotManifestManager(self.manifests_dir)
        self.provenance_auditor = PilotProvenanceAuditor(self.provenance_dir)

    def _load_config(self):
        if self.config_path.exists():
            with open(self.config_path, "r", encoding="utf-8") as f:
                cfg = json.load(f)
            limits = cfg.get("hard_limits", {})
            self.max_docs = limits.get("max_documents", 100)
            self.max_bytes = limits.get("max_download_bytes", 1048576)
            self.max_tokens = limits.get("max_accepted_tokens", 100000)
            self.max_disk = limits.get("max_temp_disk_bytes", 104857600)
        else:
            self.max_docs = 100
            self.max_bytes = 1048576
            self.max_tokens = 100000
            self.max_disk = 104857600

    def check_eligibility(self):
        """Verifies that the source is officially PILOT_ELIGIBLE."""
        if not ELIGIBILITY_PATH.exists():
            raise PilotSecurityError(f"Source eligibility matrix not found at {ELIGIBILITY_PATH}")
        with open(ELIGIBILITY_PATH, "r", encoding="utf-8") as f:
            matrix = json.load(f)
        src_info = matrix.get("sources", {}).get(self.source_id)
        if not src_info:
            raise PilotSecurityError(f"Source '{self.source_id}' is not registered in eligibility matrix.")
        status = src_info.get("pilot_status")
        if status != "PILOT_ELIGIBLE":
            raise PilotSecurityError(
                f"Source '{self.source_id}' is NOT PILOT_ELIGIBLE (status: '{status}'). Pilot execution blocked."
            )

    def verify_destination_safety(self, destination: Path):
        """Ensures the pilot never writes into authoritative production directories."""
        dest_resolved = destination.resolve()
        for forbidden in FORBIDDEN_DIRS:
            forbidden_resolved = forbidden.resolve()
            if dest_resolved == forbidden_resolved or forbidden_resolved in dest_resolved.parents:
                raise PilotSecurityError(
                    f"CRITICAL SAFETY VIOLATION: Attempted to write pilot output to production directory '{dest_resolved}'!"
                )

    @abstractmethod
    def inspect(self) -> Dict[str, Any]:
        """Performs bounded remote or local metadata inspection (<= 500 KB)."""
        pass

    @abstractmethod
    def prepare_pilot(self) -> bool:
        """Prepares scratch directories, verifies disk space, and verifies source eligibility."""
        pass

    @abstractmethod
    def acquire_pilot(self) -> Tuple[List[Dict[str, Any]], int]:
        """Acquires bounded pilot sample within strict size ceilings."""
        pass

    @abstractmethod
    def verify_pilot(self, raw_records: List[Dict[str, Any]], raw_bytes: int) -> bool:
        """Verifies integrity, schemas, and resource bounds of acquired records."""
        pass

    @abstractmethod
    def finalize_pilot(self) -> PilotResult:
        """Executes full pipeline, creates binary shard, signs manifest, and verifies conservation."""
        pass


class WikipediaPilotAdapter(PilotSourceAdapter):
    """
    Production-grade pilot adapter for wikipedia_open_corpus.
    Supports real bounded remote acquisition from Wikimedia REST API,
    as well as bounded offline testing with explicit provenance truth.
    """

    DEFAULT_TOPICS = [
        "Quantum_computing",
        "Differential_geometry",
        "Photosynthesis",
        "Turing_machine",
        "Plate_tectonics",
    ]

    def __init__(
        self,
        use_remote_source: bool = True,
        **kwargs,
    ):
        super().__init__(source_id="wikipedia_open_corpus", **kwargs)
        self.use_remote_source = use_remote_source
        self.version = "2026.09"
        self.revision = "enwiki_20260901_pilot"
        self.run_id = f"pilot_{self.source_id}_{int(time.time())}"
        self.accounting = PilotAccountingTracker(source_id=self.source_id, pilot_run_id=self.run_id)
        self.network_client = SafeBoundedNetworkClient(
            max_doc_bytes=128 * 1024,
            max_total_bytes=512 * 1024,
            timeout_seconds=10.0,
            max_redirects=3,
        )

    def inspect(self) -> Dict[str, Any]:
        self.check_eligibility()
        return {
            "source_id": self.source_id,
            "version": self.version,
            "revision": self.revision,
            "format": "wikimedia_rest_v1_json",
            "pilot_status": "PILOT_ELIGIBLE",
            "use_remote_source": self.use_remote_source,
            "max_documents": self.max_docs,
            "max_download_bytes": self.max_bytes,
        }

    def prepare_pilot(self) -> bool:
        self.check_eligibility()
        self.verify_destination_safety(self.staging_dir)
        self.verify_destination_safety(self.shards_dir)
        self.verify_destination_safety(self.manifests_dir)
        self.verify_destination_safety(self.provenance_dir)

        self.staging_dir.mkdir(parents=True, exist_ok=True)
        self.shards_dir.mkdir(parents=True, exist_ok=True)
        self.manifests_dir.mkdir(parents=True, exist_ok=True)
        self.provenance_dir.mkdir(parents=True, exist_ok=True)

        # Check disk space limit
        total, used, free = shutil.disk_usage(self.staging_dir)
        if free < self.max_disk:
            raise PilotLimitExceededError(f"Insufficient disk space for staging: {free} < {self.max_disk}")

        return True

    def _generate_bounded_pilot_records(self) -> List[Dict[str, Any]]:
        """
        Generates realistic bounded Wikipedia article records conforming strictly
        to the MediaWiki dump schema. Strictly labeled SYNTHETIC_TEST_DATA.
        """
        articles = [
            {
                "id": "wiki_1001",
                "title": "Quantum Computing",
                "revision_id": "rev_99182736",
                "timestamp": "2026-09-01T12:00:00Z",
                "contributor": "PhysicsContributor",
                "url": "https://en.wikipedia.org/wiki/Quantum_Computing",
                "license": "CC-BY-SA-4.0",
                "text": (
                    "Quantum computing is a multidisciplinary field comprising aspects of computer science, "
                    "physics, and mathematics that utilizes quantum mechanics to solve complex problems faster "
                    "than classical computers. The field of quantum computing includes hardware research and "
                    "software development. Quantum computers utilize qubits, which can exist in superposition states, "
                    "enabling quantum algorithms such as Shor's algorithm and Grover's algorithm to achieve theoretical "
                    "speedups over best-known classical algorithms."
                ),
            },
            {
                "id": "wiki_1002",
                "title": "Differential Geometry",
                "revision_id": "rev_88291024",
                "timestamp": "2026-09-01T12:05:00Z",
                "contributor": "MathContributor",
                "url": "https://en.wikipedia.org/wiki/Differential_Geometry",
                "license": "CC-BY-SA-4.0",
                "text": (
                    "Differential geometry is a mathematical discipline that studies the geometry of smooth shapes "
                    "and smooth spaces, otherwise known as smooth manifolds. It uses the techniques of differential "
                    "calculus, integral calculus, tensor calculus and linear algebra. The study of curves and surfaces "
                    "in three-dimensional Euclidean space formed the basis for the development of modern differential geometry "
                    "during the eighteenth and nineteenth centuries."
                ),
            },
            {
                "id": "wiki_1003",
                "title": "Photosynthesis",
                "revision_id": "rev_77382910",
                "timestamp": "2026-09-01T12:10:00Z",
                "contributor": "BioContributor",
                "url": "https://en.wikipedia.org/wiki/Photosynthesis",
                "license": "CC-BY-SA-4.0",
                "text": (
                    "Photosynthesis is a biological process used by plants, algae, and certain bacteria to convert light energy "
                    "into chemical energy. This chemical energy is stored in carbohydrate molecules, such as sugars, which are "
                    "synthesized from carbon dioxide and water. Photosynthesis is largely responsible for producing and maintaining "
                    "the oxygen content of the Earth's atmosphere, and supplies most of the biological energy necessary for complex life."
                ),
            },
            {
                "id": "wiki_1004",
                "title": "Turing Machine",
                "revision_id": "rev_66281903",
                "timestamp": "2026-09-01T12:15:00Z",
                "contributor": "CSContributor",
                "url": "https://en.wikipedia.org/wiki/Turing_Machine",
                "license": "CC-BY-SA-4.0",
                "text": (
                    "A Turing machine is a mathematical model of computation describing an abstract machine that manipulates "
                    "symbols on a strip of tape according to a table of rules. Despite the model's simplicity, it is capable "
                    "of implementing any computer algorithm. The machine operates on an infinite memory tape divided into discrete "
                    "cells, each of which can hold a single symbol from a finite alphabet."
                ),
            },
            {
                "id": "wiki_1005",
                "title": "Plate Tectonics",
                "revision_id": "rev_55192837",
                "timestamp": "2026-09-01T12:20:00Z",
                "contributor": "GeoContributor",
                "url": "https://en.wikipedia.org/wiki/Plate_Tectonics",
                "license": "CC-BY-SA-4.0",
                "text": (
                    "Plate tectonics is the generally accepted scientific theory that considers the Earth's lithosphere to comprise "
                    "a number of large tectonic plates which have been slowly moving since about 3.4 billion years ago. The model "
                    "builds on the concept of continental drift, an idea developed during the first decades of the twentieth century."
                ),
            },
        ]
        return articles

    def _acquire_remote_records(self) -> Tuple[List[Dict[str, Any]], int]:
        """
        Retrieves a genuine bounded sample of Wikipedia articles via the official
        Wikimedia REST API (https://en.wikipedia.org/api/rest_v1/page/summary/{title}).
        Enforces <= 5 documents and <= 512 KB payload.
        """
        records: List[Dict[str, Any]] = []
        total_downloaded_bytes = 0

        for title in self.DEFAULT_TOPICS:
            url = f"https://en.wikipedia.org/api/rest_v1/page/summary/{title}"
            dest_file = self.staging_dir / f"{self.run_id}_{title}.json"

            fetch_res = self.network_client.fetch_url_to_file(url, dest_file)
            total_downloaded_bytes += fetch_res.payload_bytes

            with open(dest_file, "r", encoding="utf-8") as f:
                data = json.load(f)

            raw_text = data.get("extract", "")
            page_id = str(data.get("pageid", title))
            rev_id = str(data.get("revision", "enwiki_rest_v1"))
            ts = data.get("timestamp", time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()))
            desktop_url = data.get("content_urls", {}).get("desktop", {}).get("page", f"https://en.wikipedia.org/wiki/{title}")

            records.append({
                "id": f"wiki_{page_id}",
                "title": data.get("title", title),
                "revision_id": rev_id,
                "timestamp": ts,
                "contributor": "Wikimedia Contributors",
                "url": desktop_url,
                "license": "CC-BY-SA-4.0",
                "text": raw_text,
                "raw_payload_hash": fetch_res.sha256_hash,
                "raw_bytes": fetch_res.payload_bytes,
                "provenance_class": PilotProvenanceClass.REMOTE_SOURCE_DATA,
                "is_network_retrieved": True,
                "is_local_fixture": False,
                "is_synthetic": False,
                "is_copied_from_repo": False,
            })

        return records, total_downloaded_bytes

    def _acquire_synthetic_records(self) -> Tuple[List[Dict[str, Any]], int]:
        """Generates synthetic test records when remote access is disabled."""
        raw_list = self._generate_bounded_pilot_records()
        records: List[Dict[str, Any]] = []
        total_bytes = 0
        for r in raw_list:
            text = r["text"]
            b_len = len(text.encode("utf-8"))
            total_bytes += b_len
            h = hashlib.sha256(text.encode("utf-8")).hexdigest()
            item = dict(r)
            item.update({
                "raw_payload_hash": h,
                "raw_bytes": b_len,
                "provenance_class": PilotProvenanceClass.SYNTHETIC_TEST_DATA,
                "is_network_retrieved": False,
                "is_local_fixture": False,
                "is_synthetic": True,
                "is_copied_from_repo": False,
            })
            records.append(item)
        return records, total_bytes

    def acquire_pilot(self) -> Tuple[List[Dict[str, Any]], int]:
        self.prepare_pilot()

        if self.use_remote_source:
            records, total_bytes = self._acquire_remote_records()
        else:
            records, total_bytes = self._acquire_synthetic_records()

        # Check ceilings before ingesting
        if len(records) > self.max_docs:
            raise PilotLimitExceededError(f"Document ceiling breached: {len(records)} > {self.max_docs}")
        if total_bytes > self.max_bytes:
            raise PilotLimitExceededError(f"Byte ceiling breached: {total_bytes} > {self.max_bytes}")

        return records, total_bytes

    def verify_pilot(self, raw_records: List[Dict[str, Any]], raw_bytes: int) -> bool:
        if raw_bytes > self.max_bytes:
            raise PilotLimitExceededError("Downloaded bytes exceed max limit.")
        if len(raw_records) > self.max_docs:
            raise PilotLimitExceededError("Discovered documents exceed max limit.")
        for r in raw_records:
            if not r.get("id") or not r.get("text"):
                raise PilotIntegrityError(f"Malformed record in pilot: {r}")
        return True

    def finalize_pilot(self, records_override: Optional[List[Dict[str, Any]]] = None) -> PilotResult:
        """
        Executes the full pipeline for the pilot batch, writing to data/pilot/shards/,
        emitting immutable pilot manifest, machine trace, and safe provenance records.
        """
        self.prepare_pilot()

        if records_override is not None:
            raw_records = records_override
            raw_bytes = sum(len(r["text"].encode("utf-8")) for r in raw_records)
            # Default to local fixture / synthetic if not specified in override
            for r in raw_records:
                if "provenance_class" not in r:
                    r["provenance_class"] = PilotProvenanceClass.LOCAL_FIXTURE
                    r["is_network_retrieved"] = False
                    r["is_local_fixture"] = True
                if "raw_payload_hash" not in r:
                    r["raw_payload_hash"] = hashlib.sha256(r["text"].encode("utf-8")).hexdigest()
                if "raw_bytes" not in r:
                    r["raw_bytes"] = len(r["text"].encode("utf-8"))
        else:
            raw_records, raw_bytes = self.acquire_pilot()

        self.verify_pilot(raw_records, raw_bytes)

        # Stage raw batch into data/pilot/staging/
        staging_file = self.staging_dir / f"{self.run_id}_raw.json"
        with open(staging_file, "w", encoding="utf-8") as f:
            json.dump(raw_records, f, indent=2)
        raw_payload_hash = hashlib.sha256(staging_file.read_bytes()).hexdigest()

        # Track accounting and stage-by-stage provenance
        doc_provenance: List[DocumentProvenanceEntry] = []
        audit_entries: List[PilotDocumentAuditEntry] = []
        trace_steps: List[DocumentTraceStep] = []
        all_token_ids: List[int] = []

        is_all_remote = True

        for r in raw_records:
            doc_id = r["id"]
            text = r["text"]
            b_len = r.get("raw_bytes", len(text.encode("utf-8")))
            est_tokens = len(text.split())
            doc_raw_hash = r.get("raw_payload_hash", hashlib.sha256(text.encode("utf-8")).hexdigest())

            prov_class = r.get("provenance_class", PilotProvenanceClass.SYNTHETIC_TEST_DATA)
            if prov_class != PilotProvenanceClass.REMOTE_SOURCE_DATA:
                is_all_remote = False

            self.accounting.record_discovery(raw_bytes=b_len, estimated_tokens=est_tokens)

            # 1. Normalization
            norm_text = self.ingestion_engine.normalize_text(text)
            doc_hash = hashlib.sha256(norm_text.encode("utf-8")).hexdigest()
            norm_b_len = len(norm_text.encode("utf-8"))

            quality_dec = "PASS"
            security_dec = "PASS"
            dedup_dec = "PASS"
            contamination_dec = "PASS"

            # 2. Quality Filter
            is_retained, qual_reason = self.ingestion_engine.filter_document(norm_text)
            if not is_retained:
                rej_stage = "quality"
                if qual_reason == "credential_secret_detected":
                    rej_stage = "security"
                    security_dec = "REJECTED_SECRET"
                elif qual_reason == "benchmark_contamination_detected":
                    rej_stage = "contamination"
                    contamination_dec = "REJECTED_CONTAMINATION"
                else:
                    quality_dec = f"REJECTED_{qual_reason}"

                self.accounting.record_rejection(
                    doc_id=doc_id,
                    stage=rej_stage,
                    reason=qual_reason or "quality_rejected",
                    char_length=len(text),
                    estimated_tokens=est_tokens,
                    safe_meta={"title": r.get("title", "")},
                )
                trace_steps.append(DocumentTraceStep(
                    doc_id=doc_id,
                    raw_source_bytes=b_len,
                    raw_payload_hash=doc_raw_hash,
                    normalized_byte_count=norm_b_len,
                    document_hash=doc_hash,
                    quality_decision=quality_dec,
                    security_decision=security_dec,
                    dedup_decision="SKIPPED",
                    contamination_decision="SKIPPED",
                    token_count=0,
                    shard_hash="NONE_REJECTED",
                ))
                continue

            # 3. Code Safety / Secrets Scan
            scan_res = self.code_safety_scanner.scan_text(norm_text)
            if scan_res.action != ScannerAction.ALLOW:
                security_dec = f"REJECTED_{scan_res.action.value}"
                self.accounting.record_rejection(
                    doc_id=doc_id,
                    stage="security",
                    reason=f"security_violation: {scan_res.action.value}",
                    char_length=len(text),
                    estimated_tokens=est_tokens,
                    safe_meta={"title": r.get("title", "")},
                )
                trace_steps.append(DocumentTraceStep(
                    doc_id=doc_id,
                    raw_source_bytes=b_len,
                    raw_payload_hash=doc_raw_hash,
                    normalized_byte_count=norm_b_len,
                    document_hash=doc_hash,
                    quality_decision=quality_dec,
                    security_decision=security_dec,
                    dedup_decision="SKIPPED",
                    contamination_decision="SKIPPED",
                    token_count=0,
                    shard_hash="NONE_REJECTED",
                ))
                continue

            # 4. Global Exact & Near Deduplication
            is_retained_dedup, dedup_reason, sim = self.dedup_pipeline.process_document(norm_text, doc_id=doc_id)
            if not is_retained_dedup:
                dedup_dec = f"REJECTED_{dedup_reason}"
                self.accounting.record_rejection(
                    doc_id=doc_id,
                    stage="dedup",
                    reason=dedup_reason or "duplicate_rejected",
                    char_length=len(text),
                    estimated_tokens=est_tokens,
                    safe_meta={"title": r.get("title", "")},
                )
                trace_steps.append(DocumentTraceStep(
                    doc_id=doc_id,
                    raw_source_bytes=b_len,
                    raw_payload_hash=doc_raw_hash,
                    normalized_byte_count=norm_b_len,
                    document_hash=doc_hash,
                    quality_decision=quality_dec,
                    security_decision=security_dec,
                    dedup_decision=dedup_dec,
                    contamination_decision="SKIPPED",
                    token_count=0,
                    shard_hash="NONE_REJECTED",
                ))
                continue

            # 5. Benchmark Decontamination
            decontam_res = self.decontamination_engine.query_document(norm_text)
            if not decontam_res.is_clean:
                contamination_dec = f"REJECTED_{decontam_res.highest_match_type.value}"
                self.accounting.record_rejection(
                    doc_id=doc_id,
                    stage="contamination",
                    reason=f"benchmark_contamination_{decontam_res.highest_match_type.value}",
                    char_length=len(text),
                    estimated_tokens=est_tokens,
                    safe_meta={"title": r.get("title", "")},
                )
                trace_steps.append(DocumentTraceStep(
                    doc_id=doc_id,
                    raw_source_bytes=b_len,
                    raw_payload_hash=doc_raw_hash,
                    normalized_byte_count=norm_b_len,
                    document_hash=doc_hash,
                    quality_decision=quality_dec,
                    security_decision=security_dec,
                    dedup_decision=dedup_dec,
                    contamination_decision=contamination_dec,
                    token_count=0,
                    shard_hash="NONE_REJECTED",
                ))
                continue

            # 6. Tokenization
            tok_ids, tok_meta = self.tokenization_pipeline.encode_document(norm_text)
            token_count = len(tok_ids)

            # Check token limit
            if (self.accounting.accepted_tokens + token_count) > self.max_tokens:
                raise PilotLimitExceededError(
                    f"Token ceiling breached! {self.accounting.accepted_tokens + token_count} > {self.max_tokens}"
                )

            # Record Acceptance
            self.accounting.record_acceptance(norm_tokens=token_count, shard_tokens=token_count)
            all_token_ids.extend(tok_ids)

            entry = DocumentProvenanceEntry(
                doc_id=doc_id,
                sha256=doc_hash,
                token_count=token_count,
                title=r.get("title", ""),
                canonical_url=r.get("url", ""),
                source_revision=str(r.get("revision_id", self.revision)),
                license_tag=r.get("license", "CC-BY-SA-4.0"),
                accepted_timestamp=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            )
            doc_provenance.append(entry)

            audit_entry = PilotDocumentAuditEntry(
                document_hash=doc_hash,
                source_id=self.source_id,
                provenance_class=prov_class,
                canonical_source=self.source_id,
                source_url=r.get("url", ""),
                source_revision=str(r.get("revision_id", self.revision)),
                retrieval_timestamp=r.get("timestamp", time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())),
                raw_byte_count=b_len,
                normalized_byte_count=norm_b_len,
                token_count=token_count,
                adapter_identifier="WikipediaPilotAdapter",
                pipeline_version="V8.8",
                acquisition_record_id=self.run_id,
                raw_payload_hash=doc_raw_hash,
                is_network_retrieved=r.get("is_network_retrieved", False),
                is_local_fixture=r.get("is_local_fixture", False),
                is_synthetic=r.get("is_synthetic", False),
                is_copied_from_repo=r.get("is_copied_from_repo", False),
            )
            audit_entries.append(audit_entry)

            trace_steps.append(DocumentTraceStep(
                doc_id=doc_id,
                raw_source_bytes=b_len,
                raw_payload_hash=doc_raw_hash,
                normalized_byte_count=norm_b_len,
                document_hash=doc_hash,
                quality_decision=quality_dec,
                security_decision=security_dec,
                dedup_decision=dedup_dec,
                contamination_decision=contamination_dec,
                token_count=token_count,
                shard_hash="",  # Updated below
            ))

        # Verify Conservation
        is_conserved, msg = self.accounting.verify_conservation()
        if not is_conserved:
            raise AccountingConservationError(f"Pilot accounting conservation violated: {msg}")

        # Write binary shard to data/pilot/shards/ (NEVER data/shards/)
        shard_bin_path = self.shards_dir / f"{self.run_id}_tokens.bin"
        self.verify_destination_safety(shard_bin_path)

        token_arr = np.array(all_token_ids, dtype=np.uint16)
        token_arr.tofile(str(shard_bin_path))
        shard_hash = hashlib.sha256(shard_bin_path.read_bytes()).hexdigest()
        self.accounting.final_shard_bytes = shard_bin_path.stat().st_size

        # Update trace shard hashes
        for step in trace_steps:
            if step.shard_hash != "NONE_REJECTED":
                step.shard_hash = shard_hash

        # Pipeline Fingerprints
        tok_fingerprint = self.tokenization_pipeline.tokenizer.compute_checksum()
        config_fingerprint = hashlib.sha256(self.config_path.read_bytes()).hexdigest() if self.config_path.exists() else "default"

        evidence_refs = {
            "official_evidence_dir": "data/source_evidence/official/wikipedia_open_corpus",
            "eligibility_matrix": "data/source_evidence/source_eligibility_matrix.json",
            "provenance_dir": str(self.provenance_dir),
        }

        # Generate Manifest
        manifest_path = self.manifest_manager.generate_manifest(
            source_id=self.source_id,
            source_version=self.version,
            source_revision=self.revision,
            raw_payload_hash=raw_payload_hash,
            final_shard_hash=shard_hash,
            final_shard_path=str(shard_bin_path),
            document_entries=doc_provenance,
            accounting_dict=self.accounting.to_dict(),
            tokenizer_fingerprint=tok_fingerprint,
            pipeline_config_fingerprint=config_fingerprint,
            evidence_references=evidence_refs,
        )

        # Save Provenance Records & Machine Trace
        prov_file = self.provenance_auditor.save_provenance_record(
            source_id=self.source_id,
            entries=audit_entries,
            run_id=self.run_id,
        )
        trace_file = self.provenance_auditor.save_trace(
            source_id=self.source_id,
            steps=trace_steps,
            final_shard_hash=shard_hash,
        )

        # Cleanup Staging file atomically
        if staging_file.exists():
            staging_file.unlink()

        # Clean up individual fetched json files in staging
        for title in self.DEFAULT_TOPICS:
            t_file = self.staging_dir / f"{self.run_id}_{title}.json"
            if t_file.exists():
                try:
                    t_file.unlink()
                except OSError:
                    pass

        overall_prov = PilotProvenanceClass.REMOTE_SOURCE_DATA if is_all_remote and len(audit_entries) > 0 else (
            audit_entries[0].provenance_class if audit_entries else PilotProvenanceClass.SYNTHETIC_TEST_DATA
        )

        return PilotResult(
            source_id=self.source_id,
            version=self.version,
            revision=self.revision,
            bytes_downloaded=self.accounting.bytes_downloaded,
            documents_discovered=self.accounting.documents_discovered,
            documents_accepted=self.accounting.documents_accepted,
            documents_rejected=self.accounting.total_rejected,
            tokens_before_filter=self.accounting.source_tokens,
            tokens_after_filter=self.accounting.accepted_tokens,
            dedup_removed=self.accounting.rejected_dedup,
            contamination_removed=self.accounting.rejected_contamination,
            security_removed=self.accounting.rejected_security,
            quality_removed=self.accounting.rejected_quality,
            checksum=shard_hash,
            manifest_path=str(manifest_path),
            status="SUCCESS",
            provenance_class=overall_prov.value,
            is_genuine_remote=is_all_remote,
            provenance_path=str(prov_file),
            trace_path=str(trace_file),
        )
