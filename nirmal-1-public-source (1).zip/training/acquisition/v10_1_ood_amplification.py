"""
V10.1 — OOD Amplification & Scaling-Dose Engine.

Experiments:
  A: Training-budget dose response (5 budgets × 2 repr × 3 seeds)
  B: Multi-rule curriculum (3 compositions × value-relative × 3 seeds)
  C: Isomorphic OOD by vocab condition (same / partial / disjoint)

All experiments reuse the V10.0 TaskGenerator, leakage_certificate,
and NirmalForCausalLM without modifying src/nirmal/.
"""

import hashlib
import json
import time
from dataclasses import dataclass, asdict, field
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
import torch
import torch.nn.functional as F
import psutil

from nirmal.configuration_nirmal import NirmalConfig
from nirmal.model import NirmalForCausalLM
from training.acquisition.v10_0_intervention_engine import (
    TaskConfig, TaskGenerator, RepresentationTransform,
    ResourceGuard,
)

# ---------------------------------------------------------------------------
# Model builder (identical to V10.0, separate copy for isolation)
# ---------------------------------------------------------------------------

def build_model(hidden: int = 32, layers: int = 2, vocab: int = 100) -> NirmalForCausalLM:
    cfg = NirmalConfig(
        vocab_size=vocab, hidden_size=hidden,
        num_hidden_layers=layers, num_attention_heads=2,
        head_dim=hidden // 2, num_key_value_heads=1,
        num_experts=2, num_experts_per_tok=1, full_attention_interval=2,
    )
    return NirmalForCausalLM(cfg)


def acc(model: NirmalForCausalLM, data: torch.Tensor) -> float:
    model.eval()
    with torch.no_grad():
        out = model(input_ids=data, labels=data)
        p   = torch.argmax(out.logits, dim=-1)
        return (p[:, :-1] == data[:, 1:]).float().mean().item()


def apply_repr(x: torch.Tensor, mode: str, lo: int = 0, vocab: int = 100) -> torch.Tensor:
    if mode == "value_relative":
        return (x - lo).clamp(0, vocab - 1)
    if mode == "modular":
        return x % vocab
    return x  # identity


# ---------------------------------------------------------------------------
# Checkpoint record
# ---------------------------------------------------------------------------

@dataclass
class Checkpoint:
    step:      int
    loss:      float
    train_acc: float
    val_acc:   float
    ood_acc:   float
    ood_gap:   float   # val_acc - ood_acc


# ---------------------------------------------------------------------------
# Experiment A — Dose Response
# ---------------------------------------------------------------------------

BUDGETS = [100, 250, 500, 1000, 2000]
SEEDS   = [42, 43, 44]
EVAL_CHECKPOINTS = {0, 50, 100, 250, 500, 1000, 2000}


@dataclass
class DoseResult:
    repr_mode: str
    seed:      int
    max_steps: int
    checkpoints: List[Checkpoint] = field(default_factory=list)
    param_count: int = 0
    elapsed_s:   float = 0.0


def run_dose(repr_mode: str, max_steps: int, seed: int,
             task_cfg: TaskConfig, out_dir: Path) -> DoseResult:
    torch.manual_seed(seed)
    np.random.seed(seed)

    gen = TaskGenerator()
    splits = gen.generate(task_cfg)
    cert   = gen.leakage_certificate(splits)
    assert cert["valid"], f"Leakage detected for seed={seed}"

    lo  = task_cfg.train_vocab[0]
    olo = task_cfg.ood_vocab[0]

    train_x = apply_repr(splits["train"], repr_mode, lo).clamp(0, 99)
    val_x   = apply_repr(splits["val"],   repr_mode, lo).clamp(0, 99)
    ood_x   = apply_repr(splits["ood"],   repr_mode, olo).clamp(0, 99)

    model = build_model()
    opt   = torch.optim.AdamW(model.parameters(), lr=5e-3)
    param_count = sum(p.numel() for p in model.parameters())

    result = DoseResult(repr_mode=repr_mode, seed=seed, max_steps=max_steps,
                        param_count=param_count)
    t0 = time.time()

    for step in range(max_steps + 1):
        # Evaluate at checkpoints
        if step in EVAL_CHECKPOINTS or step == max_steps:
            t_a = acc(model, train_x)
            v_a = acc(model, val_x)
            o_a = acc(model, ood_x)

            model.eval()
            with torch.no_grad():
                loss_val = model(input_ids=train_x, labels=train_x).loss.item()

            result.checkpoints.append(Checkpoint(
                step=step, loss=round(loss_val, 4),
                train_acc=round(t_a, 4), val_acc=round(v_a, 4),
                ood_acc=round(o_a, 4),
                ood_gap=round(v_a - o_a, 4),
            ))

        if step == max_steps:
            break

        model.train()
        opt.zero_grad()
        out = model(input_ids=train_x, labels=train_x)
        out.loss.backward()
        opt.step()

    result.elapsed_s = round(time.time() - t0, 2)

    # Save manifest
    out_dir.mkdir(parents=True, exist_ok=True)
    ts = int(time.time())
    manifest = {
        "experiment": "A_dose",
        "repr_mode": repr_mode, "seed": seed, "max_steps": max_steps,
        "param_count": param_count,
        "task_cfg": asdict(task_cfg) if hasattr(task_cfg, '__dataclass_fields__') else str(task_cfg),
        "leakage_certificate": cert,
        "checkpoints": [asdict(c) for c in result.checkpoints],
        "elapsed_s": result.elapsed_s,
        "timestamp": ts,
    }
    with open(out_dir / f"dose_{repr_mode}_s{seed}_n{max_steps}_{ts}.json", "w") as f:
        json.dump(manifest, f, indent=2)

    return result


# ---------------------------------------------------------------------------
# Experiment B — Multi-Rule Curriculum
# ---------------------------------------------------------------------------

CURRICULUM_RULES = {
    "B1_COPY":       ["copy"],
    "B2_COPY_INC":   ["copy", "increment"],
    "B3_COPY_INC_DS":["copy", "increment", "double_step"],
}


@dataclass
class CurriculumResult:
    curriculum: str
    seed:       int
    train_acc:  float
    val_acc:    float
    ood_acc:    float
    loss:       float


def run_curriculum(curriculum_name: str, rules: List[str], seed: int,
                   out_dir: Path, steps_per_rule: int = 333) -> CurriculumResult:
    torch.manual_seed(seed)
    np.random.seed(seed)

    gen = TaskGenerator()
    model = build_model()
    opt   = torch.optim.AdamW(model.parameters(), lr=5e-3)

    all_train, all_val, all_ood = [], [], []
    base_task = TaskConfig(
        rule="copy", seq_len=4,
        train_vocab=(10, 35), val_vocab=(10, 35),
        ood_vocab=(60, 85), batch_size=8, seed=seed,
    )

    for rule_idx, rule in enumerate(rules):
        task = TaskConfig(
            rule=rule, seq_len=4,
            train_vocab=(10, 35), val_vocab=(10, 35),
            ood_vocab=(60, 85), batch_size=8,
            seed=seed + rule_idx * 100,
        )
        splits = gen.generate(task)
        lo, olo = task.train_vocab[0], task.ood_vocab[0]
        all_train.append(apply_repr(splits["train"], "value_relative", lo).clamp(0, 99))
        all_val.append  (apply_repr(splits["val"],   "value_relative", lo).clamp(0, 99))
        all_ood.append  (apply_repr(splits["ood"],   "value_relative", olo).clamp(0, 99))

    # Train on each rule sequentially
    loss_val = float("inf")
    for rule_idx, train_data in enumerate(all_train):
        for step in range(steps_per_rule):
            model.train()
            opt.zero_grad()
            out = model(input_ids=train_data, labels=train_data)
            out.loss.backward()
            opt.step()
            loss_val = out.loss.item()

    # Evaluate on copy (first rule's partitions) as canonical metric
    t_a = acc(model, all_train[0])
    v_a = acc(model, all_val[0])
    o_a = acc(model, all_ood[0])

    result = CurriculumResult(
        curriculum=curriculum_name, seed=seed,
        train_acc=round(t_a, 4), val_acc=round(v_a, 4),
        ood_acc=round(o_a, 4), loss=round(loss_val, 4),
    )

    out_dir.mkdir(parents=True, exist_ok=True)
    ts = int(time.time())
    with open(out_dir / f"curriculum_{curriculum_name}_s{seed}_{ts}.json", "w") as f:
        json.dump(asdict(result), f, indent=2)

    return result


# ---------------------------------------------------------------------------
# Experiment C — Isomorphic OOD by Vocab Condition
# ---------------------------------------------------------------------------

VOCAB_CONDITIONS = {
    "SAME_VOCAB":    TaskConfig("increment", 3, (10, 30), (10, 30), (10, 30), 8, 200),
    "PARTIAL_DISJOINT": TaskConfig("increment", 3, (10, 30), (10, 30), (20, 40), 8, 201),
    "FULL_DISJOINT": TaskConfig("increment", 3, (10, 30), (10, 30), (60, 80), 8, 202),
}


@dataclass
class VocabCondResult:
    condition:  str
    seed:       int
    train_acc:  float
    val_acc:    float
    ood_acc:    float
    cert_valid: bool


def run_vocab_condition(cond_name: str, task_cfg: TaskConfig, seed: int,
                        out_dir: Path, steps: int = 500) -> VocabCondResult:
    torch.manual_seed(seed)
    np.random.seed(seed)

    gen = TaskGenerator()
    splits = gen.generate(task_cfg)
    cert   = gen.leakage_certificate(splits)

    lo  = task_cfg.train_vocab[0]
    olo = task_cfg.ood_vocab[0]

    train_x = apply_repr(splits["train"], "value_relative", lo).clamp(0, 99)
    val_x   = apply_repr(splits["val"],   "value_relative", lo).clamp(0, 99)
    ood_x   = apply_repr(splits["ood"],   "value_relative", olo).clamp(0, 99)

    model = build_model()
    opt   = torch.optim.AdamW(model.parameters(), lr=5e-3)

    for _ in range(steps):
        model.train()
        opt.zero_grad()
        model(input_ids=train_x, labels=train_x).loss.backward()
        opt.step()

    result = VocabCondResult(
        condition=cond_name, seed=seed,
        train_acc=round(acc(model, train_x), 4),
        val_acc  =round(acc(model, val_x),   4),
        ood_acc  =round(acc(model, ood_x),   4),
        cert_valid=cert["valid"],
    )

    out_dir.mkdir(parents=True, exist_ok=True)
    ts = int(time.time())
    with open(out_dir / f"vocab_{cond_name}_s{seed}_{ts}.json", "w") as f:
        json.dump(asdict(result), f, indent=2)

    return result


# ---------------------------------------------------------------------------
# Multi-seed aggregator
# ---------------------------------------------------------------------------

def aggregate(results: list, key: str) -> Tuple[float, float, float, float]:
    vals = [getattr(r, key) for r in results]
    return (
        round(float(np.mean(vals)), 4),
        round(float(np.std(vals)),  4),
        round(float(max(vals)),     4),
        round(float(min(vals)),     4),
    )
