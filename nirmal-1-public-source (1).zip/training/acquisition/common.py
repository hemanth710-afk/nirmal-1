"""
Common Infrastructure for Safe External Data Acquisition in Nirmal-1 V8.4.

Features:
- Bounded retry with exponential backoff.
- Free disk space validation (refuses execution when disk is low).
- Atomic staging: partial files (.tmp/.part) are NEVER exposed to authoritative dirs.
- Checksum validation: fails closed immediately on SHA-256 mismatch.
- Authoritative accounting: byte, document, token, duplicate, and rejection tallies.
- Immutable acquisition record generation in data/acquisition_records/.
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field, asdict
from enum import Enum
import hashlib
import json
import os
from pathlib import Path
import shutil
import time
from typing import Any, Callable, Dict, Generator, List, Optional, Tuple

REPO_ROOT = Path(__file__).resolve().parent.parent.parent
ACQUISITION_RECORDS_DIR = REPO_ROOT / "data" / "acquisition_records"
DEFAULT_STAGING_DIR = REPO_ROOT / "data" / "staging"
DEFAULT_SHARDS_DIR = REPO_ROOT / "data" / "shards"


class StagingSpaceError(Exception):
    """Raised when available disk space is insufficient for staging."""
    pass


class ChecksumMismatchError(Exception):
    """Raised when acquired content fails cryptographic SHA-256 verification."""
    pass


class SourceApprovalError(Exception):
    """Raised when an acquisition attempt is made on an unapproved source."""
    pass


@dataclass
class AcquisitionConfig:
    source_id: str
    target_revision: str
    canonical_url: str
    dry_run: bool = True
    max_retries: int = 3
    backoff_factor: float = 1.5
    expected_checksum: Optional[str] = None
    max_docs_to_acquire: Optional[int] = None
    min_free_disk_bytes: int = 10 * 1024 * 1024 * 1024  # 10 GB
    staging_dir: Path = field(default_factory=lambda: DEFAULT_STAGING_DIR)
    authoritative_dir: Path = field(default_factory=lambda: DEFAULT_SHARDS_DIR)


@dataclass
class AcquisitionResult:
    source_id: str
    success: bool
    dry_run: bool
    bytes_downloaded: int = 0
    documents_discovered: int = 0
    documents_accepted: int = 0
    documents_rejected: int = 0
    tokens_accepted: int = 0
    exact_dedup_removals: int = 0
    near_dedup_removals: int = 0
    secret_removals: int = 0
    contamination_removals: int = 0
    quality_removals: int = 0
    final_verified_token_count: int = 0
    artifact_hashes: Dict[str, str] = field(default_factory=dict)
    record_file_path: Optional[str] = None
    error_message: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


class AtomicStagingManager:
    """Manages scratch downloads with fail-closed atomic promotion."""

    def __init__(self, staging_dir: Path, authoritative_dir: Path):
        self.staging_dir = staging_dir
        self.authoritative_dir = authoritative_dir
        self.staging_dir.mkdir(parents=True, exist_ok=True)
        self.authoritative_dir.mkdir(parents=True, exist_ok=True)

    def get_staging_path(self, filename: str) -> Path:
        return self.staging_dir / f"{filename}.part"

    def promote_file(
        self,
        staging_path: Path,
        destination_filename: str,
        expected_sha256: Optional[str] = None,
    ) -> Path:
        """
        Atomically promotes a staged file to destination after verifying checksum.
        Cleans up staging file on failure.
        """
        if not staging_path.exists():
            raise FileNotFoundError(f"Staged file not found: {staging_path}")

        # 1. Compute and verify checksum
        computed_sha = hashlib.sha256(staging_path.read_bytes()).hexdigest()
        if expected_sha256 and computed_sha != expected_sha256:
            staging_path.unlink(missing_ok=True)
            raise ChecksumMismatchError(
                f"Checksum mismatch for '{destination_filename}'! "
                f"Expected: {expected_sha256}, Got: {computed_sha}"
            )

        # 2. Atomic promotion
        dest_path = self.authoritative_dir / destination_filename
        temp_dest = self.authoritative_dir / f".{destination_filename}.tmp"
        try:
            shutil.copy2(staging_path, temp_dest)
            os.replace(temp_dest, dest_path)
            staging_path.unlink(missing_ok=True)
        except Exception as e:
            if temp_dest.exists():
                temp_dest.unlink(missing_ok=True)
            raise e

        return dest_path

    def cleanup_staging(self, prefix: str = "") -> None:
        for p in self.staging_dir.glob(f"{prefix}*.part"):
            p.unlink(missing_ok=True)
        for p in self.staging_dir.glob(f"{prefix}*.tmp"):
            p.unlink(missing_ok=True)


class BaseAcquisitionAdapter(ABC):
    """
    Abstract base class for all safe production data acquisition adapters.
    """

    def __init__(self, config: AcquisitionConfig):
        self.config = config
        self.staging_mgr = AtomicStagingManager(config.staging_dir, config.authoritative_dir)
        ACQUISITION_RECORDS_DIR.mkdir(parents=True, exist_ok=True)

    def check_disk_space(self, required_bytes: int) -> None:
        """Refuses execution if free disk space is lower than required + margin."""
        stat = shutil.disk_usage(self.config.staging_dir)
        free_bytes = stat.free
        if free_bytes < (required_bytes + self.config.min_free_disk_bytes):
            raise StagingSpaceError(
                f"Insufficient disk space in '{self.config.staging_dir}'! "
                f"Free: {free_bytes / (1024**3):.2f} GB, Required: {required_bytes / (1024**3):.2f} GB "
                f"+ {self.config.min_free_disk_bytes / (1024**3):.2f} GB buffer."
            )

    def execute_with_retry(
        self,
        func: Callable[[], Any],
        operation_name: str,
    ) -> Any:
        """Executes a callable with bounded retry and exponential backoff."""
        attempt = 0
        backoff = 0.5
        while attempt < self.config.max_retries:
            try:
                return func()
            except Exception as e:
                attempt += 1
                if attempt >= self.config.max_retries:
                    raise RuntimeError(
                        f"Operation '{operation_name}' failed after {self.config.max_retries} attempts: {str(e)}"
                    ) from e
                time.sleep(backoff)
                backoff *= self.config.backoff_factor

    def save_acquisition_record(self, result: AcquisitionResult) -> Path:
        """Writes an immutable JSON audit record of the acquisition."""
        timestamp = time.strftime("%Y%m%dT%H%M%SZ", time.gmtime())
        record_filename = f"record_{self.config.source_id}_{timestamp}.json"
        p = ACQUISITION_RECORDS_DIR / record_filename

        record_data = {
            "source_id": self.config.source_id,
            "canonical_url": self.config.canonical_url,
            "target_revision": self.config.target_revision,
            "timestamp": timestamp,
            "dry_run": self.config.dry_run,
            "success": result.success,
            "accounting": {
                "bytes_downloaded": result.bytes_downloaded,
                "documents_discovered": result.documents_discovered,
                "documents_accepted": result.documents_accepted,
                "documents_rejected": result.documents_rejected,
                "tokens_accepted": result.tokens_accepted,
                "exact_dedup_removals": result.exact_dedup_removals,
                "near_dedup_removals": result.near_dedup_removals,
                "secret_removals": result.secret_removals,
                "contamination_removals": result.contamination_removals,
                "quality_removals": result.quality_removals,
                "final_verified_tokens": result.final_verified_token_count,
            },
            "artifact_hashes": result.artifact_hashes,
            "error_message": result.error_message,
        }

        with open(p, "w", encoding="utf-8") as f:
            json.dump(record_data, f, indent=2)

        result.record_file_path = str(p)
        return p

    @abstractmethod
    def acquire(self) -> AcquisitionResult:
        """Executes acquisition workflow (or dry-run simulation)."""
        pass
