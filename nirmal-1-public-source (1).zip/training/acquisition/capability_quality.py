import re
from typing import Dict, Any

class CapabilityQualityScorer:
    """
    Computes a deterministic capability-quality score based on observable properties.
    Does NOT use external LLMs. Does NOT measure 'intelligence'.
    """
    def __init__(self):
        pass

    def compute_score(self, text: str, metadata: Dict[str, Any] = None) -> float:
        if metadata is None:
            metadata = {}
            
        score = 0.0
        max_score = 5.0
        
        # 1. Length adequacy
        word_count = len(text.split())
        if word_count > 50:
            score += 1.0
        elif word_count > 10:
            score += 0.5
            
        # 2. Formatting quality (punctuation density)
        if len(text) > 0:
            punct_count = len(re.findall(r'[\.\,\!\?]', text))
            punct_ratio = punct_count / len(text)
            if 0.01 <= punct_ratio <= 0.1:
                score += 1.0
                
        # 3. Provenance completeness
        if metadata.get("provenance_class") == "REMOTE_SOURCE_DATA" and metadata.get("is_network_retrieved"):
            score += 1.0
            
        # 4. Security & Contamination Cleanliness (assuming pre-filtered if reached here, but can check metadata)
        if metadata.get("security_decision", "PASS") == "PASS":
            score += 1.0
            
        if metadata.get("contamination_decision", "PASS") == "PASS":
            score += 1.0
            
        # Normalize
        normalized_score = score / max_score
        return round(normalized_score, 3)

    def categorize_quality(self, score: float) -> str:
        if score >= 0.8: return "HIGH"
        if score >= 0.5: return "MEDIUM"
        return "LOW"
