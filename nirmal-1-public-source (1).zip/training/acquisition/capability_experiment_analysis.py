import numpy as np
from typing import Dict, List, Any

class ExperimentAnalyzer:
    """
    Analyzes the validity and sensitivity of empirical evaluations at the micro-scale.
    """
    def __init__(self):
        pass

    def compute_statistics(self, scores: List[float]) -> Dict[str, float]:
        if not scores:
            return {"mean": 0.0, "variance": 0.0, "floor": 0.0, "ceiling": 0.0}
        
        arr = np.array(scores)
        mean = np.mean(arr)
        variance = np.var(arr)
        floor = np.min(arr)
        ceiling = np.max(arr)
        return {
            "mean": float(mean),
            "variance": float(variance),
            "floor": float(floor),
            "ceiling": float(ceiling)
        }

    def compute_mde(self, baseline_scores: List[float], alpha: float = 0.05, power: float = 0.8) -> float:
        """
        Estimates the Minimum Detectable Effect (MDE).
        Simplified heuristic: MDE proportional to standard deviation.
        If variance is exactly 0.0, MDE is technically undefined (or requires absolute jump).
        """
        stats = self.compute_statistics(baseline_scores)
        std_dev = np.sqrt(stats["variance"])
        
        if std_dev == 0.0:
            return float('inf') # Unmeasurable through standard variance
            
        # Simplified multiplier for ~80% power at alpha=0.05
        multiplier = 2.8 
        return float(multiplier * std_dev)

    def classify_sensitivity(self, baseline: List[float], variant: List[float], known_difference: bool = False) -> str:
        """
        Classify metric sensitivity based on response to known differences and variance.
        Categories: SENSITIVE, WEAKLY_SENSITIVE, INSENSITIVE, UNMEASURABLE
        """
        b_stats = self.compute_statistics(baseline)
        v_stats = self.compute_statistics(variant)
        
        if b_stats["variance"] == 0.0 and v_stats["variance"] == 0.0 and b_stats["mean"] == v_stats["mean"]:
            return "UNMEASURABLE"
            
        diff = abs(b_stats["mean"] - v_stats["mean"])
        mde = self.compute_mde(baseline)
        
        if known_difference:
            if diff > 0 and diff >= (mde if mde != float('inf') else 0.01):
                return "SENSITIVE"
            elif diff > 0:
                return "WEAKLY_SENSITIVE"
            else:
                return "INSENSITIVE"
        else:
            if diff > 0:
                return "WEAKLY_SENSITIVE"
            return "INSENSITIVE"

    def run_metric_ablation(self, metric_func, inputs: List[Any], labels: List[Any]) -> Dict[str, Any]:
        """
        Ablates a metric by checking responses to:
        - unmodified
        - zeroed inputs
        - shuffled labels
        - randomized outputs
        """
        base_score = metric_func(inputs, labels)
        
        zeroed_inputs = [0.0] * len(inputs)
        zeroed_score = metric_func(zeroed_inputs, labels)
        
        shuffled_labels = list(labels)
        np.random.shuffle(shuffled_labels)
        shuffled_score = metric_func(inputs, shuffled_labels)
        
        reacts_to_inputs = base_score != zeroed_score
        reacts_to_labels = base_score != shuffled_score
        
        return {
            "base_score": base_score,
            "zeroed_score": zeroed_score,
            "shuffled_score": shuffled_score,
            "reacts_to_inputs": reacts_to_inputs,
            "reacts_to_labels": reacts_to_labels
        }
        
    def check_leakage(self, train_data: str, eval_data: str, labels: str) -> bool:
        """
        Simulates a leakage audit. 
        Returns True if leakage detected, False otherwise.
        """
        # Exact string matches
        if train_data == eval_data and len(train_data) > 0:
            return True
            
        # Label leakage into input
        if labels in train_data and len(labels) > 0:
            return True
            
        return False
