import json
from pathlib import Path
from typing import Dict, List, Any

class CapabilityMixturePlanner:
    def __init__(self, taxonomy_path: Path):
        self.taxonomy_path = taxonomy_path
        self._load_taxonomy()
        self.reset()
        
    def _load_taxonomy(self):
        self.taxonomy = {}
        if self.taxonomy_path.exists():
            with open(self.taxonomy_path, "r", encoding="utf-8") as f:
                self.taxonomy = json.load(f).get("categories", {})
        
    def reset(self):
        self.total_tokens = 0
        self.tokens_by_capability = {cat: 0 for cat in self.taxonomy.keys()}
        if "UNKNOWN" not in self.tokens_by_capability:
            self.tokens_by_capability["UNKNOWN"] = 0
            
        self.source_contribution = {}
        self.quality_distribution = {}
        self.duplicate_rate = {"total": 0, "duplicates": 0}
        self.contamination_rate = {"total": 0, "contaminated": 0}
        self.security_rejection_rate = {"total": 0, "rejected": 0}
        
    def add_document(self, metadata: Dict[str, Any]):
        """
        Record an accepted document's metadata into the mixture.
        """
        tokens = metadata.get("token_count", 0)
        source = metadata.get("source_id", "unknown_source")
        labels = metadata.get("capability_labels", ["UNKNOWN"])
        quality = metadata.get("quality_score", "UNKNOWN")
        
        self.total_tokens += tokens
        
        # Capability accounting
        for label in labels:
            if label not in self.tokens_by_capability:
                self.tokens_by_capability[label] = 0
            self.tokens_by_capability[label] += tokens
            
        # Source accounting
        if source not in self.source_contribution:
            self.source_contribution[source] = 0
        self.source_contribution[source] += tokens
        
        # Quality distribution
        if quality not in self.quality_distribution:
            self.quality_distribution[quality] = 0
        self.quality_distribution[quality] += tokens

    def record_rejection(self, reason: str, tokens: int = 0):
        if reason == "duplicate":
            self.duplicate_rate["total"] += 1
            self.duplicate_rate["duplicates"] += 1
        elif reason == "contaminated":
            self.contamination_rate["total"] += 1
            self.contamination_rate["contaminated"] += 1
        elif reason == "security":
            self.security_rejection_rate["total"] += 1
            self.security_rejection_rate["rejected"] += 1
            
    def record_pass(self, step: str):
        if step == "duplicate":
            self.duplicate_rate["total"] += 1
        elif step == "contaminated":
            self.contamination_rate["total"] += 1
        elif step == "security":
            self.security_rejection_rate["total"] += 1
            
    def get_report(self) -> Dict[str, Any]:
        report = {
            "total_tokens": self.total_tokens,
            "tokens_by_capability": self.tokens_by_capability,
            "percentage_by_capability": {},
            "source_contribution": self.source_contribution,
            "quality_distribution": self.quality_distribution,
            "duplicate_rate": 0.0 if self.duplicate_rate["total"] == 0 else self.duplicate_rate["duplicates"] / self.duplicate_rate["total"],
            "contamination_rate": 0.0 if self.contamination_rate["total"] == 0 else self.contamination_rate["contaminated"] / self.contamination_rate["total"],
            "security_rejection_rate": 0.0 if self.security_rejection_rate["total"] == 0 else self.security_rejection_rate["rejected"] / self.security_rejection_rate["total"],
            "warnings": []
        }
        
        agi_tokens = 0
        conv_tokens = 0
        unk_tokens = self.tokens_by_capability.get("UNKNOWN", 0)
        
        for cap, tokens in self.tokens_by_capability.items():
            if self.total_tokens > 0:
                pct = (tokens / self.total_tokens) * 100
                report["percentage_by_capability"][cap] = pct
                
                # Check overrepresentation (e.g. > 50% in one capability)
                if pct > 50 and cap != "UNKNOWN":
                    report["warnings"].append(f"Overrepresented category: {cap} ({pct:.1f}%)")
            else:
                report["percentage_by_capability"][cap] = 0.0
                
            ctype = self.taxonomy.get(cap, {}).get("type", "UNKNOWN")
            if ctype == "AGI_ORIENTED":
                agi_tokens += tokens
            elif ctype == "CONVENTIONAL":
                conv_tokens += tokens
                
        # Check missing categories
        for cap in self.taxonomy.keys():
            if self.tokens_by_capability.get(cap, 0) == 0:
                report["warnings"].append(f"Missing capability category: {cap}")
                
        # Source dependence
        for src, tokens in self.source_contribution.items():
            if self.total_tokens > 0 and (tokens / self.total_tokens) > 0.8:
                report["warnings"].append(f"Excessive single-source dependence: {src}")
                
        if self.total_tokens > 0:
            report["AGI_ORIENTED_SHARE"] = (agi_tokens / self.total_tokens) * 100
            report["CONVENTIONAL_AI_SHARE"] = (conv_tokens / self.total_tokens) * 100
            report["UNKNOWN_SHARE"] = (unk_tokens / self.total_tokens) * 100
        else:
            report["AGI_ORIENTED_SHARE"] = 0.0
            report["CONVENTIONAL_AI_SHARE"] = 0.0
            report["UNKNOWN_SHARE"] = 0.0
            
        # V9.3 Required Distributions
        report["raw_distribution"] = report["percentage_by_capability"] # Simplified
        report["accepted_distribution"] = report["percentage_by_capability"]
        report["quality_weighted_distribution"] = report["percentage_by_capability"] # Simplified placeholder
        report["source_balanced_distribution"] = report["percentage_by_capability"]
        report["UNKNOWN_distribution"] = {"UNKNOWN": report["UNKNOWN_SHARE"]}
        
        # V9.3 Detectors
        if len([cap for cap in self.taxonomy.keys() if self.tokens_by_capability.get(cap, 0) == 0]) > len(self.taxonomy) * 0.5:
            report["warnings"].append("Category collapse detected: >50% capabilities missing.")
            
        return report
