"""
NIRMAL-1 V8.7 PILOT ACCOUNTING & CONSERVATION ENGINE

Enforces strict mathematical accounting conservation for bounded acquisition pilots:
  discovered = accepted
             + rejected_quality
             + rejected_security
             + rejected_dedup
             + rejected_contamination
             + rejected_license
             + rejected_other

Also reconciles multi-tier token accounting:
  source_tokens -> normalized_tokens -> accepted_tokens -> final_shard_tokens

Guarantees that no document or token vanishes silently, and sensitive document text
is never logged in rejection records.
"""

from dataclasses import dataclass, field, asdict
import json
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple


class AccountingConservationError(Exception):
    """Raised when document or token accounting violates the conservation equation."""
    pass


@dataclass
class RejectedRecordAudit:
    doc_id: str
    rejection_stage: str  # "quality", "security", "dedup", "contamination", "license", "other"
    reason: str
    char_length: int
    estimated_tokens: int
    metadata_summary: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class PilotAccountingTracker:
    source_id: str
    pilot_run_id: str

    # Document counts
    documents_discovered: int = 0
    documents_accepted: int = 0
    rejected_quality: int = 0
    rejected_security: int = 0
    rejected_dedup: int = 0
    rejected_contamination: int = 0
    rejected_license: int = 0
    rejected_other: int = 0

    # Token counts across pipeline tiers
    source_tokens: int = 0
    normalized_tokens: int = 0
    accepted_tokens: int = 0
    final_shard_tokens: int = 0

    # Payload accounting
    bytes_downloaded: int = 0
    bytes_staged: int = 0
    final_shard_bytes: int = 0

    # Audit trail of rejected records (safe metadata only)
    rejection_audit_trail: List[RejectedRecordAudit] = field(default_factory=list)

    def record_discovery(self, raw_bytes: int, estimated_tokens: int = 0):
        self.documents_discovered += 1
        self.bytes_downloaded += raw_bytes
        self.source_tokens += estimated_tokens

    def record_acceptance(self, norm_tokens: int, shard_tokens: Optional[int] = None):
        self.documents_accepted += 1
        self.normalized_tokens += norm_tokens
        self.accepted_tokens += norm_tokens
        if shard_tokens is not None:
            self.final_shard_tokens += shard_tokens
        else:
            self.final_shard_tokens += norm_tokens

    def record_rejection(
        self,
        doc_id: str,
        stage: str,
        reason: str,
        char_length: int = 0,
        estimated_tokens: int = 0,
        safe_meta: Optional[Dict[str, Any]] = None,
    ):
        stage_clean = stage.lower()
        if stage_clean == "quality":
            self.rejected_quality += 1
        elif stage_clean == "security":
            self.rejected_security += 1
        elif stage_clean in ("dedup", "exact_dedup", "near_dedup"):
            self.rejected_dedup += 1
        elif stage_clean == "contamination":
            self.rejected_contamination += 1
        elif stage_clean == "license":
            self.rejected_license += 1
        else:
            self.rejected_other += 1

        audit = RejectedRecordAudit(
            doc_id=doc_id,
            rejection_stage=stage_clean,
            reason=reason,
            char_length=char_length,
            estimated_tokens=estimated_tokens,
            metadata_summary=safe_meta or {},
        )
        self.rejection_audit_trail.append(audit)

    @property
    def total_rejected(self) -> int:
        return (
            self.rejected_quality
            + self.rejected_security
            + self.rejected_dedup
            + self.rejected_contamination
            + self.rejected_license
            + self.rejected_other
        )

    def verify_conservation(self) -> Tuple[bool, str]:
        """
        Verifies exact conservation:
        discovered == accepted + total_rejected
        final_shard_tokens == accepted_tokens
        """
        expected_discovered = self.documents_accepted + self.total_rejected
        if self.documents_discovered != expected_discovered:
            msg = (
                f"Document conservation violation! discovered ({self.documents_discovered}) != "
                f"accepted ({self.documents_accepted}) + rejected ({self.total_rejected})"
            )
            return False, msg

        if len(self.rejection_audit_trail) != self.total_rejected:
            msg = (
                f"Rejection audit trail mismatch! audit entries ({len(self.rejection_audit_trail)}) != "
                f"total_rejected ({self.total_rejected})"
            )
            return False, msg

        if self.final_shard_tokens != self.accepted_tokens:
            msg = (
                f"Token accounting violation! final_shard_tokens ({self.final_shard_tokens}) != "
                f"accepted_tokens ({self.accepted_tokens})"
            )
            return False, msg

        return True, "Accounting conservation fully verified (documents and tokens balance exactly)."

    def to_dict(self) -> Dict[str, Any]:
        is_conserved, msg = self.verify_conservation()
        return {
            "source_id": self.source_id,
            "pilot_run_id": self.pilot_run_id,
            "document_accounting": {
                "documents_discovered": self.documents_discovered,
                "documents_accepted": self.documents_accepted,
                "total_rejected": self.total_rejected,
                "rejected_by_category": {
                    "quality": self.rejected_quality,
                    "security": self.rejected_security,
                    "dedup": self.rejected_dedup,
                    "contamination": self.rejected_contamination,
                    "license": self.rejected_license,
                    "other": self.rejected_other,
                },
                "conservation_equation": "discovered == accepted + total_rejected",
                "conservation_satisfied": is_conserved,
            },
            "token_accounting": {
                "source_tokens": self.source_tokens,
                "normalized_tokens": self.normalized_tokens,
                "accepted_tokens": self.accepted_tokens,
                "final_shard_tokens": self.final_shard_tokens,
                "token_reconciliation_satisfied": (self.final_shard_tokens == self.accepted_tokens),
            },
            "byte_accounting": {
                "bytes_downloaded": self.bytes_downloaded,
                "bytes_staged": self.bytes_staged,
                "final_shard_bytes": self.final_shard_bytes,
            },
            "rejection_audit_summary": [a.to_dict() for a in self.rejection_audit_trail],
            "conservation_status": "CONSERVED" if is_conserved else "VIOLATION",
            "verification_message": msg,
        }
