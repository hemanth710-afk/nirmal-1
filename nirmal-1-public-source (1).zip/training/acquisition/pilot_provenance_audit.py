"""
NIRMAL-1 V8.8: PILOT PROVENANCE TRUTH AUDIT & ADAPTER CAPABILITY ENGINE

Provides rigorous provenance verification, classification, and stage-by-stage
traceability for pretraining pilot records.

Invariants:
- Every record is classified into exactly one ProvenanceClass.
- UNKNOWN strictly fails verification.
- Local fixtures and synthetic documents can NEVER be classified as REMOTE_SOURCE_DATA.
- Never store raw copyrighted text or secrets in audit/provenance files.
- Adapters are audited and assigned explicit capability labels.
- Historical V8.7 pilot is audited and classified truthfully as SYNTHETIC_TEST_DATA (PILOT_NOT_REALLY_REMOTE).
"""

from dataclasses import dataclass, field, asdict
from enum import Enum
import hashlib
import json
from pathlib import Path
import time
from typing import Any, Dict, List, Optional, Set, Tuple

REPO_ROOT = Path(__file__).resolve().parent.parent.parent
PILOT_DIR = REPO_ROOT / "data" / "pilot"
PROVENANCE_DIR = PILOT_DIR / "provenance"
MANIFESTS_DIR = PILOT_DIR / "manifests"


class PilotProvenanceClass(str, Enum):
    REMOTE_SOURCE_DATA = "REMOTE_SOURCE_DATA"
    LOCAL_SOURCE_CACHE = "LOCAL_SOURCE_CACHE"
    LOCAL_FIXTURE = "LOCAL_FIXTURE"
    SYNTHETIC_TEST_DATA = "SYNTHETIC_TEST_DATA"
    PROJECT_GENERATED = "PROJECT_GENERATED"
    UNKNOWN = "UNKNOWN"


class AdapterCapability(str, Enum):
    REAL_REMOTE_RETRIEVAL = "REAL_REMOTE_RETRIEVAL"
    REAL_LOCAL_PARSE = "REAL_LOCAL_PARSE"
    FIXTURE_ONLY = "FIXTURE_ONLY"
    SYNTHETIC_ONLY = "SYNTHETIC_ONLY"


class ProvenanceVerificationError(Exception):
    """Raised when provenance classification fails or is falsified."""
    pass


@dataclass
class PilotDocumentAuditEntry:
    """Safe audit metadata for a single pilot document. Zero copyrighted text, zero secrets."""
    document_hash: str
    source_id: str
    provenance_class: PilotProvenanceClass
    canonical_source: str
    source_url: str
    source_revision: str
    retrieval_timestamp: str
    raw_byte_count: int
    normalized_byte_count: int
    token_count: int
    adapter_identifier: str
    pipeline_version: str
    acquisition_record_id: str
    raw_payload_hash: str = ""
    is_network_retrieved: bool = False
    is_local_fixture: bool = False
    is_synthetic: bool = False
    is_copied_from_repo: bool = False
    capability_labels: List[str] = field(default_factory=list)
    capability_confidence: str = "UNKNOWN"
    quality_score: str = "UNKNOWN"
    license_status: str = "UNKNOWN"
    security_status: str = "UNKNOWN"
    contamination_status: str = "UNKNOWN"
    dedup_status: str = "UNKNOWN"

    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        d["provenance_class"] = self.provenance_class.value
        return d


@dataclass
class DocumentTraceStep:
    """Deterministic cryptographic trace for an individual document across all pipeline stages."""
    doc_id: str
    raw_source_bytes: int
    raw_payload_hash: str
    normalized_byte_count: int
    document_hash: str
    quality_decision: str
    security_decision: str
    dedup_decision: str
    contamination_decision: str
    token_count: int
    shard_hash: str

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


class PilotProvenanceAuditor:
    """
    Audits and validates provenance truth across all pilot records and adapters.
    """

    def __init__(self, provenance_dir: Optional[Path] = None):
        self.provenance_dir = provenance_dir or PROVENANCE_DIR
        self.provenance_dir.mkdir(parents=True, exist_ok=True)

    def classify_record(
        self,
        is_network: bool,
        is_local_fixture: bool,
        is_synthetic: bool,
        is_local_cache: bool = False,
        is_project_gen: bool = False,
    ) -> PilotProvenanceClass:
        """
        Determines unambiguous provenance classification.
        Enforces that fixtures and synthetic data cannot masquerade as remote.
        """
        # Exclusivity and priority checks
        if is_network:
            if is_local_fixture or is_synthetic:
                raise ProvenanceVerificationError(
                    "CRITICAL PROVENANCE FRAUD: Record marked both network and fixture/synthetic!"
                )
            return PilotProvenanceClass.REMOTE_SOURCE_DATA
        elif is_local_cache:
            return PilotProvenanceClass.LOCAL_SOURCE_CACHE
        elif is_local_fixture:
            return PilotProvenanceClass.LOCAL_FIXTURE
        elif is_synthetic:
            return PilotProvenanceClass.SYNTHETIC_TEST_DATA
        elif is_project_gen:
            return PilotProvenanceClass.PROJECT_GENERATED
        else:
            return PilotProvenanceClass.UNKNOWN

    def verify_entry(self, entry: PilotDocumentAuditEntry) -> bool:
        """Verifies integrity and consistency of a pilot audit entry."""
        if entry.provenance_class == PilotProvenanceClass.UNKNOWN:
            raise ProvenanceVerificationError(f"Document {entry.document_hash} has UNKNOWN provenance! Verification failed.")

        if entry.provenance_class == PilotProvenanceClass.REMOTE_SOURCE_DATA:
            if not entry.is_network_retrieved:
                raise ProvenanceVerificationError("REMOTE_SOURCE_DATA claimed without network retrieval flag!")
            if not entry.source_url or not entry.source_url.startswith("https://"):
                raise ProvenanceVerificationError("REMOTE_SOURCE_DATA requires valid public HTTPS source_url!")
            if not entry.source_revision:
                raise ProvenanceVerificationError("REMOTE_SOURCE_DATA requires source_revision!")
            if entry.is_local_fixture or entry.is_synthetic or entry.is_copied_from_repo:
                raise ProvenanceVerificationError("REMOTE_SOURCE_DATA cannot have local fixture or synthetic flags!")

        if entry.provenance_class in (
            PilotProvenanceClass.LOCAL_FIXTURE,
            PilotProvenanceClass.SYNTHETIC_TEST_DATA,
            PilotProvenanceClass.PROJECT_GENERATED,
        ):
            if entry.is_network_retrieved:
                raise ProvenanceVerificationError(
                    f"Provenance class {entry.provenance_class.value} cannot be marked network-retrieved!"
                )

        if not entry.document_hash or len(entry.document_hash) != 64:
            raise ProvenanceVerificationError(f"Invalid SHA-256 document hash: {entry.document_hash}")

        return True

    def audit_adapter(self, adapter_module_path: Path) -> Dict[str, Any]:
        """
        Audits an adapter file for actual remote network calls, parsing capabilities,
        and hardcoded/synthetic payloads.
        """
        if not adapter_module_path.exists():
            return {"status": "FILE_NOT_FOUND", "capability": AdapterCapability.SYNTHETIC_ONLY.value}

        content = adapter_module_path.read_text(encoding="utf-8")

        has_urllib_or_requests = (
            "urllib.request" in content
            or "requests." in content
            or "httpx." in content
            or "SafeBoundedNetworkClient" in content
        )
        has_xml_or_json_parser = (
            "xml.etree" in content
            or "defusedxml" in content
            or "mwparserfromhell" in content
            or "CirrusSearch" in content
            or "parquet" in content
        )
        has_mock_string_payload = (
            "# Wikimedia Dump Snapshot" in content
            or "# Nirmal-1 Snapshot" in content
            or "# S3 Bulk Snapshot" in content
            or "_generate_bounded_pilot_records" in content
        )

        if has_urllib_or_requests:
            capability = AdapterCapability.REAL_REMOTE_RETRIEVAL
        elif has_xml_or_json_parser and not has_mock_string_payload:
            capability = AdapterCapability.REAL_LOCAL_PARSE
        elif has_mock_string_payload:
            capability = AdapterCapability.SYNTHETIC_ONLY
        else:
            capability = AdapterCapability.FIXTURE_ONLY

        return {
            "adapter_file": adapter_module_path.name,
            "capability": capability.value,
            "has_network_client": has_urllib_or_requests,
            "has_real_parser": has_xml_or_json_parser,
            "has_mock_payload": has_mock_string_payload,
        }

    def audit_all_adapters(self) -> Dict[str, Dict[str, Any]]:
        """Audits all external source adapters in the repository."""
        adapters = {
            "wikimedia_dump_parser": REPO_ROOT / "training" / "acquisition" / "wikimedia_parser.py",
            "hf_snapshot_sync": REPO_ROOT / "training" / "acquisition" / "hf_snapshot_sync.py",
            "s3_bulk_sync": REPO_ROOT / "training" / "acquisition" / "s3_bulk_sync.py",
            "wikipedia_pilot_adapter": REPO_ROOT / "training" / "acquisition" / "pilot_adapter.py",
        }
        return {name: self.audit_adapter(path) for name, path in adapters.items()}

    def audit_v8_7_historical_pilot(self) -> Dict[str, Any]:
        """
        Audits the V8.7 Wikipedia pilot manifest and source code.
        Accurately documents that the 5 documents came from hardcoded Python records.
        """
        v8_7_manifest_path = MANIFESTS_DIR / "wikipedia_open_corpus_pilot_manifest.json"
        has_manifest = v8_7_manifest_path.exists()

        records = [
            {
                "doc_id": "wiki_1001",
                "title": "Quantum Computing",
                "origin": "hardcoded_python_dictionary in pilot_adapter.py",
                "provenance_class": PilotProvenanceClass.SYNTHETIC_TEST_DATA.value,
                "is_network_retrieved": False,
                "is_synthetic": True,
            },
            {
                "doc_id": "wiki_1002",
                "title": "Differential Geometry",
                "origin": "hardcoded_python_dictionary in pilot_adapter.py",
                "provenance_class": PilotProvenanceClass.SYNTHETIC_TEST_DATA.value,
                "is_network_retrieved": False,
                "is_synthetic": True,
            },
            {
                "doc_id": "wiki_1003",
                "title": "Photosynthesis",
                "origin": "hardcoded_python_dictionary in pilot_adapter.py",
                "provenance_class": PilotProvenanceClass.SYNTHETIC_TEST_DATA.value,
                "is_network_retrieved": False,
                "is_synthetic": True,
            },
            {
                "doc_id": "wiki_1004",
                "title": "Turing Machine",
                "origin": "hardcoded_python_dictionary in pilot_adapter.py",
                "provenance_class": PilotProvenanceClass.SYNTHETIC_TEST_DATA.value,
                "is_network_retrieved": False,
                "is_synthetic": True,
            },
            {
                "doc_id": "wiki_1005",
                "title": "Plate Tectonics",
                "origin": "hardcoded_python_dictionary in pilot_adapter.py",
                "provenance_class": PilotProvenanceClass.SYNTHETIC_TEST_DATA.value,
                "is_network_retrieved": False,
                "is_synthetic": True,
            },
        ]

        return {
            "pilot_run": "V8.7-PILOT",
            "historical_verdict": "PILOT_NOT_REALLY_REMOTE",
            "software_pipeline_status": "SOFTWARE_PIPELINE_VERIFIED",
            "remote_acquisition_status": "REMOTE_SOURCE_ACQUISITION_NOT_YET_VERIFIED",
            "document_count": 5,
            "provenance_classification": PilotProvenanceClass.SYNTHETIC_TEST_DATA.value,
            "has_manifest": has_manifest,
            "records": records,
            "audit_note": (
                "V8.7 documents were generated by _generate_bounded_pilot_records() in pilot_adapter.py. "
                "The pipeline logic was correctly verified, but no bytes were downloaded from external Wikipedia servers."
            ),
        }

    def save_provenance_record(
        self,
        source_id: str,
        entries: List[PilotDocumentAuditEntry],
        run_id: str,
    ) -> Path:
        """Saves verified provenance records without any raw source text."""
        for e in entries:
            self.verify_entry(e)

        out_path = self.provenance_dir / f"{source_id}_provenance.json"
        data = {
            "source_id": source_id,
            "run_id": run_id,
            "audit_timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "total_documents": len(entries),
            "documents": [e.to_dict() for e in entries],
        }
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
        return out_path

    def save_trace(
        self,
        source_id: str,
        steps: List[DocumentTraceStep],
        final_shard_hash: str,
    ) -> Path:
        """Saves machine-readable end-to-end trace from raw bytes to final shard."""
        out_path = self.provenance_dir / f"{source_id}_trace.json"
        data = {
            "source_id": source_id,
            "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "total_documents": len(steps),
            "final_shard_hash": final_shard_hash,
            "trace_chain": [s.to_dict() for s in steps],
        }
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
        return out_path
