import json
from pathlib import Path
from typing import Dict, List, Tuple

class CapabilityClassifier:
    """
    Deterministic/rule-based capability classifier.
    Does NOT depend on external AI foundation models.
    """
    
    def __init__(self, taxonomy_path: Path):
        self.taxonomy_path = taxonomy_path
        self.taxonomy = self._load_taxonomy()
        self.categories = set(self.taxonomy.get("categories", {}).keys())
        
    def _load_taxonomy(self) -> Dict:
        if self.taxonomy_path.exists():
            with open(self.taxonomy_path, "r", encoding="utf-8") as f:
                return json.load(f)
        return {"categories": {}}

    def classify_document(self, text: str, metadata: Dict) -> Tuple[List[str], str]:
        """
        Returns a list of capability labels and a confidence string:
        HIGH, MEDIUM, LOW, UNKNOWN
        """
        text_lower = text.lower()
        labels = set()
        confidence = "UNKNOWN"
        
        # Heuristics based on metadata
        if metadata:
            source_id = metadata.get("source_id", "")
            if "github" in source_id or "stack" in source_id:
                labels.add("programming")
                labels.add("algorithmic reasoning")
                confidence = "HIGH"
            elif "arxiv" in source_id or "dolma" in source_id:
                labels.add("scientific reasoning")
                confidence = "HIGH"
            elif "wikipedia" in source_id:
                labels.add("world knowledge")
                confidence = "HIGH"
                
            url = metadata.get("url", "")
            if "math" in url or "arxiv.org/abs/math" in url:
                labels.add("mathematical reasoning")
                confidence = "HIGH"
                
        # Heuristics based on text content
        # Math
        if "theorem" in text_lower and "proof" in text_lower and ("\\begin{equation}" in text or "=" in text):
            labels.add("mathematical reasoning")
            if confidence == "UNKNOWN": confidence = "MEDIUM"
            
        # Code
        if "def " in text and "return " in text and "import " in text:
            labels.add("programming")
            if confidence == "UNKNOWN": confidence = "MEDIUM"
            
        # Dialogue
        if "user:" in text_lower and "assistant:" in text_lower:
            labels.add("conventional dialogue")
            confidence = "HIGH" # Text can elevate confidence
                
        # Procedural
        if "step 1" in text_lower and "step 2" in text_lower:
            labels.add("procedural knowledge")
            if confidence == "UNKNOWN":
                confidence = "LOW"
                    
            # Explanation
            if "therefore" in text_lower and "because" in text_lower and "consequently" in text_lower:
                labels.add("explanation/reasoning text")
                if confidence == "UNKNOWN":
                    confidence = "LOW"
                    
            if "cause" in text_lower and "effect" in text_lower and "resulted in" in text_lower:
                labels.add("causal reasoning")
                if confidence == "UNKNOWN":
                    confidence = "LOW"
                    
        # Filter valid categories
        valid_labels = [label for label in labels if label in self.categories]
        
        if not valid_labels:
            return ["UNKNOWN"], "UNKNOWN"
            
        return sorted(valid_labels), confidence
