from enum import Enum
from typing import Dict, Any, List
import hashlib

class CurriculumStage(Enum):
    FOUNDATION = "FOUNDATION"
    COMPOSITION = "COMPOSITION"
    REASONING = "REASONING"
    PLANNING = "PLANNING"
    LONG_HORIZON = "LONG_HORIZON"
    SPECIALIZATION = "SPECIALIZATION"
    GENERALIZATION = "GENERALIZATION"

class CapabilityCurriculumPlanner:
    def __init__(self):
        self.stage_requirements = {
            CurriculumStage.FOUNDATION: {
                "target_mix": {"world knowledge": 0.5, "programming": 0.2},
                "min_quality": 0.5,
                "max_source_concentration": 0.4,
                "max_duplicate_concentration": 0.05,
                "unknown_tolerance": 0.1
            },
            CurriculumStage.REASONING: {
                "target_mix": {"mathematical reasoning": 0.3, "scientific reasoning": 0.3},
                "min_quality": 0.8,
                "max_source_concentration": 0.2,
                "max_duplicate_concentration": 0.0,
                "unknown_tolerance": 0.01
            }
        }
        
    def get_split(self, doc_text: str, metadata: Dict[str, Any]) -> str:
        """
        Deterministic capability-aware split logic to prevent leakage across:
        source, document, revision, near-duplicate, capability template.
        """
        source_id = metadata.get("source_id", "unknown")
        # Use template ID if available, otherwise hash the text lightly (e.g. first 50 chars) to group near duplicates
        template_hash = metadata.get("template_id", hashlib.md5(doc_text[:50].encode('utf-8')).hexdigest())
        
        # Hash combination of source and template to determine split deterministically
        split_hash = hashlib.md5(f"{source_id}:{template_hash}".encode('utf-8')).hexdigest()
        split_val = int(split_hash[:4], 16) / 65535.0
        
        if split_val < 0.8:
            return "TRAIN"
        elif split_val < 0.9:
            return "VALIDATION"
        else:
            return "OOD_TEST"

    def check_stage_eligibility(self, stage: CurriculumStage, document_mix: Dict[str, float], quality: float, unknown_ratio: float) -> bool:
        if stage not in self.stage_requirements:
            return True # No strict requirements defined
            
        reqs = self.stage_requirements[stage]
        if quality < reqs["min_quality"]:
            return False
        if unknown_ratio > reqs["unknown_tolerance"]:
            return False
            
        # Simplified mix check
        return True
