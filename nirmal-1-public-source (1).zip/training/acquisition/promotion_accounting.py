"""
NIRMAL-1 V9.0: PROMOTION ACCOUNTING & CONSERVATION ENGINE

Enforces strict mathematical accounting conservation for source promotions:
  pilot_verified_documents == promoted_documents + promotion_rejections
  pilot_verified_tokens == promoted_tokens + promotion_rejected_tokens

Guarantees:
- Zero anonymous promoted data: every promoted document must have explicit
  doc_id, page_id, revision_id, doc_hash, source_manifest_hash, and promotion_manifest_hash.
- Stage-by-stage rejection tracking with safe metadata.
- Fail-closed validation on any conservation violation.
"""

from dataclasses import dataclass, field, asdict
import json
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple


class PromotionAccountingError(Exception):
    """Raised when promotion accounting conservation is violated or anonymous data is encountered."""
    pass


@dataclass
class PromotedRecordAudit:
    """Audit entry for an individual promoted document. Zero anonymous data permitted."""
    doc_id: str
    page_id: str
    revision_id: str
    doc_hash: str
    source_manifest_hash: str
    promotion_manifest_hash: str
    tokens: int
    promoted_timestamp: str

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class PromotionRejectionAudit:
    """Audit entry for a document rejected during the promotion gate."""
    doc_id: str
    reason: str
    tokens: int
    rejected_timestamp: str
    metadata_summary: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class PromotionAccountingTracker:
    """
    Tracks and mathematically reconciles documents and tokens transitioning
    from PILOT_VERIFIED to APPROVED_FOR_PRODUCTION.
    """
    source_id: str
    promotion_id: str

    # Pilot verified baseline
    pilot_verified_documents: int = 0
    pilot_verified_tokens: int = 0

    # Promoted counts
    promoted_documents: int = 0
    promoted_tokens: int = 0

    # Rejection counts
    promotion_rejections: int = 0
    promotion_rejected_tokens: int = 0

    # Audit trails
    promoted_records_audit: List[PromotedRecordAudit] = field(default_factory=list)
    rejection_audit_trail: List[PromotionRejectionAudit] = field(default_factory=list)

    def record_pilot_baseline(self, total_docs: int, total_tokens: int) -> None:
        """Establishes the immutable baseline of pilot-verified documents and tokens."""
        if total_docs < 0 or total_tokens < 0:
            raise PromotionAccountingError("Baseline counts cannot be negative.")
        self.pilot_verified_documents = total_docs
        self.pilot_verified_tokens = total_tokens

    def record_promotion(
        self,
        doc_id: str,
        page_id: str,
        revision_id: str,
        doc_hash: str,
        source_manifest_hash: str,
        promotion_manifest_hash: str,
        tokens: int,
        timestamp: Optional[str] = None,
    ) -> None:
        """
        Records a promoted document.
        STRICT ZERO ANONYMOUS DATA INVARIANT:
        All identifying hashes and revision numbers MUST be present and non-empty.
        """
        import time

        # Validate against anonymous promoted data
        if not doc_id or not str(doc_id).strip():
            raise PromotionAccountingError("Anonymous promoted data rejected: missing doc_id.")
        if not page_id or not str(page_id).strip():
            raise PromotionAccountingError("Anonymous promoted data rejected: missing page_id.")
        if not revision_id or not str(revision_id).strip():
            raise PromotionAccountingError("Anonymous promoted data rejected: missing revision_id.")
        if not doc_hash or len(str(doc_hash)) != 64:
            raise PromotionAccountingError("Anonymous promoted data rejected: missing or invalid doc_hash (SHA-256).")
        if not source_manifest_hash or len(str(source_manifest_hash)) != 64:
            raise PromotionAccountingError("Anonymous promoted data rejected: missing or invalid source_manifest_hash.")
        if not promotion_manifest_hash or len(str(promotion_manifest_hash)) != 64:
            raise PromotionAccountingError("Anonymous promoted data rejected: missing or invalid promotion_manifest_hash.")
        if tokens < 0:
            raise PromotionAccountingError("Tokens count cannot be negative.")

        ts = timestamp or time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())

        audit = PromotedRecordAudit(
            doc_id=doc_id,
            page_id=page_id,
            revision_id=revision_id,
            doc_hash=doc_hash,
            source_manifest_hash=source_manifest_hash,
            promotion_manifest_hash=promotion_manifest_hash,
            tokens=tokens,
            promoted_timestamp=ts,
        )

        self.promoted_documents += 1
        self.promoted_tokens += tokens
        self.promoted_records_audit.append(audit)

    def record_rejection(
        self,
        doc_id: str,
        reason: str,
        tokens: int = 0,
        safe_meta: Optional[Dict[str, Any]] = None,
        timestamp: Optional[str] = None,
    ) -> None:
        """Records a document rejected during the promotion gate."""
        import time

        if not doc_id or not str(doc_id).strip():
            raise PromotionAccountingError("Rejection record missing doc_id.")
        if not reason or not str(reason).strip():
            raise PromotionAccountingError("Rejection record missing reason.")
        if tokens < 0:
            raise PromotionAccountingError("Rejected tokens cannot be negative.")

        ts = timestamp or time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())

        audit = PromotionRejectionAudit(
            doc_id=doc_id,
            reason=reason,
            tokens=tokens,
            rejected_timestamp=ts,
            metadata_summary=safe_meta or {},
        )

        self.promotion_rejections += 1
        self.promotion_rejected_tokens += tokens
        self.rejection_audit_trail.append(audit)

    def verify_conservation(self) -> Tuple[bool, str]:
        """
        Verifies exact conservation equations:
        1. pilot_verified_documents == promoted_documents + promotion_rejections
        2. pilot_verified_tokens == promoted_tokens + promotion_rejected_tokens
        3. len(promoted_records_audit) == promoted_documents
        4. len(rejection_audit_trail) == promotion_rejections
        """
        expected_docs = self.promoted_documents + self.promotion_rejections
        if self.pilot_verified_documents != expected_docs:
            msg = (
                f"Promotion document conservation violation! "
                f"pilot_verified_documents ({self.pilot_verified_documents}) != "
                f"promoted ({self.promoted_documents}) + rejections ({self.promotion_rejections})"
            )
            raise PromotionAccountingError(msg)

        expected_tokens = self.promoted_tokens + self.promotion_rejected_tokens
        if self.pilot_verified_tokens != expected_tokens:
            msg = (
                f"Promotion token conservation violation! "
                f"pilot_verified_tokens ({self.pilot_verified_tokens}) != "
                f"promoted ({self.promoted_tokens}) + rejections ({self.promotion_rejected_tokens})"
            )
            raise PromotionAccountingError(msg)

        if len(self.promoted_records_audit) != self.promoted_documents:
            msg = (
                f"Promoted audit trail count mismatch! "
                f"audit entries ({len(self.promoted_records_audit)}) != "
                f"promoted_documents ({self.promoted_documents})"
            )
            raise PromotionAccountingError(msg)

        if len(self.rejection_audit_trail) != self.promotion_rejections:
            msg = (
                f"Promotion rejection audit count mismatch! "
                f"audit entries ({len(self.rejection_audit_trail)}) != "
                f"promotion_rejections ({self.promotion_rejections})"
            )
            raise PromotionAccountingError(msg)

        return True, "Promotion accounting conservation fully verified (documents and tokens balance exactly)."

    def to_dict(self) -> Dict[str, Any]:
        """Exports accounting report dictionary."""
        is_conserved = False
        msg = ""
        try:
            is_conserved, msg = self.verify_conservation()
        except PromotionAccountingError as e:
            msg = str(e)

        return {
            "source_id": self.source_id,
            "promotion_id": self.promotion_id,
            "document_accounting": {
                "pilot_verified_documents": self.pilot_verified_documents,
                "promoted_documents": self.promoted_documents,
                "promotion_rejections": self.promotion_rejections,
                "conservation_equation": "pilot_verified_documents == promoted_documents + promotion_rejections",
                "conservation_satisfied": is_conserved,
            },
            "token_accounting": {
                "pilot_verified_tokens": self.pilot_verified_tokens,
                "promoted_tokens": self.promoted_tokens,
                "promotion_rejected_tokens": self.promotion_rejected_tokens,
                "conservation_equation": "pilot_verified_tokens == promoted_tokens + promotion_rejected_tokens",
                "token_reconciliation_satisfied": is_conserved,
            },
            "promoted_records_audit": [a.to_dict() for a in self.promoted_records_audit],
            "rejection_audit_trail": [r.to_dict() for r in self.rejection_audit_trail],
            "conservation_status": "CONSERVED" if is_conserved else "VIOLATION",
            "verification_message": msg,
        }
