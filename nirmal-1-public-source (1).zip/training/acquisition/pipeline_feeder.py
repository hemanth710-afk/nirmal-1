"""
Pipeline Feeder Bridge for External Source Adapters (Nirmal-1 V8.4).

Feeds raw acquired records through the complete multi-stage pipeline:
SOURCE -> NORMALIZATION -> QUALITY FILTERING -> CODE SAFETY SCAN -> DEDUP -> BENCHMARK DECONTAMINATION -> PROVENANCE ACCOUNTING

Guarantees that no acquired document bypasses security, deduplication, or decontamination gates.
"""

from dataclasses import dataclass, field
import hashlib
import time
from typing import Any, Dict, Generator, Iterable, List, Optional, Tuple

from training.v8_2_data_engine import ProductionDocument, ProvenanceMetadata
from training.v8_4_code_safety import CodeSafetyScanner, CodeSafetyConfig, ScannerAction
from training.v8_4_decontamination import NgramDecontaminationEngine, ContaminationSplit, MatchPolicyType
from training.v8_4_global_dedup import ProductionDeduplicationPipeline
from training.v8_4_ingestion import StreamingIngestionEngine
from training.v8_4_manifest import SourceProvenanceRecord


@dataclass
class FeederAccounting:
    documents_discovered: int = 0
    documents_accepted: int = 0
    documents_rejected: int = 0
    quality_removals: int = 0
    secret_removals: int = 0
    contamination_removals: int = 0
    exact_dedup_removals: int = 0
    near_dedup_removals: int = 0
    tokens_accepted: int = 0
    rejected_reasons: Dict[str, int] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "documents_discovered": self.documents_discovered,
            "documents_accepted": self.documents_accepted,
            "documents_rejected": self.documents_rejected,
            "quality_removals": self.quality_removals,
            "secret_removals": self.secret_removals,
            "contamination_removals": self.contamination_removals,
            "exact_dedup_removals": self.exact_dedup_removals,
            "near_dedup_removals": self.near_dedup_removals,
            "tokens_accepted": self.tokens_accepted,
            "rejected_reasons": self.rejected_reasons,
        }


class PipelineFeeder:
    """
    Feeds raw records through quality, security, deduplication, and decontamination filters.
    """

    def __init__(
        self,
        source_id: str,
        code_safety_scanner: Optional[CodeSafetyScanner] = None,
        decontamination_engine: Optional[NgramDecontaminationEngine] = None,
        dedup_pipeline: Optional[ProductionDeduplicationPipeline] = None,
        ingestion_engine: Optional[StreamingIngestionEngine] = None,
    ):
        self.source_id = source_id
        self.code_safety_scanner = code_safety_scanner or CodeSafetyScanner()
        self.decontamination_engine = decontamination_engine or NgramDecontaminationEngine()
        self.dedup_pipeline = dedup_pipeline or ProductionDeduplicationPipeline(jaccard_threshold=0.85)
        self.ingestion_engine = ingestion_engine or StreamingIngestionEngine(
            code_safety_scanner=self.code_safety_scanner,
            decontamination_engine=self.decontamination_engine,
        )
        self.accounting = FeederAccounting()

    def process_raw_record(
        self,
        doc_id: str,
        raw_text: str,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Tuple[bool, Optional[ProductionDocument], Optional[str]]:
        """
        Runs a single raw record through the full security and quality gauntlet.
        Returns: (is_accepted, production_doc_or_none, rejection_reason_or_none)
        """
        self.accounting.documents_discovered += 1
        meta = metadata or {}

        # 1. Normalization
        norm_text = self.ingestion_engine.normalize_text(raw_text)

        # 2. Quality Filtering
        is_retained, qual_reason = self.ingestion_engine.filter_document(norm_text)
        if not is_retained:
            self.accounting.documents_rejected += 1
            reason = qual_reason or "quality_rejected"
            self.accounting.rejected_reasons[reason] = self.accounting.rejected_reasons.get(reason, 0) + 1

            if reason == "credential_secret_detected":
                self.accounting.secret_removals += 1
            elif reason == "benchmark_contamination_detected":
                self.accounting.contamination_removals += 1
            else:
                self.accounting.quality_removals += 1

            return False, None, reason

        # 3. Deduplication (Exact SHA-256 + MinHash LSH)
        is_unique, dedup_reason, _ = self.dedup_pipeline.process_document(norm_text, doc_id)
        if not is_unique:
            self.accounting.documents_rejected += 1
            reason = dedup_reason or "dedup_rejected"
            self.accounting.rejected_reasons[reason] = self.accounting.rejected_reasons.get(reason, 0) + 1
            if "exact_duplicate" in reason:
                self.accounting.exact_dedup_removals += 1
            else:
                self.accounting.near_dedup_removals += 1
            return False, None, reason

        # Estimate tokens (approx 1 token per 3.8 characters for telemetry)
        approx_tokens = max(1, len(norm_text) // 4)

        # 4. Accepted Production Document
        doc = ProductionDocument(
            id=doc_id,
            domain=meta.get("domain", "general"),
            raw_text=raw_text,
            clean_text=norm_text,
            provenance=ProvenanceMetadata(
                source_id=self.source_id,
                domain=meta.get("domain", "general"),
                license_provenance=meta.get("license", "declared_permissive"),
                acquisition_date=time.strftime("%Y-%m-%d"),
                preprocessing_version="v8.4",
                tokenizer_version="v7_bpe",
                sha256_hash=hashlib.sha256(norm_text.encode("utf-8")).hexdigest(),
            ),
            token_count=approx_tokens,
        )

        self.accounting.documents_accepted += 1
        self.accounting.tokens_accepted += approx_tokens

        return True, doc, None
