"""
NIRMAL-1 V8.9 HARDENED REAL WIKIMEDIA SOURCE ADAPTER

Production-grade real Wikimedia source adapter conforming strictly to the PilotSourceAdapter contract.
Implements fail-closed real remote bounded acquisition, genuine revision ID verification,
content vs metadata separation, full pipeline processing, exact accounting conservation,
atomic staging/sharding, and crash-resilient checkpointing with replay protection.

Required 7 methods:
1. inspect(): Returns metadata, endpoints, format, status PILOT_ELIGIBLE, ceilings.
2. fetch_bounded(topics=None, max_docs=10, max_payload_bytes=1048576):
   Uses SafeBoundedNetworkClient with limits (max 10 docs, max 1 MB total payload, max 128 KB/doc, 10s timeout).
   Default 10 deterministic academic topics.
   Extracts real revision ID, timestamp, URL, raw JSON payload bytes, SHA-256, and plain-text extract.
   Validates revision ID authenticity. If revision missing or invalid, sets revision_verified=False.
3. normalize(raw_records):
   Unicode NFC, LF line endings, whitespace collapse.
   Content vs metadata separation: ONLY article extract text enters normalization and tokenization.
   Thumbnails, image URLs, descriptions, API metadata, page IDs are segregated into provenance metadata.
4. validate_provenance(records):
   Enforces REMOTE_SOURCE_DATA. Rejects missing URLs, missing revision IDs, unverified revisions,
   local fixtures or synthetic records claiming remote status. Fails closed on any ambiguity.
5. run_pipeline(records=None):
   Runs full pipeline: Normalization -> Quality filter -> CodeSafetyScanner -> Global exact dedup
   -> MinHash near dedup -> 13-gram benchmark decontamination -> Tokenization
   -> Binary sharding (uint16 in data/pilot/shards/) -> Manifest signing -> Accounting -> Trace generation.
6. finalize():
   Verifies exact conservation: discovered == accepted + sum(rejected).
   Verifies token reconciliation: accepted_tokens == shard_tokens.
   Emits signed immutable manifest to data/pilot/manifests/.
   Emits safe provenance records and machine trace to data/pilot/provenance/.
   Atomically removes staging files.
7. resume(run_id=None):
   Uses checkpoint file in data/pilot/staging/ckpt_{run_id}.json.
   Supports resuming interrupted runs without duplicate accepted records, shard corruption, or accounting mismatch.
   Replay protection: Deterministic identity f'{source_id}:{page_id}:{revision_id}'.
   Same doc + same revision -> duplicate rejected; same doc + new revision -> accepted as distinct version.

Hard Invariants:
- Absolute prohibition of writes to authoritative production directory data/shards/.
- Zero modification to src/nirmal/.
- Zero leakage of raw secrets or copyrighted texts into audit/provenance files.
"""

from dataclasses import dataclass, field, asdict
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import time
from typing import Any, Dict, List, Optional, Set, Tuple
import unicodedata
import uuid

import numpy as np

from training.v8_2_data_engine import ProductionDocument, ProvenanceMetadata
from training.v8_4_code_safety import CodeSafetyScanner, CodeSafetyConfig, ScannerAction
from training.v8_4_decontamination import NgramDecontaminationEngine
from training.v8_4_global_dedup import ProductionDeduplicationPipeline
from training.v8_4_ingestion import StreamingIngestionEngine
from training.v8_4_tokenization import ProductionTokenizationPipeline, EXPECTED_TOKENIZER_CHECKSUM
from training.acquisition.capability_classifier import CapabilityClassifier
from training.acquisition.capability_mixture import CapabilityMixturePlanner
from training.acquisition.pilot_accounting import (
    PilotAccountingTracker,
    AccountingConservationError,
    RejectedRecordAudit,
)
from training.acquisition.pilot_manifest import PilotManifestManager, DocumentProvenanceEntry
from training.acquisition.safe_network_client import (
    SafeBoundedNetworkClient,
    SafeFetchResult,
    NetworkSecurityError,
    BoundedPayloadError,
)
from training.acquisition.pilot_provenance_audit import (
    PilotProvenanceClass,
    PilotProvenanceAuditor,
    PilotDocumentAuditEntry,
    DocumentTraceStep,
    ProvenanceVerificationError,
    PROVENANCE_DIR,
)
from training.acquisition.pilot_adapter import (
    PilotSourceAdapter,
    PilotResult,
    PilotLimitExceededError,
    PilotSecurityError,
    PilotIntegrityError,
    PILOT_DIR,
    PILOT_STAGING_DIR,
    PILOT_SHARDS_DIR,
    PILOT_MANIFESTS_DIR,
    PILOT_PROVENANCE_DIR,
    FORBIDDEN_DIRS,
)

DATA_DIR = Path("data")

DEFAULT_ACADEMIC_TOPICS: List[str] = [
    "Quantum_computing",
    "Differential_geometry",
    "Photosynthesis",
    "Turing_machine",
    "Plate_tectonics",
    "General_relativity",
    "Thermodynamics",
    "Cell_biology",
    "Graph_theory",
    "Computational_complexity_theory",
]


class WikimediaRealAdapter(PilotSourceAdapter):
    """
    Hardened real Wikimedia source acquisition adapter for Nirmal-1 V8.9.
    Implements genuine bounded remote HTTP acquisition, strict provenance validation,
    content/metadata separation, robust pipeline processing, atomic operations,
    and crash-safe resume with replay protection.
    """

    DEFAULT_TOPICS = DEFAULT_ACADEMIC_TOPICS

    def __init__(
        self,
        run_id: Optional[str] = None,
        config_path: Optional[Path] = None,
        staging_dir: Optional[Path] = None,
        shards_dir: Optional[Path] = None,
        manifests_dir: Optional[Path] = None,
        provenance_dir: Optional[Path] = None,
        network_client: Optional[SafeBoundedNetworkClient] = None,
    ):
        super().__init__(
            source_id="wikipedia_open_corpus",
            config_path=config_path,
            staging_dir=staging_dir,
            shards_dir=shards_dir,
            manifests_dir=manifests_dir,
            provenance_dir=provenance_dir,
        )
        self.version = "2026.09"
        self.revision = "enwiki_20260901_pilot"
        self.run_id = run_id or f"pilot_{self.source_id}_{int(time.time())}_{uuid.uuid4().hex[:6]}"
        self.accounting = PilotAccountingTracker(source_id=self.source_id, pilot_run_id=self.run_id)

        # Enforce adapter-specific hard ceilings for V9.2 bounded test
        self.max_docs = min(self.max_docs, 10)
        self.max_bytes = min(self.max_bytes, 10485760)  # 10 MB
        self.max_tokens = min(self.max_tokens, 100000)
        self.max_disk = min(self.max_disk, 104857600)  # 100 MB

        self.capability_classifier = CapabilityClassifier(taxonomy_path=DATA_DIR / "capability_taxonomy.json")
        self.capability_planner = CapabilityMixturePlanner(taxonomy_path=DATA_DIR / "capability_taxonomy.json")

        self.network_client = network_client or SafeBoundedNetworkClient(
            max_doc_bytes=128 * 1024,
            max_total_bytes=self.max_bytes,
            timeout_seconds=10.0,
            max_redirects=3,
        )

        # Internal state
        self.processed_identities: Dict[str, str] = {}  # identity -> doc_id
        self.accepted_records: List[Dict[str, Any]] = []
        self.all_token_ids: List[int] = []
        self.doc_provenance: List[DocumentProvenanceEntry] = []
        self.audit_entries: List[PilotDocumentAuditEntry] = []
        self.trace_steps: List[DocumentTraceStep] = []
        self.staging_files: List[Path] = []
        self.last_raw_payload_hash: str = ""
        self.last_shard_bin_path: Optional[Path] = None
        self.last_shard_hash: str = ""

    # ----------------------------------------------------------------------
    # 1. inspect(): Returns metadata, endpoints, format, status, ceilings
    # ----------------------------------------------------------------------
    def inspect(self) -> Dict[str, Any]:
        self.check_eligibility()
        return {
            "source_id": self.source_id,
            "version": self.version,
            "revision": self.revision,
            "endpoint": "https://en.wikipedia.org/api/rest_v1/page/summary/{title}",
            "format": "wikimedia_rest_v1_json",
            "pilot_status": "PILOT_ELIGIBLE",
            "status": "PILOT_ELIGIBLE",
            "ceilings": {
                "max_documents": self.max_docs,
                "max_download_bytes": self.max_bytes,
                "max_doc_bytes": 128 * 1024,
                "max_accepted_tokens": self.max_tokens,
                "max_temp_disk_bytes": self.max_disk,
                "timeout_seconds": 10.0,
            },
            "deterministic_academic_topics": self.DEFAULT_TOPICS,
        }

    # ----------------------------------------------------------------------
    # Helper: prepare_pilot(), acquire_pilot(), verify_pilot(), finalize_pilot()
    # ----------------------------------------------------------------------
    def prepare_pilot(self) -> bool:
        self.check_eligibility()
        self.verify_destination_safety(self.staging_dir)
        self.verify_destination_safety(self.shards_dir)
        self.verify_destination_safety(self.manifests_dir)
        self.verify_destination_safety(self.provenance_dir)

        self.staging_dir.mkdir(parents=True, exist_ok=True)
        self.shards_dir.mkdir(parents=True, exist_ok=True)
        self.manifests_dir.mkdir(parents=True, exist_ok=True)
        self.provenance_dir.mkdir(parents=True, exist_ok=True)

        total, used, free = shutil.disk_usage(self.staging_dir)
        if free < self.max_disk:
            raise PilotLimitExceededError(
                f"Insufficient disk space for staging: {free} bytes free < {self.max_disk} required."
            )
        return True

    def acquire_pilot(self) -> Tuple[List[Dict[str, Any]], int]:
        return self.fetch_bounded()

    def verify_pilot(self, raw_records: List[Dict[str, Any]], raw_bytes: int) -> bool:
        if raw_bytes > self.max_bytes:
            raise PilotLimitExceededError(f"Raw bytes exceed ceiling: {raw_bytes} > {self.max_bytes}")
        if len(raw_records) > self.max_docs:
            raise PilotLimitExceededError(f"Document count exceeds ceiling: {len(raw_records)} > {self.max_docs}")
        return self.validate_provenance(raw_records)

    def finalize_pilot(self, records_override: Optional[List[Dict[str, Any]]] = None) -> PilotResult:
        return self.run_pipeline(records=records_override)

    # ----------------------------------------------------------------------
    # Revision ID Authenticity Checker
    # ----------------------------------------------------------------------
    @staticmethod
    def _is_genuine_revision_id(rev: Any) -> bool:
        """
        Validates whether a revision ID is genuine.
        In MediaWiki, revision IDs are strictly positive integers (e.g. 1198274612).
        Non-numeric strings, placeholders ('mock', 'rev_123', 'enwiki_rest_v1'),
        nulls, or negative numbers fail verification.
        """
        if rev is None:
            return False
        if isinstance(rev, int):
            return rev > 0
        if isinstance(rev, str):
            rev_str = rev.strip()
            if rev_str.isdigit() and int(rev_str) > 0:
                return True
            return False
        return False

    # ----------------------------------------------------------------------
    # 2. fetch_bounded(topics=None, max_docs=10, max_payload_bytes=1048576)
    # ----------------------------------------------------------------------
    def fetch_bounded(
        self,
        topics: Optional[List[str]] = None,
        max_docs: int = 10,
        max_payload_bytes: int = 1048576,
    ) -> Tuple[List[Dict[str, Any]], int]:
        """
        Safely acquires a bounded batch of Wikipedia summaries from the Wikimedia REST API.
        Enforces:
        - Max 10 documents
        - Max 1 MB total payload
        - Max 128 KB per document
        - 10.0s request timeout
        - Authenticity verification of revision ID
        - Segregation of thumbnails, descriptions, image URLs into metadata
        """
        self.prepare_pilot()

        if max_docs > 10:
            raise PilotLimitExceededError(f"max_docs ceiling breached: {max_docs} > 10")
        if max_payload_bytes > 1048576:
            raise PilotLimitExceededError(f"max_payload_bytes ceiling breached: {max_payload_bytes} > 1048576")

        target_topics = list(topics) if topics is not None else self.DEFAULT_TOPICS[:max_docs]
        if len(target_topics) > max_docs:
            raise PilotLimitExceededError(
                f"Requested topics count exceeds max_docs ceiling: {len(target_topics)} > {max_docs}"
            )
        if len(target_topics) > self.max_docs:
            raise PilotLimitExceededError(
                f"Requested topics count exceeds adapter max_docs: {len(target_topics)} > {self.max_docs}"
            )

        records: List[Dict[str, Any]] = []
        total_downloaded_bytes = 0

        for title in target_topics:
            url = f"https://en.wikipedia.org/api/rest_v1/page/summary/{title}"
            dest_file = self.staging_dir / f"{self.run_id}_{title}.json"
            self.staging_files.append(dest_file)

            fetch_res = self.network_client.fetch_url_to_file(url, dest_file)
            total_downloaded_bytes += fetch_res.payload_bytes

            if total_downloaded_bytes > max_payload_bytes or total_downloaded_bytes > self.max_bytes:
                raise PilotLimitExceededError(
                    f"Cumulative download bytes ceiling breached: {total_downloaded_bytes} > {min(max_payload_bytes, self.max_bytes)}"
                )

            with open(dest_file, "r", encoding="utf-8") as f:
                data = json.load(f)

            raw_text = data.get("extract", "")
            page_id = data.get("pageid")
            rev_raw = data.get("revision")
            ts = data.get("timestamp", time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()))
            desktop_url = (
                data.get("content_urls", {}).get("desktop", {}).get("page")
                or f"https://en.wikipedia.org/wiki/{title}"
            )

            # Authenticity check on revision ID
            is_verified = self._is_genuine_revision_id(rev_raw)
            rev_id_str = str(rev_raw) if rev_raw is not None else ""

            # Content vs metadata separation:
            # ONLY extract text enters the 'text' field.
            # Thumbnails, descriptions, image URLs, dimensions, and API metadata
            # are strictly segregated into provenance metadata.
            segregated_meta = {
                "page_id": page_id,
                "description": data.get("description"),
                "thumbnail": data.get("thumbnail"),
                "originalimage": data.get("originalimage"),
                "content_urls": data.get("content_urls"),
                "wikibase_item": data.get("wikibase_item"),
                "namespace": data.get("namespace"),
                "lang": data.get("lang"),
                "dir": data.get("dir"),
                "type": data.get("type"),
                "titles": data.get("titles"),
            }

            doc_id = f"wiki_{page_id}" if page_id is not None else f"wiki_{title}"

            record: Dict[str, Any] = {
                "id": doc_id,
                "source_id": self.source_id,
                "page_id": str(page_id) if page_id is not None else "",
                "title": data.get("title", title),
                "revision_id": rev_id_str,
                "revision_verified": is_verified,
                "timestamp": ts,
                "url": desktop_url,
                "license": "CC-BY-SA-4.0",
                "text": raw_text,  # ONLY article extract text
                "raw_payload_hash": fetch_res.sha256_hash,
                "raw_bytes": fetch_res.payload_bytes,
                "provenance_class": PilotProvenanceClass.REMOTE_SOURCE_DATA.value,
                "is_network_retrieved": True,
                "is_local_fixture": False,
                "is_synthetic": False,
                "is_copied_from_repo": False,
                "metadata": segregated_meta,
            }
            records.append(record)

        return records, total_downloaded_bytes

    # ----------------------------------------------------------------------
    # 3. normalize(raw_records): NFC, LF line endings, whitespace collapse
    #    Content vs metadata separation: ONLY extract text normalized/tokenized
    # ----------------------------------------------------------------------
    def normalize(self, raw_records: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Normalizes article extract texts:
        - Unicode NFC normalization
        - LF line endings
        - Whitespace collapse
        Content vs metadata separation:
        ONLY article extract text enters normalization and tokenization.
        Thumbnails, image URLs, descriptions, API metadata, and page IDs are segregated into provenance metadata.
        """
        normalized_records: List[Dict[str, Any]] = []

        for r in raw_records:
            raw_text = r.get("text", "")
            if not isinstance(raw_text, str):
                raw_text = str(raw_text)

            # 1. Unicode NFC
            norm = unicodedata.normalize("NFC", raw_text)

            # 2. LF line endings
            norm = norm.replace("\r\n", "\n").replace("\r", "\n")

            # 3. Whitespace collapse within lines
            lines = [re.sub(r"[ \t]+", " ", line).strip() for line in norm.split("\n")]
            norm = "\n".join(lines).strip()

            # Segregate metadata: ensure no metadata leaks into text
            meta = dict(r.get("metadata", {}))
            for key in (
                "description",
                "thumbnail",
                "originalimage",
                "content_urls",
                "wikibase_item",
                "namespace",
                "page_id",
                "pageid",
                "titles",
                "dir",
                "lang",
                "type",
            ):
                if key in r and key not in meta:
                    meta[key] = r[key]

            norm_rec = dict(r)
            norm_rec["text"] = norm  # ONLY article extract text
            norm_rec["metadata"] = meta
            normalized_records.append(norm_rec)

        return normalized_records

    # ----------------------------------------------------------------------
    # 4. validate_provenance(records): Enforces REMOTE_SOURCE_DATA truth
    # ----------------------------------------------------------------------
    def validate_provenance(self, records: List[Dict[str, Any]]) -> bool:
        """
        Enforces REMOTE_SOURCE_DATA.
        Rejects:
        - Missing or invalid Wikipedia URLs (must start with https:// and be wikipedia.org)
        - Missing revision IDs
        - Unverified or non-numeric revision IDs (revision_verified must be True)
        - Local fixtures or synthetic records claiming remote status
        Fails closed on any ambiguity.
        """
        if not records:
            raise ProvenanceVerificationError("Provenance validation failed: empty records list.")

        for r in records:
            doc_id = r.get("id", "unknown_doc")

            # Check provenance classification
            prov_class = r.get("provenance_class")
            if prov_class not in (PilotProvenanceClass.REMOTE_SOURCE_DATA, PilotProvenanceClass.REMOTE_SOURCE_DATA.value):
                raise ProvenanceVerificationError(
                    f"Record '{doc_id}' has non-remote provenance class '{prov_class}'. Must be REMOTE_SOURCE_DATA."
                )

            # Reject fraud: cannot be local fixture or synthetic
            if r.get("is_local_fixture") is True:
                raise ProvenanceVerificationError(
                    f"CRITICAL PROVENANCE FRAUD: Record '{doc_id}' is marked is_local_fixture=True while claiming REMOTE_SOURCE_DATA!"
                )
            if r.get("is_synthetic") is True:
                raise ProvenanceVerificationError(
                    f"CRITICAL PROVENANCE FRAUD: Record '{doc_id}' is marked is_synthetic=True while claiming REMOTE_SOURCE_DATA!"
                )
            if r.get("is_copied_from_repo") is True:
                raise ProvenanceVerificationError(
                    f"CRITICAL PROVENANCE FRAUD: Record '{doc_id}' is marked is_copied_from_repo=True while claiming REMOTE_SOURCE_DATA!"
                )
            if not r.get("is_network_retrieved"):
                raise ProvenanceVerificationError(
                    f"Provenance validation failed: Record '{doc_id}' claims REMOTE_SOURCE_DATA but is_network_retrieved is False!"
                )

            # Validate URL
            url = r.get("url")
            if not url or not isinstance(url, str) or not (url.startswith("https://") and "wikipedia.org" in url):
                raise ProvenanceVerificationError(
                    f"Provenance validation failed: Record '{doc_id}' has missing or invalid Wikipedia HTTPS URL: '{url}'."
                )

            # Validate revision ID and authenticity flag
            rev_id = r.get("revision_id")
            if rev_id is None or str(rev_id).strip() == "":
                raise ProvenanceVerificationError(
                    f"Provenance validation failed: Record '{doc_id}' has missing revision ID."
                )

            if r.get("revision_verified") is not True:
                raise ProvenanceVerificationError(
                    f"Provenance validation failed: Record '{doc_id}' has unverified revision ID '{rev_id}' (revision_verified=False)."
                )

            if not self._is_genuine_revision_id(rev_id):
                raise ProvenanceVerificationError(
                    f"Provenance validation failed: Record '{doc_id}' has invalid non-numeric revision ID: '{rev_id}'."
                )

            # Validate raw payload hash
            raw_hash = r.get("raw_payload_hash")
            if not raw_hash or len(str(raw_hash)) != 64:
                raise ProvenanceVerificationError(
                    f"Provenance validation failed: Record '{doc_id}' missing valid SHA-256 raw payload hash."
                )

        return True

    # ----------------------------------------------------------------------
    # Checkpoint Persistence Helper
    # ----------------------------------------------------------------------
    def _save_checkpoint(self, remaining_records: Optional[List[Dict[str, Any]]] = None) -> Path:
        """
        Atomically writes intermediate execution checkpoint to data/pilot/staging/ckpt_{run_id}.json
        using a .part file for crash resilience.
        """
        ckpt_path = self.staging_dir / f"ckpt_{self.run_id}.json"
        part_path = self.staging_dir / f"ckpt_{self.run_id}.json.part"

        data = {
            "run_id": self.run_id,
            "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "source_id": self.source_id,
            "version": self.version,
            "revision": self.revision,
            "processed_identities": self.processed_identities,
            "accepted_records": self.accepted_records,
            "all_token_ids": self.all_token_ids,
            "doc_provenance": [e.to_dict() for e in self.doc_provenance],
            "audit_entries": [e.to_dict() for e in self.audit_entries],
            "trace_steps": [s.to_dict() for s in self.trace_steps],
            "accounting": self.accounting.to_dict(),
            "remaining_records": remaining_records or [],
            "last_raw_payload_hash": self.last_raw_payload_hash,
            "staging_files": [str(p) for p in self.staging_files],
        }

        with open(part_path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)

        if part_path.exists():
            if ckpt_path.exists():
                ckpt_path.unlink()
            part_path.replace(ckpt_path)

        return ckpt_path

    # ----------------------------------------------------------------------
    # 5. run_pipeline(records=None): Full multi-stage pipeline
    # ----------------------------------------------------------------------
    def run_pipeline(
        self,
        records: Optional[List[Dict[str, Any]]] = None,
        simulate_interrupt_after: Optional[int] = None,
    ) -> PilotResult:
        """
        Executes the hardened multi-stage acquisition and ingestion pipeline:
        Normalization -> Quality filter -> CodeSafetyScanner -> Global exact dedup
        -> MinHash near dedup -> 13-gram benchmark decontamination -> Tokenization
        -> Binary sharding (uint16 in data/pilot/shards/) -> Manifest signing -> Accounting -> Trace generation.
        """
        self.prepare_pilot()

        if records is None:
            raw_records, total_bytes = self.fetch_bounded()
        else:
            raw_records = records
            total_bytes = sum(r.get("raw_bytes", len(r.get("text", "").encode("utf-8"))) for r in raw_records)

        # 1. Provenance truth validation
        self.validate_provenance(raw_records)

        # 2. Normalization & metadata segregation
        norm_records = self.normalize(raw_records)

        # Stage raw records batch in data/pilot/staging/
        raw_staging_path = self.staging_dir / f"{self.run_id}_raw.json"
        self.staging_files.append(raw_staging_path)
        with open(raw_staging_path, "w", encoding="utf-8") as f:
            json.dump(raw_records, f, indent=2)
        self.last_raw_payload_hash = hashlib.sha256(raw_staging_path.read_bytes()).hexdigest()

        # Iterate through normalized records
        for idx, r in enumerate(norm_records):
            doc_id = r["id"]
            page_id = str(r.get("page_id") or doc_id)
            rev_id = str(r.get("revision_id"))
            # Deterministic Replay Identity: f'{source_id}:{page_id}:{revision_id}'
            doc_identity = f"{self.source_id}:{page_id}:{rev_id}"

            text = r["text"]
            b_len = r.get("raw_bytes", len(text.encode("utf-8")))
            est_tokens = len(text.split())
            doc_raw_hash = r.get("raw_payload_hash", hashlib.sha256(text.encode("utf-8")).hexdigest())

            self.accounting.record_discovery(raw_bytes=b_len, estimated_tokens=est_tokens)

            # Replay Protection:
            # Same doc + same revision -> duplicate rejected
            # Same doc + new revision -> accepted as distinct version
            if doc_identity in self.processed_identities:
                self.accounting.record_rejection(
                    doc_id=doc_id,
                    stage="dedup",
                    reason=f"replay_duplicate_same_revision:{doc_identity}",
                    char_length=len(text),
                    estimated_tokens=est_tokens,
                    safe_meta={"title": r.get("title", ""), "identity": doc_identity},
                )
                self.trace_steps.append(
                    DocumentTraceStep(
                        doc_id=doc_id,
                        raw_source_bytes=b_len,
                        raw_payload_hash=doc_raw_hash,
                        normalized_byte_count=len(text.encode("utf-8")),
                        document_hash=hashlib.sha256(text.encode("utf-8")).hexdigest(),
                        quality_decision="SKIPPED",
                        security_decision="SKIPPED",
                        dedup_decision="REJECTED_REPLAY_DUPLICATE",
                        contamination_decision="SKIPPED",
                        token_count=0,
                        shard_hash="NONE_REJECTED",
                    )
                )
                continue

            doc_hash = hashlib.sha256(text.encode("utf-8")).hexdigest()
            norm_b_len = len(text.encode("utf-8"))

            quality_dec = "PASS"
            security_dec = "PASS"
            dedup_dec = "PASS"
            contamination_dec = "PASS"

            # Stage 2: Quality Filter
            is_retained, qual_reason = self.ingestion_engine.filter_document(text)
            if not is_retained:
                rej_stage = "quality"
                if qual_reason == "credential_secret_detected":
                    rej_stage = "security"
                    security_dec = "REJECTED_SECRET"
                elif qual_reason == "benchmark_contamination_detected":
                    rej_stage = "contamination"
                    contamination_dec = "REJECTED_CONTAMINATION"
                else:
                    quality_dec = f"REJECTED_{qual_reason}"

                self.accounting.record_rejection(
                    doc_id=doc_id,
                    stage=rej_stage,
                    reason=qual_reason or "quality_rejected",
                    char_length=len(text),
                    estimated_tokens=est_tokens,
                    safe_meta={"title": r.get("title", "")},
                )
                self.trace_steps.append(
                    DocumentTraceStep(
                        doc_id=doc_id,
                        raw_source_bytes=b_len,
                        raw_payload_hash=doc_raw_hash,
                        normalized_byte_count=norm_b_len,
                        document_hash=doc_hash,
                        quality_decision=quality_dec,
                        security_decision=security_dec,
                        dedup_decision="SKIPPED",
                        contamination_decision="SKIPPED",
                        token_count=0,
                        shard_hash="NONE_REJECTED",
                    )
                )
                continue

            # Stage 3: Code Safety / Secrets Scan
            scan_res = self.code_safety_scanner.scan_text(text)
            if scan_res.action != ScannerAction.ALLOW:
                security_dec = f"REJECTED_{scan_res.action.value}"
                self.accounting.record_rejection(
                    doc_id=doc_id,
                    stage="security",
                    reason=f"security_violation_{scan_res.action.value}",
                    char_length=len(text),
                    estimated_tokens=est_tokens,
                    safe_meta={"title": r.get("title", "")},
                )
                self.trace_steps.append(
                    DocumentTraceStep(
                        doc_id=doc_id,
                        raw_source_bytes=b_len,
                        raw_payload_hash=doc_raw_hash,
                        normalized_byte_count=norm_b_len,
                        document_hash=doc_hash,
                        quality_decision=quality_dec,
                        security_decision=security_dec,
                        dedup_decision="SKIPPED",
                        contamination_decision="SKIPPED",
                        token_count=0,
                        shard_hash="NONE_REJECTED",
                    )
                )
                continue

            # Stage 4: Global Exact Dedup & MinHash Near Dedup
            is_retained_dedup, dedup_reason, sim = self.dedup_pipeline.process_document(text, doc_id=doc_id)
            if not is_retained_dedup:
                dedup_dec = f"REJECTED_{dedup_reason}"
                self.accounting.record_rejection(
                    doc_id=doc_id,
                    stage="dedup",
                    reason=dedup_reason or "duplicate_rejected",
                    char_length=len(text),
                    estimated_tokens=est_tokens,
                    safe_meta={"title": r.get("title", "")},
                )
                self.trace_steps.append(
                    DocumentTraceStep(
                        doc_id=doc_id,
                        raw_source_bytes=b_len,
                        raw_payload_hash=doc_raw_hash,
                        normalized_byte_count=norm_b_len,
                        document_hash=doc_hash,
                        quality_decision=quality_dec,
                        security_decision=security_dec,
                        dedup_decision=dedup_dec,
                        contamination_decision="SKIPPED",
                        token_count=0,
                        shard_hash="NONE_REJECTED",
                    )
                )
                continue

            # Stage 5: 13-gram Benchmark Decontamination
            decontam_res = self.decontamination_engine.query_document(text)
            if not decontam_res.is_clean:
                contamination_dec = f"REJECTED_{decontam_res.highest_match_type.value}"
                self.accounting.record_rejection(
                    doc_id=doc_id,
                    stage="contamination",
                    reason=f"benchmark_contamination_{decontam_res.highest_match_type.value}",
                    char_length=len(text),
                    estimated_tokens=est_tokens,
                    safe_meta={"title": r.get("title", "")},
                )
                self.trace_steps.append(
                    DocumentTraceStep(
                        doc_id=doc_id,
                        raw_source_bytes=b_len,
                        raw_payload_hash=doc_raw_hash,
                        normalized_byte_count=norm_b_len,
                        document_hash=doc_hash,
                        quality_decision=quality_dec,
                        security_decision=security_dec,
                        dedup_decision=dedup_dec,
                        contamination_decision=contamination_dec,
                        token_count=0,
                        shard_hash="NONE_REJECTED",
                    )
                )
                continue

            # Stage 6: Tokenization
            tok_ids, tok_meta = self.tokenization_pipeline.encode_document(text)
            token_count = len(tok_ids)

            # Stage 6.5: Capability Classification
            meta_for_classifier = {
                "source_id": self.source_id,
                "url": r.get("url", ""),
            }
            cap_labels, cap_confidence = self.capability_classifier.classify_document(text, meta_for_classifier)
            self.capability_planner.add_document({
                "token_count": token_count,
                "source_id": self.source_id,
                "capability_labels": cap_labels,
                "quality_score": "UNKNOWN",
            })

            # Ceiling check
            if (self.accounting.accepted_tokens + token_count) > self.max_tokens:
                raise PilotLimitExceededError(
                    f"Token ceiling breached! {self.accounting.accepted_tokens + token_count} > {self.max_tokens}"
                )

            # Record acceptance
            self.accounting.record_acceptance(norm_tokens=token_count, shard_tokens=token_count)
            self.all_token_ids.extend(tok_ids)
            self.processed_identities[doc_identity] = doc_id
            self.accepted_records.append({"doc_id": doc_id, "text": text, "identity": doc_identity})

            entry = DocumentProvenanceEntry(
                doc_id=doc_id,
                sha256=doc_hash,
                token_count=token_count,
                title=r.get("title", ""),
                canonical_url=r.get("url", ""),
                source_revision=str(r.get("revision_id", self.revision)),
                license_tag=r.get("license", "CC-BY-SA-4.0"),
                accepted_timestamp=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            )
            self.doc_provenance.append(entry)

            audit_entry = PilotDocumentAuditEntry(
                document_hash=doc_hash,
                source_id=self.source_id,
                provenance_class=PilotProvenanceClass.REMOTE_SOURCE_DATA,
                canonical_source=self.source_id,
                source_url=r.get("url", ""),
                source_revision=str(r.get("revision_id", self.revision)),
                retrieval_timestamp=r.get("timestamp", time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())),
                raw_byte_count=b_len,
                normalized_byte_count=norm_b_len,
                token_count=token_count,
                adapter_identifier="WikimediaRealAdapter",
                pipeline_version="V8.9",
                acquisition_record_id=self.run_id,
                raw_payload_hash=doc_raw_hash,
                is_network_retrieved=True,
                is_local_fixture=False,
                is_synthetic=False,
                is_copied_from_repo=False,
                capability_labels=cap_labels if 'cap_labels' in locals() else [],
                capability_confidence=cap_confidence if 'cap_confidence' in locals() else "UNKNOWN",
            )
            self.audit_entries.append(audit_entry)

            self.trace_steps.append(
                DocumentTraceStep(
                    doc_id=doc_id,
                    raw_source_bytes=b_len,
                    raw_payload_hash=doc_raw_hash,
                    normalized_byte_count=norm_b_len,
                    document_hash=doc_hash,
                    quality_decision=quality_dec,
                    security_decision=security_dec,
                    dedup_decision=dedup_dec,
                    contamination_decision=contamination_dec,
                    token_count=token_count,
                    shard_hash="",  # Updated after sharding
                )
            )

            # Simulated interruption support
            if simulate_interrupt_after is not None and (idx + 1) >= simulate_interrupt_after:
                remaining = norm_records[idx + 1 :]
                self._save_checkpoint(remaining_records=remaining)
                raise RuntimeError(f"Simulated interruption after document {idx + 1}")

        # Checkpoint before final sharding
        self._save_checkpoint(remaining_records=[])

        # Stage 7: Binary Sharding (uint16 in data/pilot/shards/)
        shard_bin_path = self.shards_dir / f"{self.run_id}_tokens.bin"
        self.verify_destination_safety(shard_bin_path)

        part_shard_path = shard_bin_path.with_suffix(".bin.part")
        token_arr = np.array(self.all_token_ids, dtype=np.uint16)
        token_arr.tofile(str(part_shard_path))
        if shard_bin_path.exists():
            shard_bin_path.unlink()
        part_shard_path.replace(shard_bin_path)

        shard_hash = hashlib.sha256(shard_bin_path.read_bytes()).hexdigest()
        self.accounting.final_shard_bytes = shard_bin_path.stat().st_size
        self.last_shard_bin_path = shard_bin_path
        self.last_shard_hash = shard_hash

        # Update trace step hashes for accepted docs
        for step in self.trace_steps:
            if step.shard_hash != "NONE_REJECTED":
                step.shard_hash = shard_hash

        return self.finalize()

    # ----------------------------------------------------------------------
    # 6. finalize(): Conservation verification & immutable manifest emission
    # ----------------------------------------------------------------------
    def finalize(self) -> PilotResult:
        """
        Verifies exact conservation: discovered == accepted + sum(rejected).
        Verifies token reconciliation: accepted_tokens == shard_tokens.
        Emits signed immutable manifest to data/pilot/manifests/.
        Emits safe provenance records and machine trace to data/pilot/provenance/.
        Atomically removes staging files.
        """
        # 1. Conservation equation verification
        is_conserved, cons_msg = self.accounting.verify_conservation()
        if not is_conserved:
            raise AccountingConservationError(f"Exact document conservation violated: {cons_msg}")

        # 2. Token reconciliation verification
        if self.accounting.accepted_tokens != self.accounting.final_shard_tokens:
            raise AccountingConservationError(
                f"Token reconciliation violated: accepted_tokens ({self.accounting.accepted_tokens}) "
                f"!= final_shard_tokens ({self.accounting.final_shard_tokens})"
            )

        # 3. Pipeline fingerprints
        tok_fingerprint = self.tokenization_pipeline.tokenizer.compute_checksum()
        config_fingerprint = (
            hashlib.sha256(self.config_path.read_bytes()).hexdigest()
            if self.config_path.exists()
            else "default"
        )

        evidence_refs = {
            "official_evidence_dir": "data/source_evidence/official/wikipedia_open_corpus",
            "eligibility_matrix": "data/source_evidence/source_eligibility_matrix.json",
            "provenance_dir": str(self.provenance_dir),
        }

        # 4. Manifest generation
        manifest_path = self.manifest_manager.generate_manifest(
            source_id=self.source_id,
            source_version=self.version,
            source_revision=self.revision,
            raw_payload_hash=self.last_raw_payload_hash,
            final_shard_hash=self.last_shard_hash,
            final_shard_path=str(self.last_shard_bin_path),
            document_entries=self.doc_provenance,
            accounting_dict=self.accounting.to_dict(),
            tokenizer_fingerprint=tok_fingerprint,
            pipeline_config_fingerprint=config_fingerprint,
            evidence_references=evidence_refs,
            code_commit="v8.9-real-adapter-hardened",
        )

        # 5. Provenance records & machine trace
        prov_file = self.provenance_auditor.save_provenance_record(
            source_id=self.source_id,
            entries=self.audit_entries,
            run_id=self.run_id,
        )
        trace_file = self.provenance_auditor.save_trace(
            source_id=self.source_id,
            steps=self.trace_steps,
            final_shard_hash=self.last_shard_hash,
        )

        # 6. Atomic cleanup of staging files
        for sf in self.staging_files:
            if sf.exists():
                try:
                    sf.unlink()
                except OSError:
                    pass

        # Cleanup checkpoint file upon successful completion
        ckpt_path = self.staging_dir / f"ckpt_{self.run_id}.json"
        if ckpt_path.exists():
            try:
                ckpt_path.unlink()
            except OSError:
                pass

        # V9.2 Capability Balance Report
        cap_report = self.capability_planner.get_report()
        cap_dir = DATA_DIR / "capability_analysis"
        cap_dir.mkdir(parents=True, exist_ok=True)
        with open(cap_dir / "capability_report.json", "w", encoding="utf-8") as f:
            json.dump(cap_report, f, indent=2)

        return PilotResult(
            source_id=self.source_id,
            version=self.version,
            revision=self.revision,
            bytes_downloaded=self.accounting.bytes_downloaded,
            documents_discovered=self.accounting.documents_discovered,
            documents_accepted=self.accounting.documents_accepted,
            documents_rejected=self.accounting.total_rejected,
            tokens_before_filter=self.accounting.source_tokens,
            tokens_after_filter=self.accounting.accepted_tokens,
            dedup_removed=self.accounting.rejected_dedup,
            contamination_removed=self.accounting.rejected_contamination,
            security_removed=self.accounting.rejected_security,
            quality_removed=self.accounting.rejected_quality,
            checksum=self.last_shard_hash,
            manifest_path=str(manifest_path),
            status="SUCCESS",
            provenance_class=PilotProvenanceClass.REMOTE_SOURCE_DATA.value,
            is_genuine_remote=True,
            provenance_path=str(prov_file),
            trace_path=str(trace_file),
        )

    # ----------------------------------------------------------------------
    # 7. resume(run_id=None): Crash resilience & Replay Protection
    # ----------------------------------------------------------------------
    def resume(
        self,
        run_id: Optional[str] = None,
        additional_records: Optional[List[Dict[str, Any]]] = None,
    ) -> PilotResult:
        """
        Resumes an interrupted pilot run using checkpoint file at data/pilot/staging/ckpt_{run_id}.json.
        Guarantees:
        - No duplicate accepted records
        - No shard corruption
        - No accounting mismatch
        - Replay protection: deterministic identity f'{source_id}:{page_id}:{revision_id}'
          Same doc + same revision -> duplicate rejected;
          Same doc + new revision -> accepted as distinct version.
        """
        target_run_id = run_id or self.run_id
        ckpt_path = self.staging_dir / f"ckpt_{target_run_id}.json"
        if not ckpt_path.exists():
            raise FileNotFoundError(f"Checkpoint file not found for run_id '{target_run_id}' at {ckpt_path}")

        with open(ckpt_path, "r", encoding="utf-8") as f:
            ckpt_data = json.load(f)

        self.run_id = ckpt_data["run_id"]
        self.last_raw_payload_hash = ckpt_data.get("last_raw_payload_hash", "")
        self.processed_identities = dict(ckpt_data.get("processed_identities", {}))
        self.accepted_records = list(ckpt_data.get("accepted_records", []))
        self.all_token_ids = list(ckpt_data.get("all_token_ids", []))
        self.staging_files = [Path(p) for p in ckpt_data.get("staging_files", [])]

        # Re-index accepted records into dedup pipeline to protect against subsequent near/exact duplicates
        for rec in self.accepted_records:
            h = hashlib.sha256(rec["text"].encode("utf-8")).hexdigest()
            self.dedup_pipeline.exact_dedup.exact_hashes[h] = rec["doc_id"]
            self.dedup_pipeline.near_dedup.is_near_duplicate(rec["text"], doc_id=rec["doc_id"])

        # Restore accounting
        acct_data = ckpt_data.get("accounting", {})
        self.accounting = PilotAccountingTracker(source_id=self.source_id, pilot_run_id=self.run_id)
        doc_acct = acct_data.get("document_accounting", {})
        self.accounting.documents_discovered = doc_acct.get("documents_discovered", 0)
        self.accounting.documents_accepted = doc_acct.get("documents_accepted", 0)
        rej_by_cat = doc_acct.get("rejected_by_category", {})
        self.accounting.rejected_quality = rej_by_cat.get("quality", 0)
        self.accounting.rejected_security = rej_by_cat.get("security", 0)
        self.accounting.rejected_dedup = rej_by_cat.get("dedup", 0)
        self.accounting.rejected_contamination = rej_by_cat.get("contamination", 0)
        self.accounting.rejected_license = rej_by_cat.get("license", 0)
        self.accounting.rejected_other = rej_by_cat.get("other", 0)

        tok_acct = acct_data.get("token_accounting", {})
        self.accounting.source_tokens = tok_acct.get("source_tokens", 0)
        self.accounting.normalized_tokens = tok_acct.get("normalized_tokens", 0)
        self.accounting.accepted_tokens = tok_acct.get("accepted_tokens", 0)
        self.accounting.final_shard_tokens = tok_acct.get("final_shard_tokens", 0)

        byte_acct = acct_data.get("byte_accounting", {})
        self.accounting.bytes_downloaded = byte_acct.get("bytes_downloaded", 0)
        self.accounting.bytes_staged = byte_acct.get("bytes_staged", 0)
        self.accounting.final_shard_bytes = byte_acct.get("final_shard_bytes", 0)

        rejection_trail = acct_data.get("rejection_audit_summary", [])
        self.accounting.rejection_audit_trail = [
            RejectedRecordAudit(
                doc_id=r["doc_id"],
                rejection_stage=r["rejection_stage"],
                reason=r["reason"],
                char_length=r["char_length"],
                estimated_tokens=r["estimated_tokens"],
                metadata_summary=r.get("metadata_summary", {}),
            )
            for r in rejection_trail
        ]

        self.doc_provenance = [
            DocumentProvenanceEntry(
                doc_id=d["doc_id"],
                sha256=d["sha256"],
                token_count=d["token_count"],
                title=d["title"],
                canonical_url=d["canonical_url"],
                source_revision=d["source_revision"],
                license_tag=d["license_tag"],
                accepted_timestamp=d["accepted_timestamp"],
            )
            for d in ckpt_data.get("doc_provenance", [])
        ]

        self.audit_entries = [
            PilotDocumentAuditEntry(
                document_hash=a["document_hash"],
                source_id=a["source_id"],
                provenance_class=PilotProvenanceClass(a["provenance_class"]),
                canonical_source=a["canonical_source"],
                source_url=a["source_url"],
                source_revision=a["source_revision"],
                retrieval_timestamp=a["retrieval_timestamp"],
                raw_byte_count=a["raw_byte_count"],
                normalized_byte_count=a["normalized_byte_count"],
                token_count=a["token_count"],
                adapter_identifier=a["adapter_identifier"],
                pipeline_version=a["pipeline_version"],
                acquisition_record_id=a["acquisition_record_id"],
                raw_payload_hash=a.get("raw_payload_hash", ""),
                is_network_retrieved=a.get("is_network_retrieved", True),
                is_local_fixture=a.get("is_local_fixture", False),
                is_synthetic=a.get("is_synthetic", False),
                is_copied_from_repo=a.get("is_copied_from_repo", False),
            )
            for a in ckpt_data.get("audit_entries", [])
        ]

        self.trace_steps = [
            DocumentTraceStep(
                doc_id=t["doc_id"],
                raw_source_bytes=t["raw_source_bytes"],
                raw_payload_hash=t["raw_payload_hash"],
                normalized_byte_count=t["normalized_byte_count"],
                document_hash=t["document_hash"],
                quality_decision=t["quality_decision"],
                security_decision=t["security_decision"],
                dedup_decision=t["dedup_decision"],
                contamination_decision=t["contamination_decision"],
                token_count=t["token_count"],
                shard_hash=t["shard_hash"],
            )
            for t in ckpt_data.get("trace_steps", [])
        ]

        remaining_records = list(ckpt_data.get("remaining_records", []))
        if additional_records:
            remaining_records.extend(additional_records)

        # Process remaining records
        for r in remaining_records:
            doc_id = r["id"]
            page_id = str(r.get("page_id") or doc_id)
            rev_id = str(r.get("revision_id"))
            doc_identity = f"{self.source_id}:{page_id}:{rev_id}"

            text = r["text"]
            b_len = r.get("raw_bytes", len(text.encode("utf-8")))
            est_tokens = len(text.split())
            doc_raw_hash = r.get("raw_payload_hash", hashlib.sha256(text.encode("utf-8")).hexdigest())

            self.accounting.record_discovery(raw_bytes=b_len, estimated_tokens=est_tokens)

            # Replay protection:
            # Same doc + same revision -> duplicate rejected
            # Same doc + new revision -> accepted as distinct version
            if doc_identity in self.processed_identities:
                self.accounting.record_rejection(
                    doc_id=doc_id,
                    stage="dedup",
                    reason=f"replay_duplicate_same_revision:{doc_identity}",
                    char_length=len(text),
                    estimated_tokens=est_tokens,
                    safe_meta={"title": r.get("title", ""), "identity": doc_identity},
                )
                self.trace_steps.append(
                    DocumentTraceStep(
                        doc_id=doc_id,
                        raw_source_bytes=b_len,
                        raw_payload_hash=doc_raw_hash,
                        normalized_byte_count=len(text.encode("utf-8")),
                        document_hash=hashlib.sha256(text.encode("utf-8")).hexdigest(),
                        quality_decision="SKIPPED",
                        security_decision="SKIPPED",
                        dedup_decision="REJECTED_REPLAY_DUPLICATE",
                        contamination_decision="SKIPPED",
                        token_count=0,
                        shard_hash="NONE_REJECTED",
                    )
                )
                continue

            doc_hash = hashlib.sha256(text.encode("utf-8")).hexdigest()
            norm_b_len = len(text.encode("utf-8"))

            quality_dec = "PASS"
            security_dec = "PASS"
            dedup_dec = "PASS"
            contamination_dec = "PASS"

            # 2. Quality Filter
            is_retained, qual_reason = self.ingestion_engine.filter_document(text)
            if not is_retained:
                rej_stage = "quality"
                if qual_reason == "credential_secret_detected":
                    rej_stage = "security"
                    security_dec = "REJECTED_SECRET"
                elif qual_reason == "benchmark_contamination_detected":
                    rej_stage = "contamination"
                    contamination_dec = "REJECTED_CONTAMINATION"
                else:
                    quality_dec = f"REJECTED_{qual_reason}"

                self.accounting.record_rejection(
                    doc_id=doc_id,
                    stage=rej_stage,
                    reason=qual_reason or "quality_rejected",
                    char_length=len(text),
                    estimated_tokens=est_tokens,
                    safe_meta={"title": r.get("title", "")},
                )
                self.trace_steps.append(
                    DocumentTraceStep(
                        doc_id=doc_id,
                        raw_source_bytes=b_len,
                        raw_payload_hash=doc_raw_hash,
                        normalized_byte_count=norm_b_len,
                        document_hash=doc_hash,
                        quality_decision=quality_dec,
                        security_decision=security_dec,
                        dedup_decision="SKIPPED",
                        contamination_decision="SKIPPED",
                        token_count=0,
                        shard_hash="NONE_REJECTED",
                    )
                )
                continue

            # 3. Code Safety / Secrets Scan
            scan_res = self.code_safety_scanner.scan_text(text)
            if scan_res.action != ScannerAction.ALLOW:
                security_dec = f"REJECTED_{scan_res.action.value}"
                self.accounting.record_rejection(
                    doc_id=doc_id,
                    stage="security",
                    reason=f"security_violation_{scan_res.action.value}",
                    char_length=len(text),
                    estimated_tokens=est_tokens,
                    safe_meta={"title": r.get("title", "")},
                )
                self.trace_steps.append(
                    DocumentTraceStep(
                        doc_id=doc_id,
                        raw_source_bytes=b_len,
                        raw_payload_hash=doc_raw_hash,
                        normalized_byte_count=norm_b_len,
                        document_hash=doc_hash,
                        quality_decision=quality_dec,
                        security_decision=security_dec,
                        dedup_decision="SKIPPED",
                        contamination_decision="SKIPPED",
                        token_count=0,
                        shard_hash="NONE_REJECTED",
                    )
                )
                continue

            # 4. Global Exact Dedup & MinHash Near Dedup
            is_retained_dedup, dedup_reason, sim = self.dedup_pipeline.process_document(text, doc_id=doc_id)
            if not is_retained_dedup:
                dedup_dec = f"REJECTED_{dedup_reason}"
                self.accounting.record_rejection(
                    doc_id=doc_id,
                    stage="dedup",
                    reason=dedup_reason or "duplicate_rejected",
                    char_length=len(text),
                    estimated_tokens=est_tokens,
                    safe_meta={"title": r.get("title", "")},
                )
                self.trace_steps.append(
                    DocumentTraceStep(
                        doc_id=doc_id,
                        raw_source_bytes=b_len,
                        raw_payload_hash=doc_raw_hash,
                        normalized_byte_count=norm_b_len,
                        document_hash=doc_hash,
                        quality_decision=quality_dec,
                        security_decision=security_dec,
                        dedup_decision=dedup_dec,
                        contamination_decision="SKIPPED",
                        token_count=0,
                        shard_hash="NONE_REJECTED",
                    )
                )
                continue

            # 5. 13-gram Benchmark Decontamination
            decontam_res = self.decontamination_engine.query_document(text)
            if not decontam_res.is_clean:
                contamination_dec = f"REJECTED_{decontam_res.highest_match_type.value}"
                self.accounting.record_rejection(
                    doc_id=doc_id,
                    stage="contamination",
                    reason=f"benchmark_contamination_{decontam_res.highest_match_type.value}",
                    char_length=len(text),
                    estimated_tokens=est_tokens,
                    safe_meta={"title": r.get("title", "")},
                )
                self.trace_steps.append(
                    DocumentTraceStep(
                        doc_id=doc_id,
                        raw_source_bytes=b_len,
                        raw_payload_hash=doc_raw_hash,
                        normalized_byte_count=norm_b_len,
                        document_hash=doc_hash,
                        quality_decision=quality_dec,
                        security_decision=security_dec,
                        dedup_decision=dedup_dec,
                        contamination_decision=contamination_dec,
                        token_count=0,
                        shard_hash="NONE_REJECTED",
                    )
                )
                continue

            # 6. Tokenization
            tok_ids, tok_meta = self.tokenization_pipeline.encode_document(text)
            token_count = len(tok_ids)

            if (self.accounting.accepted_tokens + token_count) > self.max_tokens:
                raise PilotLimitExceededError(
                    f"Token ceiling breached! {self.accounting.accepted_tokens + token_count} > {self.max_tokens}"
                )

            self.accounting.record_acceptance(norm_tokens=token_count, shard_tokens=token_count)
            self.all_token_ids.extend(tok_ids)
            self.processed_identities[doc_identity] = doc_id
            self.accepted_records.append({"doc_id": doc_id, "text": text, "identity": doc_identity})

            entry = DocumentProvenanceEntry(
                doc_id=doc_id,
                sha256=doc_hash,
                token_count=token_count,
                title=r.get("title", ""),
                canonical_url=r.get("url", ""),
                source_revision=str(r.get("revision_id", self.revision)),
                license_tag=r.get("license", "CC-BY-SA-4.0"),
                accepted_timestamp=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            )
            self.doc_provenance.append(entry)

            audit_entry = PilotDocumentAuditEntry(
                document_hash=doc_hash,
                source_id=self.source_id,
                provenance_class=PilotProvenanceClass.REMOTE_SOURCE_DATA,
                canonical_source=self.source_id,
                source_url=r.get("url", ""),
                source_revision=str(r.get("revision_id", self.revision)),
                retrieval_timestamp=r.get("timestamp", time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())),
                raw_byte_count=b_len,
                normalized_byte_count=norm_b_len,
                token_count=token_count,
                adapter_identifier="WikimediaRealAdapter",
                pipeline_version="V8.9",
                acquisition_record_id=self.run_id,
                raw_payload_hash=doc_raw_hash,
                is_network_retrieved=True,
                is_local_fixture=False,
                is_synthetic=False,
                is_copied_from_repo=False,
                capability_labels=cap_labels if 'cap_labels' in locals() else [],
                capability_confidence=cap_confidence if 'cap_confidence' in locals() else "UNKNOWN",
            )
            self.audit_entries.append(audit_entry)

            self.trace_steps.append(
                DocumentTraceStep(
                    doc_id=doc_id,
                    raw_source_bytes=b_len,
                    raw_payload_hash=doc_raw_hash,
                    normalized_byte_count=norm_b_len,
                    document_hash=doc_hash,
                    quality_decision="PASS",
                    security_decision="PASS",
                    dedup_decision="PASS",
                    contamination_decision="PASS",
                    token_count=token_count,
                    shard_hash="",
                )
            )

        # 7. Binary Sharding
        shard_bin_path = self.shards_dir / f"{self.run_id}_tokens.bin"
        self.verify_destination_safety(shard_bin_path)

        part_shard_path = shard_bin_path.with_suffix(".bin.part")
        token_arr = np.array(self.all_token_ids, dtype=np.uint16)
        token_arr.tofile(str(part_shard_path))
        if shard_bin_path.exists():
            shard_bin_path.unlink()
        part_shard_path.replace(shard_bin_path)

        shard_hash = hashlib.sha256(shard_bin_path.read_bytes()).hexdigest()
        self.accounting.final_shard_bytes = shard_bin_path.stat().st_size
        self.last_shard_bin_path = shard_bin_path
        self.last_shard_hash = shard_hash

        for step in self.trace_steps:
            if step.shard_hash != "NONE_REJECTED":
                step.shard_hash = shard_hash

        return self.finalize()
