"""
NIRMAL-1 V8.8: SAFE BOUNDED NETWORK CLIENT FOR PILOT ACQUISITION

Provides fail-closed, bounded HTTP/HTTPS retrieval for pilot samples.

Hard Security & Resource Invariants:
- Max total payload: <= 512 KB (524,288 bytes)
- Max per-document payload: <= 128 KB (131,072 bytes)
- Request timeout: 10.0 seconds
- Redirect limit: <= 3 redirects with loop detection
- Content-Type enforcement
- Streaming read with on-the-fly SHA-256 calculation
- Atomic .part file handling and immediate cleanup on failure
- Zero storage of cookies, authorization headers, or credentials
"""

from dataclasses import dataclass
import hashlib
import json
from pathlib import Path
import time
from typing import Any, Dict, List, Optional, Set, Tuple
import urllib.error
import urllib.parse
import urllib.request


class NetworkSecurityError(Exception):
    """Raised when a network safety policy or ceiling is breached."""
    pass


class BoundedPayloadError(NetworkSecurityError):
    """Raised when remote response exceeds bounded byte limit."""
    pass


class RedirectLoopError(NetworkSecurityError):
    """Raised when excessive redirects or redirect loops are detected."""
    pass


class ContentTypeMismatchError(NetworkSecurityError):
    """Raised when remote server returns unexpected content type."""
    pass


@dataclass
class SafeFetchResult:
    url: str
    status_code: int
    content_type: str
    payload_bytes: int
    sha256_hash: str
    local_path: Optional[Path]
    retrieval_timestamp: str
    redirect_count: int


class SafeBoundedNetworkClient:
    """
    Hardened network client for tiny bounded pilot acquisitions.
    Strictly forbids unbounded streaming or large downloads.
    """

    DEFAULT_USER_AGENT = "Nirmal1-ResearchBot/1.0 (academic-audit; fail-closed)"

    def __init__(
        self,
        max_doc_bytes: int = 128 * 1024,      # 128 KB per doc
        max_total_bytes: int = 512 * 1024,    # 512 KB total
        timeout_seconds: float = 10.0,
        max_redirects: int = 3,
        allowed_content_types: Optional[List[str]] = None,
    ):
        self.max_doc_bytes = max_doc_bytes
        self.max_total_bytes = max_total_bytes
        self.timeout_seconds = timeout_seconds
        self.max_redirects = max_redirects
        self.allowed_content_types = allowed_content_types or [
            "application/json",
            "text/json",
            "application/xml",
            "text/xml",
            "text/plain",
        ]
        self.cumulative_bytes_downloaded = 0

    def reset_cumulative_counter(self) -> None:
        self.cumulative_bytes_downloaded = 0

    def fetch_url_to_file(
        self,
        url: str,
        destination_path: Path,
        expected_sha256: Optional[str] = None,
    ) -> SafeFetchResult:
        """
        Safely fetches URL content into destination_path using an atomic .part file.
        Enforces timeout, max redirects, byte ceilings, and content-type validation.
        """
        # Validate URL scheme
        parsed = urllib.parse.urlparse(url)
        if parsed.scheme not in ("http", "https"):
            raise NetworkSecurityError(f"Disallowed URL scheme '{parsed.scheme}'. Only HTTP/HTTPS permitted.")

        part_file = destination_path.with_suffix(".part")
        part_file.parent.mkdir(parents=True, exist_ok=True)

        visited_urls: Set[str] = {url}
        current_url = url
        redirect_count = 0

        # Redirect resolution loop with loop detection
        while True:
            req = urllib.request.Request(
                current_url,
                headers={"User-Agent": self.DEFAULT_USER_AGENT},
                method="GET",
            )
            # Custom HTTPRedirectHandler can be bypassed by manual redirect tracking
            opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor())

            try:
                response = opener.open(req, timeout=self.timeout_seconds)
            except urllib.error.HTTPError as e:
                # Handle 3xx redirect manually to enforce loop detection and limits
                if e.code in (301, 302, 303, 307, 308):
                    redirect_count += 1
                    if redirect_count > self.max_redirects:
                        raise RedirectLoopError(
                            f"Redirect limit exceeded ({redirect_count} > {self.max_redirects}) for {url}"
                        )
                    location = e.headers.get("Location")
                    if not location:
                        raise NetworkSecurityError("Redirect header missing Location.")
                    next_url = urllib.parse.urljoin(current_url, location)
                    if next_url in visited_urls:
                        raise RedirectLoopError(f"Redirect loop detected: {next_url} already visited in chain!")
                    visited_urls.add(next_url)
                    current_url = next_url
                    continue
                else:
                    raise NetworkSecurityError(f"HTTP error {e.code}: {e.reason}")
            except urllib.error.URLError as e:
                raise NetworkSecurityError(f"Network connection failed: {e.reason}")

            # Check if opener followed redirect automatically
            final_url = response.geturl()
            if final_url != current_url:
                if final_url in visited_urls:
                    raise RedirectLoopError(f"Redirect loop detected: {final_url}")
                visited_urls.add(final_url)
                current_url = final_url

            break

        # Content-Type check
        content_type = response.headers.get("Content-Type", "").lower()
        if self.allowed_content_types:
            type_matched = any(act in content_type for act in self.allowed_content_types)
            if not type_matched:
                raise ContentTypeMismatchError(
                    f"Content-Type '{content_type}' not in allowed types: {self.allowed_content_types}"
                )

        # Stream into .part file with live SHA-256 computation and byte ceilings
        hasher = hashlib.sha256()
        bytes_read = 0

        try:
            with open(part_file, "wb") as f_out:
                while True:
                    chunk = response.read(4096)
                    if not chunk:
                        break
                    chunk_len = len(chunk)
                    bytes_read += chunk_len
                    self.cumulative_bytes_downloaded += chunk_len

                    # Check ceilings
                    if bytes_read > self.max_doc_bytes:
                        raise BoundedPayloadError(
                            f"Per-document byte ceiling breached! ({bytes_read} > {self.max_doc_bytes} bytes)"
                        )
                    if self.cumulative_bytes_downloaded > self.max_total_bytes:
                        raise BoundedPayloadError(
                            f"Total pilot payload ceiling breached! "
                            f"({self.cumulative_bytes_downloaded} > {self.max_total_bytes} bytes)"
                        )

                    hasher.update(chunk)
                    f_out.write(chunk)

            # Verification of minimum length
            if bytes_read == 0:
                raise NetworkSecurityError(f"Received empty response from {current_url}")

            actual_sha256 = hasher.hexdigest()

            # Verify expected checksum if provided
            if expected_sha256 and actual_sha256 != expected_sha256:
                raise NetworkSecurityError(
                    f"Checksum mismatch for {current_url}! Expected {expected_sha256}, got {actual_sha256}"
                )

            # Atomic promotion from .part to destination
            if destination_path.exists():
                destination_path.unlink()
            part_file.replace(destination_path)

            return SafeFetchResult(
                url=current_url,
                status_code=getattr(response, "status", 200),
                content_type=content_type,
                payload_bytes=bytes_read,
                sha256_hash=actual_sha256,
                local_path=destination_path,
                retrieval_timestamp=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                redirect_count=redirect_count,
            )

        except Exception:
            # Atomic cleanup on any failure
            if part_file.exists():
                try:
                    part_file.unlink()
                except OSError:
                    pass
            raise
