"""
V10.0 Abstraction & Systematic Generalization Intervention Engine.

Implements isolated, machine-verifiable experiments across 8 intervention axes:
  A. Representation     B. Vocabulary OOD     C. Positional
  D. Training Objective E. Task Composition   F. Isomorphic Transfer
  G. Scale Sensitivity  H. Failure Classification

All interventions are deterministic, seed-controlled and leakage-audited.
src/nirmal/ is NOT imported for modification — only NirmalConfig/model are used
as the immutable base architecture.
"""

import hashlib
import json
import time
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import psutil

from nirmal.configuration_nirmal import NirmalConfig
from nirmal.model import NirmalForCausalLM


# ---------------------------------------------------------------------------
# Resource Guard (reused from V9.6+)
# ---------------------------------------------------------------------------

class ResourceGuard:
    @staticmethod
    def check(est_ram_mb: int, est_time_s: int) -> bool:
        free = psutil.virtual_memory().available / (1024 ** 2)
        # Micro-model experiments use ~50-150 MB actual RAM.
        # Allow when system has >=200 MB free and the estimate is within budget.
        return free >= 200 and est_ram_mb <= 3000 and est_time_s <= 300


# ---------------------------------------------------------------------------
# Task Generator — deterministic, leakage-audited
# ---------------------------------------------------------------------------

@dataclass
class TaskConfig:
    rule: str           # e.g. "copy", "increment", "double"
    seq_len: int
    train_vocab: Tuple[int, int]   # (lo, hi) exclusive
    val_vocab:   Tuple[int, int]
    ood_vocab:   Tuple[int, int]
    batch_size:  int
    seed: int


class TaskGenerator:
    """Generates synthetic rule-following tasks with provably disjoint partitions."""

    RULES = ["copy", "increment", "double_step"]

    def _make_rng(self, seed: int) -> torch.Generator:
        g = torch.Generator()
        g.manual_seed(seed)
        return g

    def _apply_rule(self, base: torch.Tensor, rule: str) -> torch.Tensor:
        if rule == "copy":
            half = base.shape[1]
            return torch.cat([base, base], dim=1)
        elif rule == "increment":
            # base is shape (B, seq_len) where each row's value is the start token;
            # we use only col 0 as the start and build the ascending sequence.
            start = base[:, :1]  # (B, 1)
            offsets = torch.arange(base.shape[1]).unsqueeze(0).expand(base.shape[0], -1)
            return start + offsets
        elif rule == "double_step":
            start = base[:, :1]
            offsets = (torch.arange(base.shape[1]) * 2).unsqueeze(0).expand(base.shape[0], -1)
            return start + offsets
        else:
            raise ValueError(f"Unknown rule: {rule}")

    def generate(self, cfg: TaskConfig) -> Dict[str, torch.Tensor]:
        g_train = self._make_rng(cfg.seed)
        g_val   = self._make_rng(cfg.seed + 1000)
        g_ood   = self._make_rng(cfg.seed + 2000)

        tlo, thi = cfg.train_vocab
        vlo, vhi = cfg.val_vocab
        olo, ohi = cfg.ood_vocab

        half = cfg.seq_len

        # Safe upper bound to avoid overflow in increment/double_step
        safe_thi = thi - half * 3
        safe_vhi = vhi - half * 3
        safe_ohi = ohi - half * 3

        train_base = torch.randint(tlo, max(tlo + 1, safe_thi), (cfg.batch_size, half), generator=g_train)
        val_base   = torch.randint(vlo, max(vlo + 1, safe_vhi), (cfg.batch_size, half), generator=g_val)
        ood_base   = torch.randint(olo, max(olo + 1, safe_ohi), (cfg.batch_size, half), generator=g_ood)

        if cfg.rule == "copy":
            train = torch.cat([train_base, train_base], dim=1)
            val   = torch.cat([val_base,   val_base],   dim=1)
            ood   = torch.cat([ood_base,   ood_base],   dim=1)
        else:
            train = self._apply_rule(train_base, cfg.rule)
            val   = self._apply_rule(val_base,   cfg.rule)
            ood   = self._apply_rule(ood_base,   cfg.rule)

        return {"train": train, "val": val, "ood": ood}

    def leakage_certificate(self, splits: Dict[str, torch.Tensor]) -> Dict[str, bool]:
        """Machine-verifiable certificate: no overlap between partitions."""
        train_tokens = set(splits["train"].flatten().tolist())
        ood_tokens   = set(splits["ood"].flatten().tolist())
        train_rows   = {tuple(r) for r in splits["train"].tolist()}
        ood_rows     = {tuple(r) for r in splits["ood"].tolist()}

        vocab_disjoint = len(train_tokens & ood_tokens) == 0
        no_row_overlap = len(train_rows & ood_rows) == 0

        # substring leak check (length-3 subsequences)
        train_subs: set = set()
        for row in train_rows:
            for i in range(len(row) - 2):
                train_subs.add(row[i:i+3])
        sub_leak = False
        for row in ood_rows:
            for i in range(len(row) - 2):
                if row[i:i+3] in train_subs:
                    sub_leak = True
                    break

        return {
            "vocab_disjoint":  vocab_disjoint,
            "no_row_overlap":  no_row_overlap,
            "no_subseq_leak":  not sub_leak,
            "valid":           vocab_disjoint and no_row_overlap and not sub_leak,
        }


# ---------------------------------------------------------------------------
# Representation transforms (Axis A — applied outside architecture)
# ---------------------------------------------------------------------------

class RepresentationTransform:
    @staticmethod
    def identity(x: torch.Tensor) -> torch.Tensor:
        return x

    @staticmethod
    def value_relative(x: torch.Tensor, lo: int, hi: int) -> torch.Tensor:
        """Map token ids to [0, hi-lo) band — value-relative encoding."""
        return x - lo

    @staticmethod
    def modular_normalize(x: torch.Tensor, vocab_size: int) -> torch.Tensor:
        return x % vocab_size

    @staticmethod
    def reversed_positions(x: torch.Tensor) -> torch.Tensor:
        return torch.flip(x, dims=[1])


# ---------------------------------------------------------------------------
# Objective wrappers (Axis D — auxiliary losses without modifying architecture)
# ---------------------------------------------------------------------------

class ObjectiveWrapper:
    @staticmethod
    def causal_lm_loss(logits: torch.Tensor, targets: torch.Tensor) -> torch.Tensor:
        B, T, V = logits.shape
        return F.cross_entropy(logits[:, :-1].reshape(-1, V),
                               targets[:, 1:].reshape(-1))

    @staticmethod
    def relation_consistency_loss(logits: torch.Tensor, targets: torch.Tensor) -> torch.Tensor:
        """Penalise inconsistent predictions between structurally isomorphic positions."""
        B, T, V = logits.shape
        base = F.cross_entropy(logits[:, :-1].reshape(-1, V),
                               targets[:, 1:].reshape(-1))
        # Additional: predictions at even positions should mirror odd positions (for copy rule)
        half = T // 2
        if half > 1:
            first_half  = logits[:, :half-1]
            second_half = logits[:, half:half + half - 1]
            min_len = min(first_half.shape[1], second_half.shape[1])
            consistency = F.mse_loss(first_half[:, :min_len], second_half[:, :min_len].detach())
            return base + 0.1 * consistency
        return base

    @staticmethod
    def contrastive_iso_loss(logits: torch.Tensor, targets: torch.Tensor,
                             iso_logits: torch.Tensor, iso_targets: torch.Tensor) -> torch.Tensor:
        """Pull predictions on isomorphic tasks to agree on relative structure."""
        B, T, V = logits.shape
        base = F.cross_entropy(logits[:, :-1].reshape(-1, V),
                               targets[:, 1:].reshape(-1))
        # Softmax agreement between isomorphic task predictions
        p1 = F.softmax(logits[:, :-1], dim=-1)
        p2 = F.softmax(iso_logits[:, :-1], dim=-1)
        min_len = min(p1.shape[1], p2.shape[1])
        kl = F.kl_div(p1[:, :min_len].log(), p2[:, :min_len].detach(), reduction="batchmean")
        return base + 0.05 * kl


# ---------------------------------------------------------------------------
# Micro-model builder (uses Nirmal architecture, fully config-driven)
# ---------------------------------------------------------------------------

def build_micro_model(hidden: int = 32, layers: int = 2, vocab: int = 100) -> NirmalForCausalLM:
    cfg = NirmalConfig(
        vocab_size=vocab,
        hidden_size=hidden,
        num_hidden_layers=layers,
        num_attention_heads=2,
        head_dim=hidden // 2,
        num_key_value_heads=1,
        num_experts=2,
        num_experts_per_tok=1,
        full_attention_interval=2,
    )
    return NirmalForCausalLM(cfg)


# ---------------------------------------------------------------------------
# Training loop (shared across all interventions)
# ---------------------------------------------------------------------------

@dataclass
class RunConfig:
    intervention: str
    seed: int
    steps: int
    lr: float = 5e-3
    hidden: int = 32
    layers: int = 2
    vocab: int = 100
    repr_mode: str = "identity"      # identity | value_relative | modular
    objective: str = "causal_lm"     # causal_lm | relation_consistency | contrastive_iso
    position_mode: str = "normal"    # normal | reversed


@dataclass
class RunResult:
    intervention: str
    seed: int
    steps: int
    train_acc: float
    val_acc: float
    ood_acc: float
    final_loss: float
    primary_failure: str


def _accuracy(model: NirmalForCausalLM, data: torch.Tensor) -> float:
    model.eval()
    with torch.no_grad():
        out = model(input_ids=data, labels=data)
        preds = torch.argmax(out.logits, dim=-1)
        return (preds[:, :-1] == data[:, 1:]).float().mean().item()


def _apply_repr(x: torch.Tensor, mode: str, lo: int = 0, vocab: int = 100) -> torch.Tensor:
    if mode == "value_relative":
        return RepresentationTransform.value_relative(x, lo, lo + vocab).clamp(0, vocab - 1)
    elif mode == "modular":
        return RepresentationTransform.modular_normalize(x, vocab)
    return x  # identity


def _apply_position(x: torch.Tensor, mode: str) -> torch.Tensor:
    if mode == "reversed":
        return RepresentationTransform.reversed_positions(x)
    return x


def run_intervention(
    run_cfg: RunConfig,
    task_cfg: TaskConfig,
    out_dir: Path,
) -> RunResult:
    torch.manual_seed(run_cfg.seed)
    np.random.seed(run_cfg.seed)

    gen = TaskGenerator()
    splits = gen.generate(task_cfg)
    cert   = gen.leakage_certificate(splits)

    tlo = task_cfg.train_vocab[0]

    train_raw = splits["train"]
    val_raw   = splits["val"]
    ood_raw   = splits["ood"]

    # Apply representation transform
    train_x = _apply_repr(_apply_position(train_raw, run_cfg.position_mode), run_cfg.repr_mode, tlo, run_cfg.vocab)
    val_x   = _apply_repr(_apply_position(val_raw,   run_cfg.position_mode), run_cfg.repr_mode, tlo, run_cfg.vocab)
    ood_x   = _apply_repr(_apply_position(ood_raw,   run_cfg.position_mode), run_cfg.repr_mode, task_cfg.ood_vocab[0], run_cfg.vocab)

    # Clamp to vocab
    train_x = train_x.clamp(0, run_cfg.vocab - 1)
    val_x   = val_x.clamp(0, run_cfg.vocab - 1)
    ood_x   = ood_x.clamp(0, run_cfg.vocab - 1)

    model = build_micro_model(run_cfg.hidden, run_cfg.layers, run_cfg.vocab)
    opt   = torch.optim.AdamW(model.parameters(), lr=run_cfg.lr)

    final_loss = float("inf")
    for step in range(run_cfg.steps):
        model.train()
        opt.zero_grad()
        out = model(input_ids=train_x, labels=train_x)

        if run_cfg.objective == "relation_consistency":
            B, T, V = out.logits.shape
            loss = ObjectiveWrapper.relation_consistency_loss(out.logits, train_x)
        elif run_cfg.objective == "contrastive_iso":
            iso_x = _apply_repr(val_x, run_cfg.repr_mode, tlo, run_cfg.vocab).clamp(0, run_cfg.vocab - 1)
            iso_out = model(input_ids=iso_x, labels=iso_x)
            loss = ObjectiveWrapper.contrastive_iso_loss(out.logits, train_x, iso_out.logits, iso_x)
        else:
            loss = out.loss

        loss.backward()
        opt.step()
        final_loss = loss.item()

    t_acc = _accuracy(model, train_x)
    v_acc = _accuracy(model, val_x)
    o_acc = _accuracy(model, ood_x)

    primary_failure = _classify_failure(t_acc, v_acc, o_acc, run_cfg)

    result = RunResult(
        intervention=run_cfg.intervention,
        seed=run_cfg.seed,
        steps=run_cfg.steps,
        train_acc=round(t_acc, 4),
        val_acc=round(v_acc, 4),
        ood_acc=round(o_acc, 4),
        final_loss=round(final_loss, 4),
        primary_failure=primary_failure,
    )

    # Save manifest
    out_dir.mkdir(parents=True, exist_ok=True)
    ts = int(time.time())
    manifest = {
        "experiment_id": f"v10_0_{run_cfg.intervention}_{run_cfg.seed}_{ts}",
        "run_config": asdict(run_cfg),
        "task_config": {
            "rule": task_cfg.rule, "seq_len": task_cfg.seq_len,
            "train_vocab": task_cfg.train_vocab, "val_vocab": task_cfg.val_vocab,
            "ood_vocab": task_cfg.ood_vocab, "seed": task_cfg.seed,
        },
        "leakage_certificate": cert,
        "result": asdict(result),
        "timestamp": ts,
        "config_hash": hashlib.md5(json.dumps(asdict(run_cfg), sort_keys=True).encode()).hexdigest(),
    }
    manifest_path = out_dir / f"manifest_{run_cfg.intervention}_s{run_cfg.seed}_{ts}.json"
    with open(manifest_path, "w") as f:
        json.dump(manifest, f, indent=2)

    return result


def _classify_failure(t_acc: float, v_acc: float, o_acc: float, cfg: RunConfig) -> str:
    if t_acc < 0.5:
        return "TRAINING_SIGNAL"
    if o_acc >= 0.8 and v_acc >= 0.8:
        return "NONE"  # success
    if cfg.repr_mode in ("value_relative", "modular") and o_acc > 0.0:
        return "REPRESENTATION_PARTIAL"
    if cfg.position_mode == "reversed" and o_acc < 0.1:
        return "POSITION"
    if cfg.objective in ("relation_consistency", "contrastive_iso") and o_acc < 0.1:
        return "OBJECTIVE"
    if v_acc >= 0.8 and o_acc < 0.1:
        return "VOCABULARY"
    if t_acc >= 0.8 and v_acc < 0.5:
        return "CAPACITY"
    return "REPRESENTATION"


# ---------------------------------------------------------------------------
# Multi-seed runner (reports mean ± std)
# ---------------------------------------------------------------------------

@dataclass
class InterventionSummary:
    intervention: str
    seeds: List[int]
    mean_train: float
    std_train: float
    mean_val: float
    std_val: float
    mean_ood: float
    std_ood: float
    best_ood: float
    worst_ood: float
    primary_failure: str


def run_multi_seed(
    intervention: str,
    run_cfgs: List[RunConfig],
    task_cfg: TaskConfig,
    out_dir: Path,
) -> InterventionSummary:
    results: List[RunResult] = []
    for rc in run_cfgs:
        if not ResourceGuard.check(200, 30):
            break
        r = run_intervention(rc, task_cfg, out_dir)
        results.append(r)

    trains = [r.train_acc for r in results]
    vals   = [r.val_acc   for r in results]
    oods   = [r.ood_acc   for r in results]
    fails  = [r.primary_failure for r in results]
    primary = max(set(fails), key=fails.count) if fails else "UNKNOWN"

    return InterventionSummary(
        intervention=intervention,
        seeds=[rc.seed for rc in run_cfgs[:len(results)]],
        mean_train=round(float(np.mean(trains)), 4),
        std_train =round(float(np.std(trains)),  4),
        mean_val  =round(float(np.mean(vals)),   4),
        std_val   =round(float(np.std(vals)),    4),
        mean_ood  =round(float(np.mean(oods)),   4),
        std_ood   =round(float(np.std(oods)),    4),
        best_ood  =round(max(oods),              4),
        worst_ood =round(min(oods),              4),
        primary_failure=primary,
    )
