"""
NIRMAL-1 V8.7 PILOT MANIFEST GENERATOR & VERIFIER

Produces and cryptographically verifies immutable pilot manifests under:
  data/pilot/manifests/<source_id>_pilot_manifest.json

Every pilot manifest records complete cryptographic provenance, document-level hashes,
tokenizer fingerprints, pipeline configuration digests, and exact accounting metrics.
"""

from dataclasses import dataclass, field, asdict
import hashlib
import json
from pathlib import Path
import time
from typing import Any, Dict, List, Optional, Tuple

REPO_ROOT = Path(__file__).resolve().parent.parent.parent
DEFAULT_MANIFESTS_DIR = REPO_ROOT / "data" / "pilot" / "manifests"


class PilotManifestError(Exception):
    """Raised when manifest generation or verification fails."""
    pass


@dataclass
class DocumentProvenanceEntry:
    doc_id: str
    sha256: str
    token_count: int
    title: str
    canonical_url: str
    source_revision: str
    license_tag: str
    accepted_timestamp: str

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


class PilotManifestManager:
    """Manages immutable manifest emission and tamper verification for acquisition pilots."""

    def __init__(self, manifests_dir: Optional[Path] = None):
        self.manifests_dir = manifests_dir or DEFAULT_MANIFESTS_DIR
        self.manifests_dir.mkdir(parents=True, exist_ok=True)

    def generate_manifest(
        self,
        source_id: str,
        source_version: str,
        source_revision: str,
        raw_payload_hash: str,
        final_shard_hash: str,
        final_shard_path: str,
        document_entries: List[DocumentProvenanceEntry],
        accounting_dict: Dict[str, Any],
        tokenizer_fingerprint: str,
        pipeline_config_fingerprint: str,
        evidence_references: Dict[str, str],
        code_commit: str = "v8.7-reconciled",
    ) -> Path:
        """
        Builds, signs, and writes an immutable pilot manifest.
        """
        timestamp = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())

        payload: Dict[str, Any] = {
            "manifest_version": "V8.7-PILOT",
            "source_id": source_id,
            "source_version": source_version,
            "source_revision": source_revision,
            "acquisition_timestamp": timestamp,
            "code_commit": code_commit,
            "cryptographic_hashes": {
                "raw_payload_sha256": raw_payload_hash,
                "final_shard_sha256": final_shard_hash,
                "final_shard_path": final_shard_path,
                "tokenizer_fingerprint": tokenizer_fingerprint,
                "pipeline_config_fingerprint": pipeline_config_fingerprint,
            },
            "source_evidence_references": evidence_references,
            "accounting": accounting_dict,
            "document_provenance": [e.to_dict() for e in document_entries],
        }

        # Compute deterministic manifest fingerprint
        raw_bytes = json.dumps(payload, sort_keys=True).encode("utf-8")
        manifest_fingerprint = hashlib.sha256(raw_bytes).hexdigest()
        payload["manifest_fingerprint"] = manifest_fingerprint

        manifest_path = self.manifests_dir / f"{source_id}_pilot_manifest.json"
        with open(manifest_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2)

        return manifest_path

    @staticmethod
    def verify_manifest(manifest_path: Path) -> Tuple[bool, str]:
        """
        Verifies that manifest content matches its cryptographic manifest_fingerprint.
        """
        if not manifest_path.exists():
            return False, f"Manifest file does not exist: {manifest_path}"

        try:
            with open(manifest_path, "r", encoding="utf-8") as f:
                data = json.load(f)
        except Exception as e:
            return False, f"Malformed manifest JSON: {str(e)}"

        recorded_fingerprint = data.pop("manifest_fingerprint", None)
        if not recorded_fingerprint:
            return False, "Missing manifest_fingerprint in manifest JSON."

        raw_bytes = json.dumps(data, sort_keys=True).encode("utf-8")
        computed_fingerprint = hashlib.sha256(raw_bytes).hexdigest()

        if computed_fingerprint != recorded_fingerprint:
            return False, f"Manifest tampering detected! Recorded {recorded_fingerprint} != computed {computed_fingerprint}"

        return True, f"Manifest integrity verified: {computed_fingerprint}"
