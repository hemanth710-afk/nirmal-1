"""
Production Benchmark Decontamination & Evaluation Holdout Protection Engine for Nirmal-1 V8.4.

Features:
- Configurable N-gram contamination engine (default: 13-grams).
- Inverted index across standard benchmarks (GSM8K, HumanEval, MBPP, MMLU, ARC, MATH, and in-repo suites).
- Explicit tracking of benchmark data availability ('INDEXED' vs 'NEEDS_SOURCE_INPUT').
- Multi-tier matching policies: EXACT_MATCH, HIGH_OVERLAP, LOW_OVERLAP, NO_MATCH.
- Cross-split contamination isolation: separate accounting for training vs evaluation leakage.
- Cryptographic index fingerprinting and fail-closed validation.
- Zero copyrighted text leakage: telemetry logs only hashes, scores, and match classifications.
"""

from dataclasses import dataclass, field, asdict
from enum import Enum
import hashlib
import json
from pathlib import Path
import re
import time
from typing import Any, Dict, Generator, List, Optional, Set, Tuple

REPO_ROOT = Path(__file__).resolve().parent.parent


class MatchPolicyType(str, Enum):
    EXACT_MATCH = "EXACT_MATCH"
    HIGH_OVERLAP = "HIGH_OVERLAP"
    LOW_OVERLAP = "LOW_OVERLAP"
    NO_MATCH = "NO_MATCH"


class BenchmarkDataStatus(str, Enum):
    INDEXED = "INDEXED"
    NEEDS_SOURCE_INPUT = "NEEDS_SOURCE_INPUT"


class ContaminationSplit(str, Enum):
    TRAIN = "TRAIN"
    VAL = "VAL"
    TEST = "TEST"


class ContaminationIndexError(Exception):
    """Raised when the benchmark contamination index is corrupted, tampered, or invalid."""
    pass


@dataclass
class BenchmarkEntry:
    benchmark_id: str
    entry_id: str
    normalized_text: str
    content_sha256: str
    num_tokens: int


@dataclass
class ContaminationFinding:
    benchmark_id: str
    entry_id: str
    match_type: MatchPolicyType
    score: float
    matched_ngrams_count: int
    total_doc_ngrams: int
    max_consecutive_ngrams: int
    document_hash: str
    benchmark_entry_hash: str

    def to_dict(self) -> Dict[str, Any]:
        return {
            "benchmark_id": self.benchmark_id,
            "entry_id": self.entry_id,
            "match_type": self.match_type.value,
            "score": round(self.score, 4),
            "matched_ngrams": self.matched_ngrams_count,
            "total_doc_ngrams": self.total_doc_ngrams,
            "max_consecutive": self.max_consecutive_ngrams,
            "document_hash": self.document_hash,
            "benchmark_entry_hash": self.benchmark_entry_hash,
        }


@dataclass
class DecontaminationResult:
    is_clean: bool
    findings: List[ContaminationFinding]
    highest_match_type: MatchPolicyType
    max_score: float
    document_hash: str

    def to_dict(self) -> Dict[str, Any]:
        return {
            "is_clean": self.is_clean,
            "findings": [f.to_dict() for f in self.findings],
            "highest_match_type": self.highest_match_type.value,
            "max_score": round(self.max_score, 4),
            "document_hash": self.document_hash,
        }


class NgramDecontaminationEngine:
    """
    High-performance, deterministic N-gram benchmark decontamination engine.
    """

    SUPPORTED_BENCHMARKS = [
        "GSM8K",
        "HumanEval",
        "MBPP",
        "MMLU",
        "ARC",
        "MATH",
        "AGI_COMPOSITE_IN_REPO",
        "CAUSAL_SIMULATOR_IN_REPO",
    ]

    def __init__(
        self,
        ngram_size: int = 13,
        high_overlap_threshold: float = 0.50,
        min_consecutive_ngrams: int = 3,
    ):
        if ngram_size < 1:
            raise ValueError(f"Invalid ngram_size: {ngram_size}")
        if not (0.0 <= high_overlap_threshold <= 1.0):
            raise ValueError(f"Invalid high_overlap_threshold: {high_overlap_threshold}")

        self.ngram_size = ngram_size
        self.high_overlap_threshold = high_overlap_threshold
        self.min_consecutive_ngrams = min_consecutive_ngrams

        # Inverted index: ngram_hash -> list of (benchmark_id, entry_id, token_pos)
        self.inverted_index: Dict[str, List[Tuple[str, str, int]]] = {}
        self.entries_by_benchmark: Dict[str, Dict[str, BenchmarkEntry]] = {
            b: {} for b in self.SUPPORTED_BENCHMARKS
        }
        self.benchmark_status: Dict[str, BenchmarkDataStatus] = {
            b: BenchmarkDataStatus.NEEDS_SOURCE_INPUT for b in self.SUPPORTED_BENCHMARKS
        }

        # Index metadata
        self.total_ngrams_indexed = 0
        self.index_sha256 = ""

        # Load in-repo benchmarks automatically
        self._index_local_in_repo_benchmarks()

    def normalize_text(self, text: str) -> str:
        """Standardizes text for robust n-gram matching."""
        if not text:
            return ""
        # 1. Lowercase
        t = text.lower()
        # 2. Replace non-alphanumeric with spaces
        t = re.sub(r"[^\w\s]", " ", t)
        # 3. Collapse multiple whitespace
        return re.sub(r"\s+", " ", t).strip()

    def tokenize(self, text: str) -> List[str]:
        norm = self.normalize_text(text)
        return norm.split() if norm else []

    def compute_ngrams(self, tokens: List[str]) -> List[Tuple[str, ...]]:
        """Extracts sliding window tuples of size N."""
        if len(tokens) < self.ngram_size:
            return []
        return [tuple(tokens[i : i + self.ngram_size]) for i in range(len(tokens) - self.ngram_size + 1)]

    def _hash_ngram(self, ngram: Tuple[str, ...]) -> str:
        s = " ".join(ngram)
        return hashlib.sha256(s.encode("utf-8")).hexdigest()[:16]

    def _index_local_in_repo_benchmarks(self) -> None:
        """
        Indexes real in-repo evaluation probes and test items physically present in evals/.
        External benchmarks remain marked as NEEDS_SOURCE_INPUT until officially supplied.
        """
        in_repo_probes = {
            "AGI_COMPOSITE_IN_REPO": [
                ("probe_uuid_4815162342", "needle_key_target_uuid_4815162342 hidden within long horizon reasoning evaluation"),
                ("counterfactual_probe", "counterfactual_do_operator_intervention formal causal DAG evaluation graph verification"),
                ("hidden_probe_agi", "agi_composite_benchmark_hidden_probe synthetic verification evaluation probe"),
                ("causal_chain_ans", "synthetic_causal_chain_groundtruth_answer formal mathematical evaluation verification"),
            ],
            "CAUSAL_SIMULATOR_IN_REPO": [
                ("causal_sim_q1", "intervene on node X to observe downstream counterfactual distribution in causal simulator"),
                ("causal_sim_q2", "calculate average treatment effect under do intervention on variable A with confounding Z"),
            ],
        }

        for bench_id, items in in_repo_probes.items():
            for entry_id, text in items:
                self.add_benchmark_entry(bench_id, entry_id, text)
            self.benchmark_status[bench_id] = BenchmarkDataStatus.INDEXED

        self._update_index_checksum()

    def add_benchmark_entry(self, benchmark_id: str, entry_id: str, text: str) -> None:
        """Indexes a benchmark entry into the inverted index."""
        if benchmark_id not in self.SUPPORTED_BENCHMARKS:
            self.SUPPORTED_BENCHMARKS.append(benchmark_id)
            self.entries_by_benchmark[benchmark_id] = {}
            self.benchmark_status[benchmark_id] = BenchmarkDataStatus.NEEDS_SOURCE_INPUT

        tokens = self.tokenize(text)
        if not tokens:
            return

        norm_text = " ".join(tokens)
        content_hash = hashlib.sha256(norm_text.encode("utf-8")).hexdigest()

        entry = BenchmarkEntry(
            benchmark_id=benchmark_id,
            entry_id=entry_id,
            normalized_text=norm_text,
            content_sha256=content_hash,
            num_tokens=len(tokens),
        )
        self.entries_by_benchmark[benchmark_id][entry_id] = entry
        self.benchmark_status[benchmark_id] = BenchmarkDataStatus.INDEXED

        # Index N-grams (or single tuple if shorter than ngram_size)
        if len(tokens) >= self.ngram_size:
            ngrams = self.compute_ngrams(tokens)
        else:
            ngrams = [tuple(tokens)]

        for pos, ng in enumerate(ngrams):
            h = self._hash_ngram(ng)
            if h not in self.inverted_index:
                self.inverted_index[h] = []
            self.inverted_index[h].append((benchmark_id, entry_id, pos))
            self.total_ngrams_indexed += 1

        self._update_index_checksum()

    def _update_index_checksum(self) -> None:
        # Compute deterministic checksum of current index keys and counts
        h = hashlib.sha256()
        h.update(str(self.ngram_size).encode("utf-8"))
        for k in sorted(self.inverted_index.keys()):
            h.update(k.encode("utf-8"))
            h.update(str(len(self.inverted_index[k])).encode("utf-8"))
        self.index_sha256 = h.hexdigest()

    def verify_index_integrity(self, expected_sha256: Optional[str] = None) -> bool:
        """Verifies that the index is non-empty and matches expected cryptographic hash."""
        if not self.inverted_index:
            raise ContaminationIndexError("Benchmark inverted index is completely empty.")
        if expected_sha256 and self.index_sha256 != expected_sha256:
            raise ContaminationIndexError(
                f"Index checksum mismatch! Computed: {self.index_sha256}, Expected: {expected_sha256}"
            )
        return True

    def query_document(
        self,
        doc_text: str,
        split: ContaminationSplit = ContaminationSplit.TRAIN,
    ) -> DecontaminationResult:
        """
        Evaluates a document against the indexed benchmarks.
        Returns match type, score, and structured findings.
        """
        doc_hash = hashlib.sha256(doc_text.encode("utf-8")).hexdigest()
        tokens = self.tokenize(doc_text)
        doc_norm_str = " ".join(tokens)
        doc_ngrams = self.compute_ngrams(tokens)
        total_doc_ng = max(1, len(doc_ngrams))

        # Track matched positions per (benchmark_id, entry_id)
        hits_per_entry: Dict[Tuple[str, str], List[int]] = {}

        # 1. Match against inverted index for n-grams
        for doc_pos, ng in enumerate(doc_ngrams):
            h = self._hash_ngram(ng)
            if h in self.inverted_index:
                for b_id, e_id, b_pos in self.inverted_index[h]:
                    key = (b_id, e_id)
                    if key not in hits_per_entry:
                        hits_per_entry[key] = []
                    hits_per_entry[key].append(doc_pos)

        # 2. Check exact substring match for all entries (catches probes regardless of length)
        for b_id, entries in self.entries_by_benchmark.items():
            for e_id, entry in entries.items():
                if entry.normalized_text and entry.normalized_text in doc_norm_str:
                    key = (b_id, e_id)
                    if key not in hits_per_entry:
                        hits_per_entry[key] = [0]

        findings: List[ContaminationFinding] = []
        highest_match = MatchPolicyType.NO_MATCH
        max_score = 0.0

        for (b_id, e_id), matched_positions in hits_per_entry.items():
            entry = self.entries_by_benchmark[b_id][e_id]
            unique_matched = sorted(set(matched_positions))
            matched_count = len(unique_matched)

            # Max consecutive matches
            max_consecutive = 1
            curr_consecutive = 1
            for i in range(1, len(unique_matched)):
                if unique_matched[i] == unique_matched[i - 1] + 1:
                    curr_consecutive += 1
                    max_consecutive = max(max_consecutive, curr_consecutive)
                else:
                    curr_consecutive = 1

            # Check for exact substring match
            is_exact_substring = entry.normalized_text in doc_norm_str

            # Score = fraction of benchmark entry n-grams found in document
            entry_tokens = len(entry.normalized_text.split())
            entry_total_ng = max(1, entry_tokens - self.ngram_size + 1)
            score = min(1.0, matched_count / entry_total_ng)

            if is_exact_substring or score >= 0.99:
                match_type = MatchPolicyType.EXACT_MATCH
            elif score >= self.high_overlap_threshold or max_consecutive >= self.min_consecutive_ngrams:
                match_type = MatchPolicyType.HIGH_OVERLAP
            else:
                match_type = MatchPolicyType.LOW_OVERLAP

            finding = ContaminationFinding(
                benchmark_id=b_id,
                entry_id=e_id,
                match_type=match_type,
                score=score,
                matched_ngrams_count=matched_count,
                total_doc_ngrams=total_doc_ng,
                max_consecutive_ngrams=max_consecutive,
                document_hash=doc_hash,
                benchmark_entry_hash=entry.content_sha256,
            )
            findings.append(finding)

            if score > max_score:
                max_score = score

            # Update highest match type
            order = [
                MatchPolicyType.NO_MATCH,
                MatchPolicyType.LOW_OVERLAP,
                MatchPolicyType.HIGH_OVERLAP,
                MatchPolicyType.EXACT_MATCH,
            ]
            if order.index(match_type) > order.index(highest_match):
                highest_match = match_type

        # Training data fails closed on EXACT_MATCH or HIGH_OVERLAP
        is_clean = True
        if split == ContaminationSplit.TRAIN:
            if highest_match in (MatchPolicyType.EXACT_MATCH, MatchPolicyType.HIGH_OVERLAP):
                is_clean = False
        elif split in (ContaminationSplit.VAL, ContaminationSplit.TEST):
            if highest_match == MatchPolicyType.EXACT_MATCH:
                is_clean = False

        return DecontaminationResult(
            is_clean=is_clean,
            findings=findings,
            highest_match_type=highest_match,
            max_score=max_score,
            document_hash=doc_hash,
        )

    def get_benchmark_coverage_report(self) -> Dict[str, Any]:
        """Returns coverage report separating indexed benchmarks from those needing source input."""
        indexed_count = sum(1 for s in self.benchmark_status.values() if s == BenchmarkDataStatus.INDEXED)
        needs_input = [b for b, s in self.benchmark_status.items() if s == BenchmarkDataStatus.NEEDS_SOURCE_INPUT]
        indexed_list = [b for b, s in self.benchmark_status.items() if s == BenchmarkDataStatus.INDEXED]

        return {
            "total_supported_benchmarks": len(self.SUPPORTED_BENCHMARKS),
            "indexed_benchmarks_count": indexed_count,
            "indexed_benchmarks": indexed_list,
            "needs_source_input_count": len(needs_input),
            "needs_source_input_benchmarks": needs_input,
            "total_ngrams_indexed": self.total_ngrams_indexed,
            "index_sha256": self.index_sha256,
            "ngram_size": self.ngram_size,
        }
