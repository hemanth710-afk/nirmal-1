"""
Production Code Safety & Credential Leakage Scanner for Nirmal-1 V8.4.

Detects sensitive credentials, tokens, private keys, and cloud secrets in pretraining code corpora.
Guarantees fail-closed isolation and secret redaction to ensure credentials never enter tokenization
or logs.
"""

from dataclasses import dataclass, field, asdict
from enum import Enum
import hashlib
import math
import re
import time
from typing import Any, Dict, List, Optional, Set, Tuple


class FindingCategory(str, Enum):
    AWS_CREDENTIAL = "aws_credential"
    GITHUB_TOKEN = "github_token"
    PRIVATE_KEY = "private_key"
    CLOUD_CREDENTIAL = "cloud_credential"
    API_KEY = "api_key"
    GENERIC_SECRET = "generic_secret"


class FindingSeverity(str, Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class ScannerAction(str, Enum):
    ALLOW = "allow"
    REDACT = "redact"
    REJECT = "reject"


@dataclass
class CodeSafetyFinding:
    detector_id: str
    category: FindingCategory
    severity: FindingSeverity
    start_idx: int
    end_idx: int
    redacted_evidence: str
    action: ScannerAction = ScannerAction.REJECT

    def __repr__(self) -> str:
        return (
            f"CodeSafetyFinding(detector={self.detector_id}, category={self.category.value}, "
            f"severity={self.severity.value}, span=({self.start_idx}:{self.end_idx}), "
            f"evidence={self.redacted_evidence}, action={self.action.value})"
        )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "detector_id": self.detector_id,
            "category": self.category.value,
            "severity": self.severity.value,
            "span": [self.start_idx, self.end_idx],
            "redacted_evidence": self.redacted_evidence,
            "action": self.action.value,
        }


@dataclass
class CodeSafetyResult:
    is_safe: bool
    findings: List[CodeSafetyFinding]
    action: ScannerAction
    redacted_text: Optional[str] = None
    summary: Dict[str, int] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "is_safe": self.is_safe,
            "findings": [f.to_dict() for f in self.findings],
            "action": self.action.value,
            "summary": self.summary,
        }


@dataclass
class CodeSafetyConfig:
    default_action: ScannerAction = ScannerAction.REJECT
    fail_closed: bool = True
    min_entropy_threshold: float = 3.2
    max_scan_bytes_per_doc: int = 2_000_000

    def __post_init__(self) -> None:
        self.validate()

    def validate(self) -> None:
        if not isinstance(self.default_action, ScannerAction):
            raise ValueError(f"Invalid default_action: {self.default_action}")
        if self.min_entropy_threshold < 0.0 or self.min_entropy_threshold > 8.0:
            raise ValueError(f"Invalid min_entropy_threshold: {self.min_entropy_threshold}")
        if self.max_scan_bytes_per_doc <= 0:
            raise ValueError(f"Invalid max_scan_bytes_per_doc: {self.max_scan_bytes_per_doc}")


def calculate_shannon_entropy(s: str) -> float:
    """Calculates Shannon entropy in bits per character."""
    if not s:
        return 0.0
    freq: Dict[str, int] = {}
    for c in s:
        freq[c] = freq.get(c, 0) + 1
    entropy = 0.0
    length = len(s)
    for count in freq.values():
        p = count / length
        entropy -= p * math.log2(p)
    return entropy


def redact_secret_value(raw: str) -> str:
    """Masks secret value for safe logging and telemetry."""
    if not raw:
        return "[EMPTY]"
    if len(raw) <= 8:
        return "[REDACTED_SHORT]"
    prefix = raw[:3]
    suffix = raw[-3:]
    masked_middle = "*" * max(4, len(raw) - 6)
    return f"{prefix}{masked_middle}{suffix}"


class CodeSafetyScanner:
    """
    High-precision secret and credential detector for production code corpora.
    Filters out true secrets while minimizing false positives on benign code.
    """

    BENIGN_PLACEHOLDER_SUBSTRINGS = {
        "example", "dummy", "test", "placeholder", "your_key", "your_token",
        "your-token", "fake", "changeme", "foobar", "xxxx", "0000", "1111",
        "none", "null", "undefined", "sample", "<token>", "<api_key>",
    }

    def __init__(self, config: Optional[CodeSafetyConfig] = None):
        self.config = config or CodeSafetyConfig()
        self.config.validate()

        self._compile_patterns()

    def _compile_patterns(self) -> None:
        # 1. AWS Access Key (AKIA prefix + 16 chars)
        self.pat_aws_key = re.compile(r"(?<![A-Z0-9])(AKIA[0-9A-Z]{16})(?![A-Z0-9])")

        # 2. AWS Secret Access Key assignment
        self.pat_aws_secret = re.compile(
            r"(?i)(?:aws_secret_access_key|aws_secret_key)\s*[:=]\s*[\"']?([A-Za-z0-9/+=]{40})[\"']?"
        )

        # 3. GitHub Tokens (classic ghp_, fine-grained github_pat_, OAuth gho_)
        self.pat_github_pat = re.compile(r"(?<![a-zA-Z0-9])(ghp_[a-zA-Z0-9]{36})(?![a-zA-Z0-9])")
        self.pat_github_pat_v2 = re.compile(r"(?<![a-zA-Z0-9])(github_pat_[a-zA-Z0-9_]{82})(?![a-zA-Z0-9])")
        self.pat_github_oauth = re.compile(r"(?<![a-zA-Z0-9])(gho_[a-zA-Z0-9]{36})(?![a-zA-Z0-9])")

        # 4. Private Key Headers
        self.pat_private_key = re.compile(
            r"-----BEGIN (?:RSA |EC |DSA |OPENSSH |PGP )?PRIVATE KEY(?: BLOCK)?-----"
        )

        # 5. Slack Tokens (xoxb, xoxp, xoxa, xoxr, xoxs)
        self.pat_slack = re.compile(r"(?<![a-zA-Z0-9])(xox[baprs]-[0-9]{10,13}-[0-9]{10,13}-[a-zA-Z0-9]+)(?![a-zA-Z0-9])")

        # 6. Stripe Live API Key
        self.pat_stripe = re.compile(r"(?<![a-zA-Z0-9])(sk_live_[0-9a-zA-Z]{24,34})(?![a-zA-Z0-9])")

        # 7. Generic API Key in assignment context (must have sufficient entropy)
        self.pat_generic_assignment = re.compile(
            r"(?i)(?:api_key|apikey|secret_token|access_token|auth_token)\s*[:=]\s*[\"']([A-Za-z0-9_\-]{32,64})[\"']"
        )

    def _is_placeholder(self, val: str) -> bool:
        low = val.lower()
        if any(sub in low for sub in self.BENIGN_PLACEHOLDER_SUBSTRINGS):
            return True
        # Check if single repeated character
        if len(set(val)) <= 3:
            return True
        return False

    def scan_text(self, text: str) -> CodeSafetyResult:
        """
        Scans a document's text and returns structured findings.
        Never exposes raw secrets in the findings.
        """
        if not text:
            return CodeSafetyResult(is_safe=True, findings=[], action=ScannerAction.ALLOW, summary={})

        findings: List[CodeSafetyFinding] = []
        truncated_text = text[: self.config.max_scan_bytes_per_doc]

        # 1. AWS Access Keys
        for match in self.pat_aws_key.finditer(truncated_text):
            secret_val = match.group(1)
            # Check for standard AWS mock test key
            if "EXAMPLE" in secret_val or self._is_placeholder(secret_val):
                continue
            findings.append(
                CodeSafetyFinding(
                    detector_id="aws_access_key",
                    category=FindingCategory.AWS_CREDENTIAL,
                    severity=FindingSeverity.CRITICAL,
                    start_idx=match.start(1),
                    end_idx=match.end(1),
                    redacted_evidence=redact_secret_value(secret_val),
                    action=self.config.default_action,
                )
            )

        # 2. AWS Secret Keys
        for match in self.pat_aws_secret.finditer(truncated_text):
            secret_val = match.group(1)
            if self._is_placeholder(secret_val):
                continue
            findings.append(
                CodeSafetyFinding(
                    detector_id="aws_secret_key",
                    category=FindingCategory.AWS_CREDENTIAL,
                    severity=FindingSeverity.CRITICAL,
                    start_idx=match.start(1),
                    end_idx=match.end(1),
                    redacted_evidence=redact_secret_value(secret_val),
                    action=self.config.default_action,
                )
            )

        # 3. GitHub Tokens
        for pat, det_id in [
            (self.pat_github_pat, "github_pat_classic"),
            (self.pat_github_pat_v2, "github_pat_fine_grained"),
            (self.pat_github_oauth, "github_oauth_token"),
        ]:
            for match in pat.finditer(truncated_text):
                secret_val = match.group(1)
                if self._is_placeholder(secret_val):
                    continue
                findings.append(
                    CodeSafetyFinding(
                        detector_id=det_id,
                        category=FindingCategory.GITHUB_TOKEN,
                        severity=FindingSeverity.CRITICAL,
                        start_idx=match.start(1),
                        end_idx=match.end(1),
                        redacted_evidence=redact_secret_value(secret_val),
                        action=self.config.default_action,
                    )
                )

        # 4. Private Key Blocks
        for match in self.pat_private_key.finditer(truncated_text):
            findings.append(
                CodeSafetyFinding(
                    detector_id="private_key_header",
                    category=FindingCategory.PRIVATE_KEY,
                    severity=FindingSeverity.CRITICAL,
                    start_idx=match.start(),
                    end_idx=match.end(),
                    redacted_evidence="-----BEGIN [MASKED] PRIVATE KEY-----",
                    action=self.config.default_action,
                )
            )

        # 5. Slack Tokens
        for match in self.pat_slack.finditer(truncated_text):
            secret_val = match.group(1)
            if self._is_placeholder(secret_val):
                continue
            findings.append(
                CodeSafetyFinding(
                    detector_id="slack_token",
                    category=FindingCategory.API_KEY,
                    severity=FindingSeverity.HIGH,
                    start_idx=match.start(1),
                    end_idx=match.end(1),
                    redacted_evidence=redact_secret_value(secret_val),
                    action=self.config.default_action,
                )
            )

        # 6. Stripe Live API Keys
        for match in self.pat_stripe.finditer(truncated_text):
            secret_val = match.group(1)
            if self._is_placeholder(secret_val):
                continue
            findings.append(
                CodeSafetyFinding(
                    detector_id="stripe_live_key",
                    category=FindingCategory.API_KEY,
                    severity=FindingSeverity.CRITICAL,
                    start_idx=match.start(1),
                    end_idx=match.end(1),
                    redacted_evidence=redact_secret_value(secret_val),
                    action=self.config.default_action,
                )
            )

        # 7. Generic API Key in Assignment
        for match in self.pat_generic_assignment.finditer(truncated_text):
            secret_val = match.group(1)
            if self._is_placeholder(secret_val):
                continue
            # Entropy check: real secrets have high Shannon entropy
            ent = calculate_shannon_entropy(secret_val)
            if ent < self.config.min_entropy_threshold:
                continue
            findings.append(
                CodeSafetyFinding(
                    detector_id="generic_high_entropy_api_key",
                    category=FindingCategory.GENERIC_SECRET,
                    severity=FindingSeverity.HIGH,
                    start_idx=match.start(1),
                    end_idx=match.end(1),
                    redacted_evidence=redact_secret_value(secret_val),
                    action=self.config.default_action,
                )
            )

        # Summary counts
        summary: Dict[str, int] = {}
        for f in findings:
            cat_name = f.category.value
            summary[cat_name] = summary.get(cat_name, 0) + 1

        is_safe = len(findings) == 0
        overall_action = ScannerAction.ALLOW if is_safe else self.config.default_action

        # Generate optional redacted text if requested
        redacted_text = None
        if not is_safe and overall_action == ScannerAction.REDACT:
            # Sort findings reverse by start index to cleanly replace
            sorted_findings = sorted(findings, key=lambda x: x.start_idx, reverse=True)
            text_chars = list(text)
            for f in sorted_findings:
                replacement = f"[REDACTED_SECRET_{f.category.value.upper()}]"
                text_chars[f.start_idx : f.end_idx] = list(replacement)
            redacted_text = "".join(text_chars)

        return CodeSafetyResult(
            is_safe=is_safe,
            findings=findings,
            action=overall_action,
            redacted_text=redacted_text,
            summary=summary,
        )
