"""
Clean Data Pipeline & Integrity Enforcement System for Nirmal-1 V6.
Enforces:
1. Strict schema compliance for all training/eval examples.
2. Normalized text and structural deduplication (0% internal duplicates).
3. Cryptographic SHA-256 provenance tracking.
4. Hard split isolation invariant:
   TRAIN ∩ VALIDATION = 0
   TRAIN ∩ TEST = 0
   VALIDATION ∩ TEST = 0
   If overlap exists: FAILS THE PIPELINE (raises DataLeakageError).
"""

from dataclasses import dataclass, field, asdict
import hashlib
import json
from pathlib import Path
import re
import unicodedata
from typing import Any, Dict, Iterable, List, Optional, Set, Tuple, Union
import random


class DataLeakageError(Exception):
    """Raised when cross-split overlap or contamination is detected."""
    pass


@dataclass
class DataExample:
    """Standardized atomic data example with complete provenance metadata."""
    id: str
    source: str
    domain: str
    text: str
    split: str  # "train", "val", "test", or "unassigned"
    hash: str
    generator_version: str = "v6.0"
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "DataExample":
        return cls(**data)


def normalize_text(text: str) -> str:
    """
    Standardize text formatting:
    - Unicode NFKC normalization
    - Normalize carriage returns & line feeds
    - Collapse excessive spaces while preserving line breaks
    - Strip leading/trailing whitespace
    """
    text = unicodedata.normalize("NFKC", text)
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    # Collapse consecutive spaces on each line
    lines = [re.sub(r"[ \t]+", " ", line).strip() for line in text.split("\n")]
    return "\n".join(lines).strip()


def compute_sha256(text: str) -> str:
    """Compute SHA-256 digest of normalized text."""
    norm = normalize_text(text)
    return hashlib.sha256(norm.encode("utf-8")).hexdigest()


def compute_structural_fingerprint(text: str) -> str:
    """
    Compute structural fingerprint to catch isomorphic/near-duplicate sequences:
    - Replaces all digit sequences with <NUM>
    - Normalizes alphanumeric variable names
    - Strips whitespace
    """
    norm = normalize_text(text).lower()
    # Replace numbers with token <NUM>
    s = re.sub(r"\b\d+\b", "<NUM>", norm)
    # Collapse punctuation whitespace
    s = re.sub(r"\s+", "", s)
    return hashlib.sha256(s.encode("utf-8")).hexdigest()


@dataclass
class PipelineStatistics:
    """Structured report of dataset volume, uniqueness, and split integrity."""
    total_raw_examples: int = 0
    training_examples: int = 0
    unique_training_examples: int = 0
    duplicate_training_count: int = 0
    validation_examples: int = 0
    unique_validation_examples: int = 0
    test_examples: int = 0
    unique_test_examples: int = 0
    train_val_overlap: int = 0
    train_test_overlap: int = 0
    val_test_overlap: int = 0
    domain_counts: Dict[str, Dict[str, int]] = field(default_factory=dict)
    leakage_passed: bool = False

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


class DataPipeline:
    """
    Clean data pipeline manager for building, validating, and serving
    strictly segregated train, validation, and test datasets.
    """

    def __init__(self, seed: int = 42, generator_version: str = "v6.0"):
        self.seed = seed
        self.generator_version = generator_version
        self.rng = random.Random(seed)

    def create_example(
        self,
        domain: str,
        text: str,
        source: str,
        example_id: Optional[str] = None,
        split: str = "unassigned",
        metadata: Optional[Dict[str, Any]] = None,
    ) -> DataExample:
        """Construct a validated DataExample with deterministic hash computation."""
        norm_text = normalize_text(text)
        ex_hash = compute_sha256(norm_text)
        if example_id is None:
            # Deterministic ID based on domain and hash prefix
            example_id = f"{domain}_{ex_hash[:12]}"

        return DataExample(
            id=example_id,
            source=source,
            domain=domain,
            text=norm_text,
            split=split,
            hash=ex_hash,
            generator_version=self.generator_version,
            metadata=metadata or {},
        )

    def deduplicate(
        self,
        examples: List[DataExample],
        structural: bool = False,
    ) -> Tuple[List[DataExample], int]:
        """
        Deduplicate examples using exact SHA-256 hash or structural fingerprints.
        Returns: (unique_examples, duplicate_count)
        """
        seen_hashes: Set[str] = set()
        seen_structural: Set[str] = set()
        unique: List[DataExample] = []
        dup_count = 0

        for ex in examples:
            if ex.hash in seen_hashes:
                dup_count += 1
                continue

            if structural:
                fingerprint = compute_structural_fingerprint(ex.text)
                if fingerprint in seen_structural:
                    dup_count += 1
                    continue
                seen_structural.add(fingerprint)

            seen_hashes.add(ex.hash)
            unique.append(ex)

        return unique, dup_count

    def verify_split_isolation(
        self,
        train_examples: List[DataExample],
        val_examples: List[DataExample],
        test_examples: List[DataExample],
    ) -> PipelineStatistics:
        """
        Mandatory split isolation verification.
        Computes SHA-256 and normalized text intersections across all pairs.
        IF ANY OVERLAP EXISTS: RAISES DataLeakageError.
        """
        train_hashes = {ex.hash: ex for ex in train_examples}
        val_hashes = {ex.hash: ex for ex in val_examples}
        test_hashes = {ex.hash: ex for ex in test_examples}

        train_val_overlap = set(train_hashes.keys()) & set(val_hashes.keys())
        train_test_overlap = set(train_hashes.keys()) & set(test_hashes.keys())
        val_test_overlap = set(val_hashes.keys()) & set(test_hashes.keys())

        # Check domain breakdown
        domain_counts: Dict[str, Dict[str, int]] = {}
        for split_name, split_list in [("train", train_examples), ("val", val_examples), ("test", test_examples)]:
            for ex in split_list:
                if ex.domain not in domain_counts:
                    domain_counts[ex.domain] = {"train": 0, "val": 0, "test": 0}
                domain_counts[ex.domain][split_name] += 1

        stats = PipelineStatistics(
            total_raw_examples=len(train_examples) + len(val_examples) + len(test_examples),
            training_examples=len(train_examples),
            unique_training_examples=len(train_hashes),
            duplicate_training_count=len(train_examples) - len(train_hashes),
            validation_examples=len(val_examples),
            unique_validation_examples=len(val_hashes),
            test_examples=len(test_examples),
            unique_test_examples=len(test_hashes),
            train_val_overlap=len(train_val_overlap),
            train_test_overlap=len(train_test_overlap),
            val_test_overlap=len(val_test_overlap),
            domain_counts=domain_counts,
            leakage_passed=False,
        )

        if stats.duplicate_training_count > 0:
            raise DataLeakageError(
                f"Training set contains {stats.duplicate_training_count} internal duplicate items! "
                f"V6 requires 0% exact training duplication."
            )

        if train_val_overlap:
            sample_hash = next(iter(train_val_overlap))
            sample_ex = train_hashes[sample_hash]
            raise DataLeakageError(
                f"DATA LEAKAGE DETECTED between TRAIN and VALIDATION splits! "
                f"Found {len(train_val_overlap)} overlapping items. "
                f"Sample ID: {sample_ex.id}, Text: {sample_ex.text[:60]!r}"
            )

        if train_test_overlap:
            sample_hash = next(iter(train_test_overlap))
            sample_ex = train_hashes[sample_hash]
            raise DataLeakageError(
                f"DATA LEAKAGE DETECTED between TRAIN and TEST splits! "
                f"Found {len(train_test_overlap)} overlapping items. "
                f"Sample ID: {sample_ex.id}, Text: {sample_ex.text[:60]!r}"
            )

        if val_test_overlap:
            sample_hash = next(iter(val_test_overlap))
            sample_ex = val_hashes[sample_hash]
            raise DataLeakageError(
                f"DATA LEAKAGE DETECTED between VALIDATION and TEST splits! "
                f"Found {len(val_test_overlap)} overlapping items. "
                f"Sample ID: {sample_ex.id}, Text: {sample_ex.text[:60]!r}"
            )

        stats.leakage_passed = True
        return stats

    def export_dataset_jsonl(self, examples: List[DataExample], file_path: Union[str, Path]) -> Path:
        """Save a collection of examples to JSONL format."""
        path = Path(file_path)
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("w", encoding="utf-8") as f:
            for ex in examples:
                f.write(json.dumps(ex.to_dict()) + "\n")
        return path

    def load_dataset_jsonl(self, file_path: Union[str, Path]) -> List[DataExample]:
        """Load examples from JSONL format."""
        path = Path(file_path)
        if not path.exists():
            raise FileNotFoundError(f"File {path} does not exist.")
        examples = []
        with path.open("r", encoding="utf-8") as f:
            for line in f:
                if line.strip():
                    examples.append(DataExample.from_dict(json.loads(line)))
        return examples
