"""
Neural Training Engine for Nirmal-1 V5.
Implements a controlled training and validation loop tracking:
- Training Loss
- Validation Loss
- Validation Perplexity
- Gradient Norm
- Throughput (tokens/sec)
- Memory Footprint (MB)
- Learning curves across step checkpoints (0, 10, 50, 100, 250, 500)
"""

from dataclasses import dataclass, field
import math
from pathlib import Path
import time
from typing import Any, Dict, List, Optional, Tuple
import torch
import torch.nn.functional as F
from torch.utils.data import DataLoader

from nirmal.configuration_nirmal import NirmalConfig
from nirmal.model import NirmalForCausalLM
from training.dataset import CharTokenizer
from training.neural_curriculum import (
    NeuralCurriculum,
    CurriculumDataset,
    create_curriculum_splits,
)


@dataclass
class TrainingStepMetrics:
    """Detailed telemetry for a single training evaluation milestone."""
    step: int
    train_loss: float
    val_loss: float
    val_perplexity: float
    grad_norm: float
    throughput_tokens_per_sec: float
    elapsed_sec: float
    memory_mb: float


@dataclass
class TrainingReport:
    """Comprehensive post-training summary report."""
    model_size: str
    num_parameters: int
    total_steps: int
    learning_curve: List[TrainingStepMetrics] = field(default_factory=list)
    initial_val_loss: float = 0.0
    final_val_loss: float = 0.0
    initial_perplexity: float = 0.0
    final_perplexity: float = 0.0
    loss_improvement: float = 0.0
    perplexity_reduction: float = 0.0
    avg_throughput_tokens_sec: float = 0.0
    peak_memory_mb: float = 0.0


def create_model_configuration(
    size: str = "tiny",
    vocab_size: int = 128,
    context_length: int = 128,
) -> NirmalConfig:
    """Create calibrated model configurations suitable for CPU experimentation."""
    size = size.lower()
    if size == "tiny":
        return NirmalConfig(
            vocab_size=vocab_size,
            hidden_size=64,
            num_hidden_layers=2,
            num_attention_heads=2,
            num_key_value_heads=1,
            head_dim=32,
            context_length=context_length,
            intermediate_size=128,
            num_experts=2,
            num_experts_per_tok=1,
            full_attention_interval=2,
        )
    elif size == "small":
        return NirmalConfig(
            vocab_size=vocab_size,
            hidden_size=128,
            num_hidden_layers=4,
            num_attention_heads=4,
            num_key_value_heads=2,
            head_dim=32,
            context_length=context_length,
            intermediate_size=256,
            num_experts=4,
            num_experts_per_tok=2,
            full_attention_interval=2,
        )
    else:  # medium
        return NirmalConfig(
            vocab_size=vocab_size,
            hidden_size=256,
            num_hidden_layers=6,
            num_attention_heads=4,
            num_key_value_heads=2,
            head_dim=64,
            context_length=context_length,
            intermediate_size=512,
            num_experts=4,
            num_experts_per_tok=2,
            full_attention_interval=3,
        )


def evaluate_dataset(
    model: NirmalForCausalLM,
    dataloader: DataLoader,
    device: torch.device,
) -> Tuple[float, float]:
    """Compute cross-entropy loss and perplexity on evaluation dataloader."""
    model.eval()
    total_loss = 0.0
    total_tokens = 0

    with torch.no_grad():
        for batch in dataloader:
            input_ids = batch["input_ids"].to(device)
            labels = batch["labels"].to(device)
            outputs = model(input_ids=input_ids, labels=labels)
            if outputs.loss is not None:
                # Count non-ignored target tokens
                valid_mask = (labels != -100)
                num_valid = valid_mask.sum().item()
                if num_valid > 0:
                    total_loss += outputs.loss.item() * num_valid
                    total_tokens += num_valid

    avg_loss = (total_loss / max(1, total_tokens)) if total_tokens > 0 else 0.0
    perplexity = math.exp(min(avg_loss, 20.0))
    return round(avg_loss, 4), round(perplexity, 4)


def train_neural_model(
    model_size: str = "tiny",
    total_steps: int = 100,
    batch_size: int = 4,
    lr: float = 2e-3,
    eval_interval: int = 20,
    seed: int = 42,
    device: Optional[torch.device] = None,
) -> Tuple[NirmalForCausalLM, CharTokenizer, TrainingReport]:
    """
    Execute minimal controlled pretraining on the 8-domain synthetic curriculum.
    Returns: (trained_model, tokenizer, training_report)
    """
    torch.manual_seed(seed)
    dev = device or torch.device("cuda" if torch.cuda.is_available() else "cpu")

    # 1. Build Curriculum & Datasets
    curriculum_gen = NeuralCurriculum(seed=seed)
    full_items = curriculum_gen.build_full_curriculum(count_per_cat=30)  # 240 items
    train_items, val_items, _ = create_curriculum_splits(full_items, seed=seed)

    # Initialize Tokenizer over full text
    all_text = " ".join([item.full_text for item in full_items])
    tokenizer = CharTokenizer(text=all_text)

    seq_len = 64
    train_dataset = CurriculumDataset(train_items, tokenizer=tokenizer, seq_len=seq_len)
    val_dataset = CurriculumDataset(val_items, tokenizer=tokenizer, seq_len=seq_len)

    train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
    val_loader = DataLoader(val_dataset, batch_size=batch_size, shuffle=False)

    # 2. Build Model
    config = create_model_configuration(size=model_size, vocab_size=tokenizer.vocab_size, context_length=seq_len)
    model = NirmalForCausalLM(config).to(dev)
    num_params = model.count_parameters()["trainable"]

    optimizer = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=0.01)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=max(1, total_steps), eta_min=1e-5)

    learning_curve: List[TrainingStepMetrics] = []
    data_iter = iter(train_loader)
    step = 0
    start_time = time.time()
    total_tokens_processed = 0

    # Step 0 initial evaluation
    init_val_loss, init_val_ppl = evaluate_dataset(model, val_loader, dev)
    learning_curve.append(TrainingStepMetrics(
        step=0,
        train_loss=init_val_loss,
        val_loss=init_val_loss,
        val_perplexity=init_val_ppl,
        grad_norm=0.0,
        throughput_tokens_per_sec=0.0,
        elapsed_sec=0.0,
        memory_mb=round(torch.cuda.max_memory_allocated() / (1024 * 1024), 2) if torch.cuda.is_available() else 0.0,
    ))

    # Milestones for telemetry logging
    target_checkpoints = {10, 50, 100, 250, 500}

    # 3. Training Loop
    while step < total_steps:
        model.train()
        try:
            batch = next(data_iter)
        except StopIteration:
            data_iter = iter(train_loader)
            batch = next(data_iter)

        input_ids = batch["input_ids"].to(dev)
        labels = batch["labels"].to(dev)
        batch_tokens = (labels != -100).sum().item()
        total_tokens_processed += batch_tokens

        optimizer.zero_grad()
        outputs = model(input_ids=input_ids, labels=labels)
        loss = outputs.loss
        loss.backward()

        # Compute gradient norm
        grad_norm = torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0).item()
        optimizer.step()
        scheduler.step()

        step += 1

        # Check for milestone recording
        if step in target_checkpoints or step % eval_interval == 0 or step == total_steps:
            elapsed = time.time() - start_time
            throughput = total_tokens_processed / max(0.001, elapsed)
            val_loss, val_ppl = evaluate_dataset(model, val_loader, dev)

            # Measure approximate memory
            mem_mb = 0.0
            if torch.cuda.is_available():
                mem_mb = torch.cuda.max_memory_allocated() / (1024 * 1024)
            else:
                mem_mb = sum(p.numel() * p.element_size() for p in model.parameters()) / (1024 * 1024)

            metrics = TrainingStepMetrics(
                step=step,
                train_loss=round(loss.item(), 4),
                val_loss=val_loss,
                val_perplexity=val_ppl,
                grad_norm=round(float(grad_norm), 4),
                throughput_tokens_per_sec=round(throughput, 1),
                elapsed_sec=round(elapsed, 3),
                memory_mb=round(mem_mb, 2),
            )
            learning_curve.append(metrics)

    final_val_loss = learning_curve[-1].val_loss
    final_val_ppl = learning_curve[-1].val_perplexity
    loss_imp = init_val_loss - final_val_loss
    ppl_red = init_val_ppl - final_val_ppl

    report = TrainingReport(
        model_size=model_size,
        num_parameters=num_params,
        total_steps=total_steps,
        learning_curve=learning_curve,
        initial_val_loss=init_val_loss,
        final_val_loss=final_val_loss,
        initial_perplexity=init_val_ppl,
        final_perplexity=final_val_ppl,
        loss_improvement=round(loss_imp, 4),
        perplexity_reduction=round(ppl_red, 4),
        avg_throughput_tokens_sec=round(total_tokens_processed / max(0.001, time.time() - start_time), 1),
        peak_memory_mb=round(max(m.memory_mb for m in learning_curve), 2),
    )

    return model, tokenizer, report
