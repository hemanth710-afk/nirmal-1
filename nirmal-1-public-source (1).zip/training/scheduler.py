"""
Learning Rate Scheduler for Nirmal-1 V8.
Implements Cosine Annealing with Linear Warmup and a minimum learning rate floor (10% of peak).
"""

import math
from typing import Any, Dict, List, Optional
import torch
from torch.optim.lr_scheduler import LambdaLR


class CosineWarmupScheduler:
    """
    Computes learning rate multiplier:
    - Linear warmup for step in [0, warmup_steps]
    - Cosine decay for step in [warmup_steps, total_steps] down to min_lr_ratio
    """

    def __init__(
        self,
        optimizer: torch.optim.Optimizer,
        warmup_steps: int = 2000,
        total_steps: int = 100000,
        min_lr_ratio: float = 0.10,
    ):
        self.optimizer = optimizer
        self.warmup_steps = max(1, warmup_steps)
        self.total_steps = max(self.warmup_steps + 1, total_steps)
        self.min_lr_ratio = min_lr_ratio
        self.current_step = 0

        # Store initial learning rates and initialize to step 0
        self.base_lrs = [group["lr"] for group in optimizer.param_groups]
        init_factor = self.get_lr_factor(0)
        for group, base_lr in zip(optimizer.param_groups, self.base_lrs):
            group["lr"] = base_lr * init_factor

    def get_lr_factor(self, step: int) -> float:
        """Calculate learning rate factor in [min_lr_ratio, 1.0]."""
        if step < self.warmup_steps:
            # Linear warmup from min_lr_ratio to 1.0
            return self.min_lr_ratio + (1.0 - self.min_lr_ratio) * (float(step) / float(self.warmup_steps))
        elif step >= self.total_steps:
            return self.min_lr_ratio
        else:
            # Cosine decay from 1.0 down to min_lr_ratio
            progress = float(step - self.warmup_steps) / float(self.total_steps - self.warmup_steps)
            cosine_decay = 0.5 * (1.0 + math.cos(math.pi * progress))
            return self.min_lr_ratio + (1.0 - self.min_lr_ratio) * cosine_decay

    def step(self) -> List[float]:
        """Advance one step and update optimizer learning rates."""
        self.current_step += 1
        factor = self.get_lr_factor(self.current_step)
        current_lrs = []
        for group, base_lr in zip(self.optimizer.param_groups, self.base_lrs):
            lr = base_lr * factor
            group["lr"] = lr
            current_lrs.append(lr)
        return current_lrs

    def get_current_lr(self) -> float:
        """Returns the learning rate of the first parameter group."""
        return self.optimizer.param_groups[0]["lr"]

    def state_dict(self) -> Dict[str, Any]:
        return {
            "current_step": self.current_step,
            "warmup_steps": self.warmup_steps,
            "total_steps": self.total_steps,
            "min_lr_ratio": self.min_lr_ratio,
            "base_lrs": self.base_lrs,
        }

    def load_state_dict(self, state_dict: Dict[str, Any]) -> None:
        self.current_step = state_dict["current_step"]
        self.warmup_steps = state_dict["warmup_steps"]
        self.total_steps = state_dict["total_steps"]
        self.min_lr_ratio = state_dict["min_lr_ratio"]
        self.base_lrs = state_dict["base_lrs"]
        # Apply updated step immediately
        factor = self.get_lr_factor(self.current_step)
        for group, base_lr in zip(self.optimizer.param_groups, self.base_lrs):
            group["lr"] = base_lr * factor
