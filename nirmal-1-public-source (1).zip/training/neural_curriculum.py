"""
Deterministic Synthetic Curriculum Generator for Nirmal-1 V5.
Provides a structured 8-domain curriculum for pretraining and fine-tuning:
A. Language modeling examples
B. Sequence prediction
C. Symbolic reasoning
D. State transition prediction
E. Causal descriptions
F. Planning sequences
G. Tool-use traces
H. Error-correction examples

Supports train, validation, and test splits with strict isolation.
"""

from dataclasses import dataclass
import json
import random
from typing import Any, Dict, List, Optional, Tuple
import torch
from torch.utils.data import Dataset

from training.dataset import CharTokenizer


@dataclass
class CurriculumItem:
    """An individual curriculum example with domain and metadata."""
    category: str
    prompt: str
    target: str
    full_text: str
    metadata: Dict[str, Any]


class NeuralCurriculum:
    """Deterministic procedural generator for the 8-domain V5 synthetic curriculum."""

    def __init__(self, seed: int = 42):
        self.rng = random.Random(seed)

    def generate_category_a_language(self, count: int = 50) -> List[CurriculumItem]:
        """Category A: Language modeling examples (factual & descriptive statements)."""
        items = []
        subjects = ["Hydraulic valve", "Sensor node", "Coolant system", "Buffer cache", "Routing table", "Power unit"]
        states = ["operates nominal", "reports pressure drop", "switches to active mode", "initiates sync", "buffers incoming payload"]
        locations = ["in sector alpha", "on bus line 4", "at primary core", "across cluster node 2", "in pipeline stage 1"]

        for i in range(count):
            subj = self.rng.choice(subjects)
            st = self.rng.choice(states)
            loc = self.rng.choice(locations)
            prompt = f"System report {i+1}: {subj}"
            target = f" {st} {loc}."
            items.append(CurriculumItem(
                category="A_language_modeling",
                prompt=prompt,
                target=target,
                full_text=prompt + target,
                metadata={"index": i},
            ))
        return items

    def generate_category_b_sequence(self, count: int = 50) -> List[CurriculumItem]:
        """Category B: Sequence prediction (numerical & symbol progressions)."""
        items = []
        for i in range(count):
            seq_type = self.rng.choice(["arithmetic", "geometric", "fibonacci", "alternating"])
            start = self.rng.randint(1, 10)
            if seq_type == "arithmetic":
                step = self.rng.randint(2, 6)
                seq = [start + j * step for j in range(6)]
            elif seq_type == "geometric":
                step = self.rng.choice([2, 3])
                seq = [start * (step ** j) for j in range(5)]
            elif seq_type == "fibonacci":
                a, b = start, start + 1
                seq = [a, b]
                for _ in range(4):
                    seq.append(seq[-1] + seq[-2])
            else:
                c1, c2 = self.rng.randint(1, 5), self.rng.randint(6, 10)
                seq = [c1 if j % 2 == 0 else c2 for j in range(6)]

            prompt = f"Sequence {seq_type}: " + ", ".join(map(str, seq[:-1])) + " -> next is"
            target = f" {seq[-1]}"
            items.append(CurriculumItem(
                category="B_sequence_prediction",
                prompt=prompt,
                target=target,
                full_text=prompt + target,
                metadata={"type": seq_type, "sequence": seq},
            ))
        return items

    def generate_category_c_symbolic(self, count: int = 50) -> List[CurriculumItem]:
        """Category C: Symbolic reasoning (modus ponens, transitive deduction)."""
        items = []
        symbols = ["alpha", "beta", "gamma", "delta", "epsilon", "zeta", "eta", "theta"]
        for i in range(count):
            a, b, c = self.rng.sample(symbols, 3)
            # Transitive rule: If A implies B and B implies C, then A implies C
            prompt = f"Rule 1: {a} implies {b}. Rule 2: {b} implies {c}. Premise: {a} is active. Deduction:"
            target = f" {c} is active"
            items.append(CurriculumItem(
                category="C_symbolic_reasoning",
                prompt=prompt,
                target=target,
                full_text=prompt + target,
                metadata={"chain": [a, b, c]},
            ))
        return items

    def generate_category_d_state_transition(self, count: int = 50) -> List[CurriculumItem]:
        """Category D: State transition prediction (s_t, a_t -> s_{t+1})."""
        items = []
        variables = ["pressure", "temperature", "voltage", "flow", "level"]
        for i in range(count):
            var = self.rng.choice(variables)
            init_val = self.rng.randint(10, 80)
            delta = self.rng.choice([5, 10, 20, -5, -10])
            act = "increase" if delta > 0 else "decrease"
            next_val = init_val + delta
            prompt = f"State: {var}={init_val}. Action: {act}_{var}_{abs(delta)}. NextState:"
            target = f" {var}={next_val}"
            items.append(CurriculumItem(
                category="D_state_transition",
                prompt=prompt,
                target=target,
                full_text=prompt + target,
                metadata={"var": var, "from": init_val, "to": next_val},
            ))
        return items

    def generate_category_e_causal(self, count: int = 50) -> List[CurriculumItem]:
        """Category E: Causal descriptions & intervention scenarios."""
        items = []
        causes = ["valve_failure", "sensor_drift", "overvoltage", "coolant_blockage"]
        effects = ["initiates_emergency_shutdown", "triggers_backup_power", "alarms_operator", "diverts_flow"]
        side_effects = ["pressure_drop", "temp_spike", "status_flag_yellow", "relay_click"]

        for i in range(count):
            c = self.rng.choice(causes)
            e = self.rng.choice(effects)
            se = self.rng.choice(side_effects)
            prompt = f"Causal Mechanism: Cause {c} triggers {e}. SideEffect:"
            target = f" {se}"
            items.append(CurriculumItem(
                category="E_causal_descriptions",
                prompt=prompt,
                target=target,
                full_text=prompt + target,
                metadata={"cause": c, "effect": e, "side_effect": se},
            ))
        return items

    def generate_category_f_planning(self, count: int = 50) -> List[CurriculumItem]:
        """Category F: Planning sequences (hierarchical decompositions)."""
        items = []
        tasks = [
            ("calibrate_sensor", ["power_on", "read_baseline", "adjust_gain", "verify_offset"]),
            ("flush_pipeline", ["isolate_valve", "purge_chamber", "rinse_line", "restore_flow"]),
            ("route_packet", ["lookup_dest", "verify_bandwidth", "encrypt_payload", "dispatch_packet"]),
        ]
        for i in range(count):
            goal_name, steps = self.rng.choice(tasks)
            prompt = f"Plan for {goal_name}: Step 1 is {steps[0]}, Step 2 is {steps[1]}, Step 3 is"
            target = f" {steps[2]}, Step 4 is {steps[3]}"
            items.append(CurriculumItem(
                category="F_planning_sequences",
                prompt=prompt,
                target=target,
                full_text=prompt + target,
                metadata={"goal": goal_name, "steps": steps},
            ))
        return items

    def generate_category_g_tools(self, count: int = 50) -> List[CurriculumItem]:
        """Category G: Tool-use traces (structured calculator & string invocations)."""
        items = []
        for i in range(count):
            tool_type = self.rng.choice(["calc", "string"])
            if tool_type == "calc":
                a = self.rng.randint(2, 20)
                b = self.rng.randint(2, 20)
                op = self.rng.choice(["+", "-", "*"])
                res = a + b if op == "+" else (a - b if op == "-" else a * b)
                prompt = f"Tool invocation: calculator(expr='{a} {op} {b}') -> result:"
                target = f" {res}"
            else:
                words = ["apple", "system", "nirmal", "kernel", "matrix"]
                w = self.rng.choice(words)
                op = self.rng.choice(["upper", "reverse"])
                res = w.upper() if op == "upper" else w[::-1]
                prompt = f"Tool invocation: string_util(op='{op}', text='{w}') -> result:"
                target = f" {res}"

            items.append(CurriculumItem(
                category="G_tool_use_traces",
                prompt=prompt,
                target=target,
                full_text=prompt + target,
                metadata={"tool": tool_type},
            ))
        return items

    def generate_category_h_error_correction(self, count: int = 50) -> List[CurriculumItem]:
        """Category H: Error-correction & verification examples."""
        items = []
        errors = [
            ("Value out of bounds (120 > 100)", "clamp value to 100"),
            ("Unrecognized tool argument 'mode_x'", "fallback to default mode"),
            ("Prerequisite node 'step_1' failed", "trigger alternate recovery route"),
            ("Checksum mismatch in packet", "request packet retransmission"),
        ]
        for i in range(count):
            err, fix = self.rng.choice(errors)
            prompt = f"Diagnostic: Encountered error '{err}'. Recovery Action:"
            target = f" {fix}"
            items.append(CurriculumItem(
                category="H_error_correction",
                prompt=prompt,
                target=target,
                full_text=prompt + target,
                metadata={"error": err, "recovery": fix},
            ))
        return items

    def build_full_curriculum(self, count_per_cat: int = 40) -> List[CurriculumItem]:
        """Generate all 8 curriculum categories combined."""
        all_items = []
        all_items.extend(self.generate_category_a_language(count_per_cat))
        all_items.extend(self.generate_category_b_sequence(count_per_cat))
        all_items.extend(self.generate_category_c_symbolic(count_per_cat))
        all_items.extend(self.generate_category_d_state_transition(count_per_cat))
        all_items.extend(self.generate_category_e_causal(count_per_cat))
        all_items.extend(self.generate_category_f_planning(count_per_cat))
        all_items.extend(self.generate_category_g_tools(count_per_cat))
        all_items.extend(self.generate_category_h_error_correction(count_per_cat))
        self.rng.shuffle(all_items)
        return all_items


def create_curriculum_splits(
    curriculum: List[CurriculumItem],
    train_ratio: float = 0.70,
    val_ratio: float = 0.15,
    test_ratio: float = 0.15,
    seed: int = 42,
) -> Tuple[List[CurriculumItem], List[CurriculumItem], List[CurriculumItem]]:
    """Partition items into isolated train, validation, and test sets."""
    rng = random.Random(seed)
    shuffled = list(curriculum)
    rng.shuffle(shuffled)

    n = len(shuffled)
    n_train = int(n * train_ratio)
    n_val = int(n * val_ratio)

    train_set = shuffled[:n_train]
    val_set = shuffled[n_train : n_train + n_val]
    test_set = shuffled[n_train + n_val :]

    return train_set, val_set, test_set


class CurriculumDataset(Dataset):
    """PyTorch Dataset yielding tokenized sequences from CurriculumItem examples."""

    def __init__(
        self,
        items: List[CurriculumItem],
        tokenizer: CharTokenizer,
        seq_len: int = 64,
        target_only_loss: bool = True,
    ):
        self.items = items
        self.tokenizer = tokenizer
        self.seq_len = seq_len
        self.target_only_loss = target_only_loss

    def __len__(self) -> int:
        return len(self.items)

    def __getitem__(self, idx: int) -> Dict[str, torch.Tensor]:
        item = self.items[idx]
        tokens = self.tokenizer.encode(item.full_text, add_special_tokens=True)

        if len(tokens) > self.seq_len:
            tokens = tokens[: self.seq_len]
        else:
            tokens = tokens + [self.tokenizer.pad_token_id] * (self.seq_len - len(tokens))

        input_ids = torch.tensor(tokens, dtype=torch.long)
        labels = input_ids.clone()

        if self.target_only_loss:
            # Mask out prompt tokens so loss is only computed on the target prediction
            prompt_len = len(self.tokenizer.encode(item.prompt, add_special_tokens=False))
            # Keep prompt masked with -100 (standard PyTorch cross_entropy ignore_index)
            labels[: min(prompt_len, self.seq_len)] = -100

        # Mask pad tokens in labels
        labels[labels == self.tokenizer.pad_token_id] = -100

        return {
            "input_ids": input_ids,
            "labels": labels,
        }
