"""Leakage and integrity tests for V10.9 Foundational Episodic Learning."""

import pytest
import torch

from training.evaluation.v10_9_foundation_harness import (
    ANS_TOKEN,
    MIN_DATA_TOKEN,
    Stage1AGenerator,
    Stage1BGenerator,
)


def test_stage1a_query_not_in_support():
    gen = Stage1AGenerator(vocab_start=MIN_DATA_TOKEN, domain_size=8)
    g = torch.Generator().manual_seed(101)

    for _ in range(50):
        ep = gen.generate_episode(g)
        assert ep.query_key not in ep.keys, "Stage 1A query symbol leaked into support symbols!"


def test_answer_isolation_in_input():
    gen = Stage1BGenerator(vocab_start=MIN_DATA_TOKEN, vocab_size=64)
    g = torch.Generator().manual_seed(202)

    for _ in range(50):
        quartet = gen.generate_quartet(g)
        for ep in quartet.values():
            tokens = ep.input_ids.tolist()
            # The input sequence MUST terminate with ANS_TOKEN
            assert tokens[-1] == ANS_TOKEN
            # The target MUST NOT appear after ANS_TOKEN
            assert len(tokens) == tokens.index(ANS_TOKEN) + 1


def test_fingerprint_uniqueness_and_determinism():
    gen = Stage1BGenerator(vocab_start=MIN_DATA_TOKEN, vocab_size=64)
    g1 = torch.Generator().manual_seed(303)
    ep1 = gen.generate_quartet(g1)["correct"]

    g2 = torch.Generator().manual_seed(303)
    ep2 = gen.generate_quartet(g2)["correct"]

    # Identical seed produces identical fingerprint
    assert ep1.fingerprint == ep2.fingerprint

    # Different seed produces different fingerprint
    g3 = torch.Generator().manual_seed(304)
    ep3 = gen.generate_quartet(g3)["correct"]
    assert ep1.fingerprint != ep3.fingerprint


def test_deliberate_answer_leak_fails_closed():
    """Verify that an episode with target leaked after ANS_TOKEN is rejected."""
    gen = Stage1BGenerator(vocab_start=MIN_DATA_TOKEN, vocab_size=64)
    g = torch.Generator().manual_seed(404)
    ep = gen.generate_quartet(g)["correct"]

    # Deliberately append target to input_ids (leak!)
    leaked_tokens = torch.cat([ep.input_ids, torch.tensor([ep.target], dtype=torch.long)])

    # Validate that inspection catches the leakage
    tokens = leaked_tokens.tolist()
    assert tokens.index(ANS_TOKEN) != len(tokens) - 1, "Deliberate leak was not detected!"


def test_deliberate_support_query_overlap_in_stage1a_rejected():
    """Negative test: Stage 1A query symbol must never overlap with support keys."""
    gen = Stage1AGenerator(vocab_start=MIN_DATA_TOKEN, domain_size=8)
    g = torch.Generator().manual_seed(505)
    ep = gen.generate_episode(g)

    # Deliberately construct an invalid episode where query is in support
    invalid_query = ep.keys[0]
    invalid_tokens = ep.input_ids.clone()
    invalid_tokens[14] = invalid_query

    # Auditor check
    is_valid = invalid_query not in ep.keys
    assert not is_valid, "Auditor should detect that query overlaps support keys!"


def test_random_support_accidental_match_rejected():
    """Verify that random support generation strictly rejects accidental consistency."""
    gen = Stage1BGenerator(vocab_start=MIN_DATA_TOKEN, vocab_size=64)
    # Test across 100 quartets to guarantee zero accidental matches
    g = torch.Generator().manual_seed(606)
    for _ in range(100):
        quartet = gen.generate_quartet(g)
        r_ep = quartet["random"]
        toks = r_ep.input_ids.tolist()
        qx = r_ep.query_key
        qy = r_ep.target
        for k_idx, v_idx in [(2, 4), (6, 8), (10, 12), (14, 16)]:
            if toks[k_idx] == qx:
                assert toks[v_idx] != qy, "Accidental match in random control slipped through!"
