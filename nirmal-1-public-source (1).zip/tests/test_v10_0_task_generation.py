"""Tests for deterministic task generation — V10.0."""
import pytest
import torch
from training.acquisition.v10_0_intervention_engine import TaskConfig, TaskGenerator


@pytest.fixture
def gen():
    return TaskGenerator()


@pytest.fixture
def copy_cfg():
    return TaskConfig("copy", seq_len=4, train_vocab=(10, 35), val_vocab=(10, 35),
                      ood_vocab=(60, 85), batch_size=4, seed=7)


def test_deterministic_same_seed(gen, copy_cfg):
    s1 = gen.generate(copy_cfg)
    s2 = gen.generate(copy_cfg)
    assert (s1["train"] == s2["train"]).all()
    assert (s1["ood"] == s2["ood"]).all()


def test_deterministic_different_seed(gen, copy_cfg):
    cfg2 = TaskConfig("copy", seq_len=4, train_vocab=(10, 35), val_vocab=(10, 35),
                      ood_vocab=(60, 85), batch_size=4, seed=99)
    s1 = gen.generate(copy_cfg)
    s2 = gen.generate(cfg2)
    assert not (s1["train"] == s2["train"]).all()


def test_copy_structure(gen, copy_cfg):
    splits = gen.generate(copy_cfg)
    t = splits["train"]
    seq = copy_cfg.seq_len
    assert (t[:, :seq] == t[:, seq:]).all()


def test_increment_structure(gen):
    cfg = TaskConfig("increment", seq_len=4, train_vocab=(10, 30), val_vocab=(10, 30),
                     ood_vocab=(60, 80), batch_size=4, seed=5)
    splits = gen.generate(cfg)
    t = splits["train"]
    # Each element = start + j, so consecutive diff is 1
    assert (t[:, 1] == t[:, 0] + 1).all()



def test_output_shape(gen, copy_cfg):
    splits = gen.generate(copy_cfg)
    seq_out = copy_cfg.seq_len * 2  # copy doubles length
    assert splits["train"].shape == (4, seq_out)
    assert splits["ood"].shape   == (4, seq_out)
