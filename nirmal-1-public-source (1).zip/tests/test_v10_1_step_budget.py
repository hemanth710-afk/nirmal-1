"""V10.1 — step-budget correctness tests."""
import pytest
from training.acquisition.v10_1_ood_amplification import (
    TaskConfig, run_dose, BUDGETS
)
from pathlib import Path
import tempfile


@pytest.fixture
def task():
    return TaskConfig("copy", 4, (10, 35), (10, 35), (60, 85), 4, 1000)


@pytest.fixture
def tmpdir():
    with tempfile.TemporaryDirectory() as d:
        yield Path(d)


def test_budget_100_final_step_is_100(task, tmpdir):
    r = run_dose("identity", 100, 42, task, tmpdir)
    assert r.checkpoints[-1].step == 100


def test_budget_250_final_step_is_250(task, tmpdir):
    r = run_dose("identity", 250, 42, task, tmpdir)
    assert r.checkpoints[-1].step == 250


def test_more_steps_lower_or_equal_loss(task, tmpdir):
    r100  = run_dose("value_relative", 100,  42, task, tmpdir)
    r1000 = run_dose("value_relative", 1000, 42, task, tmpdir)
    loss100  = r100.checkpoints[-1].loss
    loss1000 = r1000.checkpoints[-1].loss
    # More steps should reduce loss (or at worst not increase it significantly)
    assert loss1000 <= loss100 + 0.5   # allow small tolerance


def test_param_count_consistent(task, tmpdir):
    r1 = run_dose("identity", 50, 42, task, tmpdir)
    r2 = run_dose("identity", 50, 43, task, tmpdir)
    assert r1.param_count == r2.param_count


def test_budgets_list_correct():
    assert BUDGETS == [100, 250, 500, 1000, 2000]
