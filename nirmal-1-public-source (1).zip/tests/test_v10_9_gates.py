"""Readiness Gates calculation tests for V10.9."""

import pytest

from training.evaluation.v10_9_foundation_harness import ReadinessGateReport


def test_gate1_train_mastery():
    # Passing: all >= 0.90
    rep_pass = ReadinessGateReport.evaluate(
        stage="stage1a",
        train_accs_final3=[0.92, 0.95, 0.94],
        val_accs_per_seed={42: 0.85, 43: 0.82, 44: 0.88},
        seed_control_gains={},
        bootstrap_ci_low=0.05,
        integrity_ok=True,
    )
    assert rep_pass.gate1_train_mastery is True

    # Failing: one < 0.90
    rep_fail = ReadinessGateReport.evaluate(
        stage="stage1a",
        train_accs_final3=[0.92, 0.88, 0.94],
        val_accs_per_seed={42: 0.85, 43: 0.82, 44: 0.88},
        seed_control_gains={},
        bootstrap_ci_low=0.05,
        integrity_ok=True,
    )
    assert rep_fail.gate1_train_mastery is False


def test_gate2_and_gate4_validation_and_seed_stability():
    # High variance across seeds: std > 0.05 fails Gate 4
    rep = ReadinessGateReport.evaluate(
        stage="stage1a",
        train_accs_final3=[0.95, 0.95, 0.95],
        val_accs_per_seed={42: 0.95, 43: 0.76, 44: 0.85},
        seed_control_gains={},
        bootstrap_ci_low=0.05,
        integrity_ok=True,
    )
    assert rep.gate2_val_generalization is True
    assert rep.gate4_seed_stability is False  # std is ~0.077 > 0.05!


def test_gate3_causal_utility_stage1b():
    # Stage 1A ignores Gate 3
    rep_1a = ReadinessGateReport.evaluate(
        stage="stage1a",
        train_accs_final3=[0.95, 0.95, 0.95],
        val_accs_per_seed={42: 0.85, 43: 0.85, 44: 0.85},
        seed_control_gains={},
        bootstrap_ci_low=-0.01,
        integrity_ok=True,
    )
    assert rep_1a.gate3_causal_utility is True

    # Stage 1B checks correct vs random/wrong/absent >= 10pp and bootstrap low > 0
    gains_pass = {
        42: {"correct_minus_random": 0.25, "correct_minus_wrong": 0.20, "correct_minus_absent": 0.22},
        43: {"correct_minus_random": 0.30, "correct_minus_wrong": 0.28, "correct_minus_absent": 0.25},
        44: {"correct_minus_random": 0.22, "correct_minus_wrong": 0.18, "correct_minus_absent": 0.19},
    }
    rep_1b_pass = ReadinessGateReport.evaluate(
        stage="stage1b",
        train_accs_final3=[0.95, 0.95, 0.95],
        val_accs_per_seed={42: 0.85, 43: 0.85, 44: 0.85},
        seed_control_gains=gains_pass,
        bootstrap_ci_low=0.15,
        integrity_ok=True,
    )
    assert rep_1b_pass.gate3_causal_utility is True
    assert rep_1b_pass.all_passed is True

    # Failing bootstrap low <= 0
    rep_1b_fail = ReadinessGateReport.evaluate(
        stage="stage1b",
        train_accs_final3=[0.95, 0.95, 0.95],
        val_accs_per_seed={42: 0.85, 43: 0.85, 44: 0.85},
        seed_control_gains=gains_pass,
        bootstrap_ci_low=-0.02,
        integrity_ok=True,
    )
    assert rep_1b_fail.gate3_causal_utility is False
    assert rep_1b_fail.all_passed is False
