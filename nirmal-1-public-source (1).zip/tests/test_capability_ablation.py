import pytest
from training.acquisition.capability_classifier import CapabilityClassifier
from pathlib import Path

@pytest.fixture
def classifier():
    return CapabilityClassifier(Path("data/capability_taxonomy.json"))

def test_full_input(classifier):
    labels, conf = classifier.classify_document(
        "def test(): return 1", 
        {"url": "arxiv.org/abs/math", "source_id": "github"}
    )
    assert len(labels) >= 2

def test_text_only(classifier):
    labels, conf = classifier.classify_document(
        "def test():\n    return 1\nimport os", 
        {}
    )
    assert "programming" in labels

def test_metadata_only(classifier):
    labels, conf = classifier.classify_document(
        "", 
        {"source_id": "github"}
    )
    assert "programming" in labels

def test_url_only(classifier):
    labels, conf = classifier.classify_document(
        "", 
        {"url": "arxiv.org/abs/math"}
    )
    assert "mathematical reasoning" in labels

def test_source_id_only(classifier):
    labels, conf = classifier.classify_document(
        "", 
        {"source_id": "wikipedia"}
    )
    assert "world knowledge" in labels

def test_no_artificial_high_confidence(classifier):
    # Metadata alone should not give HIGH confidence unless explicitly programmed
    # (In our case, some might give HIGH, but let's test a generic one)
    labels, conf = classifier.classify_document(
        "", 
        {"source_id": "unknown_source"}
    )
    assert conf == "UNKNOWN"
