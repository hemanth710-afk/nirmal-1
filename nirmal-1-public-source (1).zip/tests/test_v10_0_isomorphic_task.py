"""Tests for isomorphic task correctness — V10.0."""
import pytest
from training.acquisition.v10_0_intervention_engine import TaskConfig, TaskGenerator


@pytest.fixture
def gen():
    return TaskGenerator()


def test_isomorphic_same_rule_train_ood(gen):
    cfg = TaskConfig("increment", 3, (10, 30), (10, 30), (60, 80), 4, 5)
    splits = gen.generate(cfg)
    t = splits["train"]
    o = splits["ood"]
    # Single-start generator: t[:,j] = start + j
    assert (t[:, 1] == t[:, 0] + 1).all()
    assert (o[:, 1] == o[:, 0] + 1).all()


def test_isomorphic_vocab_disjoint(gen):
    cfg = TaskConfig("increment", 3, (10, 30), (10, 30), (60, 80), 4, 5)
    splits = gen.generate(cfg)
    cert = gen.leakage_certificate(splits)
    assert cert["vocab_disjoint"]


def test_isomorphic_double_step(gen):
    cfg = TaskConfig("double_step", 3, (10, 25), (10, 25), (60, 75), 4, 9)
    splits = gen.generate(cfg)
    t = splits["train"]
    assert (t[:, 1] == t[:, 0] + 2).all()


def test_isomorphic_ood_obeys_same_rule(gen):
    cfg = TaskConfig("double_step", 3, (10, 25), (10, 25), (60, 75), 4, 9)
    splits = gen.generate(cfg)
    o = splits["ood"]
    assert (o[:, 1] == o[:, 0] + 2).all()

