import pytest
import torch
import numpy as np

def test_seed_fixing():
    torch.manual_seed(42)
    np.random.seed(42)
    a = torch.randint(0, 100, (5,)).tolist()
    
    torch.manual_seed(42)
    np.random.seed(42)
    b = torch.randint(0, 100, (5,)).tolist()
    
    assert a == b

def test_dataset_hash():
    import hashlib
    data = torch.tensor([1, 2, 3])
    h1 = hashlib.md5(data.numpy().tobytes()).hexdigest()
    h2 = hashlib.md5(data.numpy().tobytes()).hexdigest()
    assert h1 == h2

def test_reproducible_task_generation():
    from scripts.v9_7_learning_sanity import SanityTaskGenerator
    gen = SanityTaskGenerator(100)
    torch.manual_seed(10)
    t1 = gen.generate_sequence_copy()
    torch.manual_seed(10)
    t2 = gen.generate_sequence_copy()
    assert (t1 == t2).all()

def test_reproducible_evaluator():
    from scripts.v9_7_learning_sanity import LearningSanityEvaluator
    ev = LearningSanityEvaluator(seed=42)
    assert ev.seed == 42
    
def test_manifest_recording():
    # Similar to V9.6, we track records.
    records = []
    records.append({"seed": 42, "hash": "abc"})
    records.append({"seed": 42, "hash": "abc"})
    assert records[0] == records[1]
