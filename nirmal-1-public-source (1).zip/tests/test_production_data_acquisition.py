"""
Unit and integration tests for Nirmal-1 Production Data Acquisition Launcher & Readiness Gate.

Tests:
- Dry-run mode execution
- Preflight auditor (checks A through O)
- Source registry and license validation
- Token accounting strict categorization
- Deduplication and boilerplate preservation
- Split isolation and leakage rejection
- Tokenizer checksum verification
- Shard integrity and corruption detection
- Manifest verification and tamper detection
- Ingestion resumability and failure recovery
- 12 hard production launch gates
"""

import json
from pathlib import Path
import tempfile
import pytest

from scripts.production_data_acquisition import (
    SourceRegistry,
    AcquisitionPlan,
    PreflightAuditor,
    ProductionDataGateSystem,
    ProductionDataLauncher,
    run_synthetic_adversarial_test,
)
from training.v8_4_ingestion import (
    StreamingIngestionEngine,
    IngestionCheckpoint,
    SourceDescriptor,
    SourceType,
    CorruptRecordPolicy,
    CorruptedRecordError,
)
from training.v8_4_manifest import (
    SourceProvenanceRecord,
    TokenAccountingCategories,
    DatasetManifestManager,
    ManifestIntegrityError,
    ALLOWED_LICENSES,
)
from training.v8_4_sharding import (
    DistributedShardWriter,
    DistributedShardReader,
    ShardIntegrityError,
)
from scripts.count_verified_production_tokens import TARGET_PRODUCTION_TOKENS, find_and_count_shards


def test_source_registry_loading_and_policy():
    registry = SourceRegistry()
    assert len(registry.sources) >= 5

    # Check status categories
    verified = registry.get_sources_by_status("VERIFIED")
    planned = registry.get_sources_by_status("PLANNED")
    rejected = registry.get_sources_by_status("REJECTED")

    assert len(verified) >= 1
    assert len(planned) >= 4
    assert len(rejected) >= 1

    # Check planned token summation (must equal 200B)
    planned_tokens = registry.get_planned_token_count()
    assert planned_tokens >= TARGET_PRODUCTION_TOKENS

    # Validate licenses across active/planned sources
    ok, violations = registry.validate_licenses()
    assert ok is True, f"Active/planned sources have license violations: {violations}"

    # Fingerprint computation
    fp = registry.compute_registry_fingerprint()
    assert isinstance(fp, str) and len(fp) == 64


def test_preflight_auditor():
    registry = SourceRegistry()
    preflight = PreflightAuditor(registry)
    passed, checks = preflight.audit()

    assert passed is True, f"Preflight checks failed: {checks}"
    assert checks["A_disk_capacity"]["status"] == "PASS"
    assert checks["E_tokenizer_checksum"]["status"] == "PASS"
    assert checks["G_dedup_config"]["status"] == "PASS"
    assert checks["J_source_license_evidence"]["status"] == "PASS"
    assert checks["L_required_dependencies"]["status"] == "PASS"
    assert checks["N_free_ram"]["status"] == "PASS"


def test_production_data_gate_system_fail_closed():
    registry = SourceRegistry()
    gate_sys = ProductionDataGateSystem(registry)
    status, gates = gate_sys.evaluate_gates()

    # Because verified tokens (233,997) < 200B target, overall status MUST be NO-GO
    assert status == "NO-GO"
    assert gates["GATE_1_TOKEN_COUNT"]["passed"] is False
    assert gates["GATE_1_TOKEN_COUNT"]["status"] == "FAIL"

    # Other software gates must pass
    assert gates["GATE_2_EXACT_DEDUP"]["passed"] is True
    assert gates["GATE_3_NEAR_DEDUP"]["passed"] is True
    assert gates["GATE_4_SPLIT_ISOLATION"]["passed"] is True
    assert gates["GATE_5_TOKENIZER"]["passed"] is True
    assert gates["GATE_6_SHARD_INTEGRITY"]["passed"] is True
    assert gates["GATE_7_MANIFEST_INTEGRITY"]["passed"] is True
    assert gates["GATE_9_LICENSE_POLICY"]["passed"] is True


def test_dry_run_mode_launcher():
    launcher = ProductionDataLauncher()
    report = launcher.run_dry_run()

    assert report["mode"] == "DRY_RUN"
    assert report["preflight_passed"] is True
    assert report["production_data_status"] == "NO-GO"
    assert report["final_verdicts"]["PIPELINE_SOFTWARE"] == "GO"
    assert report["final_verdicts"]["CURRENT_DATASET"] == "NO-GO"
    assert report["final_verdicts"]["200B_TOKEN_TARGET"] == "NOT AVAILABLE"
    assert report["final_verdicts"]["PRODUCTION_TRAINING"] == "NO-GO"


def test_execute_mode_gate_enforcement():
    launcher = ProductionDataLauncher()
    report = launcher.run_execute()

    assert report["mode"] == "EXECUTE"
    assert report["preflight_passed"] is True
    # Verify execute mode does NOT bypass readiness gates: status must be NO-GO
    assert report["production_data_status"] == "NO-GO"
    assert report["final_verdicts"]["CURRENT_DATASET"] == "NO-GO"


def test_synthetic_adversarial_failure_injection_suite():
    results = run_synthetic_adversarial_test()

    assert results["exact_duplicate_fail_closed"] == "PASS"
    assert results["near_duplicate_fail_closed"] == "PASS"
    assert results["cross_split_leakage_fail_closed"] == "PASS"
    assert results["invalid_utf8_fail_closed"] == "PASS"
    assert results["malformed_record_fail_closed"] == "PASS"
    assert results["corrupt_shard_fail_closed"] == "PASS"
    assert results["tampered_manifest_fail_closed"] == "PASS"
    assert results["rejected_license_fail_closed"] == "PASS"


def test_authoritative_token_accounting_separation():
    local_tokens, doc_count, shards = find_and_count_shards()
    assert local_tokens >= 233_997
    assert doc_count >= 737

    cats = TokenAccountingCategories(
        local_verified_tokens=local_tokens,
        remote_verified_tokens=0,
        planned_tokens=TARGET_PRODUCTION_TOKENS,
        estimated_tokens=0,
    )
    d = cats.to_dict()

    # Verify categories are never blended
    assert d["LOCAL_VERIFIED"] == local_tokens
    assert d["REMOTE_VERIFIED"] == 0
    assert d["PLANNED"] == TARGET_PRODUCTION_TOKENS
    assert d["ESTIMATED"] == 0
    assert d["LOCAL_VERIFIED"] != d["PLANNED"]
    assert "Never combined" in d["category_policy"]
