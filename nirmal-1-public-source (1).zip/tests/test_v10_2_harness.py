"""V10.2 Targeted Tests."""
import pytest
import torch
import json
from pathlib import Path
from training.evaluation.v10_2_harness import (
    TaskConfig, TaskGenerator, CapacityBuilder, apply_repr,
    aggregate_results, ResourceGuard
)

def test_immutable_eval_set_hashes():
    gen = TaskGenerator()
    cfg1 = TaskConfig("increment", 3, (10, 30), (10, 30), (60, 80), 4, 42)
    splits1 = gen.generate(cfg1)
    hash1 = gen.hash_dataset(splits1["ood"])
    
    splits2 = gen.generate(cfg1)
    hash2 = gen.hash_dataset(splits2["ood"])
    
    assert hash1 == hash2

def test_deterministic_evaluation():
    gen = TaskGenerator()
    cfg1 = TaskConfig("increment", 3, (10, 30), (10, 30), (60, 80), 4, 42)
    splits1 = gen.generate(cfg1)
    
    cfg2 = TaskConfig("increment", 3, (10, 30), (10, 30), (60, 80), 4, 42)
    splits2 = gen.generate(cfg2)
    
    assert (splits1["ood"] == splits2["ood"]).all()

def test_capacity_configuration_correctness():
    model = CapacityBuilder.build("L0")
    assert model.config.hidden_size == 32
    assert model.config.num_hidden_layers == 2
    
    model2 = CapacityBuilder.build("L4")
    assert model2.config.hidden_size == 256
    assert model2.config.num_hidden_layers == 6

def test_parameter_count_correctness():
    model = CapacityBuilder.build("L0")
    params = CapacityBuilder.count_params(model)
    assert params > 5000

def test_representation_condition_correctness():
    x = torch.tensor([[10, 20]])
    res = apply_repr(x, "value_relative", lo=10)
    assert res[0, 0] == 0
    assert res[0, 1] == 10

def test_vocabulary_ood_isolation():
    gen = TaskGenerator()
    cfg = TaskConfig("increment", 3, (10, 30), (10, 30), (60, 80), 4, 42)
    splits = gen.generate(cfg)
    cert = gen.leakage_certificate(splits)
    assert cert["vocab_disjoint"] is True

def test_leakage_rejection():
    gen = TaskGenerator()
    cfg = TaskConfig("increment", 3, (10, 30), (10, 30), (10, 30), 4, 42)
    splits = gen.generate(cfg)
    cert = gen.leakage_certificate(splits)
    assert cert["valid"] is False

def test_multi_seed_aggregation_and_ci():
    results = [0.1, 0.2, 0.3]
    agg = aggregate_results(results)
    assert agg["mean"] == 0.2
    assert agg["min"] == 0.1
    assert agg["max"] == 0.3
    # CI = 1.96 * std / sqrt(n)
    # std of 0.1, 0.2, 0.3 is ~0.0816
    assert agg["ci95"] > 0
