"""
NIRMAL-1 V9.0: TEST SUITE FOR HUMAN REVIEW BOUNDARY & LEGAL SIGN-OFF ENFORCEMENT

Verifies:
1. Structured human review record generation in data/promotion/human_review/.
2. CC-BY-SA licensing ambiguity automatically triggers NEEDS_HUMAN_REVIEW.
3. Software auto-approval prohibition (cannot transition to APPROVED_FOR_PRODUCTION).
4. Schema validation for human review issue records.
"""

import json
from pathlib import Path
import pytest

from training.acquisition.promotion_gate import (
    RealSourcePromotionGate,
    PromotionState,
)


@pytest.fixture
def temp_gate_dirs(tmp_path):
    prom_dir = tmp_path / "promotion"
    pilot_dir = tmp_path / "pilot"
    evidence_dir = tmp_path / "evidence"

    prom_dir.mkdir(parents=True)
    (pilot_dir / "manifests").mkdir(parents=True)
    (pilot_dir / "shards").mkdir(parents=True)
    evidence_dir.mkdir(parents=True)

    # Eligibility matrix with wikipedia
    matrix_path = evidence_dir / "source_eligibility_matrix.json"
    matrix_data = {
        "sources": {
            "wikipedia_open_corpus": {
                "canonical_name": "Wikimedia Multi-Language Open Knowledge Corpus",
                "pilot_status": "PILOT_ELIGIBLE",
                "version": "2026.09",
            }
        }
    }
    with open(matrix_path, "w", encoding="utf-8") as f:
        json.dump(matrix_data, f, indent=2)

    # Evidence dossier with declared_license = CC-BY-SA-4.0
    wiki_ev_path = evidence_dir / "wikipedia_open_corpus.json"
    wiki_ev_data = {
        "source_id": "wikipedia_open_corpus",
        "canonical_url": "https://dumps.wikimedia.org/",
        "dataset_version_identifier": "2026.09",
        "acquisition_method": "WIKIMEDIA_ENTERPRISE_SNAPSHOT",
        "snapshot_revision_identifier": "dump_snapshot_20260901",
        "declared_license": "CC-BY-SA-4.0",  # Requires human legal review!
        "approval_status": "UNDER_REVIEW",
        "known_restrictions": ["Legal review required for CC-BY-SA model weights copyright compatibility"],
        "attribution_requirements": ["Wikipedia contributor attribution retained per terms of use"],
    }
    with open(wiki_ev_path, "w", encoding="utf-8") as f:
        json.dump(wiki_ev_data, f, indent=2)

    # Pilot shard and manifest
    shard_file = pilot_dir / "shards" / "pilot_tokens.bin"
    shard_file.write_bytes(b"\x01\x00" * 20)

    manifest_file = pilot_dir / "manifests" / "wikipedia_open_corpus_pilot_manifest.json"
    manifest_data = {
        "manifest_version": "V8.7-PILOT",
        "source_id": "wikipedia_open_corpus",
        "source_version": "2026.09",
        "source_revision": "1198274612",
        "manifest_fingerprint": "a" * 64,
        "cryptographic_hashes": {
            "raw_payload_sha256": "b" * 64,
            "final_shard_sha256": "c" * 64,
            "final_shard_path": str(shard_file),
            "tokenizer_fingerprint": "21e5e370e3e1c0e396f65d19925e851e540ca17e70d4236763326def714251cf",
            "pipeline_config_fingerprint": "d" * 64,
        },
        "accounting": {
            "document_accounting": {
                "documents_discovered": 1,
                "documents_accepted": 1,
                "total_rejected": 0,
                "rejected_by_category": {},
                "conservation_satisfied": True,
            },
            "token_accounting": {
                "accepted_tokens": 20,
                "final_shard_tokens": 20,
            },
            "byte_accounting": {
                "final_shard_bytes": 40,
            },
        },
        "document_provenance": [
            {
                "doc_id": "wiki_1001",
                "sha256": "e" * 64,
                "token_count": 20,
                "source_revision": "1198274612",
                "canonical_url": "https://en.wikipedia.org/wiki/Quantum_computing",
            }
        ],
    }
    with open(manifest_file, "w", encoding="utf-8") as f:
        json.dump(manifest_data, f, indent=2)

    return prom_dir, pilot_dir, evidence_dir


class TestHumanReviewBoundary:
    """Test suite for human review boundary enforcement and CC-BY-SA legal guards."""

    def test_cc_by_sa_triggers_human_review_boundary(self, temp_gate_dirs):
        prom_dir, pilot_dir, evidence_dir = temp_gate_dirs
        gate = RealSourcePromotionGate(promotion_dir=prom_dir, pilot_dir=pilot_dir, evidence_dir=evidence_dir)

        checklist = gate.evaluate_source("wikipedia_open_corpus")
        assert checklist.all_passed is False
        assert checklist.status == "NEEDS_HUMAN_REVIEW"
        assert len(checklist.human_review_issues) > 0

        lic_item = checklist.items["4_licensing_evidence"]
        assert lic_item.status == "NEEDS_HUMAN_REVIEW"
        assert "CC-BY-SA" in lic_item.details

    def test_software_auto_approval_prohibition(self, temp_gate_dirs):
        prom_dir, pilot_dir, evidence_dir = temp_gate_dirs
        gate = RealSourcePromotionGate(promotion_dir=prom_dir, pilot_dir=pilot_dir, evidence_dir=evidence_dir)

        # Attempt to promote without human sign-off
        result = gate.promote_source("wikipedia_open_corpus")

        # Software MUST NOT approve
        assert result.verdict == "NEEDS_HUMAN_REVIEW"
        assert result.state == PromotionState.PROMOTION_PENDING.value
        assert result.promoted_shard_path is None
        assert result.promoted_manifest_path is None

    def test_human_review_record_schema_and_persistence(self, temp_gate_dirs):
        prom_dir, pilot_dir, evidence_dir = temp_gate_dirs
        gate = RealSourcePromotionGate(promotion_dir=prom_dir, pilot_dir=pilot_dir, evidence_dir=evidence_dir)

        result = gate.promote_source("wikipedia_open_corpus")
        assert len(result.human_review_records) > 0

        rec_path = Path(result.human_review_records[0])
        assert rec_path.exists()

        with open(rec_path, "r", encoding="utf-8") as f:
            rec_data = json.load(f)

        # Verify required schema
        assert "question" in rec_data
        assert "source_id" in rec_data
        assert rec_data["source_id"] == "wikipedia_open_corpus"
        assert "evidence_reference" in rec_data
        assert "reason_software_cannot_decide" in rec_data
        assert rec_data["review_status"] == "NEEDS_HUMAN_REVIEW"
        assert "timestamp" in rec_data
