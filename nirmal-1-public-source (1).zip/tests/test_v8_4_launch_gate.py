"""
Unit tests for Joint Launch Gate Logic in Nirmal-1 V8.4.
"""

from pathlib import Path
import tempfile
import pytest

from scripts.run_v8_4_launch_readiness import run_launch_readiness_audit


def test_joint_launch_gate_execution():
    with tempfile.TemporaryDirectory() as tmpdir:
        tmp_path = Path(tmpdir)
        summary = run_launch_readiness_audit(output_dir=tmp_path)

        assert "joint_verdict" in summary
        # On this workstation, local hardware is 0 GPUs and token deficit is ~199.9997B, so joint verdict MUST be NO-GO
        assert summary["joint_verdict"] == "NO-GO"
        assert summary["data_ready"] is False
        assert summary["hardware_ready"] is False
        assert len(summary["all_blockers"]) >= 2

        # Check that artifacts were written
        assert (tmp_path / "v8_4_data_progress.json").exists()
        assert (tmp_path / "v8_4_hardware_status.json").exists()
        assert (tmp_path / "v8_4_launch_readiness.json").exists()


def test_joint_verdict_truth_table():
    # Helper checking truth table
    def eval_verdict(d_ready: bool, h_ready: bool) -> str:
        if d_ready and h_ready:
            return "READY"
        elif d_ready or h_ready:
            return "PARTIALLY READY"
        else:
            return "NO-GO"

    assert eval_verdict(True, True) == "READY"
    assert eval_verdict(True, False) == "PARTIALLY READY"
    assert eval_verdict(False, True) == "PARTIALLY READY"
    assert eval_verdict(False, False) == "NO-GO"
