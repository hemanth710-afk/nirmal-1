"""
NIRMAL-1 V8.7: TEST SUITE FOR PILOT MANIFEST INTEGRITY (PHASE 8, 10)

Verifies:
1. PilotManifestManager generates complete, structured manifests.
2. Cryptographic manifest_fingerprint matches content.
3. Tampering with any byte or field in manifest immediately fails verification.
4. Nonexistent manifest file fails closed.
"""

import json
from pathlib import Path
import pytest

from training.acquisition.pilot_manifest import (
    PilotManifestManager,
    DocumentProvenanceEntry,
)


@pytest.fixture
def manifest_mgr(tmp_path):
    manifests_dir = tmp_path / "manifests"
    return PilotManifestManager(manifests_dir)


class TestPilotManifest:
    """Test suite for pilot manifest generation and tamper detection."""

    def test_manifest_generation_and_structure(self, manifest_mgr):
        doc_entries = [
            DocumentProvenanceEntry(
                doc_id="wiki_101",
                sha256="a" * 64,
                token_count=150,
                title="Physics",
                canonical_url="https://en.wikipedia.org/wiki/Physics",
                source_revision="rev_1",
                license_tag="CC-BY-SA-4.0",
                accepted_timestamp="2026-09-08T12:00:00Z",
            )
        ]

        accounting_data = {
            "documents_discovered": 1,
            "documents_accepted": 1,
            "total_rejected": 0,
            "accepted_tokens": 150,
        }

        path = manifest_mgr.generate_manifest(
            source_id="test_source",
            source_version="v1.0",
            source_revision="rev_1",
            raw_payload_hash="b" * 64,
            final_shard_hash="c" * 64,
            final_shard_path="/path/to/shard.bin",
            document_entries=doc_entries,
            accounting_dict=accounting_data,
            tokenizer_fingerprint="tok_hash_123",
            pipeline_config_fingerprint="pipe_hash_456",
            evidence_references={"evidence_dir": "data/evidence"},
        )

        assert path.exists()
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)

        assert data["manifest_version"] == "V8.7-PILOT"
        assert data["source_id"] == "test_source"
        assert "manifest_fingerprint" in data
        assert len(data["document_provenance"]) == 1

        # Verification must pass
        ok, msg = PilotManifestManager.verify_manifest(path)
        assert ok is True
        assert "integrity verified" in msg

    def test_tampered_manifest_fails_verification(self, manifest_mgr):
        """Modifying a field in the manifest breaks fingerprint verification."""
        path = manifest_mgr.generate_manifest(
            source_id="test_tamper_source",
            source_version="v1.0",
            source_revision="rev_1",
            raw_payload_hash="d" * 64,
            final_shard_hash="e" * 64,
            final_shard_path="/path/to/shard.bin",
            document_entries=[],
            accounting_dict={},
            tokenizer_fingerprint="tok_hash",
            pipeline_config_fingerprint="pipe_hash",
            evidence_references={},
        )

        # Tamper with the manifest on disk (e.g. modify version)
        with open(path, "r", encoding="utf-8") as f:
            tampered_data = json.load(f)
        tampered_data["source_version"] = "v2.0_tampered"
        with open(path, "w", encoding="utf-8") as f:
            json.dump(tampered_data, f, indent=2)

        # Verify must fail closed!
        ok, msg = PilotManifestManager.verify_manifest(path)
        assert ok is False
        assert "tampering detected" in msg.lower()

    def test_nonexistent_manifest_fails_closed(self, tmp_path):
        fake_path = tmp_path / "nonexistent_manifest.json"
        ok, msg = PilotManifestManager.verify_manifest(fake_path)
        assert ok is False
        assert "does not exist" in msg
