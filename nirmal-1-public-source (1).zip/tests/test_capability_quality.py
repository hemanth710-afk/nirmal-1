import pytest
from training.acquisition.capability_quality import CapabilityQualityScorer

@pytest.fixture
def scorer():
    return CapabilityQualityScorer()

def test_document_coherence_and_length(scorer):
    text = "Word " * 15
    score = scorer.compute_score(text)
    assert score > 0.0

def test_length_adequacy_short(scorer):
    score = scorer.compute_score("Too short.")
    # Max score 5. Length <=10 is 0. Punct > 0 gives 1, Sec gives 1, Cont gives 1. Total 3/5 = 0.6.
    assert score == 0.6

def test_length_adequacy_long(scorer):
    text = "Word " * 60 + "."
    score = scorer.compute_score(text)
    assert score >= 0.2

def test_formatting_quality(scorer):
    text = "Good formatting. With sentences. And punctuation!" * 10
    score = scorer.compute_score(text)
    assert score >= 0.2

def test_provenance_completeness(scorer):
    score = scorer.compute_score(
        "Some text.", 
        {"provenance_class": "REMOTE_SOURCE_DATA", "is_network_retrieved": True}
    )
    assert score >= 0.2

def test_security_cleanliness(scorer):
    score = scorer.compute_score(
        "Some text.", 
        {"security_decision": "PASS"}
    )
    assert score >= 0.2

def test_contamination_cleanliness(scorer):
    score = scorer.compute_score(
        "Some text.", 
        {"contamination_decision": "PASS"}
    )
    assert score >= 0.2

def test_categorize_quality(scorer):
    assert scorer.categorize_quality(0.9) == "HIGH"
    assert scorer.categorize_quality(0.6) == "MEDIUM"
    assert scorer.categorize_quality(0.2) == "LOW"
