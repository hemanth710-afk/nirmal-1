"""
NIRMAL-1 V8.8: TEST SUITE FOR PILOT PROVENANCE TRUTH (SCENARIOS 1, 2, 14, HISTORICAL AUDIT)

Verifies:
1. Local fixture masquerading as remote fails verification.
2. Synthetic document masquerading as source data fails verification.
3. Unknown provenance strictly fails verification.
4. Historical V8.7 pilot is classified as SYNTHETIC_TEST_DATA / PILOT_NOT_REALLY_REMOTE.
"""

from pathlib import Path
import pytest

from training.acquisition.pilot_provenance_audit import (
    PilotProvenanceClass,
    PilotProvenanceAuditor,
    PilotDocumentAuditEntry,
    ProvenanceVerificationError,
)


@pytest.fixture
def auditor(tmp_path):
    return PilotProvenanceAuditor(provenance_dir=tmp_path / "provenance")


class TestPilotProvenanceTruth:
    """Tests provenance truth classification and fraud prevention."""

    def test_fixture_masquerading_as_remote_fails_verification(self, auditor):
        """A local fixture claiming to be REMOTE_SOURCE_DATA fails closed."""
        with pytest.raises(ProvenanceVerificationError) as exc:
            auditor.classify_record(
                is_network=True,
                is_local_fixture=True,
                is_synthetic=False,
            )
        assert "CRITICAL PROVENANCE FRAUD" in str(exc.value)

    def test_synthetic_masquerading_as_remote_fails_verification(self, auditor):
        """Synthetic data claiming to be REMOTE_SOURCE_DATA fails closed."""
        with pytest.raises(ProvenanceVerificationError) as exc:
            auditor.classify_record(
                is_network=True,
                is_local_fixture=False,
                is_synthetic=True,
            )
        assert "CRITICAL PROVENANCE FRAUD" in str(exc.value)

    def test_remote_source_requires_valid_network_metadata(self, auditor):
        """REMOTE_SOURCE_DATA entry without network flag or valid URL is rejected."""
        entry_without_network = PilotDocumentAuditEntry(
            document_hash="a" * 64,
            source_id="wikipedia_open_corpus",
            provenance_class=PilotProvenanceClass.REMOTE_SOURCE_DATA,
            canonical_source="wikipedia_open_corpus",
            source_url="https://en.wikipedia.org/wiki/Test",
            source_revision="rev_123",
            retrieval_timestamp="2026-09-08T12:00:00Z",
            raw_byte_count=100,
            normalized_byte_count=80,
            token_count=20,
            adapter_identifier="WikipediaPilotAdapter",
            pipeline_version="V8.8",
            acquisition_record_id="run_1",
            is_network_retrieved=False,  # Fraudulent!
        )
        with pytest.raises(ProvenanceVerificationError) as exc:
            auditor.verify_entry(entry_without_network)
        assert "REMOTE_SOURCE_DATA claimed without network retrieval flag" in str(exc.value)

    def test_unknown_provenance_strictly_fails_verification(self, auditor):
        """Records with UNKNOWN provenance fail closed."""
        unknown_class = auditor.classify_record(
            is_network=False,
            is_local_fixture=False,
            is_synthetic=False,
            is_local_cache=False,
            is_project_gen=False,
        )
        assert unknown_class == PilotProvenanceClass.UNKNOWN

        entry_unknown = PilotDocumentAuditEntry(
            document_hash="b" * 64,
            source_id="wikipedia_open_corpus",
            provenance_class=PilotProvenanceClass.UNKNOWN,
            canonical_source="wikipedia_open_corpus",
            source_url="https://en.wikipedia.org/wiki/Test",
            source_revision="rev_123",
            retrieval_timestamp="2026-09-08T12:00:00Z",
            raw_byte_count=100,
            normalized_byte_count=80,
            token_count=20,
            adapter_identifier="WikipediaPilotAdapter",
            pipeline_version="V8.8",
            acquisition_record_id="run_1",
        )
        with pytest.raises(ProvenanceVerificationError) as exc:
            auditor.verify_entry(entry_unknown)
        assert "UNKNOWN provenance" in str(exc.value)

    def test_historical_v8_7_audit_verdict(self, auditor):
        """Historical V8.7 pilot is truthfully audited as PILOT_NOT_REALLY_REMOTE."""
        hist = auditor.audit_v8_7_historical_pilot()
        assert hist["historical_verdict"] == "PILOT_NOT_REALLY_REMOTE"
        assert hist["provenance_classification"] == PilotProvenanceClass.SYNTHETIC_TEST_DATA.value
        assert hist["software_pipeline_status"] == "SOFTWARE_PIPELINE_VERIFIED"
        assert hist["remote_acquisition_status"] == "REMOTE_SOURCE_ACQUISITION_NOT_YET_VERIFIED"
        assert len(hist["records"]) == 5
        for r in hist["records"]:
            assert r["provenance_class"] == PilotProvenanceClass.SYNTHETIC_TEST_DATA.value
            assert r["is_synthetic"] is True
            assert r["is_network_retrieved"] is False
