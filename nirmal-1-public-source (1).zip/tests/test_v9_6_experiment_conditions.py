import pytest
from scripts.v9_6_controlled_scaling import ScalingExperiment

def test_equal_condition_token_budgets():
    exp = ScalingExperiment()
    assert "BUDGET_1" in exp.budgets
    
    b1 = exp.budgets["BUDGET_1"]
    assert b1["steps"] == 2
    assert b1["tokens"] == 100

def test_equal_conditions_checked():
    # If a run executes, condition steps must be identical across data mixtures
    exp = ScalingExperiment()
    res_base = exp.mock_eval_run("SCALE_0", "BUDGET_1", "BASELINE", 1)
    res_bal = exp.mock_eval_run("SCALE_0", "BUDGET_1", "CAPABILITY_BALANCED", 1)
    assert len(res_base) == len(res_bal)
