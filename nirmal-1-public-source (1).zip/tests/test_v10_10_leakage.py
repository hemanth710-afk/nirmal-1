"""V10.10-SPEC-AMENDMENT-01: Leakage, collision, manifest, and locked-test guard tests."""

import json
from pathlib import Path

import pytest

from training.evaluation.v10_10_binding_harness import (
    ANS_TOKEN,
    DEVELOPMENT_SEEDS,
    BindingBenchmarkGenerator,
    LockedTestAccessGuard,
    audit_cross_split,
    audit_split,
    validate_episode,
    write_benchmark_file,
)


def test_answer_isolation_and_no_target_in_prompt():
    gen = BindingBenchmarkGenerator()
    sets = gen.generate_split("B2", "development", DEVELOPMENT_SEEDS[0], 50)
    for cs in sets:
        for ep in cs.episodes.values():
            assert ep.input_ids[-1] == ANS_TOKEN
            assert ep.answer_index == len(ep.input_ids) - 1
            # Check prompt before ANS does not contain the target value
            prompt_data_tokens = ep.input_ids[ep.query_index:ep.answer_index]
            assert ep.target[0] not in prompt_data_tokens


def test_cross_split_zero_collisions():
    gen = BindingBenchmarkGenerator()
    train = gen.generate_split("B2", "train", DEVELOPMENT_SEEDS[0], 50, purpose="development")
    dev = gen.generate_split("B2", "development", DEVELOPMENT_SEEDS[0], 50, purpose="development")
    audit = audit_cross_split({"train": train, "development": dev})
    assert audit["valid"]
    assert len(audit["collisions"]) == 0


def test_deliberate_leakage_negative_fixture_fails_closed():
    gen = BindingBenchmarkGenerator()
    ep = gen.generate_control_set("B2", "development", DEVELOPMENT_SEEDS[0], 0)["correct"]
    # Deliberately append target token to prompt
    tampered_ids = list(ep.input_ids) + list(ep.target)
    ep.input_ids = tampered_ids
    errors = validate_episode(ep)
    assert "answer_isolation" in errors


def test_locked_test_guard_requires_passed_confirmation_and_one_time_access(tmp_path: Path):
    log_path = tmp_path / "locked_test_access.log"
    conf_path = tmp_path / "confirmation_results.json"
    guard = LockedTestAccessGuard(log_path)

    # 1. No confirmation artifact -> access denied
    assert not guard.can_access(None)
    assert not guard.can_access(conf_path)

    # 2. Confirmation artifact with failed gates -> access denied
    conf_path.write_text(json.dumps({"g2_passed": False, "g3_passed": True}), encoding="utf-8")
    assert not guard.can_access(conf_path)

    # 3. Confirmation artifact with passed gates -> access granted
    conf_path.write_text(json.dumps({"g2_passed": True, "g3_passed": True}), encoding="utf-8")
    assert guard.can_access(conf_path)

    # 4. Record access -> access logged
    guard.record_access("v10.10.1-amendment01", "locked_test_evaluation")
    assert log_path.exists()

    # 5. Subsequent access attempt -> access denied (one-time guard)
    assert not guard.can_access(conf_path)
