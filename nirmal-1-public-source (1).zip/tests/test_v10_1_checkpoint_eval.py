"""V10.1 — checkpoint evaluation consistency tests."""
import pytest
from training.acquisition.v10_1_ood_amplification import (
    TaskConfig, run_dose, Checkpoint, EVAL_CHECKPOINTS
)
from pathlib import Path
import tempfile


@pytest.fixture
def task():
    return TaskConfig("copy", 4, (10, 35), (10, 35), (60, 85), 4, 1000)


@pytest.fixture
def tmpdir():
    with tempfile.TemporaryDirectory() as d:
        yield Path(d)


def test_checkpoints_at_step_zero(task, tmpdir):
    r = run_dose("identity", 5, 42, task, tmpdir)
    steps = [c.step for c in r.checkpoints]
    assert 0 in steps


def test_checkpoints_include_final_step(task, tmpdir):
    r = run_dose("identity", 100, 42, task, tmpdir)
    steps = [c.step for c in r.checkpoints]
    assert 100 in steps


def test_checkpoint_acc_bounded(task, tmpdir):
    r = run_dose("value_relative", 50, 42, task, tmpdir)
    for c in r.checkpoints:
        assert 0.0 <= c.train_acc <= 1.0
        assert 0.0 <= c.val_acc   <= 1.0
        assert 0.0 <= c.ood_acc   <= 1.0


def test_checkpoint_ood_gap_formula(task, tmpdir):
    r = run_dose("identity", 50, 42, task, tmpdir)
    for c in r.checkpoints:
        assert abs(c.ood_gap - (c.val_acc - c.ood_acc)) < 1e-5


def test_checkpoints_monotonically_ordered(task, tmpdir):
    r = run_dose("identity", 100, 42, task, tmpdir)
    steps = [c.step for c in r.checkpoints]
    assert steps == sorted(steps)
