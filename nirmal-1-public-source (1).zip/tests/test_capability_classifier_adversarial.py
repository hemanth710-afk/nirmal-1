import pytest
from training.acquisition.capability_classifier import CapabilityClassifier
from pathlib import Path

def test_adversarial_keyword_conflict():
    classifier = CapabilityClassifier(Path("data/capability_taxonomy.json"))
    # Generic text resembling multiple capabilities
    text = "The user asked for a proof of the theorem. The assistant said def prove(): import os; return True"
    labels, conf = classifier.classify_document(text, metadata={})
    # Shouldn't be easily fooled, or if it is, it should label it multi-label
    assert "programming" in labels or "conventional dialogue" in labels or "mathematical reasoning" in labels

def test_adversarial_metadata_misleading():
    classifier = CapabilityClassifier(Path("data/capability_taxonomy.json"))
    text = "This is a recipe for cake. step 1: mix. step 2: bake."
    # Misleading URL and source
    labels, conf = classifier.classify_document(text, metadata={"url": "arxiv.org/abs/math", "source_id": "github"})
    # Should identify math from URL, github from source, procedural from text
    assert "mathematical reasoning" in labels
    assert "procedural knowledge" in labels

def test_false_high_confidence():
    classifier = CapabilityClassifier(Path("data/capability_taxonomy.json"))
    text = "theorem"
    labels, conf = classifier.classify_document(text, metadata={})
    # Too short to be HIGH confidence just because of one word
    assert conf != "HIGH"
    
def test_dialogue_with_math_vocab():
    classifier = CapabilityClassifier(Path("data/capability_taxonomy.json"))
    text = "user: What is a theorem? assistant: A theorem is a proven statement."
    labels, conf = classifier.classify_document(text, metadata={})
    assert "conventional dialogue" in labels
    # Lacks proof and equations
    assert "mathematical reasoning" not in labels
    
def test_programming_in_prose():
    classifier = CapabilityClassifier(Path("data/capability_taxonomy.json"))
    text = "I definitely think we should return to the import store."
    labels, conf = classifier.classify_document(text, metadata={})
    # Lacks 'def '
    assert "programming" not in labels

def test_single_keyword_avoidance():
    classifier = CapabilityClassifier(Path("data/capability_taxonomy.json"))
    text = "step 1"
    labels, conf = classifier.classify_document(text, metadata={})
    # Lacks 'step 2'
    assert "procedural knowledge" not in labels
