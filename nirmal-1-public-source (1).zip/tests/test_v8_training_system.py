"""
Unit Tests for Nirmal-1 V8 Final Architecture & Large-Scale Training Infrastructure.
Tests:
- Final 45-50 GB artifact size boundary enforcement (raises ArtifactSizeViolationError)
- Precision byte accounting (BF16, FP16, INT8, INT4)
- Checkpoint atomic saving, state verification, and interruption recovery
- Mixed precision manager and gradient scaler
- Optimizer parameter grouping (decay vs no-decay) and gradient clipping
- Cosine annealing scheduler with linear warmup
- Distributed topology and communication volume estimation
- Selective gradient checkpointing memory reduction
"""

import math
from pathlib import Path
import shutil
import tempfile
import pytest
import torch
import torch.nn as nn

from training.final_size_calculator import (
    calculate_architecture_breakdown,
    calculate_training_memory_budget,
    calculate_first_principles_activations,
    calculate_storage_breakdown,
    calculate_multi_gpu_sharding_table,
    ArtifactSizeViolationError,
)
from training.distributed import (
    DistributedTopologyManager,
    ParallelismConfig,
    PlatformDistributedBackend,
    PlatformBackendError,
    FSDPConfig,
    NirmalFSDPManager,
)
from training.mixed_precision import MixedPrecisionManager
from training.gradient_checkpointing import GradientCheckpointingManager
from training.optimizer_config import create_optimizer, clip_gradients, OptimizerConfig
from training.scheduler import CosineWarmupScheduler
from training.checkpointing import AtomicCheckpointManager


class SimpleTestModel(nn.Module):
    def __init__(self):
        super().__init__()
        self.fc1 = nn.Linear(32, 64, bias=True)
        self.norm = nn.LayerNorm(64)
        self.fc2 = nn.Linear(64, 10, bias=False)

    def forward(self, x):
        return self.fc2(self.norm(torch.relu(self.fc1(x))))


class TestV8ArchitectureSizing:
    def test_candidate_c_satisfies_45_to_50_gb_constraint(self):
        cand_c = calculate_architecture_breakdown(
            name="Candidate C (Hybrid)",
            architecture_type="hybrid",
            hidden_size=4096,
            num_layers=12,
            num_attention_heads=32,
            num_kv_heads=8,
            head_dim=128,
            intermediate_size=10496,
            num_experts=16,
            num_experts_per_tok=2,
            full_attention_interval=4,
            vocab_size=32000,
            context_length=8192,
            precision="BF16",
            validate_size_constraint=True,
        )
        assert 45.0 <= cand_c.artifact_size_gb <= 50.0
        assert 47.0 <= cand_c.artifact_size_gb <= 49.5
        assert cand_c.active_parameters < cand_c.total_parameters

    def test_candidate_c_exact_pytorch_meta_model_consistency(self):
        """Regression test proving:
        - Calculator total == actual PyTorch meta-model parameter count
        - Calculator active == frozen config active parameter count
        - Zero discrepancy
        """
        import json
        from pathlib import Path
        from nirmal.configuration_nirmal import NirmalConfig
        from nirmal.model import NirmalForCausalLM

        # 1. Run calculator
        cand_c = calculate_architecture_breakdown(
            name="Candidate C (Hybrid)",
            architecture_type="hybrid",
            hidden_size=4096,
            num_layers=12,
            num_attention_heads=32,
            num_kv_heads=8,
            head_dim=128,
            intermediate_size=10496,
            num_experts=16,
            num_experts_per_tok=2,
            full_attention_interval=4,
            vocab_size=32000,
            context_length=8192,
            precision="BF16",
            validate_size_constraint=True,
        )

        # 2. Instantiate actual PyTorch model on meta device
        cfg = NirmalConfig(
            vocab_size=32000,
            hidden_size=4096,
            num_hidden_layers=12,
            num_attention_heads=32,
            num_key_value_heads=8,
            head_dim=128,
            intermediate_size=10496,
            num_experts=16,
            num_experts_per_tok=2,
            full_attention_interval=4,
            context_length=8192,
            tie_word_embeddings=False,
            use_bias=False,
        )
        with torch.device("meta"):
            meta_model = NirmalForCausalLM(cfg)

        meta_total = sum(p.numel() for p in meta_model.parameters())

        # 3. Read frozen pretrain configuration
        config_path = Path("data/NIRMAL-1-PRETRAIN-CONFIG-V1.json")
        config_data = json.loads(config_path.read_text(encoding="utf-8"))
        frozen_total = config_data["model_architecture"]["total_parameters"]
        frozen_active = config_data["model_architecture"]["active_parameters_per_token"]

        # 4. Strict equivalence assertions
        assert cand_c.total_parameters == meta_total, (
            f"Discrepancy between calculator ({cand_c.total_parameters}) "
            f"and PyTorch meta-model ({meta_total})"
        )
        assert cand_c.total_parameters == frozen_total, (
            f"Discrepancy between calculator ({cand_c.total_parameters}) "
            f"and frozen config ({frozen_total})"
        )
        assert cand_c.active_parameters == frozen_active, (
            f"Discrepancy between calculator active ({cand_c.active_parameters}) "
            f"and frozen active ({frozen_active})"
        )

        # Zero discrepancy checks
        assert (cand_c.total_parameters - meta_total) == 0
        assert (cand_c.total_parameters - frozen_total) == 0
        assert (cand_c.active_parameters - frozen_active) == 0

        # Exact target constants
        assert cand_c.total_parameters == 25908188576
        assert cand_c.active_parameters == 4240414112

    def test_first_principles_activation_accounting(self):
        """Verifies activation memory scaling across context lengths (8K, 4K, 2K)
        and validates that selective activation checkpointing saves >75% memory.
        """
        # S=8192
        act_8k = calculate_first_principles_activations(seq_len=8192)
        assert act_8k.uncheckpointed_gib > 100.0  # Captures DeltaNet recurrent history + GQA matrices
        assert act_8k.checkpointed_gib < 15.0
        assert act_8k.reduction_pct > 80.0
        assert act_8k.recurrent_history_gib > 70.0  # 9 DeltaNet layers x 8.0 GiB

        # S=4096
        act_4k = calculate_first_principles_activations(seq_len=4096)
        assert act_4k.uncheckpointed_gib < act_8k.uncheckpointed_gib
        assert act_4k.checkpointed_gib < act_8k.checkpointed_gib

        # S=2048
        act_2k = calculate_first_principles_activations(seq_len=2048)
        assert act_2k.uncheckpointed_gib < act_4k.uncheckpointed_gib
        assert act_2k.checkpointed_gib < act_4k.checkpointed_gib

    def test_storage_model_binary_vs_decimal_accounting(self):
        """Verifies exact storage accounting and strict separation of binary GiB/TiB and decimal GB/TB."""
        storage = calculate_storage_breakdown(total_parameters=25908188576)

        # 25.91B BF16 weights
        assert storage.weights_bf16_gib == 48.26
        assert storage.weights_bf16_gb == 51.82

        # FP32 weights
        assert storage.weights_fp32_gib == 96.52
        assert storage.weights_fp32_gb == 103.63

        # Single full checkpoint (BF16 weights + FP32 AdamW)
        assert storage.single_full_checkpoint_gib == 337.80
        assert storage.single_full_checkpoint_gb == 362.71

        # 200B Token dataset
        assert storage.dataset_200b_tokens_gib == 372.53
        assert storage.dataset_200b_tokens_gb == 400.00

        # Checkpoint retention (6x full checkpoints)
        assert storage.retained_checkpoints_6x_tib > 1.95
        assert storage.retained_checkpoints_6x_tb > 2.15

    def test_multi_gpu_sharding_feasibility(self):
        """Verifies multi-GPU sharding analysis and confirms that 8x 80GB fits while 8x 40GB/24GB do not."""
        table = calculate_multi_gpu_sharding_table(total_parameters=25908188576)
        row_map = {r["gpu_count"]: r for r in table}

        # 8 GPUs
        row_8 = row_map[8]
        assert row_8["zero3_static_per_gpu_gib"] == 48.26
        assert row_8["fits_in_80gb"] is True
        assert row_8["fits_in_40gb"] is False
        assert row_8["fits_in_24gb"] is False

        # 16 GPUs
        row_16 = row_map[16]
        assert row_16["zero3_static_per_gpu_gib"] == 24.13
        assert row_16["fits_in_80gb"] is True
        assert row_16["fits_in_40gb"] is False

        # 32 GPUs
        row_32 = row_map[32]
        assert row_32["fits_in_40gb"] is True
        assert row_32["fits_in_24gb"] is False

        # 64 GPUs: Even at 64 GPUs (static state = 6.03 GiB), dynamic working memory
        # (activations 11.08 GiB + buffers 14.0 GiB = 25.08 GiB) exceeds 24 GB VRAM!
        row_64 = row_map[64]
        assert row_64["fits_in_24gb"] is False
        assert row_64["fits_in_40gb"] is True
        assert row_64["fits_in_80gb"] is True

    def test_size_violation_raises_error(self):
        # Under 45 GB
        with pytest.raises(ArtifactSizeViolationError):
            calculate_architecture_breakdown(
                name="Too Small",
                architecture_type="hybrid",
                hidden_size=1024,
                num_layers=4,
                num_attention_heads=8,
                num_kv_heads=2,
                head_dim=64,
                validate_size_constraint=True,
            )

        # Over 50 GB
        with pytest.raises(ArtifactSizeViolationError):
            calculate_architecture_breakdown(
                name="Too Big",
                architecture_type="dense",
                hidden_size=8192,
                num_layers=80,
                num_attention_heads=64,
                num_kv_heads=8,
                head_dim=128,
                validate_size_constraint=True,
            )

    def test_precision_accounting(self):
        bf16_bd = calculate_architecture_breakdown(
            name="BF16", architecture_type="dense", hidden_size=2048, num_layers=8,
            num_attention_heads=16, num_kv_heads=4, head_dim=128, precision="BF16",
            validate_size_constraint=False,
        )
        int8_bd = calculate_architecture_breakdown(
            name="INT8", architecture_type="dense", hidden_size=2048, num_layers=8,
            num_attention_heads=16, num_kv_heads=4, head_dim=128, precision="INT8",
            validate_size_constraint=False,
        )
        int4_bd = calculate_architecture_breakdown(
            name="INT4", architecture_type="dense", hidden_size=2048, num_layers=8,
            num_attention_heads=16, num_kv_heads=4, head_dim=128, precision="INT4",
            validate_size_constraint=False,
        )

        assert math.isclose(int8_bd.raw_weight_bytes * 2, bf16_bd.raw_weight_bytes, rel_tol=0.01)
        assert math.isclose(int4_bd.raw_weight_bytes * 4, bf16_bd.raw_weight_bytes, rel_tol=0.01)


class TestV8TrainingComponents:
    def test_optimizer_parameter_grouping(self):
        model = SimpleTestModel()
        opt = create_optimizer(model, OptimizerConfig(weight_decay=0.05))

        # Check group 0 has decay, group 1 has 0 decay
        assert opt.param_groups[0]["weight_decay"] == 0.05
        assert opt.param_groups[1]["weight_decay"] == 0.0

        # Norm weight should be in group 1 (no decay)
        norm_param_ids = {id(p) for p in model.norm.parameters()}
        group1_param_ids = {id(p) for p in opt.param_groups[1]["params"]}
        assert norm_param_ids.issubset(group1_param_ids)

    def test_cosine_warmup_scheduler(self):
        model = SimpleTestModel()
        opt = torch.optim.SGD(model.parameters(), lr=1.0)
        sched = CosineWarmupScheduler(opt, warmup_steps=10, total_steps=100, min_lr_ratio=0.1)

        # Step 0: at min_lr_ratio
        assert math.isclose(sched.get_current_lr(), 0.1, rel_tol=0.01)

        # Step 10: at peak LR (1.0)
        for _ in range(10):
            sched.step()
        assert math.isclose(sched.get_current_lr(), 1.0, rel_tol=0.01)

        # Step 100: decayed to min_lr_ratio (0.1)
        for _ in range(90):
            sched.step()
        assert math.isclose(sched.get_current_lr(), 0.1, rel_tol=0.01)

    def test_mixed_precision_manager(self):
        mp = MixedPrecisionManager(precision="fp32", device_type="cpu")
        model = SimpleTestModel()
        x = torch.randn(4, 32)
        target = torch.randint(0, 10, (4,))

        with mp.autocast():
            out = model(x)
            loss = torch.nn.functional.cross_entropy(out, target)

        mp.backward(loss)
        opt = torch.optim.SGD(model.parameters(), lr=0.01)
        success = mp.step(opt, max_grad_norm=1.0)
        assert success is True

    def test_gradient_checkpointing_reduction(self):
        savings = GradientCheckpointingManager.estimate_activation_savings(
            batch_size=1, seq_len=8192, hidden_size=4096, num_layers=12, precision_bytes=2.0
        )
        assert savings["memory_reduction_pct"] > 60.0
        assert savings["checkpointed_activations_gb"] < savings["uncheckpointed_activations_gb"]

    def test_distributed_communication_calculation(self):
        mgr = DistributedTopologyManager(ParallelismConfig(world_size=8))
        comm = mgr.calculate_communication_volume(
            active_params=4_000_000_000, hidden_size=4096, num_tokens_per_batch=8192, num_layers=12
        )
        assert comm["world_size"] == 8
        assert comm["fsdp_total_comm_mb_per_step"] > 0
        assert comm["moe_alltoall_comm_mb_per_step"] > 0


class TestV8CheckpointRecovery:
    def test_atomic_checkpoint_save_and_resume(self):
        tmp_dir = Path(tempfile.mkdtemp(prefix="test_atomic_ckpt_"))
        try:
            mgr = AtomicCheckpointManager(tmp_dir)
            model = SimpleTestModel()
            opt = torch.optim.Adam(model.parameters(), lr=0.01)

            # Save initial state at step 42
            saved_dir = mgr.save_checkpoint(
                step=42,
                model=model,
                optimizer=opt,
                metadata={"step": 42, "val_loss": 1.234},
            )
            assert saved_dir.exists()
            assert (saved_dir / "model.pt").exists()
            assert (saved_dir / "metadata.json").exists()

            # Mutate model weights
            with torch.no_grad():
                for p in model.parameters():
                    p.fill_(999.0)

            # Reload into separate model
            resumed_model = SimpleTestModel()
            meta = mgr.load_checkpoint(saved_dir, resumed_model)
            assert meta["step"] == 42
            assert meta["val_loss"] == 1.234

            # Verify parameters match
            for p1, p2 in zip(resumed_model.parameters(), SimpleTestModel().parameters()):
                assert not torch.allclose(p1, torch.tensor(999.0))
        finally:
            shutil.rmtree(tmp_dir, ignore_errors=True)


class TestV8FSDPDistributed:
    def test_fsdp_config_creation_and_defaults(self):
        cfg = FSDPConfig()
        assert cfg.sharding_strategy == "FULL_SHARD"
        assert cfg.mixed_precision == "bf16"
        assert cfg.activation_checkpointing is True
        assert cfg.cpu_offload is False

        # Enums
        from torch.distributed.fsdp import ShardingStrategy, BackwardPrefetch
        assert cfg.get_sharding_strategy() == ShardingStrategy.FULL_SHARD
        assert cfg.get_backward_prefetch() == BackwardPrefetch.BACKWARD_PRE
        assert cfg.get_mixed_precision() is not None

        # Custom options
        cfg2 = FSDPConfig(sharding_strategy="NO_SHARD", mixed_precision="fp16", backward_prefetch="NONE")
        assert cfg2.get_sharding_strategy() == ShardingStrategy.NO_SHARD
        assert cfg2.get_backward_prefetch() is None

        # Serialization
        d = cfg.to_dict()
        assert d["sharding_strategy"] == "FULL_SHARD"

    def test_platform_distributed_backend_detection(self):
        info = PlatformDistributedBackend.get_platform_info()
        assert "platform" in info
        assert "cuda_available" in info
        assert "nccl_available" in info
        assert "gloo_available" in info

        rec_backend = PlatformDistributedBackend.get_recommended_backend()
        assert rec_backend in ("gloo", "nccl")

        if info["is_windows"]:
            assert PlatformDistributedBackend.supports_cuda_fsdp_backward() is False
            is_safe, msg = PlatformDistributedBackend.check_backward_safety(torch.device("cuda:0"))
            assert is_safe is False
            assert "requires Linux with NCCL" in msg

    def test_fsdp_manager_initialization_and_device(self):
        mgr = NirmalFSDPManager()
        device = mgr.assign_device()
        assert isinstance(device, torch.device)
        if torch.cuda.is_available():
            assert device.type == "cuda"
        else:
            assert device.type == "cpu"

    def test_fsdp_model_wrapping_forward_and_checkpoint(self):
        from nirmal.configuration_nirmal import NirmalConfig
        from nirmal.model import NirmalForCausalLM, NirmalDecoderLayer

        model_cfg = NirmalConfig(
            vocab_size=128,
            hidden_size=32,
            num_hidden_layers=2,
            num_attention_heads=2,
            num_key_value_heads=1,
            head_dim=16,
            intermediate_size=64,
            num_experts=2,
            num_experts_per_tok=1,
            full_attention_interval=2,
            context_length=64,
            tie_word_embeddings=False,
            use_bias=False,
        )
        fsdp_cfg = FSDPConfig(sharding_strategy="FULL_SHARD", mixed_precision="fp16", activation_checkpointing=True)
        mgr = NirmalFSDPManager(fsdp_config=fsdp_cfg)
        mgr.init_distributed()

        device = mgr.assign_device()
        raw_model = NirmalForCausalLM(model_cfg)
        if device.type == "cuda":
            raw_model = raw_model.to(device)

        fsdp_model = mgr.wrap_model(
            model=raw_model,
            auto_wrap_layer_cls=NirmalDecoderLayer,
            device_id=device,
            apply_activation_checkpointing_flag=True,
        )

        input_ids = torch.randint(0, 128, (2, 8), device=device)
        labels = torch.randint(0, 128, (2, 8), device=device)
        out = fsdp_model(input_ids=input_ids, labels=labels)
        assert out.loss is not None
        assert torch.isfinite(out.loss)
        assert out.logits.shape == (2, 8, 128)

        # Atomic checkpoint save & load
        tmp_dir = Path(tempfile.mkdtemp(prefix="test_fsdp_ckpt_"))
        try:
            saved_dir = mgr.save_checkpoint(
                model=fsdp_model,
                output_dir=tmp_dir,
                step=1,
                metadata={"test_tag": "v8_fsdp"},
            )
            assert (saved_dir / "model.pt").exists()
            assert (saved_dir / "metadata.json").exists()

            # Load into fresh non-FSDP model
            fresh = NirmalForCausalLM(model_cfg)
            meta = mgr.load_checkpoint(fresh, saved_dir)
            assert meta["step"] == 1
            assert meta.get("test_tag") == "v8_fsdp"
        finally:
            shutil.rmtree(tmp_dir, ignore_errors=True)
            mgr.destroy_distributed()

    def test_end_to_end_training_workflow(self):
        from scripts.end_to_end_training_smoke_test import run_end_to_end_training_test
        tmp_dir = Path(tempfile.mkdtemp(prefix="test_e2e_train_"))
        try:
            metrics = run_end_to_end_training_test(
                total_steps=4,
                phase1_steps=2,
                batch_size=2,
                seq_len=32,
                grad_accum_steps=2,
                checkpoint_dir=str(tmp_dir),
            )
            assert metrics["overall_status"] == "PASS"
            assert metrics["parameters_changed"] is True
            assert metrics["data_streaming_resumed_correctly"] is True
            assert metrics["resumed_training_continued"] is True
            assert metrics["nan_or_inf_occurred"] is False
            assert metrics["model_parameters"] <= 5_000_000
        finally:
            shutil.rmtree(tmp_dir, ignore_errors=True)
