"""V10.10-SPEC-AMENDMENT-01: Wilson CI, 10,000-replicate hierarchical bootstrap, and Holm families."""

import numpy as np

from training.evaluation.v10_10_binding_harness import (
    hierarchical_bootstrap_ci,
    hierarchical_bootstrap_distribution,
    holm_bonferroni,
    wilson_ci,
)


def test_wilson_ci_bounds_and_coverage():
    low, high = wilson_ci(95, 100)
    assert 0.88 < low < 0.95 < high < 0.99

    zero_low, zero_high = wilson_ci(0, 100)
    assert zero_low == 0.0
    assert zero_high > 0.0

    one_low, one_high = wilson_ci(100, 100)
    assert one_low < 1.0
    assert one_high == 1.0


def test_hierarchical_bootstrap_10000_replicates_and_percentile_ci():
    # Construct 3 seeds with positive contrast
    rng = np.random.default_rng(123)
    seed_data = {
        104729: rng.normal(loc=0.15, scale=0.05, size=200),
        130363: rng.normal(loc=0.14, scale=0.05, size=200),
        155921: rng.normal(loc=0.16, scale=0.05, size=200),
    }
    dist = hierarchical_bootstrap_distribution(seed_data, n_resamples=10_000, rng_seed=42)
    assert len(dist) == 10_000
    assert np.mean(dist) > 0.10

    lb, ub, p_val = hierarchical_bootstrap_ci(seed_data, n_resamples=10_000, rng_seed=42)
    assert lb > 0.0
    assert ub > lb
    assert p_val < 0.05


def test_separate_holm_families():
    # Specificity family: 3 contrasts
    spec_p = {"random": 0.001, "wrong": 0.02, "absent": 0.04}
    res_spec = holm_bonferroni(spec_p, alpha=0.05)
    assert len(res_spec) == 3
    assert res_spec["random"]["reject"]

    # Core family: 2 contrasts
    core_p = {"B1": 0.005, "B2": 0.01}
    res_core = holm_bonferroni(core_p, alpha=0.05)
    assert len(res_core) == 2
    assert res_core["B1"]["reject"]
    assert res_core["B2"]["reject"]

    # Serialization family: 2 contrasts
    ser_p = {"S2_S1": 0.30, "S3_S1": 0.60}
    res_ser = holm_bonferroni(ser_p, alpha=0.05)
    assert not res_ser["S2_S1"]["reject"]
    assert not res_ser["S3_S1"]["reject"]
