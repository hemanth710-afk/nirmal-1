"""V10.1 — multi-seed aggregation tests."""
import pytest
import numpy as np
from training.acquisition.v10_1_ood_amplification import (
    TaskConfig, run_dose, aggregate, SEEDS
)
from pathlib import Path
import tempfile


@pytest.fixture
def task():
    return TaskConfig("copy", 4, (10, 35), (10, 35), (60, 85), 4, 1000)


@pytest.fixture
def tmpdir():
    with tempfile.TemporaryDirectory() as d:
        yield Path(d)


def test_aggregate_mean(task, tmpdir):
    runs = [run_dose("identity", 50, s, task, tmpdir) for s in SEEDS]
    # Manually extract final OOD
    oods = [r.checkpoints[-1].ood_acc for r in runs]

    class FakeResult:
        def __init__(self, ood): self.ood_acc = ood

    fakes = [FakeResult(o) for o in oods]
    mean, std, best, worst = aggregate(fakes, "ood_acc")
    assert abs(mean - float(np.mean(oods))) < 1e-4


def test_aggregate_std(task, tmpdir):
    runs = [run_dose("identity", 50, s, task, tmpdir) for s in SEEDS]
    oods = [r.checkpoints[-1].ood_acc for r in runs]

    class FakeResult:
        def __init__(self, ood): self.ood_acc = ood

    fakes = [FakeResult(o) for o in oods]
    _, std, _, _ = aggregate(fakes, "ood_acc")
    assert abs(std - float(np.std(oods))) < 1e-4


def test_seeds_constant():
    assert len(SEEDS) == 3
    assert SEEDS == [42, 43, 44]
