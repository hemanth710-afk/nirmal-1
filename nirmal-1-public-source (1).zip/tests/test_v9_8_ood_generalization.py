import pytest
from scripts.v9_8_generalization_bridge import GeneralizationEvaluator, GeneralizationTaskGenerator

def test_ood_generalization_threshold():
    ev = GeneralizationEvaluator()
    state = ev.evaluate_model_state(train_acc=0.9, val_acc=0.9, comp_acc=0.9, ood_acc=0.85)
    assert state == "GENERALIZING"

def test_ood_rule_task_format():
    gen = GeneralizationTaskGenerator()
    d = gen.generate_task("LEVEL_4_OOD_RULE", 2, 8, 10, 40)
    # Check that a, a+2, a+4 rule holds
    assert (d[:, 1] == d[:, 0] + 2).all()

def test_ood_bounds_strictly_disjoint():
    gen = GeneralizationTaskGenerator()
    t = gen.generate_task("LEVEL_4_OOD_RULE", 100, 8, 10, 40)
    o = gen.generate_task("LEVEL_4_OOD_RULE", 100, 8, 60, 90)
    
    # Train subset bounds
    assert t.min() >= 10
    
    # OOD subset bounds 
    assert o.min() >= 60
    assert o.max() < 120 # (90-8) + (8*2) = 82 + 16 = 98 < 120

def test_generalizing_boundary():
    ev = GeneralizationEvaluator()
    state = ev.evaluate_model_state(train_acc=0.9, val_acc=0.9, comp_acc=0.9, ood_acc=0.79)
    assert state == "COMPOSING"
    
def test_generalization_requires_ood():
    ev = GeneralizationEvaluator()
    # High everything except OOD
    state = ev.evaluate_model_state(1.0, 1.0, 1.0, 0.0)
    assert state != "GENERALIZING"
