import pytest
from scripts.v9_9_ood_investigation import OodInvestigator

def test_vocab_ood_generation():
    inv = OodInvestigator()
    train, ood = inv.generate_vocab_ood_task(batch_size=2, seq_len=4)
    assert train.shape == (2, 8)
    assert ood.shape == (2, 8)

def test_vocab_ood_disjoint():
    inv = OodInvestigator()
    train, ood = inv.generate_vocab_ood_task()
    assert train.max() < 40
    assert ood.min() >= 60

def test_vocab_ood_structure():
    inv = OodInvestigator()
    train, _ = inv.generate_vocab_ood_task(batch_size=2, seq_len=4)
    assert (train[:, :4] == train[:, 4:]).all()

def test_vocab_failure_classification():
    inv = OodInvestigator()
    fail = inv.classify_failure(0.9, 0.0, "VOCAB_DISJOINT")
    assert fail == "VOCABULARY_FAILURE"

def test_vocab_failure_signal_precedence():
    inv = OodInvestigator()
    fail = inv.classify_failure(0.2, 0.0, "VOCAB_DISJOINT")
    assert fail == "TRAINING_SIGNAL_FAILURE"
