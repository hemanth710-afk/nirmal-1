"""
NIRMAL-1 V8.7: TEST SUITE FOR PILOT ACCOUNTING & CONSERVATION (PHASE 7, 10)

Verifies:
1. Exact document conservation: discovered == accepted + sum(rejected).
2. Token reconciliation: accepted_tokens == final_shard_tokens.
3. Rejection categorization tracking.
4. Conservation violation detection and fail-closed handling.
5. Safe audit metadata in rejection logs (zero sensitive document text exposed).
"""

import pytest

from training.acquisition.pilot_accounting import (
    PilotAccountingTracker,
    AccountingConservationError,
)


class TestPilotAccounting:
    """Test suite for pilot accounting conservation."""

    def test_exact_conservation_in_normal_run(self):
        tracker = PilotAccountingTracker(source_id="test_src", pilot_run_id="run_1")

        # 3 discovered docs
        tracker.record_discovery(raw_bytes=100, estimated_tokens=25)
        tracker.record_acceptance(norm_tokens=25, shard_tokens=25)

        tracker.record_discovery(raw_bytes=80, estimated_tokens=20)
        tracker.record_rejection(
            doc_id="doc_rej_1",
            stage="quality",
            reason="short_document",
            char_length=80,
            estimated_tokens=20,
            safe_meta={"title": "Short Doc"},
        )

        tracker.record_discovery(raw_bytes=120, estimated_tokens=30)
        tracker.record_rejection(
            doc_id="doc_rej_2",
            stage="security",
            reason="malicious_ast",
            char_length=120,
            estimated_tokens=30,
            safe_meta={"title": "Unsafe Doc"},
        )

        is_conserved, msg = tracker.verify_conservation()
        assert is_conserved is True
        assert tracker.documents_discovered == 3
        assert tracker.documents_accepted == 1
        assert tracker.total_rejected == 2
        assert tracker.rejected_quality == 1
        assert tracker.rejected_security == 1

        d = tracker.to_dict()
        assert d["conservation_status"] == "CONSERVED"

    def test_conservation_violation_when_counts_do_not_balance(self):
        tracker = PilotAccountingTracker(source_id="test_src", pilot_run_id="run_2")

        # 2 discovered, but only 1 accepted and 0 rejected (1 doc leaked/vanished!)
        tracker.record_discovery(raw_bytes=100, estimated_tokens=25)
        tracker.record_acceptance(norm_tokens=25, shard_tokens=25)

        tracker.record_discovery(raw_bytes=100, estimated_tokens=25)
        # Missing record_rejection or record_acceptance!

        is_conserved, msg = tracker.verify_conservation()
        assert is_conserved is False
        assert "conservation violation" in msg

    def test_token_mismatch_detected(self):
        tracker = PilotAccountingTracker(source_id="test_src", pilot_run_id="run_3")

        tracker.record_discovery(raw_bytes=100, estimated_tokens=25)
        # Accepted 25 norm_tokens, but shard only packed 10 tokens!
        tracker.record_acceptance(norm_tokens=25, shard_tokens=10)

        is_conserved, msg = tracker.verify_conservation()
        assert is_conserved is False
        assert "Token accounting violation" in msg

    def test_safe_rejection_audit_does_not_contain_full_text(self):
        tracker = PilotAccountingTracker(source_id="test_src", pilot_run_id="run_4")

        tracker.record_discovery(raw_bytes=100, estimated_tokens=25)
        tracker.record_rejection(
            doc_id="doc_secret",
            stage="security",
            reason="credential_secret_detected",
            char_length=100,
            estimated_tokens=25,
            safe_meta={"token_type": "AWS_KEY", "action": "REJECT"},
        )

        audit_entry = tracker.rejection_audit_trail[0]
        audit_dict = audit_entry.to_dict()
        assert "text" not in audit_dict
        assert "full_text" not in audit_dict
        assert audit_dict["reason"] == "credential_secret_detected"
