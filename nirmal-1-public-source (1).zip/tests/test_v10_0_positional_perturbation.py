"""Tests for positional perturbation transforms — V10.0."""
import pytest
import torch
from training.acquisition.v10_0_intervention_engine import RepresentationTransform


def test_reversed_flips_sequence():
    x = torch.tensor([[1, 2, 3, 4]])
    r = RepresentationTransform.reversed_positions(x)
    assert r[0, 0].item() == 4
    assert r[0, 3].item() == 1


def test_reversed_preserves_shape():
    x = torch.randint(0, 10, (3, 8))
    assert RepresentationTransform.reversed_positions(x).shape == (3, 8)


def test_reversed_involution():
    x = torch.randint(0, 10, (2, 6))
    assert (RepresentationTransform.reversed_positions(
        RepresentationTransform.reversed_positions(x)) == x).all()


def test_value_relative_shift():
    x = torch.tensor([[20, 30]])
    r = RepresentationTransform.value_relative(x, lo=10, hi=50)
    assert r[0, 0].item() == 10  # 20 - 10
    assert r[0, 1].item() == 20  # 30 - 10


def test_modular_normalize():
    x = torch.tensor([[105]])
    r = RepresentationTransform.modular_normalize(x, vocab_size=100)
    assert r[0, 0].item() == 5
