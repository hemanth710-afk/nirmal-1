"""
Unit and Integration Test Suite for NIRMAL-1 V8.3 Final Pre-Training Launch Gate.

Validates:
1. Physical shard inspection & token counting logic.
2. Zero leakage & benchmark holdout isolation.
3. Domain mixture measurement.
4. Tokenizer freeze integrity.
5. Candidate C parameters and artifact sizing (45-50 GB).
6. Training memory modeling & hardware classification.
7. Streaming data loader stress testing & bitwise resumption.
8. Pilot run stability & abort circuit breakers.
9. Immutable configuration file integrity.
10. Final GO / NO-GO launch matrix decision rules.
"""

import json
from pathlib import Path
import pytest
import torch

REPO_ROOT = Path(__file__).resolve().parent.parent

from training.v8_2_data_engine import (
    DeduplicationEngine,
    ByteLevelBPETokenizer,
)
from training.v8_3_gate_engine import (
    audit_physical_production_shards,
    generate_sample_production_corpus,
    reaudit_leakage_and_contamination,
    audit_measured_domain_mixture,
    audit_architecture_parameters_and_artifact,
    audit_training_memory_and_hardware,
    stress_test_streaming_data_loader,
    execute_pilot_run_with_abort_breakers,
    audit_pretrain_capability_baseline,
    evaluate_training_budget_options,
    evaluate_final_go_nogo_matrix,
)


def test_physical_shard_audit_and_token_count():
    manifest_path = REPO_ROOT / "data" / "NIRMAL-DATA-V8.2.manifest.json"
    shards_dir = REPO_ROOT / "data" / "shards"
    
    audit = audit_physical_production_shards(manifest_path, shards_dir, required_target_tokens=200_000_000_000)
    assert audit["total_physical_train_tokens"] > 0
    assert audit["total_verified_staged_tokens"] == 233997
    assert audit["token_deficit"] == 199999766003
    assert audit["volume_status"] == "NOT READY"
    assert audit["all_shards_verified"] is True
    assert audit["parity_with_manifest_train_tokens"] is True


def test_zero_leakage_and_holdout_isolation():
    clean_train, clean_val, clean_test = generate_sample_production_corpus(num_docs_per_domain=10, seed=42)
    dedup = DeduplicationEngine(jaccard_threshold=0.85, num_perm=64)
    unique_train = []
    for d in clean_train:
        is_uniq, _ = dedup.process_document(d.id, d.clean_text)
        if is_uniq:
            unique_train.append(d)

    tokenizer = ByteLevelBPETokenizer()
    for d in unique_train:
        d.token_ids = tokenizer.encode(d.clean_text)

    audit = reaudit_leakage_and_contamination(unique_train, clean_val, clean_test, tokenizer)
    assert audit["train_val_overlap"] == 0
    assert audit["train_test_overlap"] == 0
    assert audit["val_test_overlap"] == 0
    assert audit["post_tokenization_leakage"] == 0
    assert audit["final_eval_contamination_hits"] == 0
    assert audit["zero_leakage_passed"] is True
    assert audit["status"] == "PASS"


def test_domain_mixture_measurement():
    clean_train, _, _ = generate_sample_production_corpus(num_docs_per_domain=5, seed=42)
    tokenizer = ByteLevelBPETokenizer()

    mixture_audit = audit_measured_domain_mixture(clean_train, tokenizer)
    assert mixture_audit["total_measured_tokens"] > 0
    assert "language" in mixture_audit["macro_distribution"]
    assert "code" in mixture_audit["macro_distribution"]
    assert "math" in mixture_audit["macro_distribution"]
    assert mixture_audit["approved_mixture"] == "Mixture C (Reasoning & Code-Heavy)"


def test_candidate_c_parameters_and_artifact_size():
    arch_audit = audit_architecture_parameters_and_artifact()
    assert "25.91B" in arch_audit["total_parameters_formatted"]
    assert "4.24B" in arch_audit["active_parameters_formatted"]
    assert arch_audit["active_parameter_ratio_pct"] == pytest.approx(16.37, abs=0.1)
    assert 45.0 <= arch_audit["artifact_size_gb"] <= 50.0
    assert arch_audit["is_valid_artifact_size"] is True
    assert arch_audit["artifact_status"] == "PASS"


def test_training_memory_and_hardware_classification():
    mem_audit = audit_training_memory_and_hardware()
    assert mem_audit["distributed_sharded_footprint_gb"]["per_gpu_8x_h100"] < 80.0
    assert mem_audit["distributed_sharded_footprint_gb"]["headroom_8x_h100_80gb"] > 10.0
    
    classif = mem_audit["hardware_classification"]["classification_breakdown"]
    assert "PHYSICALLY MEASURED" in classif["parameter_counts"]
    assert "THEORETICAL" in classif["memory_footprint_per_gpu"]
    assert "SIMULATED" in classif["multi_worker_gradient_sync"]
    assert "THEORETICAL" in classif["throughput_tokens_per_sec"]


def test_streaming_data_loader_stress_and_resumption():
    shards_dir = REPO_ROOT / "data" / "shards"
    stress_audit = stress_test_streaming_data_loader(shards_dir, batch_sizes=[1, 2], context_length=64)
    assert stress_audit["status"] == "PASS"
    assert stress_audit["interruption_and_resumption"]["bitwise_match_pct"] == 100.0


def test_pilot_run_execution_and_circuit_breakers():
    # 1. Normal run should pass
    normal_pilot = execute_pilot_run_with_abort_breakers(steps=10)
    assert normal_pilot["aborted"] is False
    assert normal_pilot["loss_decreased"] is True
    assert normal_pilot["pilot_passed"] is True
    assert normal_pilot["average_routing_entropy"] > 0.5

    # 2. Simulated NaN should immediately trip the circuit breaker
    nan_pilot = execute_pilot_run_with_abort_breakers(steps=10, simulate_nan_step=3)
    assert nan_pilot["aborted"] is True
    assert nan_pilot["abort_step"] == 3
    assert "NaN or Inf" in nan_pilot["abort_reason"]
    assert nan_pilot["pilot_passed"] is False

    # 3. Simulated loss divergence should immediately trip circuit breaker
    spike_pilot = execute_pilot_run_with_abort_breakers(steps=10, simulate_loss_spike_step=4)
    assert spike_pilot["aborted"] is True
    assert spike_pilot["abort_step"] == 4
    assert "Loss divergence" in spike_pilot["abort_reason"]
    assert spike_pilot["pilot_passed"] is False


def test_pretrain_config_file_integrity():
    config_path = REPO_ROOT / "data" / "NIRMAL-1-PRETRAIN-CONFIG-V1.json"
    assert config_path.exists()
    
    with open(config_path, "r", encoding="utf-8") as f:
        config = json.load(f)
    
    assert config["config_name"] == "NIRMAL-1-PRETRAIN-CONFIG-V1"
    assert config["status"] == "FROZEN_IMMUTABLE"
    assert config["model_architecture"]["total_parameters"] == 25908188576
    assert config["dataset"]["target_tokens"] == 200000000000
    assert config["optimizer"]["type"] == "AdamW"
    assert config["lr_schedule"]["type"] == "CosineAnnealingWithWarmup"


def test_final_go_nogo_matrix_logic():
    manifest_path = REPO_ROOT / "data" / "NIRMAL-DATA-V8.2.manifest.json"
    shards_dir = REPO_ROOT / "data" / "shards"

    shard_audit = audit_physical_production_shards(manifest_path, shards_dir)
    leakage_audit = {"zero_leakage_passed": True, "final_eval_contamination_hits": 0}
    tokenizer_audit = {"tokenizer_frozen_verified": True, "checksum": "valid"}
    arch_audit = audit_architecture_parameters_and_artifact()
    mem_audit = audit_training_memory_and_hardware()
    dataloader_audit = {"stress_test_passed": True, "interruption_and_resumption": {"bitwise_match_pct": 100.0}}
    pilot_audit = {"pilot_passed": True, "initial_loss": 5.0, "final_loss": 3.0, "aborted": False}
    budget_audit = {"selected_budget": "200B_Tokens"}

    matrix = evaluate_final_go_nogo_matrix(
        shard_audit=shard_audit,
        leakage_audit=leakage_audit,
        tokenizer_audit=tokenizer_audit,
        arch_audit=arch_audit,
        memory_audit=mem_audit,
        dataloader_audit=dataloader_audit,
        pilot_audit=pilot_audit,
        budget_audit=budget_audit,
    )

    assert matrix["all_hard_rules_passed"] is False
    assert "NO-GO" in matrix["final_verdict"]
    assert "DATASET VOLUME DEFICIT" in matrix["final_verdict"]
    assert "PHYSICAL H100 HARDWARE UNAVAILABLE" in matrix["final_verdict"]
