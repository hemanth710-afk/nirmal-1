import pytest
from scripts.v9_9_ood_investigation import OodInvestigator

def test_context_ablation_generation():
    inv = OodInvestigator()
    d16 = inv.generate_context_ablation(16)
    assert d16.shape[1] == 16
    
    d32 = inv.generate_context_ablation(32)
    assert d32.shape[1] == 32

def test_context_ablation_structure():
    inv = OodInvestigator()
    d = inv.generate_context_ablation(8)
    assert (d[:, :4] == d[:, 4:]).all()

def test_context_failure_classification():
    inv = OodInvestigator()
    fail = inv.classify_failure(0.9, 0.0, "CONTEXT_CHANGED")
    assert fail == "CONTEXT_FAILURE"

def test_context_success():
    inv = OodInvestigator()
    fail = inv.classify_failure(0.95, 0.95, "CONTEXT_CHANGED")
    assert fail == "SUCCESS"
