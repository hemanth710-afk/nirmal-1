"""
Unit tests for NirmalModel and NirmalForCausalLM end-to-end forward/backward passes.
"""

import torch
import pytest

from nirmal.configuration_nirmal import NirmalConfig
from nirmal.model import NirmalModel, NirmalForCausalLM


def test_model_forward_and_loss():
    """Verify forward pass, logits shape, and cross-entropy loss computation."""
    config = NirmalConfig(
        vocab_size=500,
        hidden_size=128,
        num_hidden_layers=4,
        num_attention_heads=4,
        num_key_value_heads=2,
        head_dim=32,
        num_experts=4,
        num_experts_per_tok=2,
        full_attention_interval=2,
    )
    model = NirmalForCausalLM(config)

    batch_size = 2
    seq_len = 8
    input_ids = torch.randint(0, config.vocab_size, (batch_size, seq_len))
    labels = input_ids.clone()

    outputs = model(input_ids=input_ids, labels=labels)

    assert outputs.logits.shape == (batch_size, seq_len, config.vocab_size)
    assert outputs.loss is not None
    assert outputs.loss.item() > 0.0
    assert outputs.router_loss is not None


def test_backward_gradient_propagation():
    """Verify backpropagation computes valid gradients for all components."""
    config = NirmalConfig(
        vocab_size=500,
        hidden_size=128,
        num_hidden_layers=4,
        num_attention_heads=4,
        num_key_value_heads=2,
        head_dim=32,
        num_experts=4,
        num_experts_per_tok=2,
        full_attention_interval=2,
    )
    model = NirmalForCausalLM(config)

    input_ids = torch.randint(0, config.vocab_size, (2, 8))
    labels = input_ids.clone()

    outputs = model(input_ids=input_ids, labels=labels)
    outputs.loss.backward()

    # Verify embeddings have gradients
    assert model.model.embed_tokens.weight.grad is not None

    # Verify each layer has gradients (both DeltaNet and GQA)
    for layer in model.model.layers:
        assert layer.input_layernorm.weight.grad is not None
        if layer.layer_type == "causal_attention":
            assert layer.token_mixer.q_proj.weight.grad is not None
        else:
            assert layer.token_mixer.q_proj.weight.grad is not None

    # Verify LM head has gradients
    assert model.lm_head.weight.grad is not None


def test_weight_tying():
    """Verify word embeddings and LM head share weights when tie_word_embeddings=True."""
    config = NirmalConfig(
        vocab_size=200,
        hidden_size=128,
        num_hidden_layers=2,
        num_attention_heads=2,
        head_dim=64,
        tie_word_embeddings=True,
    )
    model = NirmalForCausalLM(config)
    assert model.lm_head.weight is model.model.embed_tokens.weight


def test_hybrid_cache_seq_length():
    """Regression test for Issue 4: Hybrid cache accurately returns token count when layer 0 is DeltaNet."""
    from nirmal.model import NirmalHybridCache

    config = NirmalConfig(
        vocab_size=100,
        hidden_size=64,
        num_hidden_layers=4,
        num_attention_heads=2,
        head_dim=32,
        num_experts=2,
        num_experts_per_tok=1,
        full_attention_interval=4,  # Layer 0 is DeltaNet, Layer 3 is GQA
    )
    model = NirmalForCausalLM(config)
    cache = NirmalHybridCache()

    prompt = torch.tensor([[1, 2, 3, 4, 5]])
    model(prompt, cache=cache, use_cache=True)

    # get_seq_length() must report 5 tokens
    assert cache.get_seq_length() == 5
    assert cache.get_seq_length(0) == 5
    assert cache.get_seq_length(3) == 5


def test_model_with_2d_padding_mask():
    """Regression test for Issue 2: End-to-end model forward pass with 2D padding mask."""
    config = NirmalConfig(
        vocab_size=100,
        hidden_size=64,
        num_hidden_layers=4,
        num_attention_heads=2,
        head_dim=32,
        num_experts=2,
        num_experts_per_tok=1,
        full_attention_interval=2,
    )
    model = NirmalForCausalLM(config)

    # Batch of 2, sequence 1 has last token padded
    input_ids = torch.randint(0, 100, (2, 6))
    attention_mask = torch.tensor([[1, 1, 1, 1, 1, 1], [1, 1, 1, 1, 0, 0]])

    outputs = model(input_ids=input_ids, attention_mask=attention_mask)
    assert outputs.logits.shape == (2, 6, 100)
    assert not torch.isnan(outputs.logits).any()
