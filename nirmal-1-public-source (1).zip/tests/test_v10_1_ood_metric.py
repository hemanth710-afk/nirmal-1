"""V10.1 — OOD metric correctness tests."""
import pytest
from training.acquisition.v10_1_ood_amplification import (
    TaskConfig, run_dose, run_vocab_condition, VOCAB_CONDITIONS
)
from pathlib import Path
import tempfile


@pytest.fixture
def task():
    return TaskConfig("copy", 4, (10, 35), (10, 35), (60, 85), 4, 1000)


@pytest.fixture
def tmpdir():
    with tempfile.TemporaryDirectory() as d:
        yield Path(d)


def test_ood_acc_is_zero_at_step_zero(task, tmpdir):
    # Untrained model should have ~random OOD accuracy
    r = run_dose("identity", 0, 42, task, tmpdir)
    c0 = next(c for c in r.checkpoints if c.step == 0)
    # random chance for vocab=100, seq=4 → ~1/100 per token ≈ 0.01
    assert c0.ood_acc < 0.3  # well below learning threshold


def test_ood_acc_bounded(task, tmpdir):
    r = run_dose("value_relative", 100, 42, task, tmpdir)
    for c in r.checkpoints:
        assert 0.0 <= c.ood_acc <= 1.0


def test_ood_gap_non_negative_when_memorizing(task, tmpdir):
    # When model memorises (val ≈ train, ood << val), gap should be positive
    r = run_dose("identity", 100, 42, task, tmpdir)
    final = r.checkpoints[-1]
    # gap = val - ood; memorizing means val > ood so gap > 0
    if final.val_acc > 0.1:
        assert final.ood_gap >= -0.05  # allow tiny floating point slack


def test_same_vocab_ood_better_than_disjoint(tmpdir):
    from training.acquisition.v10_1_ood_amplification import SEEDS
    sv = run_vocab_condition("SAME_VOCAB",    VOCAB_CONDITIONS["SAME_VOCAB"],    42, tmpdir, 200)
    fd = run_vocab_condition("FULL_DISJOINT", VOCAB_CONDITIONS["FULL_DISJOINT"], 42, tmpdir, 200)
    # Same vocab should yield >= disjoint OOD accuracy (or very close)
    assert sv.ood_acc >= fd.ood_acc - 0.1  # allow tolerance
