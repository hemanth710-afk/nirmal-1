"""
NIRMAL-1 V8.6: TEST SUITE FOR LICENSE RECONCILIATION (PHASE 3 & PHASE 7)

Verifies:
1. Separation of dataset-level vs underlying record/content licenses across all 6 external sources.
2. FineWeb-Edu: ODC-By database vs Common Crawl web prose (PARTIAL_MATCH).
3. The Stack v2: Software Heritage terms vs per-file SPDX licenses (CLAIM_MISMATCH).
4. arXiv: Non-exclusive license vs paper-specific CC licenses (CLAIM_MISMATCH).
5. Dolma: ODC-By top-level vs 6 heterogeneous subcollections (CLAIM_MISMATCH).
6. RedPajama: Tooling Apache-2.0 vs Common Crawl raw text (CLAIM_MISMATCH).
7. Wikimedia: CC-BY-SA 4.0 prose vs CC0 1.0 metadata (PARTIAL_MATCH).
8. Adversarial: Dataset-level license incorrectly applied to records fails closed.
9. Adversarial: Changed official license detected.
10. Adversarial: Stale license artifact (tampered hash) detected.
"""

from pathlib import Path
import pytest

from training.acquisition.source_reconciliation import (
    IndependentSourceReconciler,
    ReconciliationResult,
    INDEPENDENT_SOURCE_OBSERVATIONS,
)
from training.acquisition.evidence import (
    SourceEvidenceManager,
    SourceEvidenceDossier,
    ApprovalStatus,
    EvidenceValidationError,
    ApprovalPolicyEvaluator,
)
from training.acquisition.official_evidence import OfficialEvidenceManager


@pytest.fixture
def reconciler():
    return IndependentSourceReconciler()


@pytest.fixture
def policy_evaluator():
    return ApprovalPolicyEvaluator()


@pytest.fixture
def official_mgr():
    return OfficialEvidenceManager()


class TestLicenseReconciliation:
    """Rigorous reconciliation of dataset-level vs document-level licensing."""

    def test_fineweb_edu_license_reconciliation(self, reconciler):
        s = reconciler.reconcile_source("fineweb_edu_permissive")
        assert s.license_result == ReconciliationResult.PARTIAL_MATCH
        lic_entry = next(e for e in s.entries if e.field == "licensing_model")
        assert "ODC-By" in lic_entry.official_observation
        assert "Common Crawl" in lic_entry.official_observation

    def test_the_stack_v2_license_reconciliation(self, reconciler):
        s = reconciler.reconcile_source("the_stack_v2_permissive")
        assert s.license_result == ReconciliationResult.CLAIM_MISMATCH
        lic_entry = next(e for e in s.entries if e.field == "licensing_model")
        assert "Software Heritage" in lic_entry.official_observation
        assert "Heterogeneous per-file" in lic_entry.official_observation

    def test_arxiv_license_reconciliation(self, reconciler):
        s = reconciler.reconcile_source("arxiv_open_access_papers")
        assert s.license_result == ReconciliationResult.CLAIM_MISMATCH
        lic_entry = next(e for e in s.entries if e.field == "licensing_model")
        assert "non-exclusive" in lic_entry.official_observation.lower()
        assert "per-paper" in lic_entry.official_observation.lower()

    def test_dolma_license_reconciliation(self, reconciler):
        s = reconciler.reconcile_source("dolma_v1_7_permissive")
        assert s.license_result == ReconciliationResult.CLAIM_MISMATCH
        lic_entry = next(e for e in s.entries if e.field == "licensing_model")
        assert "ODC-By" in lic_entry.official_observation
        assert "6 subcollections" in lic_entry.official_observation

    def test_redpajama_license_reconciliation(self, reconciler):
        s = reconciler.reconcile_source("redpajama_v2_permissive")
        assert s.license_result == ReconciliationResult.CLAIM_MISMATCH
        lic_entry = next(e for e in s.entries if e.field == "licensing_model")
        assert "tooling" in lic_entry.official_observation.lower()
        assert "Common Crawl" in lic_entry.official_observation

    def test_wikipedia_license_reconciliation(self, reconciler):
        s = reconciler.reconcile_source("wikipedia_open_corpus")
        assert s.license_result == ReconciliationResult.PARTIAL_MATCH
        lic_entry = next(e for e in s.entries if e.field == "licensing_model")
        assert "CC-BY-SA 4.0" in lic_entry.official_observation
        assert "CC0" in lic_entry.official_observation

    def test_adversarial_dataset_level_license_incorrectly_applied_to_records(self, reconciler):
        """
        Adversarial: An ingest adapter incorrectly assumes that all files in The Stack v2
        inherit the dataset license. The reconciler explicitly registers this as a blocker.
        """
        s = reconciler.reconcile_source("the_stack_v2_permissive")
        assert s.license_result == ReconciliationResult.CLAIM_MISMATCH
        has_blocker = any("License claim mismatch" in b for b in s.unresolved_blockers)
        assert has_blocker is True

    def test_adversarial_changed_official_license_fails_closed(self, reconciler):
        """
        Adversarial: If a source changes license terms upstream to non-commercial,
        it must be detected and rejected.
        """
        s = reconciler.reconcile_source("non_commercial_research_corpus")
        assert s.overall_status == "REJECTED"

    def test_adversarial_stale_or_tampered_license_artifact(self, official_mgr, tmp_path):
        """
        Adversarial: If an on-disk license artifact has been modified/tampered with,
        its computed SHA-256 will mismatch the recorded artifact hash.
        """
        # Create a fake tampered evidence file
        tampered_file = tmp_path / "license_evidence.txt"
        tampered_file.write_text("TAMPERED LICENSE TEXT")

        recorded_hash = "a" * 64
        import hashlib
        computed_hash = hashlib.sha256(tampered_file.read_bytes()).hexdigest()
        assert computed_hash != recorded_hash
