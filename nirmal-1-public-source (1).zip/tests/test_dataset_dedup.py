"""
Unit tests for dataset deduplication (tests/test_dataset_dedup.py).
Verifies:
1. Exact deduplication eliminates identical items (0% internal duplicates).
2. Structural deduplication catches near-duplicate parameterizations.
3. CleanCurriculumGenerator produces 0% duplicates across all 12 domains.
"""

import pytest
from training.data_pipeline import DataPipeline, DataExample
from training.clean_dataset import CleanCurriculumGenerator


def test_exact_deduplication():
    pipeline = DataPipeline(seed=42)
    ex1 = pipeline.create_example("A", "Identical prompt text", "gen")
    ex2 = pipeline.create_example("A", "Identical prompt text", "gen")
    ex3 = pipeline.create_example("A", "Distinct prompt text", "gen")

    unique, dup_count = pipeline.deduplicate([ex1, ex2, ex3])
    assert len(unique) == 2
    assert dup_count == 1
    assert unique[0].text == "Identical prompt text"
    assert unique[1].text == "Distinct prompt text"


def test_structural_deduplication():
    pipeline = DataPipeline(seed=42)
    ex1 = pipeline.create_example("B", "Math: calculate (10 + 20) * 2", "gen")
    ex2 = pipeline.create_example("B", "Math: calculate (30 + 40) * 5", "gen")
    ex3 = pipeline.create_example("B", "Completely different string logic", "gen")

    # With structural=True, ex1 and ex2 share fingerprint "<NUM> + <NUM> * <NUM>"
    unique, dup_count = pipeline.deduplicate([ex1, ex2, ex3], structural=True)
    assert len(unique) == 2
    assert dup_count == 1


def test_clean_curriculum_zero_duplicates():
    gen = CleanCurriculumGenerator(seed=42)
    train_set = gen.generate_split("train", count_per_domain=20)
    pipeline = DataPipeline()
    unique, dup_count = pipeline.deduplicate(train_set)
    assert dup_count == 0
    assert len(unique) == len(train_set)
