import pytest
from scripts.v9_8_generalization_bridge import GeneralizationEvaluator

def test_memorization_threshold():
    ev = GeneralizationEvaluator()
    state = ev.evaluate_model_state(train_acc=0.9, val_acc=0.1, comp_acc=0.1, ood_acc=0.1)
    assert state == "MEMORIZING"

def test_not_memorizing_if_val_high():
    ev = GeneralizationEvaluator()
    state = ev.evaluate_model_state(train_acc=0.9, val_acc=0.85, comp_acc=0.1, ood_acc=0.1)
    assert state != "MEMORIZING"
    assert state == "INTERPOLATING"

def test_not_memorizing_if_train_low():
    ev = GeneralizationEvaluator()
    state = ev.evaluate_model_state(train_acc=0.1, val_acc=0.1, comp_acc=0.1, ood_acc=0.1)
    assert state == "RANDOM"

def test_learning_state():
    ev = GeneralizationEvaluator()
    state = ev.evaluate_model_state(train_acc=0.5, val_acc=0.1, comp_acc=0.1, ood_acc=0.1)
    assert state == "LEARNING"

def test_learning_boundary():
    ev = GeneralizationEvaluator()
    state = ev.evaluate_model_state(train_acc=0.79, val_acc=0.1, comp_acc=0.1, ood_acc=0.1)
    assert state == "LEARNING"
    
def test_memorization_fails_val():
    ev = GeneralizationEvaluator()
    state = ev.evaluate_model_state(train_acc=1.0, val_acc=0.0, comp_acc=0.0, ood_acc=0.0)
    assert state == "MEMORIZING"

def test_memorizing_random_boundary():
    ev = GeneralizationEvaluator()
    state = ev.evaluate_model_state(train_acc=0.19, val_acc=0.0, comp_acc=0.0, ood_acc=0.0)
    assert state == "RANDOM"
    
def test_interpolating_high_comp_fails():
    ev = GeneralizationEvaluator()
    state = ev.evaluate_model_state(train_acc=0.9, val_acc=0.9, comp_acc=0.1, ood_acc=0.0)
    assert state == "INTERPOLATING"

def test_composing_high_ood_fails():
    ev = GeneralizationEvaluator()
    state = ev.evaluate_model_state(train_acc=0.9, val_acc=0.9, comp_acc=0.9, ood_acc=0.1)
    assert state == "COMPOSING"

def test_random_all_zeros():
    ev = GeneralizationEvaluator()
    assert ev.evaluate_model_state(0, 0, 0, 0) == "RANDOM"
