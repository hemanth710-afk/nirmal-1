"""
Test Suite for External Data Acquisition Integrity & Safety Invariants (Nirmal-1 V8.4).

Verifies:
1. Partial download cleanup: interrupted or aborted downloads clean up .part files.
2. Cryptographic checksum mismatch fails closed: promoted file is never created.
3. Interrupted recovery: stale staging artifacts are cleanly purged before resumption.
4. Feeder exact deduplication: identical documents across or within sources are rejected.
5. Feeder near deduplication: MinHash Jaccard near-duplicates are detected and rejected.
6. Feeder benchmark decontamination: text overlapping benchmark probes is rejected.
7. Feeder secret credential safety: API keys/tokens are detected and blocked.
8. Comprehensive accounting integrity: discovered, accepted, rejected counts match.
"""

import hashlib
from pathlib import Path
import pytest

from training.acquisition.common import (
    AtomicStagingManager,
    ChecksumMismatchError,
    AcquisitionConfig,
    AcquisitionResult,
)
from training.acquisition.pipeline_feeder import PipelineFeeder
from training.v8_4_code_safety import CodeSafetyScanner
from training.v8_4_decontamination import NgramDecontaminationEngine, ContaminationSplit
from training.v8_4_global_dedup import ProductionDeduplicationPipeline


@pytest.fixture
def temp_dirs(tmp_path):
    staging_dir = tmp_path / "staging"
    auth_dir = tmp_path / "auth"
    staging_dir.mkdir()
    auth_dir.mkdir()
    return staging_dir, auth_dir


class TestAcquisitionIntegrity:
    """Rigorous integrity and isolation testing for external acquisition."""

    def test_partial_download_cleanup_on_error(self, temp_dirs):
        staging_dir, auth_dir = temp_dirs
        mgr = AtomicStagingManager(staging_dir, auth_dir)

        staged = mgr.get_staging_path("test_payload")
        staged.write_bytes(b"partial byte stream corrupted before finish")

        # Checksum mismatch should delete the staged file and not write to auth_dir
        expected_sha = hashlib.sha256(b"full authentic byte stream").hexdigest()
        with pytest.raises(ChecksumMismatchError):
            mgr.promote_file(staged, "test_payload.bin", expected_sha256=expected_sha)

        assert not staged.exists()
        assert not (auth_dir / "test_payload.bin").exists()
        assert list(auth_dir.glob("*")) == []

    def test_checksum_mismatch_fail_closed(self, temp_dirs):
        staging_dir, auth_dir = temp_dirs
        mgr = AtomicStagingManager(staging_dir, auth_dir)

        staged = mgr.get_staging_path("tampered_source")
        staged.write_text("Tampered or modified dataset content", encoding="utf-8")

        fake_hash = "f" * 64
        with pytest.raises(ChecksumMismatchError) as exc:
            mgr.promote_file(staged, "tampered_source.parquet", expected_sha256=fake_hash)

        assert "Checksum mismatch" in str(exc.value)
        assert not (auth_dir / "tampered_source.parquet").exists()
        assert not staged.exists()

    def test_interrupted_recovery_purges_stale_artifacts(self, temp_dirs):
        staging_dir, auth_dir = temp_dirs
        mgr = AtomicStagingManager(staging_dir, auth_dir)

        # Simulate leftover crashed artifacts from a prior process
        stale_part = staging_dir / "stale_run.part"
        stale_part.write_bytes(b"incomplete data from prior crash")
        stale_tmp = staging_dir / "stale_run.tmp"
        stale_tmp.write_bytes(b"temp data")

        assert stale_part.exists()
        assert stale_tmp.exists()

        mgr.cleanup_staging()

        assert not stale_part.exists()
        assert not stale_tmp.exists()

    def test_feeder_exact_deduplication(self):
        feeder = PipelineFeeder(source_id="test_source")
        doc_text = "This is a high-quality educational document discussing principles of thermodynamics and statistical physics."

        # First document: accepted
        is_acc1, doc1, reason1 = feeder.process_raw_record("doc_001", doc_text)
        assert is_acc1 is True
        assert doc1 is not None
        assert reason1 is None

        # Second document (exact duplicate): rejected
        is_acc2, doc2, reason2 = feeder.process_raw_record("doc_002", doc_text)
        assert is_acc2 is False
        assert doc2 is None
        assert "exact_duplicate" in reason2
        assert feeder.accounting.exact_dedup_removals == 1
        assert feeder.accounting.documents_accepted == 1
        assert feeder.accounting.documents_rejected == 1

    def test_feeder_near_deduplication(self):
        feeder = PipelineFeeder(source_id="test_source")
        words = ["nirmal", "neural", "model", "architecture", "delta", "recurrence", "attention", "transformer", "scaling", "reasoning"] * 5
        base_text = " ".join(words)
        slight_mod = " ".join(words[:-1] + ["telemetry"])

        is_acc1, _, _ = feeder.process_raw_record("doc_orig", base_text)
        assert is_acc1 is True

        is_acc2, _, reason2 = feeder.process_raw_record("doc_near", slight_mod)
        assert is_acc2 is False
        assert "near_duplicate" in reason2
        assert feeder.accounting.near_dedup_removals == 1

    def test_feeder_benchmark_contamination_rejection(self):
        decontam = NgramDecontaminationEngine(ngram_size=5)
        # Register a probe
        probe_text = "needle key target hidden within long horizon reasoning evaluation benchmark"
        decontam.add_benchmark_entry("CUSTOM_BENCHMARK", "probe_1", probe_text)

        feeder = PipelineFeeder(source_id="test_source", decontamination_engine=decontam)

        contaminated_text = (
            "In this study, we notice that needle key target hidden within long horizon "
            "reasoning evaluation benchmark reveals interesting behavior."
        )
        is_acc, doc, reason = feeder.process_raw_record("doc_contam", contaminated_text)
        assert is_acc is False
        assert doc is None
        assert reason == "benchmark_contamination_detected"
        assert feeder.accounting.contamination_removals == 1
        assert feeder.accounting.documents_rejected == 1

    def test_feeder_secret_credential_rejection(self):
        feeder = PipelineFeeder(source_id="test_source")

        # Text with genuine AWS Access Key pattern (no benign placeholder keywords)
        secret_text = (
            "def authenticate_aws():\n"
            "    aws_access_key = 'AKIA2G5Q8Z9R7W4X6B1D'\n"
            "    github_token = 'ghp_EXAMPLE_TEST_TOKEN_NOT_REAL_1234567890'\n"
            "    return aws_access_key, github_token\n"
        )
        is_acc, doc, reason = feeder.process_raw_record("doc_secret", secret_text)
        assert is_acc is False
        assert doc is None
        assert reason == "credential_secret_detected"
        assert feeder.accounting.secret_removals == 1
        assert feeder.accounting.documents_rejected == 1

    def test_provenance_accounting_integrity(self):
        feeder = PipelineFeeder(source_id="test_accounting_source")

        # 1. Clean valid doc
        feeder.process_raw_record("doc_1", "Valid scientific text explaining gravitational waves detected by LIGO interferometers.")

        # 2. Secret doc
        feeder.process_raw_record("doc_2", "aws_key = 'AKIA2G5Q8Z9R7W4X6B1D'\nconnect()\n")

        # 3. Duplicate doc
        feeder.process_raw_record("doc_3", "Valid scientific text explaining gravitational waves detected by LIGO interferometers.")

        # 4. Short / low quality doc
        feeder.process_raw_record("doc_4", "short")

        acc = feeder.accounting
        assert acc.documents_discovered == 4
        assert acc.documents_accepted == 1
        assert acc.documents_rejected == 3
        assert acc.secret_removals == 1
        assert acc.exact_dedup_removals == 1
        assert acc.quality_removals == 1
        assert acc.tokens_accepted > 0
        assert sum(acc.rejected_reasons.values()) == acc.documents_rejected
