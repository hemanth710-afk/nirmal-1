"""V10.1 — curriculum composition tests."""
import pytest
from training.acquisition.v10_1_ood_amplification import (
    CURRICULUM_RULES, run_curriculum
)
from pathlib import Path
import tempfile


@pytest.fixture
def tmpdir():
    with tempfile.TemporaryDirectory() as d:
        yield Path(d)


def test_curriculum_rules_defined():
    assert "B1_COPY"        in CURRICULUM_RULES
    assert "B2_COPY_INC"    in CURRICULUM_RULES
    assert "B3_COPY_INC_DS" in CURRICULUM_RULES


def test_b1_rules_count():
    assert len(CURRICULUM_RULES["B1_COPY"]) == 1


def test_b2_rules_count():
    assert len(CURRICULUM_RULES["B2_COPY_INC"]) == 2


def test_b3_rules_count():
    assert len(CURRICULUM_RULES["B3_COPY_INC_DS"]) == 3


def test_curriculum_run_returns_valid_result(tmpdir):
    r = run_curriculum("B1_COPY", CURRICULUM_RULES["B1_COPY"], 42, tmpdir, steps_per_rule=10)
    assert 0.0 <= r.train_acc <= 1.0
    assert 0.0 <= r.ood_acc   <= 1.0
    assert r.curriculum == "B1_COPY"
