"""
Unit tests for StreamingIngestionEngine and IngestionCheckpoint in Nirmal-1 V8.4.
"""

import gzip
from pathlib import Path
import tempfile
import pytest

from training.v8_4_ingestion import StreamingIngestionEngine, IngestionCheckpoint
from training.v8_4_manifest import SourceProvenanceRecord


def test_unicode_and_crlf_normalization():
    engine = StreamingIngestionEngine()
    raw = "Hello\r\nWorld\r\n\r\n\r\n\r\nTest Line   \r\n"
    norm = engine.normalize_text(raw)
    assert "\r" not in norm
    assert "Hello\nWorld\n\nTest Line" == norm


def test_quality_filters():
    engine = StreamingIngestionEngine(min_doc_length=20, max_doc_length=1000)

    # Too short
    retained, reason = engine.filter_document("Too short")
    assert not retained
    assert reason == "empty_or_too_short"

    # Replacement character
    retained, reason = engine.filter_document("Corrupted text \ufffd\ufffd\ufffd with replacement chars in stream")
    assert not retained
    assert reason == "invalid_unicode_replacement"

    # Character repetition
    retained, reason = engine.filter_document("Normal header " + "!" * 50)
    assert not retained
    assert reason == "excessive_char_repetition"

    # Valid text
    valid_text = "This is a clean, verified scientific text containing enough information to pass all standard filters."
    retained, reason = engine.filter_document(valid_text)
    assert retained
    assert reason is None


def test_streaming_ingestion_and_resumption():
    with tempfile.TemporaryDirectory() as tmpdir:
        tmp_path = Path(tmpdir)
        checkpoint_dir = tmp_path / "checkpoints"
        data_file = tmp_path / "stream_data.txt"

        lines = [
            f"Document {i}: This is valid text that is sufficiently long to pass filters for document number {i}."
            for i in range(20)
        ]
        with open(data_file, "w", encoding="utf-8") as f:
            f.write("\n".join(lines))

        engine = StreamingIngestionEngine(checkpoint_dir=checkpoint_dir, min_doc_length=20)
        prov = SourceProvenanceRecord(
            source_name="TestSource",
            source_identifier=str(data_file),
            license="Apache-2.0",
            provenance_details="Unit test stream",
            acquisition_timestamp="2026-09-06T00:00:00Z",
            original_size_bytes=data_file.stat().st_size,
            processed_size_bytes=data_file.stat().st_size,
            measured_token_count=0,
            source_sha256="dummy",
            preprocessing_version="v8.4.0",
        )

        generator = engine.stream_records_from_file(data_file, source_record=prov, resume=False, save_interval=5)
        docs = []
        for i, d in enumerate(generator):
            docs.append(d)
            if len(docs) >= 10:
                break
        generator.close()

        assert len(docs) == 10
        assert engine.total_retained == 10

        # Save checkpoint explicitly or test checkpoint saving
        ckpt_obj = IngestionCheckpoint(
            source_identifier=prov.source_identifier,
            last_processed_line=10,
            last_processed_bytes=1000,
            documents_ingested=10,
            documents_rejected=0,
            timestamp="2026-09-06T00:00:00Z",
        )
        engine.save_checkpoint(ckpt_obj)
        cp = engine.load_checkpoint(prov.source_identifier)
        assert cp is not None
        assert cp.documents_ingested == 10
        assert cp.last_processed_line == 10
