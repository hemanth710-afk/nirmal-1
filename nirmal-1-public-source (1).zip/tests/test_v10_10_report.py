"""V10.10-SPEC-AMENDMENT-01: Model identities, protected paths, safety, and network guard tests."""

import socket
from pathlib import Path

import pytest
import torch

from training.evaluation.v10_10_binding_harness import (
    AUTHORITATIVE_CORPUS_TOKENS,
    CANDIDATE_C_TARGET_PARAMS,
    EXTERNAL_PRODUCTION_APPROVALS,
    PRODUCTION_STATUS,
    AmendedTransformer,
    OfflineNetworkGuard,
    ProtectedScopeSnapshot,
    build_amended_model,
    count_trainable_parameters,
    initialize_model_weights,
)

ROOT = Path(__file__).resolve().parents[1]


def test_model_identities_and_exact_parameter_counts():
    l0 = build_amended_model("L0")
    assert count_trainable_parameters(l0) == 37_632
    assert l0.hidden_size == 32
    assert l0.num_layers == 2
    assert l0.vocab_size == 128
    assert l0.context_length == 256

    l1 = build_amended_model("L1")
    assert count_trainable_parameters(l1) == 224_128
    assert l1.hidden_size == 64
    assert l1.num_layers == 4
    assert l1.vocab_size == 128
    assert l1.context_length == 256


def test_rejection_of_unauthorized_model_scales():
    for forbidden in ("L2", "L3", "Candidate_C", "production"):
        with pytest.raises(ValueError, match="Scale must be L0 or L1"):
            build_amended_model(forbidden)


def test_weight_initialization_fixtures():
    model = build_amended_model("L0")
    initialize_model_weights(model, init_seed=12345)

    # Check linear and embedding weights have ~0 mean and ~0.02 std
    lin_weights = [m.weight.data for m in model.modules() if isinstance(m, (torch.nn.Linear, torch.nn.Embedding))]
    all_w = torch.cat([w.flatten() for w in lin_weights])
    assert abs(all_w.mean().item()) < 0.005
    assert abs(all_w.std().item() - 0.02) < 0.005

    # Check biases are 0
    for m in model.modules():
        if isinstance(m, torch.nn.Linear) and m.bias is not None:
            assert torch.all(m.bias == 0)
        elif isinstance(m, torch.nn.LayerNorm):
            if m.bias is not None:
                assert torch.all(m.bias == 0)
            if m.weight is not None:
                assert torch.all(m.weight == 1.0)


def test_protected_scope_remains_completely_untouched():
    snap = ProtectedScopeSnapshot.capture(ROOT)
    assert snap.src_nirmal == ""
    assert snap.data_shards == ""


def test_corpus_count_candidate_c_and_production_governance():
    assert AUTHORITATIVE_CORPUS_TOKENS == 233_997
    assert CANDIDATE_C_TARGET_PARAMS == 25_908_188_576
    assert EXTERNAL_PRODUCTION_APPROVALS == "0/6"
    assert PRODUCTION_STATUS == "STRICT NO-GO"


def test_offline_network_guard_blocks_socket_connections():
    with OfflineNetworkGuard() as guard:
        sock = socket.socket()
        with pytest.raises(RuntimeError, match="External/network calls are forbidden"):
            sock.connect(("1.1.1.1", 80))
        sock.close()
    assert len(guard.attempts) > 0


def test_complete_g0_to_g6_report_output():
    from scripts.v10_10_fill_report import format_gate_report_line
    gate = {
        "level": "B2",
        "g0": True,
        "g1": True,
        "g2": True,
        "g3": True,
        "g4": True,
        "g5": True,
        "g6": True,
    }
    line = format_gate_report_line("B2", "ASSOCIATIVE_BINDING_ESTABLISHED", gate)
    assert "G0 (Artifact integrity)=True" in line
    assert "G1 (Harness validity)=True" in line
    assert "G2 (Positive control)=True" in line
    assert "G3 (Negative-control specificity)=True" in line
    assert "G4 (Core binding)=True" in line
    assert "G5 (Robustness)=True" in line
    assert "G6 (Scaling)=True" in line
    # Legacy labels must NOT appear
    for legacy in ("gate0_integrity", "gate1_train", "gate2_validation", "gate3_causal", "gate4_seeds", "gate5_position_order"):
        assert legacy not in line

