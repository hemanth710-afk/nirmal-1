"""
Unit tests for GlobalExactDeduplicator and MinHashLSHDeduplicator in Nirmal-1 V8.4.
"""

from pathlib import Path
import tempfile
import pytest

from training.v8_4_global_dedup import (
    GlobalExactDeduplicator,
    MinHashLSHDeduplicator,
    ProductionDeduplicationPipeline,
)


def test_global_exact_deduplication():
    exact = GlobalExactDeduplicator()

    doc1 = "The quick brown fox jumps over the lazy dog."
    doc2 = "The quick brown fox jumps over the lazy dog."
    doc3 = "A completely different scientific sentence."

    is_dup1, _ = exact.is_duplicate(doc1, "d1")
    assert not is_dup1

    is_dup2, match2 = exact.is_duplicate(doc2, "d2")
    assert is_dup2
    assert match2 == "d1"

    is_dup3, _ = exact.is_duplicate(doc3, "d3")
    assert not is_dup3

    rep = exact.get_report()
    assert rep["exact_duplicates_removed"] == 1
    assert rep["unique_retained"] == 2
    assert rep["zero_exact_duplicates_guaranteed"] is True


def test_minhash_lsh_near_deduplication():
    near_dedup = MinHashLSHDeduplicator(num_perm=64, num_bands=16, jaccard_threshold=0.85)

    words = ["nirmal", "neural", "model", "architecture", "delta", "recurrence", "attention", "transformer", "scaling", "reasoning"] * 5
    base_text = " ".join(words)
    slight_mod = " ".join(words[:-1] + ["telemetry"])
    distinct_text = "Quantum computing relies upon qubits and quantum entanglement principles."

    is_near1, _, _ = near_dedup.is_near_duplicate(base_text, "base_doc")
    assert not is_near1

    is_near2, match, sim = near_dedup.is_near_duplicate(slight_mod, "mod_doc")
    assert is_near2
    assert match == "base_doc"
    assert sim >= 0.85

    is_near3, _, _ = near_dedup.is_near_duplicate(distinct_text, "dist_doc")
    assert not is_near3


def test_domain_boilerplate_protection():
    near_dedup = MinHashLSHDeduplicator(num_perm=64, num_bands=16, jaccard_threshold=0.85)

    # Two distinct code snippets sharing an Apache-2.0 license banner
    header = "# Copyright 2026 Nirmal Project.\n# Licensed under the Apache License, Version 2.0\n"
    code_a = header + "def calculate_matrix_determinant(matrix):\n    return np.linalg.det(matrix)\n"
    code_b = header + "def parse_ast_tree(source_code):\n    return ast.parse(source_code)\n"

    is_near_a, _, _ = near_dedup.is_near_duplicate(code_a, "code_a", domain="code")
    assert not is_near_a

    is_near_b, _, _ = near_dedup.is_near_duplicate(code_b, "code_b", domain="code")
    # With boilerplate stripping, distinct code remains distinct
    assert not is_near_b
