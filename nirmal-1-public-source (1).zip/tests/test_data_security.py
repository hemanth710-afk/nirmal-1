"""
Test Suite for Production Code Safety & Credential Leakage Scanner (Nirmal-1 V8.4).

Verifies:
1. True-positive detection: fake AWS keys, GitHub PATs, private keys, Slack tokens, Stripe keys.
2. False-positive minimization: normal Python, JS, Bash, config files, benign placeholders.
3. Secret redaction: raw secret value is NEVER printed, logged, or exposed in finding evidence.
4. Fail-closed behavior: invalid configuration or detected secret rejects document.
5. Ingestion integration: StreamingIngestionEngine rejects secret-bearing documents.
"""

from pathlib import Path
import pytest

from training.v8_4_code_safety import (
    CodeSafetyScanner,
    CodeSafetyConfig,
    CodeSafetyFinding,
    FindingCategory,
    FindingSeverity,
    ScannerAction,
    calculate_shannon_entropy,
    redact_secret_value,
)
from training.v8_4_ingestion import StreamingIngestionEngine, SourceProvenanceRecord


@pytest.fixture
def scanner():
    return CodeSafetyScanner()


class TestCodeSafetyScanner:
    """Rigorous tests for credential detection, redaction, and false-positive avoidance."""

    def test_aws_access_key_detection(self, scanner):
        # Fake AWS IAM Access Key ID (AKIA + 16 chars)
        fake_key = "AKIA1234567890ABCDEF"
        code = f"""
        import boto3
        s3 = boto3.client('s3', aws_access_key_id='{fake_key}')
        """
        res = scanner.scan_text(code)
        assert not res.is_safe, "Document with AWS access key must not be safe"
        assert len(res.findings) >= 1
        f = res.findings[0]
        assert f.category == FindingCategory.AWS_CREDENTIAL
        assert f.severity == FindingSeverity.CRITICAL
        # Assert raw secret is NOT in evidence
        assert fake_key not in f.redacted_evidence
        assert fake_key not in repr(f)
        assert f.redacted_evidence.startswith("AKI")

    def test_github_token_detection(self, scanner):
        # Fake GitHub Classic PAT
        fake_ghp = "ghp_EXAMPLE_TEST_TOKEN_NOT_REAL_1234567890"
        text = f"export GITHUB_TOKEN='{fake_ghp}'"
        res = scanner.scan_text(text)
        assert not res.is_safe
        assert len(res.findings) == 1
        assert res.findings[0].category == FindingCategory.GITHUB_TOKEN
        assert fake_ghp not in res.findings[0].redacted_evidence
        assert fake_ghp not in repr(res.findings[0])

    def test_private_key_block_detection(self, scanner):
        rsa_key = """
        -----BEGIN RSA PRIVATE KEY-----
        MIIEowIBAAKCAQEA0Y1W9...fake_key_material...
        -----END RSA PRIVATE KEY-----
        """
        res = scanner.scan_text(rsa_key)
        assert not res.is_safe
        assert any(f.category == FindingCategory.PRIVATE_KEY for f in res.findings)

        openssh_key = """
        -----BEGIN OPENSSH PRIVATE KEY-----
        b3BlbnNzaC1rZXktdjEAAAA...fake_key...
        -----END OPENSSH PRIVATE KEY-----
        """
        res2 = scanner.scan_text(openssh_key)
        assert not res2.is_safe
        assert any(f.category == FindingCategory.PRIVATE_KEY for f in res2.findings)

    def test_slack_and_stripe_token_detection(self, scanner):
        slack_code = "SLACK_BOT_TOKEN = 'xoxb-123456789012-123456789012-AbCdEfGhIjKlMnOpQrStUvWx'"
        res_slack = scanner.scan_text(slack_code)
        assert not res_slack.is_safe
        assert any(f.detector_id == "slack_token" for f in res_slack.findings)

        stripe_code = "stripe.api_key = 'sk_live_1234567890abcdef1234567890'"
        res_stripe = scanner.scan_text(stripe_code)
        assert not res_stripe.is_safe
        assert any(f.detector_id == "stripe_live_key" for f in res_stripe.findings)

    def test_benign_code_false_positive_avoidance(self, scanner):
        """Standard Python, JavaScript, Bash, and config files must PASS cleanly."""
        normal_python = """
        import os
        import json

        def get_api_key(service_name: str) -> str:
            # Reads key from environment securely
            api_key = os.environ.get("API_KEY", None)
            if api_key is None:
                raise ValueError(f"Missing API key for {service_name}")
            return api_key

        class Config:
            key_id = "default_key_id"
            token = None
            max_retries = 3
        """
        res_py = scanner.scan_text(normal_python)
        assert res_py.is_safe, f"Benign python code triggered false positive: {res_py.findings}"

        normal_js = """
        const fetch = require('node-fetch');
        async function queryEndpoint(url, token = null) {
            const headers = { 'Content-Type': 'application/json' };
            if (token) {
                headers['Authorization'] = `Bearer ${token}`;
            }
            return await fetch(url, { headers });
        }
        """
        res_js = scanner.scan_text(normal_js)
        assert res_js.is_safe, f"Benign JS code triggered false positive: {res_js.findings}"

        normal_bash = """
        #!/bin/bash
        set -euo pipefail
        echo "Starting deployment sequence..."
        export ENV_MODE="production"
        aws s3 sync ./dist s3://my-static-assets-bucket/
        """
        res_sh = scanner.scan_text(normal_bash)
        assert res_sh.is_safe

    def test_benign_placeholders_not_flagged(self, scanner):
        """Example test fixtures and placeholders must not be flagged as live secrets."""
        test_fixture = """
        # Test configuration with dummy placeholder
        api_key = "your_key_here_placeholder_example_test"
        dummy_token = "00000000000000000000000000000000"
        aws_mock_key = "AKIAIOSFODNN7EXAMPLE"
        """
        res = scanner.scan_text(test_fixture)
        assert res.is_safe, f"Placeholder triggered false positive: {res.findings}"

    def test_redaction_mode(self):
        redact_cfg = CodeSafetyConfig(default_action=ScannerAction.REDACT)
        redact_scanner = CodeSafetyScanner(config=redact_cfg)
        secret_text = "const key = 'sk_live_1234567890abcdef1234567890';"
        res = redact_scanner.scan_text(secret_text)
        assert not res.is_safe
        assert res.action == ScannerAction.REDACT
        assert res.redacted_text is not None
        assert "sk_live_" not in res.redacted_text
        assert "[REDACTED_SECRET_API_KEY]" in res.redacted_text

    def test_fail_closed_invalid_configuration(self):
        with pytest.raises(ValueError):
            CodeSafetyConfig(default_action="INVALID_ACTION")  # type: ignore

        with pytest.raises(ValueError):
            CodeSafetyConfig(min_entropy_threshold=-1.0)

    def test_ingestion_engine_secret_rejection(self, tmp_path):
        engine = StreamingIngestionEngine(checkpoint_dir=tmp_path)
        secret_doc = """
        # Critical infrastructure script
        AWS_ACCESS_KEY_ID = "AKIA9876543210FEDCBA"
        def deploy():
            pass
        """
        is_retained, reason = engine.filter_document(secret_doc)
        assert not is_retained
        assert reason == "credential_secret_detected"
        assert engine.rejection_reasons["credential_secret_detected"] == 1
