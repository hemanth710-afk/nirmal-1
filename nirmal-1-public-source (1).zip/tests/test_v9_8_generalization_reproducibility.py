import pytest
import torch
from scripts.v9_8_generalization_bridge import GeneralizationEvaluator

def test_evaluator_scales():
    ev = GeneralizationEvaluator()
    assert "MICRO" in ev.scales
    assert "SMALL" in ev.scales
    assert "MEDIUM" in ev.scales
    
def test_reproducible_task_generation():
    from scripts.v9_8_generalization_bridge import GeneralizationTaskGenerator
    gen = GeneralizationTaskGenerator()
    torch.manual_seed(42)
    d1 = gen.generate_task("LEVEL_3_COMPOSITION", 2, 8, 10, 40)
    torch.manual_seed(42)
    d2 = gen.generate_task("LEVEL_3_COMPOSITION", 2, 8, 10, 40)
    assert (d1 == d2).all()

def test_reproducible_task_different_seed():
    from scripts.v9_8_generalization_bridge import GeneralizationTaskGenerator
    gen = GeneralizationTaskGenerator()
    torch.manual_seed(42)
    d1 = gen.generate_task("LEVEL_3_COMPOSITION", 2, 8, 10, 40)
    torch.manual_seed(43)
    d2 = gen.generate_task("LEVEL_3_COMPOSITION", 2, 8, 10, 40)
    assert not (d1 == d2).all()

def test_scale_monotonicity():
    ev = GeneralizationEvaluator()
    assert ev.scales["MICRO"]["dim"] < ev.scales["SMALL"]["dim"]
    assert ev.scales["SMALL"]["dim"] < ev.scales["MEDIUM"]["dim"]

def test_scale_resource_limits():
    ev = GeneralizationEvaluator()
    # Ensure they fit within the 4GB local limit design
    assert ev.scales["MEDIUM"]["ram"] <= 4096
    assert ev.scales["MEDIUM"]["time"] <= 300
