"""
Test Suite for Strict 12-Requirement Approval Policy (Nirmal-1 V8.5).

Verifies:
1. ApprovalPolicyEvaluator enforces all 12 explicit approval requirements.
2. In-repo synthetic corpus satisfies all 12 requirements.
3. None of the 6 external candidate sources satisfy all 12 requirements (all remain UNDER_REVIEW).
4. Adversarial 9: Unsigned, unstable, or placeholder revision fails requirement 2 and prevents approval.
5. Adversarial 14: Unsupported acquisition method fails requirement 5 and prevents approval.
6. Forcibly setting approval_status=APPROVED on an external source raises EvidenceValidationError.
7. 'READY' state is never treated as APPROVED.
"""

from pathlib import Path
import pytest

from training.acquisition.evidence import (
    SourceEvidenceManager,
    SourceEvidenceDossier,
    ApprovalStatus,
    EvidenceValidationError,
    ApprovalPolicyEvaluator,
)
from training.acquisition.official_evidence import OfficialEvidenceManager


@pytest.fixture
def evidence_mgr():
    return SourceEvidenceManager()


@pytest.fixture
def official_mgr():
    return OfficialEvidenceManager()


@pytest.fixture
def policy_evaluator():
    return ApprovalPolicyEvaluator()


class TestApprovalPolicy:
    """Rigorous testing of the 12 explicit production approval requirements."""

    def test_synthetic_source_passes_all_12_requirements(self, policy_evaluator):
        all_passed, results = policy_evaluator.evaluate_source("nirmal_synthetic_v8_2")
        assert all_passed is True
        assert len(results) == 12
        for req_id, res in results.items():
            assert res.passed is True, f"Requirement {req_id} failed for synthetic corpus: {res.details}"

    def test_all_six_external_sources_fail_approval_requirements(self, policy_evaluator, official_mgr):
        external_sources = [
            "fineweb_edu_permissive",
            "the_stack_v2_permissive",
            "arxiv_open_access_papers",
            "dolma_v1_7_permissive",
            "redpajama_v2_permissive",
            "wikipedia_open_corpus",
        ]
        for src in external_sources:
            record = official_mgr.load_verification_record(src)
            all_passed, results = policy_evaluator.evaluate_source(src, record)
            assert all_passed is False, f"External source '{src}' must NOT pass approval requirements!"

            # Requirement 2 (revision) must fail for all external sources
            assert results["req_02_version_revision"].passed is False
            assert results["req_02_version_revision"].status == "UNVERIFIED"

    def test_adversarial_9_unsigned_unstable_revision_prevents_approval(self, evidence_mgr):
        valid_ev_file = "evidence_files/nirmal_synthetic_v8_2_evidence.txt"
        dossier = SourceEvidenceDossier(
            source_id="unstable_rev_source",
            canonical_source_name="Unstable Rev Source",
            canonical_url="https://valid.org/data",
            dataset_version_identifier="1.0",
            acquisition_method="TEST",
            snapshot_revision_identifier="UNVERIFIED_REVISION_FLOAT",
            retrieval_timestamp="2026-09-07",
            source_checksum="a" * 64,
            license_url="https://valid.org/license",
            license_text_hash=None,
            license_evidence_file_path=valid_ev_file,
            terms_policy_evidence_file_path=None,
            dataset_card_evidence_file_path=None,
            declared_license="Apache-2.0",
            per_file_license_policy="TEST",
            provenance_requirements=["commit_hash"],
            attribution_requirements=["Test Author"],
            security_screening_status="PASSED_NO_CREDENTIALS",
            benchmark_contamination_status="SYNTHETIC_CLEAN",
            approval_status=ApprovalStatus.APPROVED,
        )

        with pytest.raises(EvidenceValidationError) as exc:
            dossier.validate(base_dir=evidence_mgr.evidence_dir)
        assert "unverified or placeholder revision" in str(exc.value)

    def test_adversarial_14_unsupported_acquisition_method_prevents_approval(self, evidence_mgr):
        valid_ev_file = "evidence_files/nirmal_synthetic_v8_2_evidence.txt"
        dossier = SourceEvidenceDossier(
            source_id="unsupported_method_source",
            canonical_source_name="Unsupported Method Source",
            canonical_url="https://valid.org/data",
            dataset_version_identifier="1.0",
            acquisition_method="placeholder_method",
            snapshot_revision_identifier="git_commit_abcdef1234567890",
            retrieval_timestamp="2026-09-07",
            source_checksum="b" * 64,
            license_url="https://valid.org/license",
            license_text_hash=None,
            license_evidence_file_path=valid_ev_file,
            terms_policy_evidence_file_path=None,
            dataset_card_evidence_file_path=None,
            declared_license="Apache-2.0",
            per_file_license_policy="TEST",
            provenance_requirements=["commit_hash"],
            attribution_requirements=["Test Author"],
            security_screening_status="PASSED_NO_CREDENTIALS",
            benchmark_contamination_status="SYNTHETIC_CLEAN",
            approval_status=ApprovalStatus.APPROVED,
        )

        with pytest.raises(EvidenceValidationError) as exc:
            dossier.validate(base_dir=evidence_mgr.evidence_dir)
        assert "invalid acquisition method" in str(exc.value)

    def test_forcibly_approved_external_source_fails_validation(self, evidence_mgr):
        # Even if someone sets approval_status=APPROVED on fineweb_edu_permissive in memory
        dossier = evidence_mgr.load_dossier("fineweb_edu_permissive")
        assert dossier is not None
        dossier.approval_status = ApprovalStatus.APPROVED

        with pytest.raises(EvidenceValidationError) as exc:
            dossier.validate(base_dir=evidence_mgr.evidence_dir)
        # It must fail because evidence file is missing, checksum is missing, etc.
        assert "cannot be APPROVED" in str(exc.value)

    def test_ready_is_not_approved(self, evidence_mgr):
        # A dossier with status READY or similar non-APPROVED status cannot be treated as APPROVED
        is_app, reason = evidence_mgr.check_source_approval("fineweb_edu_permissive")
        assert is_app is False
        assert "not APPROVED" in reason
