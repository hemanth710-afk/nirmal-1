"""
Unit tests for Experience Schema & EpisodicBuffer enhancements.
Verifies serialization, fields, roundtrips, and backward compatibility.
"""

import json
from nirmal.learning import Experience, EpisodicBuffer


def test_experience_backward_compatibility():
    """Verify trajectory_id and goal backward compatibility."""
    exp = Experience(trajectory_id="traj_99", goal="Compute test", success=True)
    assert exp.trajectory_id == "traj_99"
    assert exp.task_id == "traj_99"
    assert exp.goal == "Compute test"
    assert exp.success is True


def test_experience_structured_fields_and_serialization():
    """Verify all explicit schema fields and JSON/dict roundtrips."""
    exp = Experience(
        task_id="task_123",
        task_family="data_encoding",
        context="Input data ready",
        goal="Encode payload",
        retrieved_memory=["cipher_key: 0x4F"],
        proposed_plan={"nodes": {"s1": {"tool": "string_util"}}},
        actions=[{"tool": "string_util", "args": {"operation": "uppercase"}}],
        observations=["Encoded successfully"],
        verification_result={"is_valid": True, "score": 1.0},
        reward=1.0,
        success=True,
        failure_reason=None,
        strategy_used="caesar_encoding_strategy",
        episode_index=42,
    )

    # Dictionary roundtrip
    d = exp.to_dict()
    assert d["task_id"] == "task_123"
    assert d["task_family"] == "data_encoding"
    assert d["strategy_used"] == "caesar_encoding_strategy"
    assert d["episode_index"] == 42
    assert d["verification_result"]["is_valid"] is True

    from_d = Experience.from_dict(d)
    assert from_d.task_id == exp.task_id
    assert from_d.strategy_used == exp.strategy_used
    assert from_d.retrieved_memory == exp.retrieved_memory

    # JSON roundtrip
    json_str = exp.to_json()
    assert isinstance(json_str, str)
    from_j = Experience.from_json(json_str)
    assert from_j.task_id == exp.task_id
    assert from_j.reward == 1.0
    assert from_j.success is True


def test_episodic_buffer_filtering():
    """Verify EpisodicBuffer query filtering by task_family and success."""
    buf = EpisodicBuffer(max_capacity=20)
    buf.add(Experience(task_id="t1", task_family="family_a", success=True))
    buf.add(Experience(task_id="t2", task_family="family_b", success=False))
    buf.add(Experience(task_id="t3", task_family="family_a", success=False))
    buf.add(Experience(task_id="t4", task_family="family_a", success=True))

    family_a = buf.query(task_family="family_a")
    assert len(family_a) == 3
    # Most recent first
    assert family_a[0].task_id == "t4"
    assert family_a[1].task_id == "t3"

    successful_a = buf.query(task_family="family_a", success=True)
    assert len(successful_a) == 2
    assert [e.task_id for e in successful_a] == ["t4", "t1"]
