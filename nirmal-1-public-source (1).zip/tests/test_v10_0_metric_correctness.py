"""Tests for metric correctness and failure classification — V10.0."""
import pytest
from training.acquisition.v10_0_intervention_engine import RunConfig, _classify_failure


def cfg(repr_mode="identity", objective="causal_lm", position_mode="normal"):
    return RunConfig("test", 42, 32, repr_mode=repr_mode,
                     objective=objective, position_mode=position_mode)


def test_classify_success():
    assert _classify_failure(0.95, 0.90, 0.85, cfg()) == "NONE"


def test_classify_training_signal():
    assert _classify_failure(0.30, 0.10, 0.00, cfg()) == "TRAINING_SIGNAL"


def test_classify_vocabulary_failure():
    # High train & val, OOD=0, identity repr
    assert _classify_failure(0.90, 0.85, 0.01, cfg()) == "VOCABULARY"


def test_classify_position_failure():
    assert _classify_failure(0.90, 0.80, 0.00, cfg(position_mode="reversed")) == "POSITION"


def test_classify_objective_failure():
    assert _classify_failure(0.90, 0.80, 0.00, cfg(objective="relation_consistency")) == "OBJECTIVE"


def test_classify_representation_partial():
    c = cfg(repr_mode="value_relative")
    # value_relative with some OOD > 0 but < 0.8
    result = _classify_failure(0.90, 0.80, 0.25, c)
    assert result == "REPRESENTATION_PARTIAL"
