"""V10.10-SPEC-AMENDMENT-01: G0-G6 gates and deterministic classification tests."""

from training.evaluation.v10_10_binding_harness import (
    CLASSIFICATIONS,
    ClassificationEvidence,
    ComprehensiveGateReport,
    G0ArtifactIntegrity,
    G1HarnessValidity,
    G6Scaling,
    OptimizationLimitEvidence,
    SerializationLimitEvidence,
    classify_binding,
    compute_delta_scale,
)


def test_seven_distinct_gates_and_all_passed_summary():
    report = ComprehensiveGateReport(
        g0=True, g1=True, g2=True, g3=True, g4=True, g5=True, g6=True,
        all_passed=True,
    )
    assert report.g0 and report.g1 and report.g2 and report.g3 and report.g4 and report.g5 and report.g6
    assert report.all_passed

    report_fail = ComprehensiveGateReport(
        g0=True, g1=True, g2=True, g3=True, g4=True, g5=True, g6=False,
        all_passed=False,
    )
    assert not report_fail.all_passed
    assert not report_fail.g6


def test_g0_artifact_integrity_deterministic_invariants():
    g0_valid = G0ArtifactIntegrity()
    assert g0_valid.passed

    # Protected diff
    assert not G0ArtifactIntegrity(protected_diffs=1).passed
    # Corpus count mismatch
    assert not G0ArtifactIntegrity(corpus_tokens=233_996).passed
    # Candidate C update
    assert not G0ArtifactIntegrity(candidate_c_updates=1).passed
    # External approvals not 0/6
    assert not G0ArtifactIntegrity(external_approvals="1/6").passed
    # Production status not STRICT NO-GO
    assert not G0ArtifactIntegrity(production_status="GO").passed
    # Truncation
    assert not G0ArtifactIntegrity(truncations=1).passed
    # Imbalance > 1
    assert not G0ArtifactIntegrity(target_imbalance=2).passed


def test_g1_harness_validity_invariants():
    g1_valid = G1HarnessValidity()
    assert g1_valid.passed

    # Round trip failure
    assert not G1HarnessValidity(round_trip_success=0.99).passed
    # Malformed record accepted
    assert not G1HarnessValidity(malformed_rejection=0.99).passed
    # Leakage
    assert not G1HarnessValidity(leakage_cases=1).passed
    # Continuity failure
    assert not G1HarnessValidity(v10_9_continuity_passed=False).passed


def test_classification_precedence_exact_order():
    assert CLASSIFICATIONS == (
        "INVALID",
        "TASK_CONSTRUCTION",
        "SERIALIZATION_LIMIT",
        "OPTIMIZATION_LIMIT",
        "CAPACITY_LIMIT",
        "REPRESENTATION_LIMIT",
        "CONTEXT_ACCESS_LIMIT",
        "ASSOCIATIVE_BINDING_FAILURE",
        "PARTIAL_ASSOCIATIVE_BINDING",
        "ASSOCIATIVE_BINDING_ESTABLISHED",
    )

    # Earlier overrides later: INVALID overrides everything
    e_invalid = ClassificationEvidence(integrity_ok=False, g0_passed=False, g4_passed=True, g5_passed=True)
    assert classify_binding(e_invalid) == "INVALID"

    # TASK_CONSTRUCTION overrides SERIALIZATION_LIMIT
    e_task = ClassificationEvidence(task_construction_defect=True, corrected_task_passed=True, serialization_limit_passed=True)
    assert classify_binding(e_task) == "TASK_CONSTRUCTION"

    # SERIALIZATION_LIMIT overrides OPTIMIZATION_LIMIT
    e_ser = ClassificationEvidence(serialization_limit_passed=True, optimization_limit_passed=True)
    assert classify_binding(e_ser) == "SERIALIZATION_LIMIT"

    # OPTIMIZATION_LIMIT overrides CAPACITY_LIMIT
    e_opt = ClassificationEvidence(
        optimization_limit_passed=True,
        capacity_limit_passed=True,
        l0_fails_g4_after_fair_grid=True,
        l1_passes_g4=True,
    )
    assert classify_binding(e_opt) == "OPTIMIZATION_LIMIT"

    # CAPACITY_LIMIT overrides REPRESENTATION_LIMIT
    e_cap = ClassificationEvidence(
        capacity_limit_passed=True,
        representation_limit_detected=True,
        l0_fails_g4_after_fair_grid=True,
        l1_passes_g4=True,
    )
    assert classify_binding(e_cap) == "CAPACITY_LIMIT"

    # REPRESENTATION_LIMIT overrides CONTEXT_ACCESS_LIMIT
    e_rep = ClassificationEvidence(representation_limit_detected=True, context_access_limit_detected=True)
    assert classify_binding(e_rep) == "REPRESENTATION_LIMIT"

    # CONTEXT_ACCESS_LIMIT overrides ASSOCIATIVE_BINDING_FAILURE
    e_ctx = ClassificationEvidence(context_access_limit_detected=True, core_binding_failed=True)
    assert classify_binding(e_ctx) == "CONTEXT_ACCESS_LIMIT"

    # PARTIAL_ASSOCIATIVE_BINDING when G4 passes but G5 fails
    e_partial = ClassificationEvidence(g2_passed=True, g3_passed=True, g4_passed=True, g5_passed=False)
    assert classify_binding(e_partial) == "PARTIAL_ASSOCIATIVE_BINDING"

    # ASSOCIATIVE_BINDING_ESTABLISHED when G0 through G5 all pass
    e_est = ClassificationEvidence(g0_passed=True, g1_passed=True, g2_passed=True, g3_passed=True, g4_passed=True, g5_passed=True)
    assert classify_binding(e_est) == "ASSOCIATIVE_BINDING_ESTABLISHED"


# ---------------------------------------------------------------------------
# Amendment-01 Non-Scientific Deterministic Regression Tests
# ---------------------------------------------------------------------------

def test_g6_capacity_effect_pass_fail_thresholds():
    assert round(compute_delta_scale(0.85, 0.70), 2) == 0.15

    # PASS: all conditions met
    g6_pass = G6Scaling(
        l0_passed_g4=False,
        l1_passed_g4=True,
        l0_failed_g4_after_fair_grid=True,
        delta_scale_per_seed={104729: 0.12, 130363: 0.15, 155921: 0.10},
        bootstrap_95_ci=(0.02, 0.18),
        holm_adjusted_p=0.03,
    )
    assert g6_pass.is_capacity_effect is True
    assert g6_pass.passed is True
    assert g6_pass.outcome == "CAPACITY_EFFECT"

    # FAIL: Δscale < 0.10 on one seed
    g6_low_delta = G6Scaling(
        l0_passed_g4=False,
        l1_passed_g4=True,
        l0_failed_g4_after_fair_grid=True,
        delta_scale_per_seed={104729: 0.09, 130363: 0.15, 155921: 0.10},
        bootstrap_95_ci=(0.02, 0.18),
        holm_adjusted_p=0.03,
    )
    assert g6_low_delta.is_capacity_effect is False
    assert g6_low_delta.outcome == "INCONCLUSIVE"

    # FAIL: bootstrap lower bound <= 0
    g6_low_boot = G6Scaling(
        l0_passed_g4=False,
        l1_passed_g4=True,
        l0_failed_g4_after_fair_grid=True,
        delta_scale_per_seed={104729: 0.12, 130363: 0.15, 155921: 0.10},
        bootstrap_95_ci=(0.00, 0.18),
        holm_adjusted_p=0.03,
    )
    assert g6_low_boot.is_capacity_effect is False

    # FAIL: Holm p >= 0.05
    g6_high_p = G6Scaling(
        l0_passed_g4=False,
        l1_passed_g4=True,
        l0_failed_g4_after_fair_grid=True,
        delta_scale_per_seed={104729: 0.12, 130363: 0.15, 155921: 0.10},
        bootstrap_95_ci=(0.02, 0.18),
        holm_adjusted_p=0.05,
    )
    assert g6_high_p.is_capacity_effect is False

    # FAIL: L1 fails G4
    g6_l1_fail = G6Scaling(
        l0_passed_g4=False,
        l1_passed_g4=False,
        l0_failed_g4_after_fair_grid=True,
        delta_scale_per_seed={104729: 0.12, 130363: 0.15, 155921: 0.10},
        bootstrap_95_ci=(0.02, 0.18),
        holm_adjusted_p=0.03,
    )
    assert g6_l1_fail.is_capacity_effect is False

    # FAIL: L0 did not fail G4 after fair grid
    g6_l0_no_fail = G6Scaling(
        l0_passed_g4=False,
        l1_passed_g4=True,
        l0_failed_g4_after_fair_grid=False,
        delta_scale_per_seed={104729: 0.12, 130363: 0.15, 155921: 0.10},
        bootstrap_95_ci=(0.02, 0.18),
        holm_adjusted_p=0.03,
    )
    assert g6_l0_no_fail.is_capacity_effect is False


def test_g6_no_material_scaling_interval_rule():
    # PASS: L0 and L1 both fail G4, CI within [-0.05, 0.05]
    g6_same_fail = G6Scaling(
        l0_passed_g4=False,
        l1_passed_g4=False,
        bootstrap_95_ci=(-0.03, 0.04),
    )
    assert g6_same_fail.is_no_material_scaling is True
    assert g6_same_fail.passed is True
    assert g6_same_fail.outcome == "NO_MATERIAL_SCALING"

    # PASS: L0 and L1 both pass G4, CI within [-0.05, 0.05]
    g6_same_pass = G6Scaling(
        l0_passed_g4=True,
        l1_passed_g4=True,
        bootstrap_95_ci=(-0.05, 0.05),
    )
    assert g6_same_pass.is_no_material_scaling is True
    assert g6_same_pass.passed is True

    # FAIL: CI exceeds upper limit 0.05
    g6_wide_upper = G6Scaling(
        l0_passed_g4=False,
        l1_passed_g4=False,
        bootstrap_95_ci=(-0.02, 0.06),
    )
    assert g6_wide_upper.is_no_material_scaling is False

    # FAIL: CI exceeds lower limit -0.05
    g6_wide_lower = G6Scaling(
        l0_passed_g4=False,
        l1_passed_g4=False,
        bootstrap_95_ci=(-0.06, 0.02),
    )
    assert g6_wide_lower.is_no_material_scaling is False

    # FAIL: L0 and L1 differ in G4 outcome
    g6_diff_outcome = G6Scaling(
        l0_passed_g4=False,
        l1_passed_g4=True,
        bootstrap_95_ci=(-0.02, 0.02),
    )
    assert g6_diff_outcome.is_no_material_scaling is False


def test_g6_inconclusive_case():
    # Neither capacity effect nor no material scaling
    g6_inc = G6Scaling(
        l0_passed_g4=False,
        l1_passed_g4=True,
        l0_failed_g4_after_fair_grid=True,
        delta_scale_per_seed={104729: 0.08, 130363: 0.05},
        bootstrap_95_ci=(-0.02, 0.12),
        holm_adjusted_p=0.20,
    )
    assert g6_inc.is_capacity_effect is False
    assert g6_inc.is_no_material_scaling is False
    assert g6_inc.passed is False
    assert g6_inc.outcome == "INCONCLUSIVE"

    # Fairness violation forces inconclusive even if numbers appear valid
    g6_unfair = G6Scaling(
        l0_passed_g4=False,
        l1_passed_g4=True,
        l0_failed_g4_after_fair_grid=True,
        delta_scale_per_seed={104729: 0.15, 130363: 0.15},
        bootstrap_95_ci=(0.05, 0.20),
        holm_adjusted_p=0.01,
        fairness_violated=True,
    )
    assert g6_unfair.passed is False
    assert g6_unfair.outcome == "INCONCLUSIVE"


def test_serialization_limit_threshold_logic():
    # PASS
    ser_valid = SerializationLimitEvidence(
        alternate_passes_g4=True,
        canonical_fails_g4=True,
        matched_gain_per_seed=[0.10, 0.15, 0.12],
        holm_bootstrap_lower_bound=0.02,
    )
    assert ser_valid.satisfied is True
    e_ser = ClassificationEvidence(serialization_evidence=ser_valid)
    assert classify_binding(e_ser) == "SERIALIZATION_LIMIT"

    # FAIL: gain < 0.10 on one seed
    ser_low_gain = SerializationLimitEvidence(
        alternate_passes_g4=True,
        canonical_fails_g4=True,
        matched_gain_per_seed=[0.09, 0.15, 0.12],
        holm_bootstrap_lower_bound=0.02,
    )
    assert ser_low_gain.satisfied is False

    # FAIL: lower bound <= 0
    ser_zero_bound = SerializationLimitEvidence(
        alternate_passes_g4=True,
        canonical_fails_g4=True,
        matched_gain_per_seed=[0.10, 0.15, 0.12],
        holm_bootstrap_lower_bound=0.0,
    )
    assert ser_zero_bound.satisfied is False

    # FAIL: alternate fails G4
    ser_alt_fail = SerializationLimitEvidence(
        alternate_passes_g4=False,
        canonical_fails_g4=True,
        matched_gain_per_seed=[0.10, 0.15, 0.12],
        holm_bootstrap_lower_bound=0.02,
    )
    assert ser_alt_fail.satisfied is False


def test_optimization_limit_threshold_logic():
    # PASS
    opt_valid = OptimizationLimitEvidence(
        referenced_point_fails_g4=True,
        alternate_cell_passes_g4=True,
        gain_per_seed=[0.10, 0.12, 0.14],
        holm_bootstrap_lower_bound=0.01,
    )
    assert opt_valid.satisfied is True
    e_opt = ClassificationEvidence(optimization_evidence=opt_valid)
    assert classify_binding(e_opt) == "OPTIMIZATION_LIMIT"

    # FAIL: referenced point passed G4 (no optimization failure to explain)
    opt_ref_passed = OptimizationLimitEvidence(
        referenced_point_fails_g4=False,
        alternate_cell_passes_g4=True,
        gain_per_seed=[0.10, 0.12, 0.14],
        holm_bootstrap_lower_bound=0.01,
    )
    assert opt_ref_passed.satisfied is False

    # FAIL: alternate cell fails G4
    opt_alt_failed = OptimizationLimitEvidence(
        referenced_point_fails_g4=True,
        alternate_cell_passes_g4=False,
        gain_per_seed=[0.10, 0.12, 0.14],
        holm_bootstrap_lower_bound=0.01,
    )
    assert opt_alt_failed.satisfied is False


def test_capacity_limit_dependency_on_l0_l1_g4():
    g6_cap = G6Scaling(
        l0_passed_g4=False,
        l1_passed_g4=True,
        l0_failed_g4_after_fair_grid=True,
        delta_scale_per_seed={104729: 0.12, 130363: 0.15},
        bootstrap_95_ci=(0.02, 0.18),
        holm_adjusted_p=0.03,
    )
    assert g6_cap.is_capacity_effect is True

    # Both conditions met -> CAPACITY_LIMIT
    e_pass = ClassificationEvidence(
        g6_evidence=g6_cap,
        l0_fails_g4_after_fair_grid=True,
        l1_passes_g4=True,
    )
    assert classify_binding(e_pass) == "CAPACITY_LIMIT"

    # L0 did NOT fail G4 after fair grid -> cannot be CAPACITY_LIMIT
    e_no_l0_fail = ClassificationEvidence(
        g6_evidence=g6_cap,
        l0_fails_g4_after_fair_grid=False,
        l1_passes_g4=True,
    )
    assert classify_binding(e_no_l0_fail) != "CAPACITY_LIMIT"

    # L1 did NOT pass G4 -> cannot be CAPACITY_LIMIT
    e_no_l1_pass = ClassificationEvidence(
        g6_evidence=g6_cap,
        l0_fails_g4_after_fair_grid=True,
        l1_passes_g4=False,
    )
    assert classify_binding(e_no_l1_pass) != "CAPACITY_LIMIT"


def test_binding_failure_requirement_for_g0_through_g3():
    # G0 fail -> INVALID
    e_g0 = ClassificationEvidence(g0_passed=False, g1_passed=True, g2_passed=True, g3_passed=True, g4_fails_both_l0_and_l1=True)
    assert classify_binding(e_g0) == "INVALID"

    # G1 fail -> INVALID
    e_g1 = ClassificationEvidence(g0_passed=True, g1_passed=False, g2_passed=True, g3_passed=True, g4_fails_both_l0_and_l1=True)
    assert classify_binding(e_g1) == "INVALID"

    # G2 fail -> NOT ASSOCIATIVE_BINDING_FAILURE
    e_g2 = ClassificationEvidence(g0_passed=True, g1_passed=True, g2_passed=False, g3_passed=True, g4_fails_both_l0_and_l1=True)
    assert classify_binding(e_g2) != "ASSOCIATIVE_BINDING_FAILURE"
    assert classify_binding(e_g2) == "INCONCLUSIVE"

    # G3 fail -> NOT ASSOCIATIVE_BINDING_FAILURE
    e_g3 = ClassificationEvidence(g0_passed=True, g1_passed=True, g2_passed=True, g3_passed=False, g4_fails_both_l0_and_l1=True)
    assert classify_binding(e_g3) != "ASSOCIATIVE_BINDING_FAILURE"
    assert classify_binding(e_g3) == "INCONCLUSIVE"

    # G0-G3 all pass and G4 fails across both L0 and L1 -> ASSOCIATIVE_BINDING_FAILURE
    e_valid_failure = ClassificationEvidence(
        g0_passed=True, g1_passed=True, g2_passed=True, g3_passed=True,
        g4_fails_both_l0_and_l1=True, partial_binding_detected=False,
    )
    assert classify_binding(e_valid_failure) == "ASSOCIATIVE_BINDING_FAILURE"


def test_no_unconditional_binding_failure_fallback():
    # If no criteria match and preconditions for binding failure are not met,
    # the classifier must return INCONCLUSIVE rather than fall through to ASSOCIATIVE_BINDING_FAILURE
    e_unmatched = ClassificationEvidence(
        g0_passed=True,
        g1_passed=True,
        g2_passed=False,
        g3_passed=False,
        core_binding_failed=True,
    )
    assert classify_binding(e_unmatched) == "INCONCLUSIVE"

