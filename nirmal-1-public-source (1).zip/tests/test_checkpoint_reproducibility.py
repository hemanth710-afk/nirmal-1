"""
Unit tests for checkpoint reproducibility (tests/test_checkpoint_reproducibility.py).
Verifies:
1. Atomic saving and metadata logging (git commit, tokens, steps, seeds).
2. Deterministic restore: loaded model produces identical forward outputs.
3. Checkpoint rotation correctly enforces max_to_keep.
"""

import tempfile
from pathlib import Path
import pytest
import torch

from nirmal.configuration_nirmal import NirmalConfig
from nirmal.model import NirmalForCausalLM
from training.checkpoint_manager import CheckpointManagerV6


@pytest.fixture
def tiny_model():
    cfg = NirmalConfig(
        vocab_size=64,
        hidden_size=64,
        num_hidden_layers=2,
        num_attention_heads=2,
        num_key_value_heads=1,
        head_dim=32,
        context_length=64,
        intermediate_size=128,
        num_experts=2,
        num_experts_per_tok=1,
        full_attention_interval=2,
    )
    return NirmalForCausalLM(cfg)


def test_checkpoint_atomic_save_and_restore(tiny_model):
    with tempfile.TemporaryDirectory() as tmpdir:
        mgr = CheckpointManagerV6(save_dir=tmpdir, max_to_keep=2)
        opt = torch.optim.AdamW(tiny_model.parameters(), lr=1e-3)

        # Run 1 forward pass
        input_ids = torch.randint(0, 64, (2, 16))
        with torch.no_grad():
            out1 = tiny_model(input_ids=input_ids).logits

        ckpt_dir = mgr.save(
            model=tiny_model,
            step=10,
            total_tokens=1280,
            train_loss=2.5,
            val_loss=2.6,
            optimizer=opt,
            learning_rate=1e-3,
            seed=42,
        )
        assert ckpt_dir.exists()
        assert (ckpt_dir / "model.pt").exists()
        assert (ckpt_dir / "metadata.json").exists()

        # Create new model and load checkpoint
        new_model = NirmalForCausalLM(tiny_model.config)
        meta = mgr.load(ckpt_dir, new_model)
        assert meta.step == 10
        assert meta.total_tokens == 1280

        # Bit-exact forward pass verification
        with torch.no_grad():
            out2 = new_model(input_ids=input_ids).logits
        assert torch.allclose(out1, out2, atol=1e-6)


def test_checkpoint_rotation(tiny_model):
    with tempfile.TemporaryDirectory() as tmpdir:
        mgr = CheckpointManagerV6(save_dir=tmpdir, max_to_keep=2)
        for s in range(1, 5):
            mgr.save(
                model=tiny_model,
                step=s * 10,
                total_tokens=s * 100,
                train_loss=2.0,
                val_loss=2.0,
            )
        # Only latest 2 should exist
        dirs = [d for d in Path(tmpdir).iterdir() if d.is_dir() and d.name.startswith("v6_ckpt_step_")]
        assert len(dirs) == 2
        names = sorted([d.name for d in dirs])
        assert "v6_ckpt_step_30" in names[0]
        assert "v6_ckpt_step_40" in names[1]
