"""
Unit tests for training/data_pipeline.py.
Verifies:
1. DataExample schema validation and serialization
2. Text normalization (NFKC, whitespace collapsing)
3. Deterministic SHA-256 hash generation
4. Provenance tracking and JSONL round-trip
"""

import tempfile
from pathlib import Path
import pytest

from training.data_pipeline import (
    DataExample,
    DataPipeline,
    normalize_text,
    compute_sha256,
    compute_structural_fingerprint,
)


def test_data_example_schema():
    pipeline = DataPipeline(seed=42)
    ex = pipeline.create_example(
        domain="A_language_modeling",
        text="System telemetry: Valve 1 nominal.",
        source="unit_test",
        split="train",
        metadata={"unit": 1},
    )
    assert ex.id.startswith("A_language_modeling_")
    assert ex.domain == "A_language_modeling"
    assert ex.split == "train"
    assert len(ex.hash) == 64
    assert ex.generator_version == "v6.0"

    d = ex.to_dict()
    restored = DataExample.from_dict(d)
    assert restored.id == ex.id
    assert restored.hash == ex.hash
    assert restored.metadata == {"unit": 1}


def test_normalize_text():
    raw = "  System   telemetry  report:\r\n  Valve \t A1  nominal.  \n\n"
    norm = normalize_text(raw)
    assert norm == "System telemetry report:\nValve A1 nominal."
    assert "\r" not in norm


def test_sha256_deterministic():
    text1 = "Valve A1 nominal."
    text2 = "  Valve   A1  nominal.  \n"
    h1 = compute_sha256(text1)
    h2 = compute_sha256(text2)
    assert h1 == h2  # Due to normalization


def test_structural_fingerprint():
    t1 = "State: {valve_1: 45}. Action: act_1. Next: {valve_1: 55}."
    t2 = "State: {valve_1: 99}. Action: act_1. Next: {valve_1: 109}."
    fp1 = compute_structural_fingerprint(t1)
    fp2 = compute_structural_fingerprint(t2)
    # Different numbers should map to the same structural fingerprint (<NUM>)
    assert fp1 == fp2


def test_jsonl_export_and_load():
    pipeline = DataPipeline(seed=42)
    examples = [
        pipeline.create_example(domain="A", text=f"Item {i}", source="test")
        for i in range(5)
    ]
    with tempfile.TemporaryDirectory() as tmpdir:
        jsonl_path = Path(tmpdir) / "dataset.jsonl"
        pipeline.export_dataset_jsonl(examples, jsonl_path)
        assert jsonl_path.exists()

        loaded = pipeline.load_dataset_jsonl(jsonl_path)
        assert len(loaded) == 5
        assert [ex.id for ex in loaded] == [ex.id for ex in examples]
