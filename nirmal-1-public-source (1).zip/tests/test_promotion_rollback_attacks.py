import pytest
import json
from pathlib import Path
from training.acquisition.promotion_gate import RealSourcePromotionGate, PromotionSecurityError, DATA_DIR

@pytest.fixture
def gate(tmp_path):
    return RealSourcePromotionGate(promotion_dir=tmp_path/"promotion", pilot_dir=tmp_path/"pilot", evidence_dir=tmp_path/"evidence")

def test_rollback_invalid_id(gate):
    with pytest.raises(KeyError, match="not found in registry"):
        gate.rollback_promotion("invalid_id_123")

def test_rollback_production_shard(gate, tmp_path):
    registry_dir = tmp_path / "promotion" / "verified"
    registry_dir.mkdir(parents=True, exist_ok=True)
    
    prod_file = DATA_DIR / "shards" / "prod.bin"
    
    registry = {
        "promotions": {
            "attack_id": {
                "source_id": "test_source",
                "promoted_shard_path": str(prod_file),
                "promoted_manifest_path": str(tmp_path / "manifest.json")
            }
        }
    }
    
    with open(registry_dir / "promoted_registry.json", "w") as f:
        json.dump(registry, f)
        
    with pytest.raises(PromotionSecurityError, match="CRITICAL SAFETY VIOLATION"):
        gate.rollback_promotion("attack_id")
