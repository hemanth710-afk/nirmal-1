"""
NIRMAL-1 V8.7: TEST SUITE FOR PILOT FAIL-CLOSED BEHAVIORS (PHASE 6, 10)

Verifies:
1. Pilot execution with unapproved/ineligible source fails closed (PilotSecurityError).
2. Attempted write to production directory (data/shards) fails closed (PilotSecurityError).
3. Corrupt/malformed document fails closed (PilotIntegrityError).
4. Secret credential detection rejects document into accounting.
5. Benchmark contamination detection rejects document into accounting.
6. Exact duplicate detection rejects document into accounting.
7. Atomic cleanup of staging files upon completion or interruption.
"""

from pathlib import Path
import pytest

from training.acquisition.pilot_adapter import (
    WikipediaPilotAdapter,
    PilotSecurityError,
    PilotIntegrityError,
    FORBIDDEN_DIRS,
)
from training.acquisition.pilot_accounting import AccountingConservationError


@pytest.fixture
def pilot_adapter(tmp_path):
    staging_dir = tmp_path / "staging"
    shards_dir = tmp_path / "shards"
    manifests_dir = tmp_path / "manifests"
    return WikipediaPilotAdapter(
        staging_dir=staging_dir,
        shards_dir=shards_dir,
        manifests_dir=manifests_dir,
    )


class TestPilotFailClosed:
    """Test suite for adversarial failure injection in bounded pilot."""

    def test_unapproved_ineligible_source_fails_closed(self, tmp_path):
        """A source not marked PILOT_ELIGIBLE (e.g. fineweb_edu_permissive) fails closed."""
        adapter = WikipediaPilotAdapter(
            staging_dir=tmp_path / "staging",
            shards_dir=tmp_path / "shards",
            manifests_dir=tmp_path / "manifests",
        )
        # Point to an ineligible source
        adapter.source_id = "fineweb_edu_permissive"

        with pytest.raises(PilotSecurityError) as exc:
            adapter.prepare_pilot()
        assert "NOT PILOT_ELIGIBLE" in str(exc.value)

    def test_attempted_write_to_production_directory_fails_closed(self, pilot_adapter):
        """Attempting to direct pilot shard output to data/shards raises PilotSecurityError."""
        for forbidden in FORBIDDEN_DIRS:
            with pytest.raises(PilotSecurityError) as exc:
                pilot_adapter.verify_destination_safety(forbidden)
            assert "CRITICAL SAFETY VIOLATION" in str(exc.value)

    def test_corrupt_malformed_document_fails_closed(self, pilot_adapter):
        """Record missing required fields (id or text) raises PilotIntegrityError."""
        malformed_records = [
            {"id": "doc_1", "text": "Valid text"},
            {"id": "", "text": "Missing ID"},  # Malformed!
        ]
        with pytest.raises(PilotIntegrityError) as exc:
            pilot_adapter.verify_pilot(malformed_records, raw_bytes=100)
        assert "Malformed record in pilot" in str(exc.value)

    def test_secret_credential_detected_and_rejected(self, pilot_adapter):
        """Record containing a live private key is rejected by CodeSafetyScanner into accounting."""
        records_with_secret = [
            {
                "id": "wiki_secret_1",
                "title": "Secret Doc",
                "revision_id": "rev_sec_1",
                "timestamp": "2026-09-08T12:00:00Z",
                "contributor": "Attacker",
                "url": "https://en.wikipedia.org/wiki/Secret",
                "license": "CC-BY-SA-4.0",
                # Hardcoded private key header
                "text": "The server configuration contains a private key:\n-----BEGIN RSA PRIVATE KEY-----\nMIIEowIBAAKCAQEA0Y1v\n-----END RSA PRIVATE KEY-----",
            }
        ]
        result = pilot_adapter.finalize_pilot(records_override=records_with_secret)
        assert result.documents_discovered == 1
        assert result.documents_accepted == 0
        assert result.documents_rejected == 1
        assert result.security_removed == 1

    def test_benchmark_contamination_detected_and_rejected(self, pilot_adapter):
        """Record containing indexed evaluation probe is rejected into accounting."""
        records_with_probe = [
            {
                "id": "wiki_probe_1",
                "title": "Contaminated Benchmark Probe",
                "revision_id": "rev_probe_1",
                "timestamp": "2026-09-08T12:00:00Z",
                "contributor": "Attacker",
                "url": "https://en.wikipedia.org/wiki/Probe",
                "license": "CC-BY-SA-4.0",
                # Indexed benchmark probe text from AGI_COMPOSITE_IN_REPO
                "text": "This article discusses the needle_key_target_uuid_4815162342 hidden within long horizon reasoning evaluation benchmarks.",
            }
        ]
        result = pilot_adapter.finalize_pilot(records_override=records_with_probe)
        assert result.documents_discovered == 1
        assert result.documents_accepted == 0
        assert result.documents_rejected == 1
        assert result.contamination_removed == 1

    def test_exact_duplicate_document_detected_and_rejected(self, pilot_adapter):
        """Duplicate documents in pilot are rejected by GlobalExactDeduplicator."""
        duplicate_records = [
            {
                "id": "wiki_dup_1",
                "title": "Doc 1",
                "revision_id": "rev_1",
                "timestamp": "2026-09-08T12:00:00Z",
                "contributor": "Editor",
                "url": "https://en.wikipedia.org/wiki/Doc1",
                "license": "CC-BY-SA-4.0",
                "text": "Albert Einstein developed the theory of relativity, one of the two pillars of modern physics alongside quantum mechanics.",
            },
            {
                "id": "wiki_dup_2",
                "title": "Doc 2 (Exact Duplicate)",
                "revision_id": "rev_2",
                "timestamp": "2026-09-08T12:05:00Z",
                "contributor": "Editor",
                "url": "https://en.wikipedia.org/wiki/Doc2",
                "license": "CC-BY-SA-4.0",
                "text": "Albert Einstein developed the theory of relativity, one of the two pillars of modern physics alongside quantum mechanics.",
            },
        ]
        result = pilot_adapter.finalize_pilot(records_override=duplicate_records)
        assert result.documents_discovered == 2
        assert result.documents_accepted == 1
        assert result.documents_rejected == 1
        assert result.dedup_removed == 1

    def test_staging_cleaned_up_atomically(self, pilot_adapter):
        """After finalize_pilot, scratch staging files are deleted."""
        result = pilot_adapter.finalize_pilot()
        assert result.status == "SUCCESS"
        # Staging directory must contain 0 remaining .part or raw json files
        remaining_staging = list(pilot_adapter.staging_dir.glob("*"))
        assert len(remaining_staging) == 0
