import pytest
from pathlib import Path
from training.acquisition.capability_mixture import CapabilityMixturePlanner

@pytest.fixture
def planner():
    return CapabilityMixturePlanner(Path("data/capability_taxonomy.json"))

def test_capability_accounting(planner):
    planner.add_document({
        "token_count": 100,
        "source_id": "src1",
        "capability_labels": ["programming"],
        "quality_score": "HIGH"
    })
    planner.add_document({
        "token_count": 50,
        "source_id": "src2",
        "capability_labels": ["programming", "mathematical reasoning"],
        "quality_score": "HIGH"
    })
    
    report = planner.get_report()
    assert report["total_tokens"] == 150
    assert report["tokens_by_capability"]["programming"] == 150
    assert report["tokens_by_capability"]["mathematical reasoning"] == 50

def test_percentage_conservation(planner):
    planner.add_document({
        "token_count": 100,
        "source_id": "src1",
        "capability_labels": ["UNKNOWN"]
    })
    
    report = planner.get_report()
    assert report["UNKNOWN_SHARE"] == 100.0
    assert report["AGI_ORIENTED_SHARE"] == 0.0

def test_source_concentration_detection(planner):
    planner.add_document({"token_count": 900, "source_id": "src1"})
    planner.add_document({"token_count": 100, "source_id": "src2"})
    
    report = planner.get_report()
    warnings = report["warnings"]
    assert any("Excessive single-source dependence: src1" in w for w in warnings)
