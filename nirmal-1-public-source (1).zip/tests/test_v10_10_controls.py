"""V10.10-SPEC-AMENDMENT-01: Matched causal-control and counterfactual tests."""

from collections import Counter

from training.evaluation.v10_10_binding_harness import (
    BAG_TOKEN,
    CONTROLS,
    DEVELOPMENT_SEEDS,
    FILL_TOKEN,
    KEY_ATOM_COUNT,
    KEY_ATOM_START,
    KEY_TOKENS,
    LEVELS,
    VALUE_ATOM_COUNT,
    VALUE_ATOM_START,
    VALUE_TOKENS,
    BindingBenchmarkGenerator,
    validate_control_set,
)


def support_data_tokens(ep):
    return [
        t for t in ep.input_ids[:ep.query_index]
        if KEY_ATOM_START <= t < KEY_ATOM_START + KEY_ATOM_COUNT
        or VALUE_ATOM_START <= t < VALUE_ATOM_START + VALUE_ATOM_COUNT
    ]


def test_random_derangement_changes_queried_value():
    gen = BindingBenchmarkGenerator()
    for i in range(50):
        cs = gen.generate_control_set("B2", "development", DEVELOPMENT_SEEDS[0], i)
        assert cs["random_deranged"].counterfactual_value != cs.base.target
        assert Counter(support_data_tokens(cs["random_deranged"])) == Counter(support_data_tokens(cs["correct"]))


def test_targeted_wrong_is_a_two_value_swap_and_tracks_lure():
    gen = BindingBenchmarkGenerator()
    for i in range(50):
        cs = gen.generate_control_set("B2", "development", DEVELOPMENT_SEEDS[0], i)
        wrong = cs["targeted_wrong"]
        assert wrong.counterfactual_value != cs.base.target
        assert Counter(support_data_tokens(wrong)) == Counter(support_data_tokens(cs["correct"]))


def test_primary_absent_is_unpaired_bag_and_secondary_is_placeholder():
    gen = BindingBenchmarkGenerator()
    for level in ("B1", "B2", "B3", "B4"):
        cs = gen.generate_control_set(level, "development", DEVELOPMENT_SEEDS[0], 0, "S1", "Q1", True)
        assert validate_control_set(cs)["valid"]

        # Primary absent (unpaired bag) contains BAG_TOKEN and exact data multiset
        unpaired_ids = cs["absent_unpaired"].input_ids[:cs["absent_unpaired"].query_index]
        assert BAG_TOKEN in unpaired_ids
        assert Counter(support_data_tokens(cs["absent_unpaired"])) == Counter(support_data_tokens(cs["correct"]))

        # Secondary absent (placeholder) has all data atoms replaced with FILL_TOKEN
        placeholder_ids = cs["absent_placeholder"].input_ids[:cs["absent_placeholder"].query_index]
        assert not any(
            KEY_ATOM_START <= t < KEY_ATOM_START + KEY_ATOM_COUNT
            or VALUE_ATOM_START <= t < VALUE_ATOM_START + VALUE_ATOM_COUNT
            for t in placeholder_ids
        )


def test_length_and_query_position_matching_across_all_controls():
    gen = BindingBenchmarkGenerator()
    for level in LEVELS:
        cs = gen.generate_control_set(level, "development", DEVELOPMENT_SEEDS[0], 1, "S1", "Q1", True)
        assert set(cs.episodes) == set(CONTROLS)
        lengths = {len(ep.input_ids) for ep in cs.episodes.values()}
        query_indices = {ep.query_index for ep in cs.episodes.values()}
        answer_indices = {ep.answer_index for ep in cs.episodes.values()}
        assert len(lengths) == 1
        assert len(query_indices) == 1
        assert len(answer_indices) == 1


def test_invalid_control_detected_fail_closed():
    gen = BindingBenchmarkGenerator()
    cs = gen.generate_control_set("B2", "development", DEVELOPMENT_SEEDS[0], 0)
    # Tamper with counterfactual
    cs.episodes["random_deranged"].counterfactual_value = cs.base.target
    audit = validate_control_set(cs)
    assert not audit["valid"]
    assert "random_query_value_unchanged" in audit["errors"]
