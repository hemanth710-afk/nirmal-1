import pytest
import json
from pathlib import Path
from training.acquisition.promotion_gate import RealSourcePromotionGate, PromotionSecurityError

@pytest.fixture
def setup_gate(tmp_path):
    gate = RealSourcePromotionGate(promotion_dir=tmp_path/"promotion", pilot_dir=tmp_path/"pilot", evidence_dir=tmp_path/"evidence")
    
    pilot_dir = tmp_path / "pilot"
    manifest_dir = pilot_dir / "manifests"
    manifest_dir.mkdir(parents=True, exist_ok=True)
    shard_dir = pilot_dir / "shards"
    shard_dir.mkdir(parents=True, exist_ok=True)
    prov_dir = pilot_dir / "provenance"
    prov_dir.mkdir(parents=True, exist_ok=True)
    
    with open(shard_dir / "test.bin", "wb") as f:
        f.write(b"00")
        
    manifest = {
        "source_id": "test_source",
        "state": "PILOT_ELIGIBLE",
        "cryptographic_hashes": {
            "final_shard_sha256": "81143896dfa1c3e1db6f52e259b15e2193556c4d7e98d5c9071c713b194fb847"
        },
        "shard_path": str(shard_dir / "test.bin")
    }
    with open(manifest_dir / "test_source_pilot_manifest.json", "w") as f:
        json.dump(manifest, f)
        
    return gate, tmp_path, prov_dir

def test_local_data_spoofing(setup_gate):
    gate, tmp_path, prov_dir = setup_gate
    
    with open(prov_dir / "prov_test_source.jsonl", "w") as f:
        json.dump({"doc_id": "doc1", "source_revision": "1", "license": "CC-BY-SA 4.0", "origin_type": "LOCAL_FIXTURE"}, f)
        f.write("\n")
        
    result = gate.promote_source("test_source")
    assert result.verdict == "REJECTED" or result.state == "REJECTED" or result.state == "PROMOTION_PENDING"

def test_missing_origin_type(setup_gate):
    gate, tmp_path, prov_dir = setup_gate
    
    with open(prov_dir / "prov_test_source.jsonl", "w") as f:
        json.dump({"doc_id": "doc1", "source_revision": "1", "license": "CC-BY-SA 4.0"}, f)
        f.write("\n")
        
    result = gate.promote_source("test_source")
