"""
Unit tests for autoregressive text generation and sampling strategies.
"""

import torch
import pytest

from nirmal.configuration_nirmal import NirmalConfig
from nirmal.model import NirmalForCausalLM
from nirmal.generation import NirmalGenerator


def test_greedy_generation_length_and_determinism():
    """Verify greedy generation produces exact requested length and is deterministic."""
    config = NirmalConfig(
        vocab_size=100,
        hidden_size=128,
        num_hidden_layers=2,
        num_attention_heads=2,
        head_dim=64,
        num_experts=2,
        num_experts_per_tok=1,
    )
    model = NirmalForCausalLM(config)
    generator = NirmalGenerator(model)

    prompt = torch.tensor([[10, 20, 30]])
    max_new_tokens = 5

    out1 = generator.generate(prompt, max_new_tokens=max_new_tokens, temperature=0.0, use_cache=True)
    out2 = generator.generate(prompt, max_new_tokens=max_new_tokens, temperature=0.0, use_cache=True)

    assert out1.shape == (1, 3 + max_new_tokens)
    assert torch.equal(out1, out2)


def test_cache_vs_uncached_generation_equivalence():
    """Verify greedy generation produces identical tokens with or without hybrid cache."""
    config = NirmalConfig(
        vocab_size=100,
        hidden_size=128,
        num_hidden_layers=3,
        num_attention_heads=2,
        head_dim=64,
        full_attention_interval=2,
        num_experts=2,
        num_experts_per_tok=1,
    )
    model = NirmalForCausalLM(config)
    generator = NirmalGenerator(model)

    prompt = torch.tensor([[5, 12, 18]])
    max_new_tokens = 4

    out_cached = generator.generate(prompt, max_new_tokens=max_new_tokens, temperature=0.0, use_cache=True)
    out_uncached = generator.generate(prompt, max_new_tokens=max_new_tokens, temperature=0.0, use_cache=False)

    assert torch.equal(out_cached, out_uncached)


def test_stop_token_termination():
    """Verify generation halts when encountering EOS token."""
    config = NirmalConfig(
        vocab_size=50,
        hidden_size=128,
        num_hidden_layers=2,
        num_attention_heads=2,
        head_dim=64,
    )
    model = NirmalForCausalLM(config)
    generator = NirmalGenerator(model)

    prompt = torch.tensor([[1, 2]])
    # Force EOS token by generating with greedy and selecting a token that appears
    out_first = generator.generate(prompt, max_new_tokens=3, temperature=0.0)
    target_eos = out_first[0, -1].item()

    out_stopped = generator.generate(prompt, max_new_tokens=10, temperature=0.0, eos_token_id=target_eos)
    assert out_stopped[0, -1].item() == target_eos
    assert out_stopped.shape[-1] <= prompt.shape[-1] + 3


def test_batched_generation_eos_locking():
    """Regression test for Issue 5: Finished sequences in a batch are locked and don't produce new random tokens."""
    torch.manual_seed(1)
    config = NirmalConfig(
        vocab_size=50,
        hidden_size=128,
        num_hidden_layers=2,
        num_attention_heads=2,
        head_dim=64,
        num_experts=2,
        num_experts_per_tok=1,
    )
    model = NirmalForCausalLM(config)
    generator = NirmalGenerator(model)

    eos_id = 9
    pad_id = 0
    # Batch of 2
    prompt = torch.tensor([[1, 2], [3, 4]])

    out = generator.generate(
        prompt,
        max_new_tokens=6,
        temperature=1.0,
        eos_token_id=eos_id,
        pad_token_id=pad_id,
        use_cache=True,
    )
    assert out.shape[0] == 2
    assert out.shape[1] == 8

    # For each row, after the first EOS token, all subsequent tokens must be pad_id
    for b in range(2):
        row = out[b].tolist()
        if eos_id in row:
            eos_idx = row.index(eos_id)
            for after in row[eos_idx + 1 :]:
                assert after == pad_id


def test_top_p_filtering_clean():
    """Regression test for Issue 11: top_p filtering cleanly masks low probability tokens."""
    from nirmal.generation import top_k_top_p_filtering

    logits = torch.tensor([[10.0, 5.0, 1.0, -10.0]])
    filtered = top_k_top_p_filtering(logits, top_p=0.8)
    # The highest logit (10.0) takes > 99% probability mass, so lower ones should be -inf
    assert filtered[0, 0] == 10.0
    assert filtered[0, 2] == float("-inf")
    assert filtered[0, 3] == float("-inf")
