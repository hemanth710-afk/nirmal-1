"""Tests for V10.8 Benchmark Immutability and Manifest Verification."""

import hashlib
from pathlib import Path

import pytest

BENCHMARK_DIR = Path("experiments/v10_8/benchmark")
MANIFEST_FILE = BENCHMARK_DIR / "MANIFEST.sha256"


def test_manifest_and_files_exist():
    assert BENCHMARK_DIR.exists(), "Benchmark directory missing!"
    assert MANIFEST_FILE.exists(), "MANIFEST.sha256 missing!"
    assert (BENCHMARK_DIR / "benchmark_data.pt").exists(), "benchmark_data.pt missing!"
    assert (BENCHMARK_DIR / "metadata.json").exists(), "metadata.json missing!"


def test_benchmark_hashes_match_manifest():
    lines = MANIFEST_FILE.read_text(encoding="utf-8").strip().splitlines()
    assert len(lines) >= 3, "Manifest must contain at least 3 tracked files."

    for line in lines:
        parts = line.strip().split()
        expected_hash = parts[0]
        fname = parts[1]

        target_file = BENCHMARK_DIR / fname
        if not target_file.exists():
            # Check if it's the builder script in scripts/
            target_file = Path("scripts") / fname
        assert target_file.exists(), f"Tracked file {fname} not found!"

        actual_hash = hashlib.sha256(target_file.read_bytes()).hexdigest()
        assert actual_hash == expected_hash, f"Hash mismatch for {fname}! Expected {expected_hash}, got {actual_hash}"


def test_tamper_detection():
    """Verify that simulating file tampering raises an integrity assertion."""
    dummy_data = b"tampered benchmark payload"
    dummy_hash = hashlib.sha256(dummy_data).hexdigest()
    expected_original = "0000000000000000000000000000000000000000000000000000000000000000"

    assert dummy_hash != expected_original
