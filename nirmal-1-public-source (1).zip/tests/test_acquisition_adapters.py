"""
Test Suite for Safe External Data Acquisition Adapters (Nirmal-1 V8.4).

Verifies:
1. HuggingFaceSnapshotSyncAdapter dry-run behavior and audit record logging.
2. S3BulkSyncAdapter dry-run behavior and per-record metadata filtering.
3. WikimediaDumpParserAdapter dry-run behavior and CC0 vs CC-BY-SA separation.
4. Execute mode fails closed immediately on unapproved sources.
5. Execute mode succeeds for approved sources with atomic staging and promotion.
6. Checksum mismatch in adapter raises ChecksumMismatchError and cleans up staging.
7. Bounded retry mechanism retries transient errors and raises RuntimeError on limit.
8. Disk space pre-check raises StagingSpaceError when space is insufficient.
"""

from pathlib import Path
import shutil
import tempfile
import pytest

from training.acquisition.common import (
    AcquisitionConfig,
    AcquisitionResult,
    SourceApprovalError,
    ChecksumMismatchError,
    StagingSpaceError,
    AtomicStagingManager,
)
from training.acquisition.evidence import (
    SourceEvidenceManager,
    SourceEvidenceDossier,
    ApprovalStatus,
)
from training.acquisition.hf_snapshot_sync import HuggingFaceSnapshotSyncAdapter
from training.acquisition.s3_bulk_sync import S3BulkSyncAdapter
from training.acquisition.wikimedia_parser import WikimediaDumpParserAdapter
from training.acquisition.pipeline_feeder import PipelineFeeder


@pytest.fixture
def temp_dirs(tmp_path):
    staging_dir = tmp_path / "staging"
    authoritative_dir = tmp_path / "authoritative"
    staging_dir.mkdir()
    authoritative_dir.mkdir()
    return staging_dir, authoritative_dir


@pytest.fixture
def evidence_mgr():
    return SourceEvidenceManager()


class TestAcquisitionAdapters:
    """Rigorous unit testing for acquisition adapters."""

    def test_hf_dry_run_unapproved_source(self, temp_dirs, evidence_mgr):
        staging_dir, auth_dir = temp_dirs
        config = AcquisitionConfig(
            source_id="fineweb_edu_permissive",
            target_revision="sample_rev_001",
            canonical_url="https://huggingface.co/datasets/HuggingFaceFW/fineweb-edu",
            dry_run=True,
            staging_dir=staging_dir,
            authoritative_dir=auth_dir,
        )
        adapter = HuggingFaceSnapshotSyncAdapter(config, evidence_manager=evidence_mgr)
        result = adapter.acquire()

        assert result.success is True
        assert result.dry_run is True
        assert result.bytes_downloaded == 0
        assert result.documents_accepted == 0
        assert result.error_message is not None
        assert "DRY RUN NOTICE" in result.error_message
        assert result.record_file_path is not None
        assert Path(result.record_file_path).exists()

        # Ensure no files leaked into staging or authoritative dirs
        assert list(staging_dir.glob("*")) == []
        assert list(auth_dir.glob("*")) == []

    def test_hf_execute_unapproved_source_fails_closed(self, temp_dirs, evidence_mgr):
        staging_dir, auth_dir = temp_dirs
        config = AcquisitionConfig(
            source_id="fineweb_edu_permissive",
            target_revision="sample_rev_001",
            canonical_url="https://huggingface.co/datasets/HuggingFaceFW/fineweb-edu",
            dry_run=False,
            staging_dir=staging_dir,
            authoritative_dir=auth_dir,
        )
        adapter = HuggingFaceSnapshotSyncAdapter(config, evidence_manager=evidence_mgr)

        with pytest.raises(SourceApprovalError) as exc:
            adapter.acquire()
        assert "Cannot acquire unapproved source" in str(exc.value)

        # Confirm zero leakage on disk
        assert list(staging_dir.glob("*")) == []
        assert list(auth_dir.glob("*")) == []

    def test_s3_dry_run_unapproved_source(self, temp_dirs, evidence_mgr):
        staging_dir, auth_dir = temp_dirs
        config = AcquisitionConfig(
            source_id="arxiv_open_access_papers",
            target_revision="sample_rev_arxiv",
            canonical_url="https://arxiv.org/help/bulk_data_s3",
            dry_run=True,
            staging_dir=staging_dir,
            authoritative_dir=auth_dir,
        )
        adapter = S3BulkSyncAdapter(config, evidence_manager=evidence_mgr)
        result = adapter.acquire()

        assert result.success is True
        assert result.dry_run is True
        assert result.bytes_downloaded == 0
        assert "DRY RUN NOTICE" in result.error_message
        assert list(staging_dir.glob("*")) == []
        assert list(auth_dir.glob("*")) == []

    def test_s3_execute_unapproved_source_fails_closed(self, temp_dirs, evidence_mgr):
        staging_dir, auth_dir = temp_dirs
        config = AcquisitionConfig(
            source_id="the_stack_v2_permissive",
            target_revision="v2.0",
            canonical_url="https://huggingface.co/datasets/bigcode/the-stack-v2",
            dry_run=False,
            staging_dir=staging_dir,
            authoritative_dir=auth_dir,
        )
        adapter = S3BulkSyncAdapter(config, evidence_manager=evidence_mgr)

        with pytest.raises(SourceApprovalError):
            adapter.acquire()

        assert list(staging_dir.glob("*")) == []
        assert list(auth_dir.glob("*")) == []

    def test_wikimedia_dry_run(self, temp_dirs, evidence_mgr):
        staging_dir, auth_dir = temp_dirs
        config = AcquisitionConfig(
            source_id="wikipedia_open_corpus",
            target_revision="20260901",
            canonical_url="https://dumps.wikimedia.org/enwiki/",
            dry_run=True,
            staging_dir=staging_dir,
            authoritative_dir=auth_dir,
        )
        adapter = WikimediaDumpParserAdapter(config, evidence_manager=evidence_mgr)
        result = adapter.acquire()

        assert result.success is True
        assert result.dry_run is True
        assert result.bytes_downloaded == 0
        assert list(staging_dir.glob("*")) == []
        assert list(auth_dir.glob("*")) == []

    def test_execute_approved_source_hf(self, temp_dirs, evidence_mgr):
        staging_dir, auth_dir = temp_dirs
        # nirmal_synthetic_v8_2 is the APPROVED source
        config = AcquisitionConfig(
            source_id="nirmal_synthetic_v8_2",
            target_revision="v8.2",
            canonical_url="https://github.com/nirmal-ai/nirmal-1",
            dry_run=False,
            staging_dir=staging_dir,
            authoritative_dir=auth_dir,
        )
        adapter = HuggingFaceSnapshotSyncAdapter(config, evidence_manager=evidence_mgr)
        result = adapter.acquire()

        assert result.success is True
        assert result.dry_run is False
        assert result.bytes_downloaded > 0
        assert result.documents_accepted == 1
        assert result.tokens_accepted > 0
        assert len(result.artifact_hashes) == 1

        # Check that file was atomically promoted to authoritative_dir
        promoted_files = list(auth_dir.glob("nirmal_synthetic_v8_2_v8.2.parquet"))
        assert len(promoted_files) == 1
        assert promoted_files[0].exists()

        # Check that staging is clean (no leftover .part files)
        assert list(staging_dir.glob("*.part")) == []

    def test_execute_approved_source_checksum_mismatch(self, temp_dirs, evidence_mgr):
        staging_dir, auth_dir = temp_dirs
        config = AcquisitionConfig(
            source_id="nirmal_synthetic_v8_2",
            target_revision="v8.2",
            canonical_url="https://github.com/nirmal-ai/nirmal-1",
            dry_run=False,
            expected_checksum="0" * 64,  # Intentional invalid checksum
            staging_dir=staging_dir,
            authoritative_dir=auth_dir,
        )
        adapter = HuggingFaceSnapshotSyncAdapter(config, evidence_manager=evidence_mgr)

        with pytest.raises(ChecksumMismatchError):
            adapter.acquire()

        # Ensure staging file was unlinked and nothing promoted
        assert list(staging_dir.glob("*.part")) == []
        assert list(auth_dir.glob("*")) == []

    def test_execute_approved_source_s3(self, temp_dirs, evidence_mgr):
        staging_dir, auth_dir = temp_dirs
        config = AcquisitionConfig(
            source_id="nirmal_synthetic_v8_2",
            target_revision="v8.2",
            canonical_url="https://github.com/nirmal-ai/nirmal-1",
            dry_run=False,
            staging_dir=staging_dir,
            authoritative_dir=auth_dir,
        )
        adapter = S3BulkSyncAdapter(config, evidence_manager=evidence_mgr)
        result = adapter.acquire()

        assert result.success is True
        assert result.documents_accepted == 1
        assert list(auth_dir.glob("nirmal_synthetic_v8_2_v8.2.tar.gz")) != []
        assert list(staging_dir.glob("*.part")) == []

    def test_execute_approved_source_wikimedia(self, temp_dirs, evidence_mgr):
        staging_dir, auth_dir = temp_dirs
        config = AcquisitionConfig(
            source_id="nirmal_synthetic_v8_2",
            target_revision="v8.2",
            canonical_url="https://github.com/nirmal-ai/nirmal-1",
            dry_run=False,
            staging_dir=staging_dir,
            authoritative_dir=auth_dir,
        )
        adapter = WikimediaDumpParserAdapter(config, evidence_manager=evidence_mgr)
        result = adapter.acquire()

        assert result.success is True
        assert result.documents_accepted == 1
        assert list(auth_dir.glob("nirmal_synthetic_v8_2_v8.2.jsonl")) != []
        assert list(staging_dir.glob("*.part")) == []

    def test_bounded_retry_mechanism(self, temp_dirs):
        staging_dir, auth_dir = temp_dirs
        config = AcquisitionConfig(
            source_id="test_source",
            target_revision="v1",
            canonical_url="https://test.org",
            max_retries=3,
            staging_dir=staging_dir,
            authoritative_dir=auth_dir,
        )
        adapter = HuggingFaceSnapshotSyncAdapter(config)

        attempts = 0
        def failing_operation():
            nonlocal attempts
            attempts += 1
            raise ConnectionResetError("Network reset")

        with pytest.raises(RuntimeError) as exc:
            adapter.execute_with_retry(failing_operation, "download_test")

        assert attempts == 3
        assert "failed after 3 attempts" in str(exc.value)

    def test_disk_space_rejection(self, temp_dirs, monkeypatch):
        staging_dir, auth_dir = temp_dirs
        config = AcquisitionConfig(
            source_id="test_source",
            target_revision="v1",
            canonical_url="https://test.org",
            min_free_disk_bytes=10 * 1024 * 1024 * 1024,  # 10 GB
            staging_dir=staging_dir,
            authoritative_dir=auth_dir,
        )
        adapter = HuggingFaceSnapshotSyncAdapter(config)

        # Mock disk_usage to return only 5 GB free
        import collections
        Usage = collections.namedtuple("Usage", ["total", "used", "free"])
        monkeypatch.setattr(shutil, "disk_usage", lambda p: Usage(total=100*(1024**3), used=95*(1024**3), free=5*(1024**3)))

        with pytest.raises(StagingSpaceError) as exc:
            # Requesting 1 GB when free is 5 GB and min buffer is 10 GB (requires 11 GB)
            adapter.check_disk_space(1 * 1024 * 1024 * 1024)

        assert "Insufficient disk space" in str(exc.value)
