import pytest
import torch
import numpy as np
from scripts.run_capability_eval import CapabilityEvaluator, set_seed

def test_equal_token_budgets():
    evaluator = CapabilityEvaluator()
    baseline = evaluator.generate_dummy_dataset(1000)
    balanced = evaluator.generate_dummy_dataset(1000)
    curriculum = evaluator.generate_dummy_dataset(1000)
    assert len(baseline) == len(balanced) == len(curriculum) == 1000

def test_split_isolation():
    evaluator = CapabilityEvaluator()
    suite = evaluator.get_eval_suite()
    # Check that OOD transfer test is isolated
    assert "OOD transfer" in suite
    assert len(suite["OOD transfer"]) > 0

def test_equal_architecture():
    evaluator = CapabilityEvaluator()
    assert evaluator.config.vocab_size == 500
    assert evaluator.config.hidden_size == 64
