import pytest
from training.acquisition.capability_curriculum import CapabilityCurriculumPlanner, CurriculumStage

@pytest.fixture
def planner():
    return CapabilityCurriculumPlanner()

def test_stage_definitions(planner):
    assert CurriculumStage.FOUNDATION in planner.stage_requirements
    assert CurriculumStage.REASONING in planner.stage_requirements

def test_target_capability_mix(planner):
    reqs = planner.stage_requirements[CurriculumStage.FOUNDATION]
    assert "target_mix" in reqs
    assert reqs["target_mix"]["programming"] == 0.2

def test_minimum_quality(planner):
    reqs = planner.stage_requirements[CurriculumStage.REASONING]
    assert reqs["min_quality"] == 0.8

def test_maximum_source_concentration(planner):
    reqs = planner.stage_requirements[CurriculumStage.FOUNDATION]
    assert reqs["max_source_concentration"] == 0.4

def test_maximum_duplicate_concentration(planner):
    reqs = planner.stage_requirements[CurriculumStage.REASONING]
    assert reqs["max_duplicate_concentration"] == 0.0

def test_unknown_tolerance(planner):
    reqs = planner.stage_requirements[CurriculumStage.FOUNDATION]
    assert reqs["unknown_tolerance"] == 0.1

def test_stage_eligibility(planner):
    # Pass
    assert planner.check_stage_eligibility(CurriculumStage.FOUNDATION, {"world knowledge": 0.5}, 0.6, 0.05) == True
    # Fail quality
    assert planner.check_stage_eligibility(CurriculumStage.FOUNDATION, {"world knowledge": 0.5}, 0.4, 0.05) == False
    # Fail unknown tolerance
    assert planner.check_stage_eligibility(CurriculumStage.FOUNDATION, {"world knowledge": 0.5}, 0.6, 0.2) == False
