import pytest
from scripts.run_capability_eval import CapabilityEvaluator, set_seed

def test_training_budget_accounting():
    evaluator = CapabilityEvaluator()
    data = evaluator.generate_dummy_dataset(200)
    
    # Very small step budget
    res_0 = evaluator.train_and_eval(data, steps=0, seed=1)
    res_2 = evaluator.train_and_eval(data, steps=2, seed=1)
    
    # We just ensure it runs and outputs metrics at multiple budgets
    assert len(res_0) == 10
    assert len(res_2) == 10
    
def test_data_budget_accounting():
    evaluator = CapabilityEvaluator()
    data_small = evaluator.generate_dummy_dataset(50)
    data_medium = evaluator.generate_dummy_dataset(150)
    
    res_s = evaluator.train_and_eval(data_small, steps=1, seed=1)
    res_m = evaluator.train_and_eval(data_medium, steps=1, seed=1)
    
    assert len(res_s) == 10
    assert len(res_m) == 10

def test_curve_non_monotonic():
    # Model behavior on small data could be random/non-monotonic
    pass

def test_capability_specific_sensitivity():
    # If all returns 0.0 accuracy, they are 'UNMEASURABLE'
    evaluator = CapabilityEvaluator()
    data = evaluator.generate_dummy_dataset(100)
    res = evaluator.train_and_eval(data, steps=1, seed=1)
    
    # Since accuracy is approx 0.0 for all, we expect they can be classified as unmeasurable
    for k, v in res.items():
        assert isinstance(v, float)

def test_training_budget_accounting_step4():
    evaluator = CapabilityEvaluator()
    data = evaluator.generate_dummy_dataset(200)
    res_4 = evaluator.train_and_eval(data, steps=4, seed=1)
    assert len(res_4) == 10

def test_training_budget_accounting_step8():
    evaluator = CapabilityEvaluator()
    data = evaluator.generate_dummy_dataset(200)
    res_8 = evaluator.train_and_eval(data, steps=8, seed=1)
    assert len(res_8) == 10
