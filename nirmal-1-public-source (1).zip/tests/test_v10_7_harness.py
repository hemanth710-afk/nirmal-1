"""Unit tests for V10.7 Rule Generalization and Algorithm Transfer Harness."""

import json
from pathlib import Path

import pytest
import torch
import torch.nn as nn

from training.evaluation.v10_2_harness import CapacityBuilder, aggregate_results
from training.evaluation.v10_7_harness import (
    ALL_RULES,
    DISJOINT_VOCAB,
    PARTIAL_VOCAB,
    SEP_TOKEN,
    TRAIN_VOCAB,
    PermutationAugmentor,
    V10_7_DataBuilder,
    apply_rule,
    classify_generalization,
    compute_representation_diagnostics,
    compute_retention_metrics,
    evaluate_few_shot_acc,
    evaluate_seq_acc,
)

VOCAB = 250


# ── Rule generator correctness ───────────────────────────────────────────────
def test_rule_generator_correctness():
    b = torch.tensor([[10]])
    assert torch.equal(apply_rule(b, "copy"), torch.tensor([[10, 10, 10]]))
    assert torch.equal(apply_rule(b, "increment"), torch.tensor([[10, 11, 12]]))
    assert torch.equal(apply_rule(b, "double_step"), torch.tensor([[10, 12, 14]]))
    assert torch.equal(apply_rule(b, "reverse"), torch.tensor([[12, 11, 10]]))
    assert torch.equal(apply_rule(b, "fixed_shift"), torch.tensor([[10, 13, 16]]))
    assert torch.equal(apply_rule(b, "simple_composition"), torch.tensor([[10, 11, 13]]))

    with pytest.raises(ValueError):
        apply_rule(b, "invalid_rule")


# ── Held-out rule isolation ──────────────────────────────────────────────────
def test_held_out_rule_isolation():
    all_rules_set = set(ALL_RULES)
    held_out = "simple_composition"
    train_rules = [r for r in ALL_RULES if r != held_out]

    assert held_out not in train_rules
    assert len(train_rules) == len(all_rules_set) - 1
    assert set(train_rules) | {held_out} == all_rules_set


# ── Permutation correctness ──────────────────────────────────────────────────
def test_permutation_correctness():
    aug = PermutationAugmentor(rng_seed=42)
    seq = torch.tensor([[10, 11, 12]])
    g = torch.Generator().manual_seed(99)
    remapped = aug.remap(seq, 130, 200, "increment", g=g)

    assert remapped.shape == seq.shape
    assert remapped.min().item() >= 130
    assert remapped.max().item() < 200
    # Rule structure must be preserved (increment: step = 1)
    assert (remapped[0, 1] - remapped[0, 0]).item() == 1
    assert (remapped[0, 2] - remapped[0, 1]).item() == 1


def test_permutation_intensity():
    aug = PermutationAugmentor(rng_seed=42)
    batch = torch.tensor([[10, 11, 12]])
    g = torch.Generator().manual_seed(123)

    # 0% intensity must return original batch unchanged
    res_0 = aug.maybe_remap(batch, "increment", prob=0.0, g=g)
    assert torch.equal(res_0, batch)

    # 100% intensity must remap to disjoint vocabulary
    res_1 = aug.maybe_remap(batch, "increment", prob=1.0, g=g)
    assert res_1.min().item() >= DISJOINT_VOCAB[0]


# ── Demonstration correctness ────────────────────────────────────────────────
def test_demonstration_correctness():
    db = V10_7_DataBuilder(vocab_size=VOCAB)
    k = 2
    batch_size = 4
    input_ids, targets = db.make_few_shot_batch(
        "increment", TRAIN_VOCAB, k_shots=k, batch_size=batch_size, seed=42
    )

    # Each demo has 3 tokens + 1 SEP token = 4 tokens. Query has 2 tokens -> 4*2 + 2 = 10 tokens
    expected_len = k * 4 + 2
    assert input_ids.shape == (batch_size, expected_len)
    assert targets.shape == (batch_size,)

    # Verify SEP tokens are placed correctly
    for row in input_ids:
        assert row[3].item() == SEP_TOKEN
        assert row[7].item() == SEP_TOKEN

        # Verify query target is consistent with increment rule (q_in[1] + 1)
        q_last_in = row[expected_len - 1].item()
        # Find corresponding target
        idx = (input_ids == row).all(dim=1).nonzero(as_tuple=True)[0][0].item()
        assert targets[idx].item() == q_last_in + 1


# ── Demonstration leakage ────────────────────────────────────────────────────
def test_demonstration_leakage():
    db = V10_7_DataBuilder(vocab_size=VOCAB)
    train_batch = db.make_batch("increment", TRAIN_VOCAB, 16, seed=1)
    ood_batch = db.make_batch("increment", DISJOINT_VOCAB, 16, seed=2)

    cert = db.leakage_certificate(train_batch, ood_batch)
    assert cert["vocab_disjoint"] is True
    assert cert["no_row_overlap"] is True
    assert cert["no_subseq_leak"] is True
    assert cert["valid"] is True


# ── Vocabulary separation ────────────────────────────────────────────────────
def test_vocabulary_separation():
    train_set = set(range(TRAIN_VOCAB[0], TRAIN_VOCAB[1]))
    disjoint_set = set(range(DISJOINT_VOCAB[0], DISJOINT_VOCAB[1]))
    partial_set = set(range(PARTIAL_VOCAB[0], PARTIAL_VOCAB[1]))

    assert len(train_set & disjoint_set) == 0  # Fully disjoint
    assert len(train_set & partial_set) > 0    # Partially overlapping
    assert len(disjoint_set & partial_set) > 0 # Also overlaps upper range


# ── Cross-rule evaluation ────────────────────────────────────────────────────
def test_cross_rule_evaluation():
    db = V10_7_DataBuilder(vocab_size=VOCAB)
    model = CapacityBuilder.build("L0", vocab=VOCAB)
    batch = db.make_batch("double_step", TRAIN_VOCAB, 8, seed=42)
    acc = evaluate_seq_acc(model, batch, torch.device("cpu"))

    assert isinstance(acc, float)
    assert 0.0 <= acc <= 1.0


# ── Retention and forgetting metrics ─────────────────────────────────────────
def test_retention_forgetting_metrics():
    rules = ["copy", "increment", "fixed_shift"]
    # Simulated sequential stage performance
    eval_matrix = [
        {"copy": 0.90},
        {"copy": 0.70, "increment": 0.85},
        {"copy": 0.50, "increment": 0.60, "fixed_shift": 0.80},
    ]

    metrics = compute_retention_metrics(eval_matrix, rules)
    assert metrics["initial_accs"]["copy"] == 0.90
    assert metrics["final_accs"]["copy"] == 0.50
    assert abs(metrics["forgetting_per_rule"]["copy"] - 0.40) < 1e-5
    assert metrics["initial_accs"]["increment"] == 0.85
    assert metrics["final_accs"]["increment"] == 0.60
    assert abs(metrics["forgetting_per_rule"]["increment"] - 0.25) < 1e-5
    assert metrics["avg_forgetting"] > 0.0


# ── Representation diagnostics ───────────────────────────────────────────────
def test_representation_diagnostics():
    db = V10_7_DataBuilder(vocab_size=VOCAB)
    model = CapacityBuilder.build("L0", vocab=VOCAB)
    diag = compute_representation_diagnostics(model, db, torch.device("cpu"), seed=42)

    assert "d_same" in diag
    assert "d_diff" in diag
    assert "invariance_gap" in diag
    assert "ratio" in diag
    assert isinstance(diag["d_same"], float)
    assert isinstance(diag["d_diff"], float)


# ── Deterministic seeds ──────────────────────────────────────────────────────
def test_deterministic_seeds():
    db = V10_7_DataBuilder(vocab_size=VOCAB)
    b1 = db.make_batch("reverse", TRAIN_VOCAB, 8, seed=123)
    b2 = db.make_batch("reverse", TRAIN_VOCAB, 8, seed=123)
    assert torch.equal(b1, b2)

    fs1_in, fs1_tgt = db.make_few_shot_batch("reverse", TRAIN_VOCAB, k_shots=2, batch_size=4, seed=123)
    fs2_in, fs2_tgt = db.make_few_shot_batch("reverse", TRAIN_VOCAB, k_shots=2, batch_size=4, seed=123)
    assert torch.equal(fs1_in, fs2_in)
    assert torch.equal(fs1_tgt, fs2_tgt)


# ── Classification logic ─────────────────────────────────────────────────────
def test_classification_logic():
    # Strong transfer, no rule generalization
    tags = classify_generalization(level1_ood=0.85, level2_gen=0.10, level3_comp=0.05, avg_forgetting=0.10)
    assert "KNOWN_RULE_TRANSFER" in tags
    assert "NO_RULE_GENERALIZATION" in tags

    # Partial transfer with catastrophic interference
    tags = classify_generalization(level1_ood=0.20, level2_gen=0.05, level3_comp=0.0, avg_forgetting=0.55)
    assert "PARTIAL_RULE_TRANSFER" in tags
    assert "CATASTROPHIC_INTERFERENCE" in tags
    assert "RULE_SPECIFIC_MEMORIZATION" in tags


# ── Report completeness ──────────────────────────────────────────────────────
def test_report_completeness():
    results_dir = Path("experiments/v10_7")
    files = list(results_dir.glob("v10_7_results_*.json"))
    if not files:
        pytest.skip("V10.7 results not yet generated")
    data = json.loads(files[-1].read_text(encoding="utf-8"))

    required_keys = [
        "exp_a_multi_rule",
        "exp_b_rule_transfer",
        "exp_c_held_out",
        "exp_d_few_shot",
        "exp_e_cross_rule",
        "exp_f_intensity",
        "exp_g_diagnostics",
        "exp_h_retention",
        "leakage",
        "classification",
    ]
    for k in required_keys:
        assert k in data, f"Missing key in results: {k}"
