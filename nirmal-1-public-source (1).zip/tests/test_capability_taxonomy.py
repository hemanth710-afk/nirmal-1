import pytest
import json
from pathlib import Path

def test_capability_taxonomy(tmp_path):
    tax_path = Path("data/capability_taxonomy.json")
    assert tax_path.exists(), "Taxonomy file missing"
    
    with open(tax_path, "r", encoding="utf-8") as f:
        data = json.load(f)
        
    assert "categories" in data
    categories = data["categories"]
    assert "abstract reasoning" in categories
    assert "safety/robustness examples" in categories
    assert "UNKNOWN" in categories
    
    # Assert specific types
    assert categories["abstract reasoning"]["type"] == "AGI_ORIENTED"
    assert categories["safety/robustness examples"]["type"] == "CONVENTIONAL"
    assert categories["UNKNOWN"]["type"] == "UNKNOWN"
