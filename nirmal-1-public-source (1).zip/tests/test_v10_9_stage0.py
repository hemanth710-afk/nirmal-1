"""Tests for V10.9 Stage 0 Instrumentation and Null Calibration."""

import pytest
import torch
import torch.nn as nn

from training.evaluation.v10_2_harness import CapacityBuilder
from training.evaluation.v10_9_foundation_harness import (
    DEFAULT_VOCAB_SIZE,
    GradientHealthLog,
    Stage0Sanitizer,
    Stage1BGenerator,
    collate_foundation_episodes,
)


def test_stage0_one_batch_overfit_set_size():
    eps = Stage0Sanitizer.make_one_batch_overfit_set(size=128, seed=42)
    assert len(eps) == 128
    for ep in eps:
        assert ep.task_type == "stage1b_retrieval"
        assert len(ep.input_ids) == 21
        assert ep.target >= 10


def test_stage0_direct_label_sanity():
    eps = Stage0Sanitizer.make_direct_label_control_set(size=32, seed=77)
    assert len(eps) == 32
    for ep in eps:
        assert ep.task_type == "stage0_direct_label"
        tokens = ep.input_ids.tolist()
        # Ensure direct answer is in support slot
        assert tokens[4] == ep.target


def test_stage0_no_update_control():
    model = CapacityBuilder.build("L0", vocab=DEFAULT_VOCAB_SIZE)
    # Freeze parameters
    for p in model.parameters():
        p.requires_grad_(False)

    pre_checksums = {name: p.data.sum().item() for name, p in model.named_parameters()}

    # Run forward pass
    dummy_in = torch.randint(10, 50, (2, 10))
    _ = model(input_ids=dummy_in)

    post_checksums = {name: p.data.sum().item() for name, p in model.named_parameters()}
    assert pre_checksums == post_checksums, "Frozen parameters changed!"


def test_stage0_gradient_health_logger():
    model = nn.Linear(10, 5)
    pre_params = {name: p.data.clone() for name, p in model.named_parameters()}

    x = torch.randn(4, 10)
    out = model(x).sum()
    out.backward()

    # Simulate update
    with torch.no_grad():
        for p in model.parameters():
            p -= 0.01 * p.grad

    log = GradientHealthLog.inspect(
        model=model,
        pre_params=pre_params,
        step=1,
        max_norm=1.0,
        predictions=[1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],  # 100% collapsed
    )

    assert log.global_grad_norm > 0.0
    assert log.param_update_norm > 0.0
    assert log.update_ratio > 0.0
    assert log.nan_inf_count == 0
    assert log.collapsed_prediction is True


def test_stage0_label_permutation_null():
    """Verify label permutation produces chance-level generalization on held-out data."""
    gen = Stage1BGenerator(vocab_start=10, vocab_size=64)
    g = torch.Generator().manual_seed(99)
    # Generate 50 episodes and permute targets
    clean_eps = [gen.generate_quartet(g)["correct"] for _ in range(50)]
    clean_targets = [ep.target for ep in clean_eps]

    # Permute targets
    perm = torch.randperm(len(clean_targets)).tolist()
    shuffled_targets = [clean_targets[i] for i in perm]

    # Check that shuffled targets differ from clean targets
    matches = sum(1 for a, b in zip(clean_targets, shuffled_targets) if a == b)
    # Match rate with random shuffle of 50 items should be low (~1/50 = 2%)
    assert matches / len(clean_targets) < 0.20
