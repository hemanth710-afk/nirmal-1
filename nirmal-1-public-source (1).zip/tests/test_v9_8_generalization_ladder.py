import pytest
import torch
from scripts.v9_8_generalization_bridge import GeneralizationTaskGenerator

def test_ladder_levels_exist():
    gen = GeneralizationTaskGenerator()
    levels = ["LEVEL_0_COPY", "LEVEL_1_PATTERN", "LEVEL_2_SIMPLE_RULE", "LEVEL_3_COMPOSITION", "LEVEL_4_OOD_RULE"]
    for l in levels:
        data = gen.generate_task(l, 2, 8, 10, 40)
        assert data.shape == (2, 8)

def test_subset_isolation():
    gen = GeneralizationTaskGenerator()
    d1 = gen.generate_task("LEVEL_0_COPY", 2, 8, 10, 40)
    d2 = gen.generate_task("LEVEL_0_COPY", 2, 8, 60, 90)
    # Elements in d1 should be strictly < 40
    assert (d1 < 40).all()
    # Elements in d2 should be >= 60
    assert (d2 >= 60).all()

def test_copy_task_format():
    gen = GeneralizationTaskGenerator()
    d = gen.generate_task("LEVEL_0_COPY", 2, 8, 10, 40)
    assert (d[:, :4] == d[:, 4:]).all()

def test_pattern_task_format():
    gen = GeneralizationTaskGenerator()
    d = gen.generate_task("LEVEL_1_PATTERN", 2, 8, 10, 40)
    assert (d[:, 0] == d[:, 1]).all()
    assert (d[:, 2] == d[:, 3]).all()

def test_rule_task_format():
    gen = GeneralizationTaskGenerator()
    d = gen.generate_task("LEVEL_2_SIMPLE_RULE", 2, 8, 10, 40)
    assert (d[:, 1] == d[:, 0] + 1).all()
