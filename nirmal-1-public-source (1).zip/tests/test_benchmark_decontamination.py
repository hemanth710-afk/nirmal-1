"""
Test Suite for Benchmark Decontamination & Evaluation Holdout Protection (Nirmal-1 V8.4).

Verifies:
1. Deterministic N-gram extraction and indexing (configurable N, default 13).
2. Distinction between INDEXED benchmarks and those requiring NEEDS_SOURCE_INPUT.
3. Matching policy verification: EXACT_MATCH, HIGH_OVERLAP, LOW_OVERLAP, NO_MATCH.
4. Training split fail-closed behavior on EXACT_MATCH and HIGH_OVERLAP.
5. Index integrity verification: tampering, corruption, and checksum mismatch detection.
6. Zero copyrighted text leakage: findings contain only hashes, scores, and classifications.
7. Integration with StreamingIngestionEngine: contaminated documents are rejected and accounted.
"""

from pathlib import Path
import pytest

from training.v8_4_decontamination import (
    NgramDecontaminationEngine,
    MatchPolicyType,
    BenchmarkDataStatus,
    ContaminationSplit,
    ContaminationIndexError,
)
from training.v8_4_ingestion import StreamingIngestionEngine


@pytest.fixture
def decontam_engine():
    return NgramDecontaminationEngine(ngram_size=13, high_overlap_threshold=0.50)


class TestBenchmarkDecontamination:
    """Rigorous verification of the 13-gram decontamination engine."""

    def test_benchmark_data_status_tracking(self, decontam_engine):
        report = decontam_engine.get_benchmark_coverage_report()
        # In-repo benchmarks must be INDEXED
        assert "AGI_COMPOSITE_IN_REPO" in report["indexed_benchmarks"]
        assert "CAUSAL_SIMULATOR_IN_REPO" in report["indexed_benchmarks"]

        # External benchmarks without local sources must be marked NEEDS_SOURCE_INPUT
        assert "GSM8K" in report["needs_source_input_benchmarks"]
        assert "HumanEval" in report["needs_source_input_benchmarks"]
        assert "MBPP" in report["needs_source_input_benchmarks"]
        assert "MMLU" in report["needs_source_input_benchmarks"]
        assert "ARC" in report["needs_source_input_benchmarks"]
        assert "MATH" in report["needs_source_input_benchmarks"]

    def test_ngram_tokenization_and_generation(self, decontam_engine):
        text = "The quick brown fox jumps over the lazy dog and runs away happily."
        tokens = decontam_engine.tokenize(text)
        assert len(tokens) == 13
        ngrams = decontam_engine.compute_ngrams(tokens)
        assert len(ngrams) == 1
        assert ngrams[0] == tuple(tokens)

    def test_exact_match_detection_and_fail_closed(self, decontam_engine):
        # Text containing exact probe from evals/
        probe_text = (
            "We now present the key finding: needle_key_target_uuid_4815162342 "
            "hidden within long horizon reasoning evaluation. This concludes the test."
        )
        res = decontam_engine.query_document(probe_text, split=ContaminationSplit.TRAIN)
        assert not res.is_clean, "Document with exact benchmark probe must fail closed"
        assert res.highest_match_type == MatchPolicyType.EXACT_MATCH
        assert res.max_score >= 0.99
        assert len(res.findings) >= 1

        finding = res.findings[0]
        assert finding.benchmark_id == "AGI_COMPOSITE_IN_REPO"
        assert finding.match_type == MatchPolicyType.EXACT_MATCH
        # Assert no raw benchmark or probe text is exposed in finding dict
        finding_dict = finding.to_dict()
        assert "needle_key" not in str(finding_dict)
        assert "document_hash" in finding_dict
        assert "benchmark_entry_hash" in finding_dict

    def test_high_overlap_match_detection(self, decontam_engine):
        # Text containing partial consecutive 13-grams of probe
        partial_text = (
            "During research we observed needle_key_target_uuid_4815162342 hidden within "
            "long horizon reasoning evaluation alongside auxiliary synthetic tasks."
        )
        res = decontam_engine.query_document(partial_text, split=ContaminationSplit.TRAIN)
        assert not res.is_clean
        assert res.highest_match_type in (MatchPolicyType.EXACT_MATCH, MatchPolicyType.HIGH_OVERLAP)

    def test_benign_document_no_match(self, decontam_engine):
        benign_text = """
        Transformers are deep learning models introduced in 2017. They utilize self-attention
        mechanisms to process input tokens in parallel rather than sequentially like recurrent
        neural networks. This architecture has become the foundation of modern large language models.
        """
        res = decontam_engine.query_document(benign_text, split=ContaminationSplit.TRAIN)
        assert res.is_clean, f"Benign text flagged falsely: {res.findings}"
        assert res.highest_match_type == MatchPolicyType.NO_MATCH
        assert res.max_score == 0.0
        assert len(res.findings) == 0

    def test_configurable_ngram_size(self):
        engine_5 = NgramDecontaminationEngine(ngram_size=5)
        text = "one two three four five six seven eight"
        tokens = engine_5.tokenize(text)
        ngrams = engine_5.compute_ngrams(tokens)
        assert len(ngrams) == len(tokens) - 5 + 1

    def test_invalid_parameters_fail_closed(self):
        with pytest.raises(ValueError):
            NgramDecontaminationEngine(ngram_size=0)
        with pytest.raises(ValueError):
            NgramDecontaminationEngine(high_overlap_threshold=1.5)

    def test_index_integrity_tamper_detection(self, decontam_engine):
        expected_hash = decontam_engine.index_sha256
        assert decontam_engine.verify_index_integrity(expected_hash) is True

        with pytest.raises(ContaminationIndexError):
            decontam_engine.verify_index_integrity("tampered_hash_value_12345")

    def test_ingestion_pipeline_rejection_accounting(self, tmp_path, decontam_engine):
        engine = StreamingIngestionEngine(
            checkpoint_dir=tmp_path,
            decontamination_engine=decontam_engine,
        )
        contaminated_doc = (
            "Analysis document: needle_key_target_uuid_4815162342 hidden within "
            "long horizon reasoning evaluation."
        )
        is_retained, reason = engine.filter_document(contaminated_doc)
        assert not is_retained
        assert reason == "benchmark_contamination_detected"
        assert engine.rejection_reasons["benchmark_contamination_detected"] == 1
