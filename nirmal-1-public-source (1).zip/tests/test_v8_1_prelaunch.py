"""
Unit and Integration Tests for Nirmal-1 Milestone V8.1:
Final Architecture Pre-Launch Validation & System Audits.
"""

import copy
import hashlib
from pathlib import Path
import shutil
import pytest
import torch
import torch.nn as nn

from nirmal.configuration_nirmal import NirmalConfig
from nirmal.model import NirmalForCausalLM, NirmalHybridCache
from training.checkpointing import AtomicCheckpointManager
from scripts.run_v8_1_prelaunch_validation import (
    calculate_exact_nirmal_parameters,
    calculate_serialized_artifact_size,
    V81PrelaunchValidationAudit,
)


def test_exact_parameter_count_formula_vs_pytorch():
    """Verify that analytical parameter formula matches PyTorch module instantiation with 0 discrepancy."""
    configs = [
        NirmalConfig(
            vocab_size=1000,
            hidden_size=128,
            num_hidden_layers=2,
            num_attention_heads=4,
            num_key_value_heads=1,
            head_dim=32,
            intermediate_size=256,
            num_experts=2,
            num_experts_per_tok=1,
            full_attention_interval=2,
        ),
        NirmalConfig(
            vocab_size=2000,
            hidden_size=256,
            num_hidden_layers=4,
            num_attention_heads=4,
            num_key_value_heads=2,
            head_dim=64,
            intermediate_size=640,
            num_experts=4,
            num_experts_per_tok=2,
            full_attention_interval=4,
        ),
        NirmalConfig(
            vocab_size=3000,
            hidden_size=384,
            num_hidden_layers=4,
            num_attention_heads=6,
            num_key_value_heads=2,
            head_dim=64,
            intermediate_size=960,
            num_experts=4,
            num_experts_per_tok=2,
            full_attention_interval=4,
        ),
    ]

    for idx, cfg in enumerate(configs):
        model = NirmalForCausalLM(cfg)
        actual_pytorch = sum(p.numel() for p in model.parameters())
        formula_dict = calculate_exact_nirmal_parameters(cfg)
        calc = formula_dict["total_parameters"]
        discrepancy = calc - actual_pytorch
        assert discrepancy == 0, f"Config {idx} parameter mismatch: calculated={calc}, actual={actual_pytorch}"


def test_serialized_artifact_size_within_bounds():
    """Verify that Candidate C serialized artifact size is strictly within 45.0 GB - 50.0 GB."""
    cfg_c = NirmalConfig(
        vocab_size=32000,
        hidden_size=4096,
        num_hidden_layers=12,
        num_attention_heads=32,
        num_key_value_heads=8,
        head_dim=128,
        intermediate_size=10496,
        num_experts=16,
        num_experts_per_tok=2,
        full_attention_interval=4,
        context_length=8192,
        tie_word_embeddings=False,
    )

    counts = calculate_exact_nirmal_parameters(cfg_c)
    total_params = counts["total_parameters"]

    bf16_sizing = calculate_serialized_artifact_size(total_params, bytes_per_param=2.0)
    artifact_gb = bf16_sizing["artifact_size_gb"]

    assert 45.0 <= artifact_gb <= 50.0, f"Candidate C size {artifact_gb} GB outside [45.0, 50.0] GB"
    assert 47.0 <= artifact_gb <= 49.5, f"Candidate C size {artifact_gb} GB outside target [47.0, 49.5] GB"
    assert bf16_sizing["is_within_45_50_gb_bounds"] is True


def test_tensor_shapes_forward_backward_optimizer_generation():
    """Verify tensor shape dynamics through forward, backward, optimizer step, and generation."""
    cfg = NirmalConfig(
        vocab_size=500,
        hidden_size=128,
        num_hidden_layers=4,
        num_attention_heads=4,
        num_key_value_heads=2,
        head_dim=32,
        intermediate_size=320,
        num_experts=4,
        num_experts_per_tok=2,
        full_attention_interval=2,
    )
    model = NirmalForCausalLM(cfg)
    model.train()

    batch_size = 2
    seq_len = 8
    x = torch.randint(0, cfg.vocab_size, (batch_size, seq_len))
    labels = torch.randint(0, cfg.vocab_size, (batch_size, seq_len))

    # Forward
    out = model(x, labels=labels)
    assert out.logits.shape == (batch_size, seq_len, cfg.vocab_size)
    assert out.loss is not None
    assert not torch.isnan(out.loss)

    # Backward
    out.loss.backward()
    for name, p in model.named_parameters():
        if p.requires_grad:
            assert p.grad is not None, f"Gradient missing for {name}"

    # Optimizer
    optimizer = torch.optim.AdamW(model.parameters(), lr=1e-3)
    optimizer.step()
    optimizer.zero_grad()

    # Autoregressive generation with cache
    model.eval()
    with torch.no_grad():
        cache = NirmalHybridCache()
        gen_in = torch.randint(0, cfg.vocab_size, (1, 1))
        gen_out = model(gen_in, cache=cache, use_cache=True)
        assert gen_out.logits.shape == (1, 1, cfg.vocab_size)
        assert cache.seen_tokens > 0


def test_scaled_analogues_ratios():
    """Verify that 4 scaled analogues preserve architectural ratios."""
    ratios = [
        ("1/100", 384, 12, 3, 32, 960),
        ("1/50", 576, 12, 3, 48, 1472),
        ("1/20", 768, 12, 3, 64, 1984),
        ("1/10", 1280, 20, 5, 64, 3264),
    ]

    for label, h, qh, kvh, hd, inter in ratios:
        cfg = NirmalConfig(
            vocab_size=32000,
            hidden_size=h,
            num_hidden_layers=12,
            num_attention_heads=qh,
            num_key_value_heads=kvh,
            head_dim=hd,
            intermediate_size=inter,
            num_experts=16,
            num_experts_per_tok=2,
            full_attention_interval=4,
        )
        counts = calculate_exact_nirmal_parameters(cfg)

        # 4:1 Q:KV ratio
        assert qh // kvh == 4
        # 3:1 DeltaNet:GQA ratio (9 DeltaNet, 3 GQA)
        assert counts["deltanet_layers_count"] == 9
        assert counts["gqa_layers_count"] == 3
        # Intermediate / Hidden ratio ~ 2.5 - 2.6
        ratio = inter / h
        assert 2.45 <= ratio <= 2.65


def test_moe_routing_entropy_and_balance():
    """Verify that MoE router maintains high entropy on uniform input and penalizes imbalance."""
    from nirmal.moe import NirmalTopKRouter

    router = NirmalTopKRouter(hidden_size=128, num_experts=8, top_k=2)

    # Uniform input
    x_uniform = torch.randn(4, 32, 128)
    w_u, idx_u, loss_u = router(x_uniform)

    # Skewed input
    x_skewed = torch.ones(4, 32, 128) * 10.0
    w_s, idx_s, loss_s = router(x_skewed)

    # Skewed input should incur higher auxiliary balancing loss
    assert loss_s.item() > loss_u.item()


def test_checkpoint_interruption_deterministic_recovery(tmp_path):
    """Verify that checkpoint save and resume produces identical loss trajectory."""
    cfg = NirmalConfig(
        vocab_size=200,
        hidden_size=64,
        num_hidden_layers=2,
        num_attention_heads=2,
        num_key_value_heads=1,
        head_dim=32,
        intermediate_size=128,
        num_experts=1,
        num_experts_per_tok=1,
        full_attention_interval=2,
    )

    ckpt_mgr = AtomicCheckpointManager(tmp_path / "checkpoints")

    # Uninterrupted run
    torch.manual_seed(123)
    model_ref = NirmalForCausalLM(cfg)
    optim_ref = torch.optim.AdamW(model_ref.parameters(), lr=1e-3)
    data = torch.randint(0, cfg.vocab_size, (5, 2, 8))

    ref_losses = []
    for step in range(5):
        optim_ref.zero_grad()
        loss = model_ref(data[step], labels=data[step]).loss
        loss.backward()
        optim_ref.step()
        ref_losses.append(loss.item())

    # Interrupted and resumed run
    torch.manual_seed(123)
    model_run = NirmalForCausalLM(cfg)
    optim_run = torch.optim.AdamW(model_run.parameters(), lr=1e-3)

    resumed_losses = []
    for step in range(2):
        optim_run.zero_grad()
        loss = model_run(data[step], labels=data[step]).loss
        loss.backward()
        optim_run.step()
        resumed_losses.append(loss.item())

    ckpt_path = ckpt_mgr.save_checkpoint(step=2, model=model_run, optimizer=optim_run)

    # Resume on fresh model
    fresh_model = NirmalForCausalLM(cfg)
    fresh_optim = torch.optim.AdamW(fresh_model.parameters(), lr=1e-3)
    ckpt_mgr.load_checkpoint(ckpt_path, model=fresh_model, optimizer=fresh_optim, restore_rng=True)

    for step in range(2, 5):
        fresh_optim.zero_grad()
        loss = fresh_model(data[step], labels=data[step]).loss
        loss.backward()
        fresh_optim.step()
        resumed_losses.append(loss.item())

    max_diff = max(abs(a - b) for a, b in zip(ref_losses, resumed_losses))
    assert max_diff < 1e-6, f"Checkpoint resumption loss discrepancy: {max_diff}"


def test_checkpoint_hash_tamper_detection(tmp_path):
    """Verify that modifying weights in model.pt triggers hash mismatch detection."""
    cfg = NirmalConfig(
        vocab_size=100,
        hidden_size=64,
        num_hidden_layers=2,
        num_attention_heads=2,
        num_key_value_heads=1,
        head_dim=32,
        intermediate_size=128,
        num_experts=1,
        num_experts_per_tok=1,
        full_attention_interval=2,
    )

    ckpt_mgr = AtomicCheckpointManager(tmp_path / "checkpoints_tamper")
    model = NirmalForCausalLM(cfg)
    ckpt_path = ckpt_mgr.save_checkpoint(step=1, model=model)

    # Modify tensor weights in checkpoint
    model_pt = ckpt_path / "model.pt"
    sd = torch.load(model_pt, map_location="cpu", weights_only=True)
    first_key = list(sd.keys())[0]
    sd[first_key] = sd[first_key] + 10.0
    torch.save(sd, model_pt)

    with pytest.raises(ValueError, match="Checkpoint hash mismatch"):
        ckpt_mgr.load_checkpoint(ckpt_path, model=NirmalForCausalLM(cfg))


def test_distributed_equivalence():
    """Verify mathematical equivalence between 4 workers x bs=2 and 1 worker x bs=8."""
    cfg = NirmalConfig(
        vocab_size=200,
        hidden_size=64,
        num_hidden_layers=2,
        num_attention_heads=2,
        num_key_value_heads=1,
        head_dim=32,
        intermediate_size=128,
        num_experts=1,
        num_experts_per_tok=1,
        full_attention_interval=2,
    )

    torch.manual_seed(42)
    model_single = NirmalForCausalLM(cfg)
    model_multi = copy.deepcopy(model_single)

    torch.manual_seed(999)
    full_batch = torch.randint(0, cfg.vocab_size, (8, 8))

    # Single batch of 8
    loss_single = model_single(full_batch, labels=full_batch).loss
    loss_single.backward()
    single_grads = [p.grad.clone() for p in model_single.parameters() if p.grad is not None]

    # 4 simulated workers with microbatch 2
    multi_grads = [torch.zeros_like(p) for p in model_multi.parameters()]
    for i in range(4):
        model_multi.zero_grad()
        chunk = full_batch[i*2:(i+1)*2]
        loss_chunk = model_multi(chunk, labels=chunk).loss
        loss_chunk.backward()
        for idx, p in enumerate(model_multi.parameters()):
            if p.grad is not None:
                multi_grads[idx] += p.grad / 4.0

    max_diff = max(torch.max(torch.abs(sg - mg)).item() for sg, mg in zip(single_grads, multi_grads))
    assert max_diff < 1e-5, f"Gradient difference too large: {max_diff}"


def test_training_launch_gates_all_evaluated():
    """Verify that all 14 training-launch gates are evaluated and dataset deficit blocks launch."""
    audit = V81PrelaunchValidationAudit()
    results = audit.run_all_audits()
    gates = results["launch_gates"]

    assert gates["total_gates_count"] == 14
    assert gates["passed_gates_count"] == 13

    dataset_gate = [g for g in gates["gates"] if g["name"] == "Dataset Volume & Readiness Gate"][0]
    assert dataset_gate["status"] == "NOT READY"
    assert "NOT READY -- DATASET VOLUME GAP" in gates["final_readiness_status"]
