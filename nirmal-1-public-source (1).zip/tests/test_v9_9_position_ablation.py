import pytest
import torch
from scripts.v9_9_ood_investigation import OodInvestigator

def test_positional_ablation_logic():
    inv = OodInvestigator()
    t = torch.tensor([[1, 2, 3]])
    flipped = inv.apply_positional_ablation(t)
    assert flipped[0, 0].item() == 3
    assert flipped[0, 2].item() == 1

def test_positional_ablation_shape():
    inv = OodInvestigator()
    t = torch.randint(0, 10, (2, 8))
    res = inv.apply_positional_ablation(t)
    assert res.shape == (2, 8)

def test_positional_failure_classification():
    inv = OodInvestigator()
    fail = inv.classify_failure(0.9, 0.0, "POSITION_PERMUTED")
    assert fail == "POSITION_FAILURE"

def test_positional_signal_precedence():
    inv = OodInvestigator()
    fail = inv.classify_failure(0.79, 0.0, "POSITION_PERMUTED")
    assert fail == "TRAINING_SIGNAL_FAILURE"
