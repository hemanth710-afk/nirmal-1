"""Unit tests for V10.8 Learning-to-Learn Harness."""

import pytest
import torch

from training.evaluation.v10_8_harness import (
    DEFAULT_VOCAB_SIZE,
    HELD_OUT_TRANSLATE_C,
    MIN_DATA_TOKEN,
    P_FIELD,
    PAD_TOKEN,
    QST_TOKEN,
    SEP_TOKEN,
    EpisodeBuilder,
    RuleDefinition,
    RuleSampler,
    Symbolizer,
    classify_v10_8_study,
    collate_episodes,
    compute_metrics,
    wilson_score_interval,
)


def test_rule_definition_math():
    r_trans = RuleDefinition("translate", (10,))
    assert r_trans.apply(5, 97) == 15
    assert r_trans.apply(90, 97) == 3

    r_scale = RuleDefinition("scale", (3,))
    assert r_scale.apply(10, 97) == 30
    assert r_scale.apply(50, 97) == (150 % 97)

    r_power = RuleDefinition("power", ())
    assert r_power.apply(10, 97) == (100 % 97)

    r_thresh = RuleDefinition("threshold", (40,))
    assert r_thresh.apply(30, 97) == 1
    assert r_thresh.apply(50, 97) == 0

    r_affine = RuleDefinition("affine", (3, 7))
    assert r_affine.apply(10, 97) == (37 % 97)


def test_symbolizer_regimes():
    g = torch.Generator().manual_seed(42)

    # V-A Offset
    va = Symbolizer.sample_symbolization("V-A", is_unseen=False, g=g)
    assert va(0) >= MIN_DATA_TOKEN
    assert va(10) - va(0) == 10

    # V-B Affine
    vb = Symbolizer.sample_symbolization("V-B", is_unseen=False, g=g)
    assert vb(0) >= MIN_DATA_TOKEN
    # Differences must be constant stride
    stride = vb(1) - vb(0)
    assert vb(5) - vb(0) == 5 * stride

    # V-C Arbitrary Permutation (diagnostic)
    vc = Symbolizer.sample_symbolization("V-C", is_unseen=False, g=g)
    assert vc(0) >= MIN_DATA_TOKEN


def test_episode_format_and_reserved_tokens():
    g = torch.Generator().manual_seed(123)
    builder = EpisodeBuilder(p=P_FIELD)
    rule = RuleDefinition("translate", (5,))

    ep = builder.build_episode(rule, k=3, symbol_regime="V-A", is_unseen_symbol=False, g=g)

    tokens = ep.input_ids.tolist()
    # Format: x1, y1, SEP, x2, y2, SEP, x3, y3, SEP, QST, qx -> length = 3*3 + 2 = 11
    assert len(tokens) == 11
    assert tokens[2] == SEP_TOKEN
    assert tokens[5] == SEP_TOKEN
    assert tokens[8] == SEP_TOKEN
    assert tokens[9] == QST_TOKEN

    # Verify query x is not in support xs
    assert ep.qx_val not in ep.support_xs

    # Verify all data tokens >= 3
    data_tokens = [t for t in tokens if t not in (PAD_TOKEN, SEP_TOKEN, QST_TOKEN)]
    assert all(t >= MIN_DATA_TOKEN for t in data_tokens)


def test_collate_episodes():
    g = torch.Generator().manual_seed(456)
    builder = EpisodeBuilder(p=P_FIELD)
    rule = RuleDefinition("translate", (5,))

    ep1 = builder.build_episode(rule, k=1, symbol_regime="V-A", is_unseen_symbol=False, g=g)  # len = 5
    ep2 = builder.build_episode(rule, k=2, symbol_regime="V-A", is_unseen_symbol=False, g=g)  # len = 8

    padded, targets = collate_episodes([ep1, ep2])
    assert padded.shape == (2, 8)
    # ep1 was length 5, so first 3 tokens must be PAD (0)
    assert padded[0, :3].tolist() == [PAD_TOKEN, PAD_TOKEN, PAD_TOKEN]
    assert padded[0, 3:].tolist() == ep1.input_ids.tolist()
    assert padded[1].tolist() == ep2.input_ids.tolist()
    assert targets.tolist() == [ep1.target, ep2.target]


def test_wilson_score_interval():
    low, high = wilson_score_interval(10, 100, confidence=0.95)
    assert 0.05 < low < 0.10
    assert 0.10 < high < 0.18

    # Edge cases
    assert wilson_score_interval(0, 100)[0] == 0.0
    assert wilson_score_interval(100, 100)[1] == 1.0


def test_classification_logic():
    # Optimization failure
    tags_opt = classify_v10_8_study(
        l1_acc=0.01, l2_acc=0.01, l3_acc=0.01, l4_acc=0.01, l5_acc=0.01,
        k16_vs_k0_gain=0.0, correct_vs_random_gain=0.0, train_acc=0.05
    )
    assert "OPTIMIZATION_FAILURE" in tags_opt

    # Meta-learning signal
    tags_meta = classify_v10_8_study(
        l1_acc=0.70, l2_acc=0.50, l3_acc=0.20, l4_acc=0.15, l5_acc=0.10,
        k16_vs_k0_gain=0.40, correct_vs_random_gain=0.35, train_acc=0.75
    )
    assert "META_LEARNING_SIGNAL" in tags_meta
