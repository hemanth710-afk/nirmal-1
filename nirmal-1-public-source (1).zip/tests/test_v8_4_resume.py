"""
Unit tests for Ingestion and Sharding Checkpoint Resumption in Nirmal-1 V8.4.
"""

from pathlib import Path
import tempfile
import pytest

from training.v8_4_ingestion import IngestionCheckpoint
from training.v8_4_sharding import DistributedShardReader


def test_ingestion_checkpoint_serialization():
    cp = IngestionCheckpoint(
        source_identifier="s3://data-bucket/stream1.jsonl.gz",
        last_processed_line=15000,
        last_processed_bytes=45000000,
        documents_ingested=14980,
        documents_rejected=20,
        timestamp="2026-09-06T12:00:00Z",
    )
    d = cp.to_dict()
    assert d["last_processed_line"] == 15000
    assert d["last_processed_bytes"] == 45000000
    assert d["documents_ingested"] == 14980


def test_shard_reader_state_checkpoint_and_restore():
    reader = DistributedShardReader(
        shard_manifests=[],
        shard_dir=Path("."),
        batch_size=4,
        seq_len=128,
        seed=123,
    )
    # Simulate advance
    reader.current_shard_idx = 2
    reader.current_token_offset = 1024
    reader.global_step = 256
    reader.epoch = 1

    state = reader.get_state()
    assert state["current_shard_idx"] == 2
    assert state["current_token_offset"] == 1024
    assert state["global_step"] == 256

    new_reader = DistributedShardReader(
        shard_manifests=[],
        shard_dir=Path("."),
        batch_size=4,
        seq_len=128,
        seed=999,
    )
    new_reader.load_state(state)
    assert new_reader.current_shard_idx == 2
    assert new_reader.current_token_offset == 1024
    assert new_reader.global_step == 256
    assert new_reader.seed == 123
