"""V10.3 Tests."""
import pytest
import torch
import json
from pathlib import Path
from training.evaluation.v10_2_harness import TaskConfig, CapacityBuilder, aggregate_results
from training.evaluation.v10_3_harness import (
    V10_3_TaskGenerator, relational_consistency_loss, contrastive_isomorphic_loss, check_scaffold_off
)

def test_deterministic_curriculum():
    gen = V10_3_TaskGenerator()
    curr1 = gen.generate_curriculum(4, 42)
    curr2 = gen.generate_curriculum(4, 42)
    assert (curr1[0] == curr2[0]).all()
    assert (curr1[1] == curr2[1]).all()
    assert (curr1[2] == curr2[2]).all()

def test_no_latent_feature_leakage():
    gen = V10_3_TaskGenerator()
    div = gen.generate_diversity("increment", 4, 3, 4, 42)
    for idx, s in enumerate(div["train_surfaces"]):
        # Each surface occupies 15 tokens.
        lo = idx * 15
        assert s.min() >= lo
        assert s.max() < lo + 15

def test_task_isomorphism_correctness():
    gen = V10_3_TaskGenerator()
    cp = gen.generate_contrastive_pairs(4, 3, 42)
    # Both pos_a and pos_b must have increment structure, but different vocab bounds.
    # pos_a base is [10, 20), pos_b base is [40, 50)
    assert cp["pos_a"].min() >= 10 and cp["pos_a"].max() < 25
    assert cp["pos_b"].min() >= 40 and cp["pos_b"].max() < 55
    # Check increment pattern (diff = 1)
    diff = cp["pos_a"][:, 1] - cp["pos_a"][:, 0]
    assert (diff == 1).all()

def test_objective_correctness():
    model = CapacityBuilder.build("L0", vocab=100)
    gen = V10_3_TaskGenerator()
    cp = gen.generate_contrastive_pairs(2, 3, 42)
    
    # Test relational loss
    r_loss = relational_consistency_loss(model, cp["pos_a"], cp["pos_b"])
    assert r_loss.item() > 0
    
    # Test contrastive loss
    c_loss = contrastive_isomorphic_loss(model, cp["pos_a"], cp["pos_b"], cp["neg_a"], cp["neg_b"])
    assert c_loss.item() > 0

def test_scaffold_removal_decorator():
    # Test that evaluating through scaffold_off returns accuracy (float)
    model = CapacityBuilder.build("L0", vocab=100)
    data = torch.tensor([[10, 11, 12]])
    
    @check_scaffold_off
    def eval_fn(m, d):
        pass
        
    res = eval_fn(model, data)
    assert isinstance(res, float)
    
def test_immutable_evaluation_hashes():
    gen = V10_3_TaskGenerator()
    cp = gen.generate_contrastive_pairs(4, 3, 42)
    h1 = gen.hash_dataset(cp["pos_a"])
    cp2 = gen.generate_contrastive_pairs(4, 3, 42)
    h2 = gen.hash_dataset(cp2["pos_a"])
    assert h1 == h2

def test_leakage_rejection():
    gen = V10_3_TaskGenerator()
    div = gen.generate_diversity("increment", 2, 3, 4, 42)
    # The two surfaces should have disjoint vocabs
    cert = gen.leakage_certificate({"train": div["train_surfaces"][0], "ood": div["train_surfaces"][1]})
    assert cert["vocab_disjoint"] is True

def test_report_completeness():
    results_files = list(Path("experiments/v10_3").glob("v10_3_results_*.json"))
    if not results_files:
        pytest.skip("Results not yet generated")
    results_files.sort()
    data = json.loads(results_files[-1].read_text())
    assert "E1_baseline" in data
    assert "E7_diversity_relational_contrastive" in data
