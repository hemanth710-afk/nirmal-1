import pytest
import torch
from scripts.v9_9_ood_investigation import OodInvestigator

def test_representation_ablation_init():
    inv = OodInvestigator()
    assert inv.vocab_size == 100

def test_failure_classification_representation():
    inv = OodInvestigator()
    fail = inv.classify_failure(0.95, 0.1, "REPRESENTATION_CHANGED")
    assert fail == "REPRESENTATION_FAILURE"

def test_failure_classification_success():
    inv = OodInvestigator()
    fail = inv.classify_failure(0.95, 0.95, "REPRESENTATION_CHANGED")
    assert fail == "SUCCESS"

def test_failure_classification_signal():
    inv = OodInvestigator()
    # Low train acc -> training signal failure
    fail = inv.classify_failure(0.5, 0.1, "REPRESENTATION_CHANGED")
    assert fail == "TRAINING_SIGNAL_FAILURE"

def test_failure_classification_unknown():
    inv = OodInvestigator()
    fail = inv.classify_failure(0.95, 0.1, "SOMETHING_ELSE")
    assert fail == "UNKNOWN"
