"""
Regression and specification alignment tests for Nirmal-1 Cognitive AGI Subsystems:
- Memory: Vector store 2D query handling, WorkingMemory budget and observation methods.
- Reasoning: VerificationResult, step verification, structured trace generation.
- Planning: Dynamic replanning lifecycle, task graph completion semantics.
- Tools: Schema alignment and execution dispatching.
- Learning: O(1) buffer capacity eviction and trajectory sampling.
"""

import torch
import pytest

from nirmal.memory import WorkingMemory, InMemoryVectorStore, MemoryRecord, RetrievalEngine
from nirmal.reasoning import ReasoningEngine, ReasoningTrace, ReasoningStep, StepType, VerificationResult
from nirmal.planning import Planner, TaskGraph, PlanNode, PlanStatus
from nirmal.learning import Experience, EpisodicBuffer, ExperienceCollector
from nirmal.tools import Tool, ToolResult, ToolRegistry, CalculatorTool


def test_vector_store_2d_query():
    """Regression test for Issue 6: Vector store retrieves records with 2D (1, D) query tensor."""
    store = InMemoryVectorStore()
    embedding = torch.randn(64)
    store.store("doc_1", MemoryRecord("doc_1", "Test content", embedding=embedding))

    # 2D query tensor with shape (1, 64)
    query_2d = embedding.unsqueeze(0)
    results = store.retrieve(query_2d, top_k=1)

    assert len(results) == 1
    assert results[0].key == "doc_1"


def test_working_memory_budget_and_spec_methods():
    """Regression test for Issue 7: WorkingMemory implements append_observation, prune_or_summarize, get_context_tokens."""
    wm = WorkingMemory(max_token_budget=20)
    wm.set_goal("Test Goal")
    wm.add_scratchpad_note("Note 1")
    wm.append_observation(role="user", content="First observation message")
    wm.append_observation(role="assistant", content="Response message")
    wm.append_observation(role="user", content="A very long message that should push over budget")

    # Ensure get_context_tokens returns a tensor
    tokens = wm.get_context_tokens()
    assert isinstance(tokens, torch.Tensor)
    assert tokens.shape[0] == 1

    # Prune according to budget
    wm.prune_or_summarize(max_budget=15)
    # Oldest message should have been pruned
    assert len(wm.conversation_history) < 3


def test_reasoning_engine_spec_methods():
    """Regression test for Issue 8: ReasoningEngine implements verify_step, VerificationResult, and generate_trace."""
    engine = ReasoningEngine()

    # Test verify_step
    valid_step = ReasoningStep(index=0, step_type=StepType.DEDUCTION, content="2 + 2 = 4", confidence=0.95)
    res = engine.verify_step(valid_step)
    assert isinstance(res, VerificationResult)
    assert res.is_valid is True
    assert res.score == 0.95

    empty_step = ReasoningStep(index=1, step_type=StepType.DEDUCTION, content="", confidence=0.5)
    res_empty = engine.verify_step(empty_step)
    assert res_empty.is_valid is False

    # Test generate_trace
    raw_output = "<think>\nFirst principle\nSecond principle\n</think>\nFinal conclusion."
    trace = engine.generate_trace(goal="Solve logic problem", raw_model_output=raw_output)
    assert isinstance(trace, ReasoningTrace)
    assert trace.is_verified is True
    assert any(s.step_type == StepType.CONCLUSION for s in trace.steps)


def test_planning_spec_methods_and_recovery():
    """Regression test for Issue 9: TaskGraph.is_finished stays False during replanning recovery."""
    planner = Planner()
    graph = planner.create_linear_plan("Complete objective", [{"id": "s1", "description": "Step 1"}])

    # Mark s1 as failed
    graph.mark_failed("s1", "Network timeout")

    # Before replanning, graph has 1 failed node and no active nodes -> is_finished is True
    assert graph.is_finished() is True

    # Replan by injecting recovery node
    planner.update_plan(graph, failed_step="s1", error="Network timeout")

    # Now there is an active pending recovery node -> is_finished MUST BE False!
    assert graph.is_finished() is False
    assert "recovery_for_s1" in graph.nodes

    # Once recovery is completed, graph is finished
    graph.mark_completed("recovery_for_s1", output="Recovered")
    assert graph.is_finished() is True

    # Test Planner.plan() conforming to AGI_SPEC.md
    new_graph = planner.plan("Explore environment")
    assert isinstance(new_graph, TaskGraph)
    assert len(new_graph.nodes) >= 1


def test_episodic_buffer_spec_methods():
    """Regression test for Issue 12: EpisodicBuffer implements record, sample_batch, and O(1) bounded capacity."""
    buffer = EpisodicBuffer(max_capacity=3)

    for i in range(5):
        exp = Experience(trajectory_id=f"traj_{i}", goal=f"Goal {i}", success=(i % 2 == 0))
        buffer.record(exp)

    # Max capacity is 3, older experiences traj_0 and traj_1 must be evicted
    assert len(buffer) == 3
    remaining_ids = [e.trajectory_id for e in buffer.buffer]
    assert remaining_ids == ["traj_2", "traj_3", "traj_4"]

    # Test sample_batch
    sample = buffer.sample_batch(batch_size=2)
    assert len(sample) == 2


def test_tool_spec_interface():
    """Regression test for Issue 10: Tool.parameters_schema and ToolRegistry.dispatch."""
    registry = ToolRegistry()
    tool = registry.get("calculator")
    assert tool is not None

    # Verify parameters_schema property
    assert hasattr(tool, "parameters_schema")
    assert "properties" in tool.parameters_schema

    # Verify dispatch method
    result = registry.dispatch("calculator", {"expression": "100 / 4"})
    assert isinstance(result, ToolResult)
    assert result.success is True
    assert result.output == 25.0
