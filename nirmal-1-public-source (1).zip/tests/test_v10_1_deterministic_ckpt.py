"""V10.1 — deterministic checkpoint selection tests."""
import pytest
from training.acquisition.v10_1_ood_amplification import TaskConfig, run_dose
from pathlib import Path
import tempfile


@pytest.fixture
def task():
    return TaskConfig("copy", 4, (10, 35), (10, 35), (60, 85), 4, 1000)


@pytest.fixture
def tmpdir():
    with tempfile.TemporaryDirectory() as d:
        yield Path(d)


def test_same_seed_identical_checkpoints(task, tmpdir):
    r1 = run_dose("identity", 100, 42, task, tmpdir)
    r2 = run_dose("identity", 100, 42, task, tmpdir)
    for c1, c2 in zip(r1.checkpoints, r2.checkpoints):
        assert c1.step      == c2.step
        assert c1.train_acc == c2.train_acc
        assert c1.ood_acc   == c2.ood_acc


def test_different_seeds_may_differ(task, tmpdir):
    r1 = run_dose("value_relative", 100, 42, task, tmpdir)
    r2 = run_dose("value_relative", 100, 43, task, tmpdir)
    # At least the final step's loss should differ (not guaranteed but usual)
    # We simply check both runs are valid
    assert len(r1.checkpoints) > 0
    assert len(r2.checkpoints) > 0


def test_repr_modes_differ(task, tmpdir):
    ri = run_dose("identity",       100, 42, task, tmpdir)
    rv = run_dose("value_relative", 100, 42, task, tmpdir)
    # Different preprocessing → different accuracy trajectory
    # At minimum, both should be valid result objects
    assert ri.repr_mode == "identity"
    assert rv.repr_mode == "value_relative"
