"""
Unit tests for 3-way split isolation and contamination prevention in Nirmal-1 V8.4.
"""

import hashlib
import pytest

from training.data_pipeline import DataLeakageError
from training.v8_2_data_engine import SplitIsolationAuditor, ProductionDocument, ProvenanceMetadata


def test_strict_split_isolation_and_holdout_check():
    auditor = SplitIsolationAuditor()

    def make_prov(name: str, domain: str, text: str) -> ProvenanceMetadata:
        return ProvenanceMetadata(
            source_id=name,
            domain=domain,
            license_provenance="Apache-2.0",
            acquisition_date="2026-09-06T00:00:00Z",
            preprocessing_version="v8.4.0",
            tokenizer_version="v8.4",
            sha256_hash=hashlib.sha256(text.encode("utf-8")).hexdigest(),
        )

    t1 = "Math premise A implies B."
    t2 = "Validation problem: calculate integral of x^2."
    t3 = "Test theorem: show convergence of Fourier series."

    train_doc = ProductionDocument(
        id="tr_1", domain="math", raw_text=t1,
        clean_text=t1, provenance=make_prov("tr1", "math", t1), split="train",
        token_ids=[1, 2, 3]
    )
    val_doc = ProductionDocument(
        id="vl_1", domain="math", raw_text=t2,
        clean_text=t2, provenance=make_prov("vl1", "math", t2), split="val",
        token_ids=[4, 5, 6]
    )
    test_doc = ProductionDocument(
        id="ts_1", domain="math", raw_text=t3,
        clean_text=t3, provenance=make_prov("ts1", "math", t3), split="test",
        token_ids=[7, 8, 9]
    )

    report = auditor.verify_split_isolation([train_doc], [val_doc], [test_doc])
    assert report["train_val_overlap"] == 0
    assert report["train_test_overlap"] == 0
    assert report["val_test_overlap"] == 0
    assert report["isolation_status"] == "STRICT_ZERO_LEAKAGE_CONFIRMED"


def test_leakage_detection():
    auditor = SplitIsolationAuditor()
    prov = ProvenanceMetadata("u", "code", "MIT", "2026", "v8.4", "v8.4", "h")

    shared_text = "Exact leaked function across partitions def foo(): pass"
    d_train = ProductionDocument(id="tr", domain="code", raw_text=shared_text, clean_text=shared_text, provenance=prov, split="train")
    d_val = ProductionDocument(id="vl", domain="code", raw_text=shared_text, clean_text=shared_text, provenance=prov, split="val")

    with pytest.raises(DataLeakageError):
        auditor.verify_split_isolation([d_train], [d_val], [])
