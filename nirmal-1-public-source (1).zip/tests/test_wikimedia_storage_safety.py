"""
NIRMAL-1 V8.9: TEST SUITE FOR WIKIMEDIA STORAGE SAFETY & ATOMIC STAGING

Verifies:
1. Atomic staging flow (.part -> staging -> shard).
2. Incomplete file cleanup on failure (no dangling .part or corrupted files).
3. Staging file cleanup upon successful finalization.
4. Absolute prohibition of writes to authoritative production directory data/shards/.
5. Absolute prohibition of writes to src/nirmal/.
"""

import hashlib
import json
from pathlib import Path
from unittest.mock import patch
import pytest

from training.acquisition.wikimedia_real_adapter import WikimediaRealAdapter
from training.acquisition.pilot_adapter import (
    PilotSecurityError,
    PilotLimitExceededError,
    REPO_ROOT,
)
from training.acquisition.pilot_provenance_audit import PilotProvenanceClass


@pytest.fixture
def temp_pilot_dirs(tmp_path):
    staging_dir = tmp_path / "pilot" / "staging"
    shards_dir = tmp_path / "pilot" / "shards"
    manifests_dir = tmp_path / "pilot" / "manifests"
    provenance_dir = tmp_path / "pilot" / "provenance"
    staging_dir.mkdir(parents=True)
    shards_dir.mkdir(parents=True)
    manifests_dir.mkdir(parents=True)
    provenance_dir.mkdir(parents=True)
    return staging_dir, shards_dir, manifests_dir, provenance_dir


def create_sample_record() -> dict:
    text = (
        "Quantum computing utilizes quantum mechanics to solve problems that are intractable "
        "for classical computing architectures."
    )
    return {
        "id": "wiki_safe_101",
        "page_id": "safe_101",
        "title": "Quantum Computing",
        "revision_id": "1198274612",
        "revision_verified": True,
        "timestamp": "2026-09-01T12:00:00Z",
        "url": "https://en.wikipedia.org/wiki/Quantum_Computing",
        "license": "CC-BY-SA-4.0",
        "text": text,
        "raw_payload_hash": hashlib.sha256(text.encode("utf-8")).hexdigest(),
        "raw_bytes": len(text.encode("utf-8")),
        "provenance_class": PilotProvenanceClass.REMOTE_SOURCE_DATA.value,
        "is_network_retrieved": True,
        "is_local_fixture": False,
        "is_synthetic": False,
        "is_copied_from_repo": False,
    }


class TestWikimediaStorageSafety:
    """Rigorous tests for atomic storage operations, cleanup, and production directory guards."""

    def test_prohibition_of_writes_to_production_shards(self, temp_pilot_dirs):
        staging_dir, _, manifests_dir, prov_dir = temp_pilot_dirs
        forbidden_shards = REPO_ROOT / "data" / "shards"

        adapter = WikimediaRealAdapter(
            staging_dir=staging_dir,
            shards_dir=forbidden_shards,
            manifests_dir=manifests_dir,
            provenance_dir=prov_dir,
        )

        with pytest.raises(PilotSecurityError) as exc:
            adapter.prepare_pilot()
        assert "CRITICAL SAFETY VIOLATION" in str(exc.value)
        assert "production directory" in str(exc.value)

    def test_prohibition_of_writes_to_src_nirmal(self, temp_pilot_dirs):
        _, shards_dir, manifests_dir, prov_dir = temp_pilot_dirs
        forbidden_staging = REPO_ROOT / "src" / "nirmal"

        adapter = WikimediaRealAdapter(
            staging_dir=forbidden_staging,
            shards_dir=shards_dir,
            manifests_dir=manifests_dir,
            provenance_dir=prov_dir,
        )

        with pytest.raises(PilotSecurityError) as exc:
            adapter.prepare_pilot()
        assert "CRITICAL SAFETY VIOLATION" in str(exc.value)
        assert "production directory" in str(exc.value)

    def test_authoritative_shards_directory_remains_completely_untouched(self, temp_pilot_dirs):
        staging_dir, shards_dir, manifests_dir, prov_dir = temp_pilot_dirs
        production_shards_dir = REPO_ROOT / "data" / "shards"
        initial_production_files = set(production_shards_dir.glob("*")) if production_shards_dir.exists() else set()

        adapter = WikimediaRealAdapter(
            run_id="run_safety_guard",
            staging_dir=staging_dir,
            shards_dir=shards_dir,
            manifests_dir=manifests_dir,
            provenance_dir=prov_dir,
        )

        result = adapter.run_pipeline(records=[create_sample_record()])
        assert result.status == "SUCCESS"

        # Verify pilot shard was written exclusively to data/pilot/shards/ (or test shards_dir)
        pilot_shard = shards_dir / f"{adapter.run_id}_tokens.bin"
        assert pilot_shard.exists()

        # Verify production shards directory has zero changes
        current_production_files = set(production_shards_dir.glob("*")) if production_shards_dir.exists() else set()
        assert current_production_files == initial_production_files

    def test_atomic_staging_flow_and_clean_finalization(self, temp_pilot_dirs):
        staging_dir, shards_dir, manifests_dir, prov_dir = temp_pilot_dirs
        adapter = WikimediaRealAdapter(
            run_id="run_atomic_staging_test",
            staging_dir=staging_dir,
            shards_dir=shards_dir,
            manifests_dir=manifests_dir,
            provenance_dir=prov_dir,
        )

        # Track written files during checkpoint and sharding
        observed_part_files = []
        original_tofile = getattr(type(adapter), "_save_checkpoint")

        result = adapter.run_pipeline(records=[create_sample_record()])
        assert result.status == "SUCCESS"

        # 1. Verify final shard exists and has positive size
        shard_path = shards_dir / f"{adapter.run_id}_tokens.bin"
        assert shard_path.exists()
        assert shard_path.stat().st_size > 0

        # 2. Verify no lingering .part files exist in shards or staging
        lingering_parts = list(shards_dir.glob("*.part")) + list(staging_dir.glob("*.part"))
        assert lingering_parts == []

        # 3. Verify staging files (raw json and ckpt json) are cleaned up upon successful finalize()
        raw_staging_file = staging_dir / f"{adapter.run_id}_raw.json"
        ckpt_file = staging_dir / f"ckpt_{adapter.run_id}.json"
        assert not raw_staging_file.exists()
        assert not ckpt_file.exists()

    def test_incomplete_file_cleanup_on_failure(self, temp_pilot_dirs):
        staging_dir, shards_dir, manifests_dir, prov_dir = temp_pilot_dirs
        from training.acquisition.safe_network_client import (
            SafeBoundedNetworkClient,
            BoundedPayloadError,
        )

        client = SafeBoundedNetworkClient(
            max_doc_bytes=100,  # Tiny limit to trigger failure mid-stream
            max_total_bytes=1000,
        )

        target_file = staging_dir / "failed_download.json"
        part_file = target_file.with_suffix(".part")

        # Mock urllib to return a stream exceeding 100 bytes
        class FakeResponse:
            def __init__(self):
                self.headers = {"Content-Type": "application/json"}
                self.data = [b"x" * 80, b"y" * 80]
                self.idx = 0

            def read(self, size):
                if self.idx < len(self.data):
                    chunk = self.data[self.idx]
                    self.idx += 1
                    return chunk
                return b""

            def geturl(self):
                return "https://en.wikipedia.org/test"

        class FakeOpener:
            def open(self, req, timeout=10.0):
                return FakeResponse()

        with patch("urllib.request.build_opener", return_value=FakeOpener()):
            with pytest.raises(BoundedPayloadError):
                client.fetch_url_to_file("https://en.wikipedia.org/test", target_file)

        # Confirm .part file was cleaned up and never left on disk
        assert not part_file.exists()
        assert not target_file.exists()
