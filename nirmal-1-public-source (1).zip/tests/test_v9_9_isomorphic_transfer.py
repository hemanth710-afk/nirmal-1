import pytest
from scripts.v9_9_ood_investigation import OodInvestigator

def test_isomorphic_task_generation():
    inv = OodInvestigator()
    train, ood = inv.generate_isomorphic_task(batch_size=2)
    assert train.shape == (2, 2)
    assert ood.shape == (2, 2)

def test_isomorphic_rule_holds():
    inv = OodInvestigator()
    train, ood = inv.generate_isomorphic_task(batch_size=4)
    assert (train[:, 1] == train[:, 0] + 1).all()
    assert (ood[:, 1] == ood[:, 0] + 1).all()

def test_isomorphic_disjoint():
    inv = OodInvestigator()
    train, ood = inv.generate_isomorphic_task()
    assert train.max() < 60
    assert ood.min() >= 60

def test_isomorphic_classification():
    inv = OodInvestigator()
    fail = inv.classify_failure(0.9, 0.0, "REPRESENTATION_CHANGED")
    assert fail == "REPRESENTATION_FAILURE"
