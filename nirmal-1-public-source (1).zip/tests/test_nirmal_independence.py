import os
from pathlib import Path
import pytest

def test_no_external_ai_dependencies():
    """
    Ensure no accidental runtime or architectural dependencies on external AI providers.
    Scans src/ and training/ for forbidden keywords.
    """
    project_root = Path(__file__).parent.parent
    src_dir = project_root / "src"
    training_dir = project_root / "training"
    
    forbidden_terms = ["openai", "anthropic", "claude", "gemini", "lightning.ai", "notion ai"]
    
    # Exceptions allowed in historical docs or comments, but ideally we fail if found in runtime code.
    # To be safe, we check all .py files in src and training.
    
    violations = []
    
    for directory in [src_dir, training_dir]:
        if not directory.exists():
            continue
        for py_file in directory.rglob("*.py"):
            content = py_file.read_text(encoding="utf-8").lower()
            for term in forbidden_terms:
                if term in content:
                    violations.append(f"Found forbidden term '{term}' in {py_file}")
                    
    assert len(violations) == 0, "\n".join(violations)

def test_independence_invariants():
    """
    Ensure the production tokens remain strictly 233,997.
    """
    project_root = Path(__file__).parent.parent
    data_shards_dir = project_root / "data" / "shards"
    
    # Calculate tokens based on 16-bit integers
    total_tokens = 0
    if data_shards_dir.exists():
        for bin_file in data_shards_dir.glob("*.bin"):
            total_tokens += bin_file.stat().st_size // 2
            
    assert total_tokens == 233997, f"Production token invariant broken! Expected 233997, got {total_tokens}"
