import pytest
from pathlib import Path
from training.acquisition.capability_classifier import CapabilityClassifier

@pytest.fixture
def classifier():
    return CapabilityClassifier(Path("data/capability_taxonomy.json"))

def test_deterministic_classification(classifier):
    # Test programming heuristic
    labels, conf = classifier.classify_document(
        "def hello():\n    return 'world'\nimport sys",
        metadata={"source_id": "github_repos"}
    )
    assert "programming" in labels
    assert conf == "HIGH"
    
def test_unknown_handling(classifier):
    labels, conf = classifier.classify_document(
        "This is just some random text with no particular structure.",
        metadata={}
    )
    assert labels == ["UNKNOWN"]
    assert conf == "UNKNOWN"

def test_conflicting_labels(classifier):
    # Test multiple matches
    labels, conf = classifier.classify_document(
        "user: what is the meaning of life? assistant: Let's consider a mathematical proof. \\begin{equation} x=1",
        metadata={"source_id": "chat_logs", "url": "arxiv.org/abs/math"}
    )
    # Math comes from URL (HIGH), dialogue from text (HIGH)
    assert "mathematical reasoning" in labels
    assert "conventional dialogue" in labels
    assert conf == "HIGH"
