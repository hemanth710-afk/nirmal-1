import pytest
from scripts.v9_7_learning_sanity import LearningSanityEvaluator

def test_discriminates_random():
    ev = LearningSanityEvaluator()
    assert ev.evaluate_model_state(0.05, 0.05, 0.05) == "RANDOM"

def test_discriminates_partial():
    ev = LearningSanityEvaluator()
    assert ev.evaluate_model_state(0.5, 0.4, 0.3) == "PARTIALLY_TRAINED"

def test_discriminates_overfit():
    ev = LearningSanityEvaluator()
    assert ev.evaluate_model_state(0.99, 0.05, 0.01) == "OVERFIT"

def test_discriminates_generalizing():
    ev = LearningSanityEvaluator()
    assert ev.evaluate_model_state(0.95, 0.95, 0.95) == "GENERALIZING"

def test_discriminator_coverage():
    ev = LearningSanityEvaluator()
    states = [
        ev.evaluate_model_state(0.0, 0.0, 0.0),
        ev.evaluate_model_state(0.5, 0.5, 0.5),
        ev.evaluate_model_state(1.0, 0.0, 0.0),
        ev.evaluate_model_state(1.0, 1.0, 0.0),
        ev.evaluate_model_state(1.0, 1.0, 1.0)
    ]
    assert len(set(states)) == 5 # Ensures 5 distinct categories are reachable
