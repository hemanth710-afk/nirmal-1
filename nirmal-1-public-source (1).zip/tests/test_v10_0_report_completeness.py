"""Tests for report completeness — V10.0."""
import json
import pytest
from pathlib import Path

RESULTS_PATH = Path("experiments/v10_0/results.json")

REQUIRED_KEYS = {
    "intervention", "mean_ood", "std_ood", "mean_val",
    "mean_train", "best_ood", "worst_ood", "primary_failure"
}


@pytest.mark.skipif(not RESULTS_PATH.exists(), reason="Results not yet generated")
def test_results_file_exists():
    assert RESULTS_PATH.exists()


@pytest.mark.skipif(not RESULTS_PATH.exists(), reason="Results not yet generated")
def test_results_schema():
    rows = json.loads(RESULTS_PATH.read_text())
    assert len(rows) > 0
    for row in rows:
        for key in REQUIRED_KEYS:
            assert key in row, f"Missing key {key!r} in row {row}"


@pytest.mark.skipif(not RESULTS_PATH.exists(), reason="Results not yet generated")
def test_all_ood_values_bounded():
    rows = json.loads(RESULTS_PATH.read_text())
    for row in rows:
        assert 0.0 <= row["mean_ood"] <= 1.0
        assert 0.0 <= row["best_ood"] <= 1.0
        assert 0.0 <= row["worst_ood"] <= 1.0


@pytest.mark.skipif(not RESULTS_PATH.exists(), reason="Results not yet generated")
def test_failure_labels_valid():
    valid = {"NONE", "VOCABULARY", "REPRESENTATION", "REPRESENTATION_PARTIAL",
             "POSITION", "OBJECTIVE", "TRAINING_SIGNAL", "CAPACITY",
             "OPTIMIZATION", "EVALUATION", "UNKNOWN"}
    rows = json.loads(RESULTS_PATH.read_text())
    for row in rows:
        assert row["primary_failure"] in valid, f"Unknown failure: {row['primary_failure']}"


@pytest.mark.skipif(not RESULTS_PATH.exists(), reason="Results not yet generated")
def test_baseline_present():
    rows = json.loads(RESULTS_PATH.read_text())
    names = {r["intervention"] for r in rows}
    assert any("BASELINE" in n for n in names)
