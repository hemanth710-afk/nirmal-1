import pytest
import torch
from scripts.run_capability_eval import CapabilityEvaluator, set_seed

def test_deterministic_dataset_fingerprints():
    evaluator = CapabilityEvaluator()
    set_seed(100)
    ds1 = evaluator.generate_dummy_dataset(100)
    set_seed(100)
    ds2 = evaluator.generate_dummy_dataset(100)
    assert torch.all(ds1 == ds2)
    
    set_seed(200)
    ds3 = evaluator.generate_dummy_dataset(100)
    assert not torch.all(ds1 == ds3)
