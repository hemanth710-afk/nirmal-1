import pytest
import json
from pathlib import Path
from training.acquisition.promotion_gate import RealSourcePromotionGate, PromotionSecurityError, DATA_DIR

@pytest.fixture
def setup_gate(tmp_path):
    gate = RealSourcePromotionGate(promotion_dir=tmp_path/"promotion", pilot_dir=tmp_path/"pilot", evidence_dir=tmp_path/"evidence")
    
    pilot_dir = tmp_path / "pilot"
    manifest_dir = pilot_dir / "manifests"
    manifest_dir.mkdir(parents=True, exist_ok=True)
    shard_dir = pilot_dir / "shards"
    shard_dir.mkdir(parents=True, exist_ok=True)
    prov_dir = pilot_dir / "provenance"
    prov_dir.mkdir(parents=True, exist_ok=True)
    
    with open(shard_dir / "test.bin", "wb") as f:
        f.write(b"00")
        
    return gate, tmp_path, manifest_dir

def test_path_traversal_shard(setup_gate):
    gate, tmp_path, manifest_dir = setup_gate
    
    traversal_path = str(DATA_DIR / "shards" / "test.bin")
    manifest = {
        "source_id": "test_source",
        "state": "PILOT_ELIGIBLE",
        "cryptographic_hashes": {
            "final_shard_sha256": "dummy"
        },
        "shard_path": traversal_path
    }
    with open(manifest_dir / "test_source_pilot_manifest.json", "w") as f:
        json.dump(manifest, f)
        
    try:
        result = gate.promote_source("test_source")
        assert result.verdict == "REJECTED"
    except Exception:
        pass
