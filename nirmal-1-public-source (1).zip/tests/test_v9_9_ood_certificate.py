import pytest
import torch
from scripts.v9_9_ood_investigation import OodInvestigator

def test_ood_certificate_valid():
    inv = OodInvestigator()
    train, ood = inv.generate_vocab_ood_task()
    cert = inv.validate_ood_certificate(train, ood)
    assert cert["vocab_isolated"] == True
    assert cert["no_exact_match"] == True
    assert cert["no_subseq_leak"] == True
    assert cert["valid"] == True

def test_ood_certificate_vocab_leak():
    inv = OodInvestigator()
    train = torch.tensor([[10, 20, 30]])
    ood = torch.tensor([[30, 40, 50]])
    cert = inv.validate_ood_certificate(train, ood)
    assert cert["vocab_isolated"] == False
    assert cert["valid"] == False

def test_ood_certificate_exact_match():
    inv = OodInvestigator()
    train = torch.tensor([[10, 20, 30]])
    ood = torch.tensor([[10, 20, 30]])
    cert = inv.validate_ood_certificate(train, ood)
    assert cert["no_exact_match"] == False
    assert cert["valid"] == False

def test_ood_certificate_subseq_leak():
    inv = OodInvestigator()
    train = torch.tensor([[10, 20, 30, 40]])
    ood = torch.tensor([[10, 20, 30, 50]])
    cert = inv.validate_ood_certificate(train, ood)
    assert cert["no_subseq_leak"] == False
    assert cert["valid"] == False

def test_ood_certificate_isomorphic_task():
    inv = OodInvestigator()
    train, ood = inv.generate_isomorphic_task()
    cert = inv.validate_ood_certificate(train, ood)
    assert cert["valid"] == True
