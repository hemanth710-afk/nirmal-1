import pytest
import torch
from scripts.run_capability_eval import CapabilityEvaluator, set_seed

def test_reproducible_seed_handling():
    evaluator = CapabilityEvaluator()
    data = evaluator.generate_dummy_dataset(200)
    
    # Run twice with same seed
    res1 = evaluator.train_and_eval(data, steps=2, seed=42)
    res2 = evaluator.train_and_eval(data, steps=2, seed=42)
    
    for k in res1:
        assert res1[k] == res2[k]

    # Run with different seed
    res3 = evaluator.train_and_eval(data, steps=2, seed=43)
    # Different seed yields different initializations, but accuracy might still be 0.0 across the board.
    # We just ensure it runs without error.
    assert isinstance(res3, dict)
