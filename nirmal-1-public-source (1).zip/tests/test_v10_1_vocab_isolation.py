"""V10.1 — vocabulary isolation tests (reuses leakage_certificate)."""
import pytest
from training.acquisition.v10_1_ood_amplification import (
    VOCAB_CONDITIONS, TaskConfig, TaskGenerator
)


@pytest.fixture
def gen():
    return TaskGenerator()


def test_full_disjoint_cert_valid(gen):
    task = VOCAB_CONDITIONS["FULL_DISJOINT"]
    splits = gen.generate(task)
    cert = gen.leakage_certificate(splits)
    assert cert["vocab_disjoint"]
    assert cert["valid"]


def test_same_vocab_not_disjoint(gen):
    task = VOCAB_CONDITIONS["SAME_VOCAB"]
    splits = gen.generate(task)
    cert = gen.leakage_certificate(splits)
    # Same range → vocab overlap expected
    assert not cert["vocab_disjoint"]


def test_partial_disjoint_vocab(gen):
    task = VOCAB_CONDITIONS["PARTIAL_DISJOINT"]
    splits = gen.generate(task)
    # train [10,30), ood [20,40) — overlap at [20,30)
    train_tokens = set(splits["train"].flatten().tolist())
    ood_tokens   = set(splits["ood"].flatten().tolist())
    # there may or may not be overlap depending on which tokens were sampled
    # — what we check is that the structure is correct
    assert splits["train"].shape[0] == 8
    assert splits["ood"].shape[0]   == 8


def test_all_conditions_defined():
    assert "SAME_VOCAB"        in VOCAB_CONDITIONS
    assert "PARTIAL_DISJOINT"  in VOCAB_CONDITIONS
    assert "FULL_DISJOINT"     in VOCAB_CONDITIONS
