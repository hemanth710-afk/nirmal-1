"""
Unit tests for physical hardware detection and Candidate C validation in Nirmal-1 V8.4.
"""

import pytest

from scripts.check_training_hardware_ready import (
    probe_local_hardware,
    evaluate_hardware_readiness,
    MIN_PRODUCTION_GPUS,
    MIN_TOTAL_CLUSTER_VRAM_GB,
)


def test_probe_local_hardware():
    info = probe_local_hardware()
    assert "os" in info
    assert "cpu_logical_cores" in info
    assert "ram_gb" in info
    assert "cuda_available" in info
    assert "gpu_count" in info
    assert "total_vram_gb" in info


def test_evaluate_hardware_readiness_insufficient():
    # Synthetic insufficient host (0 GPUs, no CUDA)
    synth_host = {
        "os": "Windows",
        "cuda_available": False,
        "gpu_count": 0,
        "total_vram_gb": 0.0,
    }
    rep = evaluate_hardware_readiness(synth_host)
    assert rep["is_ready"] is False
    assert rep["verdict"] == "HARDWARE_NOT_READY"
    assert len(rep["deficits_and_blockers"]) >= 3


def test_evaluate_hardware_readiness_sufficient():
    # Synthetic compliant cluster (64x H100 80GB = 5120GB)
    synth_cluster = {
        "os": "Linux",
        "cuda_available": True,
        "gpu_count": 64,
        "total_vram_gb": 5120.0,
    }
    rep = evaluate_hardware_readiness(synth_cluster)
    assert rep["is_ready"] is True
    assert rep["verdict"] == "HARDWARE_READY"
    assert len(rep["deficits_and_blockers"]) == 0
