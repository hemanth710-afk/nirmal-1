"""
NIRMAL-1 V8.9: TEST SUITE FOR HARDENED REAL WIKIMEDIA ADAPTER

Verifies:
1. Real HTTP response parsing from mock response (genuine fields, extract text, URLs).
2. Genuine revision ID extraction and authenticity verification (positive integer check).
3. Content vs metadata separation (thumbnails, descriptions, dimensions not in tokenized stream).
4. Ceilings enforcement:
   - max 10 documents
   - max 1 MB download bytes
   - max 100,000 accepted tokens
   - max 100 MB temporary disk space
5. Bounded inspect() metadata and PILOT_ELIGIBLE status.
"""

import hashlib
import json
from pathlib import Path
import shutil
from typing import Any, Dict, List, Optional, Tuple
from unittest.mock import patch, MagicMock
import pytest

from training.acquisition.wikimedia_real_adapter import (
    WikimediaRealAdapter,
    DEFAULT_ACADEMIC_TOPICS,
)
from training.acquisition.pilot_adapter import (
    PilotLimitExceededError,
    PilotSecurityError,
)
from training.acquisition.pilot_provenance_audit import (
    PilotProvenanceClass,
    ProvenanceVerificationError,
)
from training.acquisition.safe_network_client import (
    SafeBoundedNetworkClient,
    SafeFetchResult,
)


@pytest.fixture
def temp_pilot_dirs(tmp_path):
    staging_dir = tmp_path / "pilot" / "staging"
    shards_dir = tmp_path / "pilot" / "shards"
    manifests_dir = tmp_path / "pilot" / "manifests"
    provenance_dir = tmp_path / "pilot" / "provenance"
    staging_dir.mkdir(parents=True)
    shards_dir.mkdir(parents=True)
    manifests_dir.mkdir(parents=True)
    provenance_dir.mkdir(parents=True)
    return staging_dir, shards_dir, manifests_dir, provenance_dir


def create_mock_summary_payload(
    title: str = "Quantum_computing",
    pageid: int = 24508,
    revision: any = 1198274612,
    extract: str = (
        "Quantum computing is a multidisciplinary field comprising aspects of computer science, "
        "physics, and mathematics that utilizes quantum mechanics to solve complex problems faster "
        "than classical computers. The field of quantum computing includes hardware research and "
        "algorithm development."
    ),
    description: str = "Multidisciplinary field of quantum information science",
    thumbnail_url: str = "https://upload.wikimedia.org/wikipedia/commons/thumb/q/qc.jpg/320px-qc.jpg",
) -> Dict[str, any]:
    return {
        "type": "standard",
        "title": title.replace("_", " "),
        "displaytitle": f"<i>{title.replace('_', ' ')}</i>",
        "pageid": pageid,
        "extract": extract,
        "extract_html": f"<p>{extract}</p>",
        "thumbnail": {"source": thumbnail_url, "width": 320, "height": 240},
        "originalimage": {"source": thumbnail_url.replace("320px-", ""), "width": 1200, "height": 900},
        "lang": "en",
        "dir": "ltr",
        "revision": revision,
        "tid": "12345678-abcd-ef01-2345-6789abcdef01",
        "timestamp": "2026-09-01T12:00:00Z",
        "description": description,
        "description_source": "local",
        "content_urls": {
            "desktop": {
                "page": f"https://en.wikipedia.org/wiki/{title}",
                "revisions": f"https://en.wikipedia.org/wiki/{title}?action=history",
                "edit": f"https://en.wikipedia.org/wiki/{title}?action=edit",
                "talk": f"https://en.wikipedia.org/wiki/Talk:{title}",
            },
            "mobile": {
                "page": f"https://en.m.wikipedia.org/wiki/{title}",
            },
        },
        "namespace": {"id": 0, "text": ""},
        "wikibase_item": "Q11190",
        "titles": {
            "canonical": title,
            "normalized": title.replace("_", " "),
            "display": title.replace("_", " "),
        },
    }


class MockNetworkClient:
    """Mock network client that emits realistic Wikimedia summary API payloads."""

    def __init__(self, payload_override=None, byte_overhead=0):
        self.payload_override = payload_override
        self.byte_overhead = byte_overhead
        self.calls = []

    def fetch_url_to_file(self, url: str, destination_path: Path, expected_sha256=None) -> SafeFetchResult:
        self.calls.append(url)
        title = url.split("/")[-1]
        if self.payload_override is not None:
            data = self.payload_override
        else:
            data = create_mock_summary_payload(title=title)

        raw_bytes = json.dumps(data, indent=2).encode("utf-8")
        if self.byte_overhead > 0:
            raw_bytes += b" " * self.byte_overhead

        destination_path.parent.mkdir(parents=True, exist_ok=True)
        destination_path.write_bytes(raw_bytes)
        sha256_hash = hashlib.sha256(raw_bytes).hexdigest()

        return SafeFetchResult(
            url=url,
            status_code=200,
            content_type="application/json",
            payload_bytes=len(raw_bytes),
            sha256_hash=sha256_hash,
            local_path=destination_path,
            retrieval_timestamp="2026-09-01T12:00:00Z",
            redirect_count=0,
        )


class TestWikimediaRealAdapter:
    """Rigorous tests for the hardened Wikimedia Real Adapter."""

    def test_inspect_returns_metadata_and_ceilings(self, temp_pilot_dirs):
        staging_dir, shards_dir, manifests_dir, prov_dir = temp_pilot_dirs
        adapter = WikimediaRealAdapter(
            staging_dir=staging_dir,
            shards_dir=shards_dir,
            manifests_dir=manifests_dir,
            provenance_dir=prov_dir,
        )
        info = adapter.inspect()
        assert info["source_id"] == "wikipedia_open_corpus"
        assert info["pilot_status"] == "PILOT_ELIGIBLE"
        assert info["status"] == "PILOT_ELIGIBLE"
        assert info["format"] == "wikimedia_rest_v1_json"
        assert info["endpoint"] == "https://en.wikipedia.org/api/rest_v1/page/summary/{title}"
        assert info["ceilings"]["max_documents"] == 10
        assert info["ceilings"]["max_download_bytes"] == 1048576
        assert info["ceilings"]["max_doc_bytes"] == 128 * 1024
        assert info["ceilings"]["max_accepted_tokens"] == 100000
        assert info["ceilings"]["max_temp_disk_bytes"] == 104857600
        assert len(info["deterministic_academic_topics"]) == 10
        assert info["deterministic_academic_topics"] == DEFAULT_ACADEMIC_TOPICS

    def test_real_http_response_parsing_from_mock_response(self, temp_pilot_dirs):
        staging_dir, shards_dir, manifests_dir, prov_dir = temp_pilot_dirs
        mock_client = MockNetworkClient()
        adapter = WikimediaRealAdapter(
            staging_dir=staging_dir,
            shards_dir=shards_dir,
            manifests_dir=manifests_dir,
            provenance_dir=prov_dir,
            network_client=mock_client,
        )

        records, total_bytes = adapter.fetch_bounded(topics=["Quantum_computing"], max_docs=1)
        assert len(records) == 1
        rec = records[0]

        # Verify parsed identity and revision fields
        assert rec["id"] == "wiki_24508"
        assert rec["page_id"] == "24508"
        assert rec["title"] == "Quantum computing"
        assert rec["revision_id"] == "1198274612"
        assert rec["revision_verified"] is True
        assert rec["url"] == "https://en.wikipedia.org/wiki/Quantum_computing"
        assert rec["provenance_class"] == PilotProvenanceClass.REMOTE_SOURCE_DATA.value
        assert rec["is_network_retrieved"] is True
        assert rec["is_local_fixture"] is False
        assert rec["is_synthetic"] is False

        # Verify plain-text extract
        assert "Quantum computing is a multidisciplinary field" in rec["text"]
        assert rec["raw_bytes"] == total_bytes
        assert len(rec["raw_payload_hash"]) == 64

        # Verify segregated metadata
        meta = rec["metadata"]
        assert meta["page_id"] == 24508
        assert "thumb/q/qc.jpg" in meta["thumbnail"]["source"]
        assert meta["thumbnail"]["width"] == 320
        assert meta["description"] == "Multidisciplinary field of quantum information science"

    def test_genuine_revision_id_extraction(self, temp_pilot_dirs):
        staging_dir, shards_dir, manifests_dir, prov_dir = temp_pilot_dirs

        # Test case 1: Positive integer revision -> genuine
        p1 = create_mock_summary_payload(revision=1198274612)
        adapter1 = WikimediaRealAdapter(
            staging_dir=staging_dir,
            shards_dir=shards_dir,
            manifests_dir=manifests_dir,
            provenance_dir=prov_dir,
            network_client=MockNetworkClient(payload_override=p1),
        )
        records1, _ = adapter1.fetch_bounded(topics=["Quantum_computing"], max_docs=1)
        assert records1[0]["revision_id"] == "1198274612"
        assert records1[0]["revision_verified"] is True

        # Test case 2: Numeric string revision -> genuine
        p2 = create_mock_summary_payload(revision="99887766")
        adapter2 = WikimediaRealAdapter(
            staging_dir=staging_dir,
            shards_dir=shards_dir,
            manifests_dir=manifests_dir,
            provenance_dir=prov_dir,
            network_client=MockNetworkClient(payload_override=p2),
        )
        records2, _ = adapter2.fetch_bounded(topics=["Differential_geometry"], max_docs=1)
        assert records2[0]["revision_id"] == "99887766"
        assert records2[0]["revision_verified"] is True

        # Test case 3: Non-numeric revision ("rev_99182736" or "mock") -> unverified
        p3 = create_mock_summary_payload(revision="rev_99182736")
        adapter3 = WikimediaRealAdapter(
            staging_dir=staging_dir,
            shards_dir=shards_dir,
            manifests_dir=manifests_dir,
            provenance_dir=prov_dir,
            network_client=MockNetworkClient(payload_override=p3),
        )
        records3, _ = adapter3.fetch_bounded(topics=["Photosynthesis"], max_docs=1)
        assert records3[0]["revision_id"] == "rev_99182736"
        assert records3[0]["revision_verified"] is False

        # Test case 4: None revision -> unverified
        p4 = create_mock_summary_payload(revision=None)
        adapter4 = WikimediaRealAdapter(
            staging_dir=staging_dir,
            shards_dir=shards_dir,
            manifests_dir=manifests_dir,
            provenance_dir=prov_dir,
            network_client=MockNetworkClient(payload_override=p4),
        )
        records4, _ = adapter4.fetch_bounded(topics=["Turing_machine"], max_docs=1)
        assert records4[0]["revision_verified"] is False

    def test_content_vs_metadata_separation(self, temp_pilot_dirs):
        staging_dir, shards_dir, manifests_dir, prov_dir = temp_pilot_dirs
        mock_client = MockNetworkClient()
        adapter = WikimediaRealAdapter(
            staging_dir=staging_dir,
            shards_dir=shards_dir,
            manifests_dir=manifests_dir,
            provenance_dir=prov_dir,
            network_client=mock_client,
        )

        records, _ = adapter.fetch_bounded(topics=["Quantum_computing"], max_docs=1)
        rec = records[0]

        # Ensure extract text in 'text' does NOT contain metadata fields
        thumbnail_url = rec["metadata"]["thumbnail"]["source"]
        description = rec["metadata"]["description"]

        assert thumbnail_url not in rec["text"]
        assert description not in rec["text"]
        assert "320px" not in rec["text"]

        # Run normalize() and verify isolation is preserved
        norm_records = adapter.normalize(records)
        norm_text = norm_records[0]["text"]
        assert thumbnail_url not in norm_text
        assert description not in norm_text

        # Run full pipeline and inspect tokenized stream
        result = adapter.run_pipeline(records=records)
        assert result.status == "SUCCESS"
        assert result.documents_accepted == 1

        # Decode tokens to verify zero metadata was tokenized
        decoded_corpus = adapter.tokenization_pipeline.tokenizer.decode(adapter.all_token_ids)
        assert thumbnail_url not in decoded_corpus
        assert description not in decoded_corpus
        assert "Quantum computing is a multidisciplinary field" in decoded_corpus

    def test_ceilings_enforcement_max_documents(self, temp_pilot_dirs):
        staging_dir, shards_dir, manifests_dir, prov_dir = temp_pilot_dirs
        adapter = WikimediaRealAdapter(
            staging_dir=staging_dir,
            shards_dir=shards_dir,
            manifests_dir=manifests_dir,
            provenance_dir=prov_dir,
            network_client=MockNetworkClient(),
        )

        # Breach via max_docs > 10
        with pytest.raises(PilotLimitExceededError) as exc1:
            adapter.fetch_bounded(max_docs=11)
        assert "max_docs ceiling breached" in str(exc1.value)

        # Breach via topics list > 10
        too_many_topics = DEFAULT_ACADEMIC_TOPICS + ["Extra_topic_11"]
        with pytest.raises(PilotLimitExceededError) as exc2:
            adapter.fetch_bounded(topics=too_many_topics, max_docs=10)
        assert "Requested topics count exceeds max_docs ceiling" in str(exc2.value)

    def test_ceilings_enforcement_max_payload_bytes(self, temp_pilot_dirs):
        staging_dir, shards_dir, manifests_dir, prov_dir = temp_pilot_dirs
        adapter = WikimediaRealAdapter(
            staging_dir=staging_dir,
            shards_dir=shards_dir,
            manifests_dir=manifests_dir,
            provenance_dir=prov_dir,
            network_client=MockNetworkClient(),
        )

        # Breach via max_payload_bytes parameter > 1 MB
        with pytest.raises(PilotLimitExceededError) as exc:
            adapter.fetch_bounded(max_payload_bytes=1048577)
        assert "max_payload_bytes ceiling breached" in str(exc.value)

        # Breach via actual downloaded bytes exceeding ceiling
        huge_mock_client = MockNetworkClient(byte_overhead=1048576 + 100)
        adapter_huge = WikimediaRealAdapter(
            staging_dir=staging_dir,
            shards_dir=shards_dir,
            manifests_dir=manifests_dir,
            provenance_dir=prov_dir,
            network_client=huge_mock_client,
        )
        with pytest.raises(PilotLimitExceededError) as exc2:
            adapter_huge.fetch_bounded(topics=["Quantum_computing"], max_docs=1)
        assert "Cumulative download bytes ceiling breached" in str(exc2.value)

    def test_ceilings_enforcement_max_tokens(self, temp_pilot_dirs):
        staging_dir, shards_dir, manifests_dir, prov_dir = temp_pilot_dirs
        adapter = WikimediaRealAdapter(
            staging_dir=staging_dir,
            shards_dir=shards_dir,
            manifests_dir=manifests_dir,
            provenance_dir=prov_dir,
        )
        adapter.max_tokens = 50  # Artificially low ceiling for test

        # Document with ~100 tokens
        long_text = "Quantum computing algorithms utilize entanglement and superposition to accelerate processing. " * 15
        rec = {
            "id": "wiki_long",
            "page_id": "24508",
            "title": "Quantum computing",
            "revision_id": "1198274612",
            "revision_verified": True,
            "timestamp": "2026-09-01T12:00:00Z",
            "url": "https://en.wikipedia.org/wiki/Quantum_computing",
            "license": "CC-BY-SA-4.0",
            "text": long_text,
            "raw_payload_hash": hashlib.sha256(long_text.encode("utf-8")).hexdigest(),
            "raw_bytes": len(long_text.encode("utf-8")),
            "provenance_class": PilotProvenanceClass.REMOTE_SOURCE_DATA.value,
            "is_network_retrieved": True,
            "is_local_fixture": False,
            "is_synthetic": False,
            "is_copied_from_repo": False,
        }

        with pytest.raises(PilotLimitExceededError) as exc:
            adapter.run_pipeline(records=[rec])
        assert "Token ceiling breached" in str(exc.value)

    def test_ceilings_enforcement_disk_space(self, temp_pilot_dirs):
        staging_dir, shards_dir, manifests_dir, prov_dir = temp_pilot_dirs
        adapter = WikimediaRealAdapter(
            staging_dir=staging_dir,
            shards_dir=shards_dir,
            manifests_dir=manifests_dir,
            provenance_dir=prov_dir,
        )

        # Mock shutil.disk_usage to report only 50 MB free (< 100 MB required)
        with patch("shutil.disk_usage", return_value=(1000 * 1024 * 1024, 950 * 1024 * 1024, 50 * 1024 * 1024)):
            with pytest.raises(PilotLimitExceededError) as exc:
                adapter.prepare_pilot()
            assert "Insufficient disk space for staging" in str(exc.value)
