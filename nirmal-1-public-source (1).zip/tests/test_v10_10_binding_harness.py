"""V10.10-SPEC-AMENDMENT-01: Symbol, seed, serialization, query, and ladder tests."""

import pytest

from training.evaluation.v10_10_binding_harness import (
    ANS_TOKEN,
    BOS_TOKEN,
    CONFIRMATION_SEEDS,
    CONTEXT_LENGTH,
    DEFAULT_VOCAB_SIZE,
    DEVELOPMENT_SEEDS,
    DIAGNOSTIC_ATOM_COUNT,
    DIAGNOSTIC_ATOM_START,
    DIAGNOSTIC_TOKENS,
    FILL_TOKEN,
    HISTORICAL_SEED_42,
    KEY_ATOM_COUNT,
    KEY_ATOM_START,
    KEY_ROLE_TOKEN,
    KEY_TOKENS,
    LEVELS,
    MAP_TOKEN,
    PAIR_CLOSE_TOKEN,
    PAIR_OPEN_TOKEN,
    PAIR_SEP_TOKEN,
    QUERY_FORMATS,
    QUERY_TOKEN,
    RECORD_SEP_TOKEN,
    RESERVED_TOKENS,
    SERIALIZATIONS,
    VALUE_ATOM_COUNT,
    VALUE_ATOM_START,
    VALUE_ROLE_TOKEN,
    VALUE_TOKENS,
    BindingBenchmarkGenerator,
    audit_split,
    derive_namespace_seed,
    encode_pair,
    encode_query,
    parse_query_tokens,
    parse_support_tokens,
    validate_control_set,
)


def test_128_symbol_table_and_disjoint_partitions():
    assert len(RESERVED_TOKENS) == 17  # 15..31
    assert len(KEY_TOKENS) == 32       # 32..63
    assert len(VALUE_TOKENS) == 32     # 64..95
    assert len(DIAGNOSTIC_TOKENS) == 32 # 96..127
    all_symbols = (
        set(range(15))  # structural 0..14
        | set(RESERVED_TOKENS)
        | set(KEY_TOKENS)
        | set(VALUE_TOKENS)
        | set(DIAGNOSTIC_TOKENS)
    )
    assert len(all_symbols) == 128
    assert max(all_symbols) == 127
    assert min(all_symbols) == 0
    # Disjointness checks
    assert not (set(KEY_TOKENS) & set(VALUE_TOKENS))
    assert not (set(KEY_TOKENS) & set(DIAGNOSTIC_TOKENS))
    assert not (set(VALUE_TOKENS) & set(DIAGNOSTIC_TOKENS))
    assert not (set(RESERVED_TOKENS) & (set(KEY_TOKENS) | set(VALUE_TOKENS) | set(DIAGNOSTIC_TOKENS)))


def test_frozen_root_seeds_and_exclusion_of_seed_42():
    assert DEVELOPMENT_SEEDS == (104729, 130363, 155921)
    assert CONFIRMATION_SEEDS == (196613, 262147, 393241)
    assert not (set(DEVELOPMENT_SEEDS) & set(CONFIRMATION_SEEDS))
    assert HISTORICAL_SEED_42 not in DEVELOPMENT_SEEDS
    assert HISTORICAL_SEED_42 not in CONFIRMATION_SEEDS


def test_cryptographic_namespace_derivation_and_test_vectors():
    s_dev, eff_dev = derive_namespace_seed(
        purpose="development",
        root_seed=104729,
        split="development",
        level="B2",
        serialization="S1",
        query="Q1",
        control="correct",
        index=0,
        stream="episode",
    )
    assert s_dev == "NIRMAL-1|V10.10-SPEC-AMENDMENT-01|purpose=development|root=104729|split=development|level=B2|serialization=S1|query=Q1|control=correct|index=0|stream=episode"
    assert eff_dev == 3368561188779504967

    s_conf, eff_conf = derive_namespace_seed(
        purpose="confirmation",
        root_seed=196613,
        split="confirmation",
        level="B2",
        serialization="S1",
        query="Q1",
        control="correct",
        index=0,
        stream="episode",
    )
    assert eff_conf == 7724636064580088382


def test_purpose_and_split_agreement_enforcement():
    # Purpose development requires train or development split
    with pytest.raises(ValueError, match="do not agree"):
        derive_namespace_seed("development", 104729, "locked-test", "B2", "S1", "Q1", "correct", 0, "episode")

    # Purpose locked-test requires locked-test split
    with pytest.raises(ValueError, match="do not agree"):
        derive_namespace_seed("locked-test", 196613, "train", "B2", "S1", "Q1", "correct", 0, "episode")

    # Invalid purpose
    with pytest.raises(ValueError, match="Invalid purpose"):
        derive_namespace_seed("unapproved", 104729, "train", "B2", "S1", "Q1", "correct", 0, "episode")


def test_exact_s1_s2_s3_round_trip_and_serialization_enum():
    assert SERIALIZATIONS == ("S1", "S2", "S3")
    sample_pairs = [
        ((32,), (64,)),
        ((33, 34), (65, 66)),
    ]
    for fmt in ("S1", "S2", "S3"):
        tokens = [BOS_TOKEN]
        for k, v in sample_pairs:
            tokens.extend(encode_pair(k, v, fmt))
        parsed = parse_support_tokens(tokens, fmt)
        assert parsed == sample_pairs


def test_malformed_support_records_fail_closed():
    # Missing BOS
    with pytest.raises(ValueError):
        parse_support_tokens([KEY_ROLE_TOKEN, 32, MAP_TOKEN, VALUE_ROLE_TOKEN, 64, PAIR_SEP_TOKEN], "S1")
    # Empty key span in S1
    with pytest.raises(ValueError):
        parse_support_tokens([BOS_TOKEN, KEY_ROLE_TOKEN, MAP_TOKEN, VALUE_ROLE_TOKEN, 64, PAIR_SEP_TOKEN], "S1")
    # Key atom out of range in S1
    with pytest.raises(ValueError):
        parse_support_tokens([BOS_TOKEN, KEY_ROLE_TOKEN, 15, MAP_TOKEN, VALUE_ROLE_TOKEN, 64, PAIR_SEP_TOKEN], "S1")
    # Unclosed S2 record
    with pytest.raises(ValueError):
        parse_support_tokens([BOS_TOKEN, PAIR_OPEN_TOKEN, KEY_ROLE_TOKEN, 32, VALUE_ROLE_TOKEN, 64], "S2")
    # S3 missing RECORD_SEP
    with pytest.raises(ValueError):
        parse_support_tokens([BOS_TOKEN, 32, MAP_TOKEN, 64], "S3")


def test_q1_q2_q3_parsing_and_length_matching():
    assert QUERY_FORMATS == ("Q1", "Q2", "Q3")
    q_key = (32, 33)  # key length 2 -> slot width 5 + 2 = 7
    q1 = encode_query(q_key, "Q1")
    q2 = encode_query(q_key, "Q2")
    q3 = encode_query(q_key, "Q3")

    # All slots have identical width 7
    assert len(q1) == len(q2) == len(q3) == 7
    # Terminal token is always ANS_TOKEN
    assert q1[-1] == q2[-1] == q3[-1] == ANS_TOKEN
    # Shorter queries have leading FILL
    assert q1[:2] == [FILL_TOKEN, FILL_TOKEN]
    assert q2[:3] == [FILL_TOKEN, FILL_TOKEN, FILL_TOKEN]
    assert q3[0] != FILL_TOKEN

    # Parser ignores leading FILL and recovers exact key tuple
    assert parse_query_tokens(q1, "Q1") == q_key
    assert parse_query_tokens(q2, "Q2") == q_key
    assert parse_query_tokens(q3, "Q3") == q_key


def test_difficulty_ladder_b0_through_b5():
    assert LEVELS == ("B0", "B1", "B2", "B3", "B4", "B5")
    gen = BindingBenchmarkGenerator()
    for level in LEVELS:
        sets = gen.generate_split(level, "development", DEVELOPMENT_SEEDS[0], 16, "S1", "Q1")
        assert len(sets) == 16
        for cs in sets:
            assert validate_control_set(cs)["valid"]
            # Check maximum sequence length fits within CONTEXT_LENGTH (256)
            for ep in cs.episodes.values():
                assert len(ep.input_ids) <= CONTEXT_LENGTH
                assert ep.input_ids[-1] == ANS_TOKEN

    # Check pair counts
    assert BindingBenchmarkGenerator.pair_count("B0") == 1
    assert BindingBenchmarkGenerator.pair_count("B1") == 1
    assert BindingBenchmarkGenerator.pair_count("B2") == 2
    assert BindingBenchmarkGenerator.pair_count("B3") == 4
    assert BindingBenchmarkGenerator.pair_count("B4") == 8
    assert BindingBenchmarkGenerator.pair_count("B5") == 16


def test_b4_and_b5_multi_token_structure():
    gen = BindingBenchmarkGenerator()
    b4 = gen.generate_base("B4", "development", DEVELOPMENT_SEEDS[0], 0)
    assert len(b4.pairs) == 8
    assert len(b4.pairs[0].key) == 2
    assert len(b4.pairs[0].value) == 2

    b5 = gen.generate_base("B5", "development", DEVELOPMENT_SEEDS[0], 0)
    assert len(b5.pairs) == 16
    assert len(b5.pairs[0].key) == 2
    assert len(b5.pairs[0].value) == 2


def test_query_and_target_balance():
    gen = BindingBenchmarkGenerator()
    sets = gen.generate_split("B2", "development", DEVELOPMENT_SEEDS[0], 32, "S1", "Q1")
    audit = audit_split(sets)
    assert audit["valid"]
    assert audit["target_balance_gap"] <= 1
    assert audit["position_balance_gap"] <= 1
