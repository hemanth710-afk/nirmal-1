"""V10.1 — report completeness tests."""
import json
import pytest
from pathlib import Path

RESULTS_PATH = Path("experiments/v10_1/v10_1_results.json")

REQUIRED_TOP_KEYS = {"experiment_a_dose", "experiment_b_curriculum", "experiment_c_vocab"}
REPR_MODES = {"identity", "value_relative"}
CURRICULUM_NAMES = {"B1_COPY", "B2_COPY_INC", "B3_COPY_INC_DS"}
VOCAB_CONDITIONS_NAMES = {"SAME_VOCAB", "PARTIAL_DISJOINT", "FULL_DISJOINT"}


@pytest.mark.skipif(not RESULTS_PATH.exists(), reason="Results not yet generated")
def test_results_file_exists():
    assert RESULTS_PATH.exists()


@pytest.mark.skipif(not RESULTS_PATH.exists(), reason="Results not yet generated")
def test_top_level_keys():
    data = json.loads(RESULTS_PATH.read_text())
    for key in REQUIRED_TOP_KEYS:
        assert key in data, f"Missing top-level key: {key}"


@pytest.mark.skipif(not RESULTS_PATH.exists(), reason="Results not yet generated")
def test_exp_a_repr_modes_present():
    data = json.loads(RESULTS_PATH.read_text())
    for mode in REPR_MODES:
        assert mode in data["experiment_a_dose"]


@pytest.mark.skipif(not RESULTS_PATH.exists(), reason="Results not yet generated")
def test_exp_a_ood_bounded():
    data = json.loads(RESULTS_PATH.read_text())
    for mode in data["experiment_a_dose"]:
        for budget, stats in data["experiment_a_dose"][mode].items():
            assert 0.0 <= stats["mean_ood"] <= 1.0
            assert 0.0 <= stats["best_ood"] <= 1.0


@pytest.mark.skipif(not RESULTS_PATH.exists(), reason="Results not yet generated")
def test_exp_b_curriculum_present():
    data = json.loads(RESULTS_PATH.read_text())
    for name in CURRICULUM_NAMES:
        assert name in data["experiment_b_curriculum"]


@pytest.mark.skipif(not RESULTS_PATH.exists(), reason="Results not yet generated")
def test_exp_c_vocab_conditions_present():
    data = json.loads(RESULTS_PATH.read_text())
    for name in VOCAB_CONDITIONS_NAMES:
        assert name in data["experiment_c_vocab"]
