"""
Automated Test Suite for Nirmal-1 Production Source Verification & Approval Audit.

Tests:
1. Source approval rules: only sources with verified on-disk evidence are APPROVED.
2. Rejected source handling: proprietary or non-commercial sources are REJECTED and blocked.
3. Missing license evidence: planned sources without local legal proof remain in REQUIRES_REVIEW.
4. Missing provenance: records missing required provenance metadata fail verification.
5. Contamination-risk blocking: sources with unresolved benchmark overlap are blocked.
6. Token accounting: claimed/expected tokens never inflate verified token count.
7. Mixture recalculation: validates mathematical consistency of Baseline, Conservative, and High-Headroom mixes.
8. Source fingerprinting: tampering with any source property invalidates its cryptographic fingerprint.
"""

import hashlib
import json
from pathlib import Path
import pytest

REPO_ROOT = Path(__file__).resolve().parent.parent


@pytest.fixture
def source_plan_v2():
    path = REPO_ROOT / "data" / "production_source_plan_v2.json"
    assert path.exists(), "production_source_plan_v2.json must exist"
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


@pytest.fixture
def source_registry():
    path = REPO_ROOT / "data" / "source_registry.json"
    assert path.exists(), "source_registry.json must exist"
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


class TestProductionSourceVerification:
    """Test suite verifying source audit and approval rules."""

    def test_source_approval_rules_and_status_isolation(self, source_plan_v2):
        """Only sources with verified on-disk evidence can be APPROVED."""
        sources = {s["source_id"]: s for s in source_plan_v2["sources"]}

        # nirmal_synthetic_v8_2 has physical files and in-repo code
        assert sources["nirmal_synthetic_v8_2"]["approval_status"] == "APPROVED"
        assert sources["nirmal_synthetic_v8_2"]["eligible_for_acquisition"] is True
        assert sources["nirmal_synthetic_v8_2"]["verified_tokens"] == 233997

        # All 6 planned external sources must NOT be approved without physical evidence
        planned_ids = [
            "fineweb_edu_permissive",
            "the_stack_v2_permissive",
            "arxiv_open_access_papers",
            "dolma_v1_7_permissive",
            "redpajama_v2_permissive",
            "wikipedia_open_corpus",
        ]
        for pid in planned_ids:
            assert sources[pid]["approval_status"] == "REQUIRES_REVIEW"
            assert sources[pid]["eligible_for_acquisition"] is False
            assert sources[pid]["verified_tokens"] == 0

    def test_rejected_source_handling(self, source_plan_v2):
        """Proprietary and non-commercial sources are strictly REJECTED."""
        sources = {s["source_id"]: s for s in source_plan_v2["sources"]}

        assert sources["proprietary_forum_scrapes"]["approval_status"] == "REJECTED"
        assert sources["proprietary_forum_scrapes"]["eligible_for_acquisition"] is False

        assert sources["non_commercial_research_corpus"]["approval_status"] == "REJECTED"
        assert sources["non_commercial_research_corpus"]["eligible_for_acquisition"] is False

    def test_missing_license_evidence_blocks_approval(self, source_plan_v2):
        """Sources with PARTIAL_EXTERNAL evidence cannot have approval_status == APPROVED."""
        for s in source_plan_v2["sources"]:
            if s["license_evidence_status"] == "PARTIAL_EXTERNAL":
                assert s["approval_status"] != "APPROVED", (
                    f"Source {s['source_id']} with partial external evidence cannot be approved!"
                )

    def test_missing_provenance_schema_validation(self):
        """Ensures all 11 required provenance fields are defined and enforced."""
        required_provenance_fields = [
            "source_id",
            "source_url_or_location",
            "source_version",
            "license",
            "license_evidence_ref",
            "acquisition_timestamp",
            "document_id",
            "content_hash",
            "source_checksum",
            "preprocessing_version",
            "tokenizer_checksum",
        ]
        dummy_record = {
            "source_id": "test_src",
            "source_url_or_location": "https://example.com/data",
            "source_version": "1.0",
            # missing license
        }
        missing = [f for f in required_provenance_fields if f not in dummy_record]
        assert "license" in missing
        assert len(missing) > 0

    def test_contamination_risk_blocks_acquisition(self, source_plan_v2):
        """Sources with unresolved benchmark overlap risk must be ineligible for acquisition."""
        for s in source_plan_v2["sources"]:
            if "UNRESOLVED" in s["contamination_risk"] or "OVERLAP" in s["contamination_risk"]:
                assert s["eligible_for_acquisition"] is False

    def test_token_accounting_integrity(self, source_plan_v2):
        """Claimed tokens must NEVER inflate the verified token count."""
        claimed_sum = sum(s["claimed_tokens"] for s in source_plan_v2["sources"])
        verified_sum = sum(s["verified_tokens"] for s in source_plan_v2["sources"])

        assert claimed_sum > 200_000_000_000, "Claimed tokens exceed 200B"
        assert verified_sum == 233997, "Only 233,997 tokens are physically verified"
        assert source_plan_v2["current_verified_tokens"] == verified_sum
        assert source_plan_v2["verified_deficit_tokens"] == (200_000_000_000 - 233997)

    def test_mixture_recalculation_consistency(self, source_plan_v2):
        """Validates mathematical properties of Baseline, Conservative, and High-Headroom mixes."""
        models = source_plan_v2["mixture_models"]

        for mix_key in ["baseline_mix", "conservative_mix", "high_headroom_mix"]:
            mix = models[mix_key]
            raw = mix["raw_staged_tokens"]
            expected = mix["expected_yield_tokens"]
            target = mix["target_verified_tokens"]

            # Headroom factor check
            assert raw > expected >= target >= 200_000_000_000
            assert mix["headroom_factor"] > 1.0

            # Sum of allocations matches totals
            alloc_raw_sum = sum(a["raw_tokens"] for a in mix["allocations"])
            alloc_yield_sum = sum(a["yield_tokens"] for a in mix["allocations"])
            assert alloc_raw_sum == raw
            assert alloc_yield_sum == expected

    def test_source_fingerprinting_tamper_detection(self, source_plan_v2):
        """Tampering with source metadata changes its cryptographic fingerprint."""
        raw_bytes = json.dumps(source_plan_v2["sources"], sort_keys=True).encode("utf-8")
        h1 = hashlib.sha256(raw_bytes).hexdigest()

        # Modify a field
        tampered_sources = json.loads(json.dumps(source_plan_v2["sources"]))
        tampered_sources[1]["claimed_license"] = "GPL-3.0"
        tampered_bytes = json.dumps(tampered_sources, sort_keys=True).encode("utf-8")
        h2 = hashlib.sha256(tampered_bytes).hexdigest()

        assert h1 != h2, "Fingerprint must change when source metadata is tampered"
