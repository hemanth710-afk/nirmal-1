"""
Unit tests for attention mechanisms, RoPE, RMSNorm, and KV caching.
"""

import torch
import pytest

from nirmal.configuration_nirmal import NirmalConfig
from nirmal.attention import NirmalRMSNorm, NirmalRotaryEmbedding, NirmalCausalAttention, rotate_half


def test_rmsnorm_numerical_stability():
    """Verify RMSNorm produces expected normalized variance and preserves shape."""
    dim = 128
    norm = NirmalRMSNorm(dim, eps=1e-6)
    x = torch.randn(2, 16, dim) * 50.0  # Large variance input
    out = norm(x)

    assert out.shape == x.shape
    # Check that variance along the last dimension is close to 1
    var = out.pow(2).mean(-1)
    assert torch.allclose(var, torch.ones_like(var), atol=1e-2)


def test_rotary_embedding_norm_preservation():
    """RoPE rotation must preserve the L2 norm of head vectors."""
    dim = 64
    seq_len = 10
    rope = NirmalRotaryEmbedding(dim=dim)
    dummy_x = torch.randn(1, 1, seq_len, dim)
    cos, sin = rope(dummy_x, seq_len=seq_len)

    q = torch.randn(2, 4, seq_len, dim)
    cos_s = cos.unsqueeze(0).unsqueeze(0)
    sin_s = sin.unsqueeze(0).unsqueeze(0)
    q_rot = (q * cos_s) + (rotate_half(q) * sin_s)

    norm_before = torch.norm(q, dim=-1)
    norm_after = torch.norm(q_rot, dim=-1)
    assert torch.allclose(norm_before, norm_after, atol=1e-4)


def test_causal_attention_shapes_and_caching():
    """Verify GQA causal attention forward pass and incremental KV caching equivalence."""
    config = NirmalConfig(
        hidden_size=256,
        num_attention_heads=4,
        num_key_value_heads=2,
        head_dim=64,
        context_length=512,
    )
    attn = NirmalCausalAttention(config)
    attn.eval()

    batch_size = 2
    seq_len = 8
    x = torch.randn(batch_size, seq_len, config.hidden_size)

    # 1. Full sequence forward pass without cache
    with torch.no_grad():
        out_full, _ = attn(x, use_cache=False)
    assert out_full.shape == (batch_size, seq_len, config.hidden_size)

    # 2. Incremental forward pass with KV cache
    with torch.no_grad():
        # Prefill prompt of length 4
        out_prefix, past_kv = attn(x[:, :4, :], use_cache=True)
        assert past_kv[0].shape[-2] == 4

        # Incremental token steps 4..7
        step_outputs = [out_prefix]
        for t in range(4, seq_len):
            step_out, past_kv = attn(x[:, t : t + 1, :], past_key_value=past_kv, use_cache=True)
            step_outputs.append(step_out)

        out_cached = torch.cat(step_outputs, dim=1)

    assert out_cached.shape == out_full.shape
    # Check numerical consistency between cached and uncached forward
    assert torch.allclose(out_full, out_cached, atol=1e-4)


def test_attention_with_explicit_position_ids():
    """Regression test for Issue 1: RoPE handles non-zero position_ids exceeding seq_len."""
    config = NirmalConfig(
        hidden_size=256,
        num_attention_heads=4,
        num_key_value_heads=2,
        head_dim=64,
        context_length=512,
    )
    attn = NirmalCausalAttention(config)
    x = torch.randn(1, 4, 256)
    # Positions 100..103 for sequence of length 4
    position_ids = torch.tensor([[100, 101, 102, 103]])
    out, _ = attn(x, position_ids=position_ids)
    assert out.shape == (1, 4, 256)
    assert not torch.isnan(out).any()


def test_causal_mask_preserved_with_padding_mask():
    """Regression test for Issue 2: 2D padding mask does not crash and causality is maintained."""
    config = NirmalConfig(
        hidden_size=256,
        num_attention_heads=4,
        num_key_value_heads=2,
        head_dim=64,
        context_length=512,
    )
    attn = NirmalCausalAttention(config)

    # 2 sequences, sequence 1 has last token padded
    x = torch.randn(2, 4, 256)
    padding_mask = torch.tensor([[1, 1, 1, 1], [1, 1, 1, 0]])

    out, _ = attn(x, attention_mask=padding_mask)
    assert out.shape == (2, 4, 256)
    assert not torch.isnan(out).any()
