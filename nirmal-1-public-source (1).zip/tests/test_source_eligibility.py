"""
NIRMAL-1 V8.7: TEST SUITE FOR SOURCE ELIGIBILITY (PHASE 1, 2, 10)

Verifies:
1. Source eligibility matrix JSON structure and policy status definitions.
2. All 9 sources are evaluated across all 10 criteria.
3. Separation of PILOT_ELIGIBLE vs APPROVED_FOR_PRODUCTION.
4. wikipedia_open_corpus is rank 1 and ELIGIBLE_FOR_PILOT.
5. All other 5 external candidate sources are NOT_ELIGIBLE / REQUIRES_REVIEW.
6. Rejected sources remain REJECTED.
7. External sources are NOT approved for production.
"""

import json
from pathlib import Path
import pytest

REPO_ROOT = Path(__file__).resolve().parent.parent
ELIGIBILITY_PATH = REPO_ROOT / "data" / "source_evidence" / "source_eligibility_matrix.json"


@pytest.fixture
def eligibility_matrix():
    assert ELIGIBILITY_PATH.exists(), f"Eligibility matrix missing at {ELIGIBILITY_PATH}"
    with open(ELIGIBILITY_PATH, "r", encoding="utf-8") as f:
        return json.load(f)


class TestSourceEligibility:
    """Test suite for Phase 1 & 2 Source Eligibility Matrix."""

    def test_matrix_structure_and_definitions(self, eligibility_matrix):
        assert "matrix_version" in eligibility_matrix
        assert "policy_status_definitions" in eligibility_matrix
        defs = eligibility_matrix["policy_status_definitions"]
        assert "PILOT_ELIGIBLE" in defs
        assert "APPROVED_FOR_PRODUCTION" in defs
        assert "REQUIRES_REVIEW" in defs
        assert "REJECTED" in defs

        criteria = eligibility_matrix["evaluation_criteria"]
        assert len(criteria) == 10

    def test_wikipedia_selected_as_safest_pilot_source(self, eligibility_matrix):
        assert eligibility_matrix["selected_pilot_candidate"] == "wikipedia_open_corpus"
        wiki = eligibility_matrix["sources"]["wikipedia_open_corpus"]
        assert wiki["pilot_status"] == "PILOT_ELIGIBLE"
        assert wiki["production_status"] == "UNDER_REVIEW"
        assert wiki["composite_score"] >= 90
        assert wiki["selection_rank"] == 1

    def test_pilot_eligible_distinct_from_approved_for_production(self, eligibility_matrix):
        wiki = eligibility_matrix["sources"]["wikipedia_open_corpus"]
        # An external source may be PILOT_ELIGIBLE but must NOT be APPROVED_FOR_PRODUCTION
        assert wiki["pilot_status"] == "PILOT_ELIGIBLE"
        assert wiki["production_status"] != "APPROVED"
        assert wiki["production_status"] == "UNDER_REVIEW"

    def test_other_five_external_sources_are_not_pilot_eligible(self, eligibility_matrix):
        other_sources = [
            "fineweb_edu_permissive",
            "the_stack_v2_permissive",
            "arxiv_open_access_papers",
            "dolma_v1_7_permissive",
            "redpajama_v2_permissive",
        ]
        for s in other_sources:
            entry = eligibility_matrix["sources"][s]
            assert entry["pilot_status"] == "NOT_ELIGIBLE"
            assert entry["status"] == "REQUIRES_REVIEW"
            assert entry["production_status"] == "UNDER_REVIEW"

    def test_rejected_sources_permanently_rejected(self, eligibility_matrix):
        for s in ["proprietary_forum_scrapes", "non_commercial_research_corpus"]:
            entry = eligibility_matrix["sources"][s]
            assert entry["status"] == "REJECTED"
            assert entry["pilot_status"] == "REJECTED"
            assert entry["production_status"] == "REJECTED"
            assert entry["composite_score"] == 0

    def test_synthetic_source_is_approved_for_production(self, eligibility_matrix):
        entry = eligibility_matrix["sources"]["nirmal_synthetic_v8_2"]
        assert entry["production_status"] == "APPROVED"
        assert entry["pilot_status"] == "PILOT_ELIGIBLE"
        assert entry["composite_score"] == 100
