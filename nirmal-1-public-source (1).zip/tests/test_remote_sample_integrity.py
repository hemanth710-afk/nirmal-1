"""
NIRMAL-1 V8.8: TEST SUITE FOR REMOTE SAMPLE INTEGRITY & NETWORK SAFETY (SCENARIOS 3-10)

Verifies:
3. Missing source URL fails closed.
4. Missing revision identifier fails closed.
5. Altered raw bytes / checksum mismatch fails closed.
6. Response exceeding byte ceiling triggers BoundedPayloadError.
7. Redirect loop triggers RedirectLoopError.
8. Invalid content type triggers ContentTypeMismatchError.
9. Incomplete/corrupt response is cleaned up atomically (.part unlinked).
"""

from pathlib import Path
import pytest
from unittest.mock import MagicMock, patch
import urllib.error

from training.acquisition.pilot_provenance_audit import (
    PilotProvenanceClass,
    PilotProvenanceAuditor,
    PilotDocumentAuditEntry,
    ProvenanceVerificationError,
)
from training.acquisition.safe_network_client import (
    SafeBoundedNetworkClient,
    SafeFetchResult,
    NetworkSecurityError,
    BoundedPayloadError,
    RedirectLoopError,
    ContentTypeMismatchError,
)


@pytest.fixture
def network_client():
    return SafeBoundedNetworkClient(
        max_doc_bytes=1024,      # 1 KB for test
        max_total_bytes=2048,    # 2 KB total
        timeout_seconds=2.0,
        max_redirects=2,
    )


class TestRemoteSampleIntegrity:
    """Tests network safety and sample integrity guarantees."""

    def test_missing_source_url_fails_closed(self):
        """Audit entry with empty or non-https URL fails validation."""
        auditor = PilotProvenanceAuditor()
        entry = PilotDocumentAuditEntry(
            document_hash="c" * 64,
            source_id="wikipedia_open_corpus",
            provenance_class=PilotProvenanceClass.REMOTE_SOURCE_DATA,
            canonical_source="wikipedia_open_corpus",
            source_url="",  # Missing!
            source_revision="rev_1",
            retrieval_timestamp="2026-09-08T12:00:00Z",
            raw_byte_count=100,
            normalized_byte_count=80,
            token_count=20,
            adapter_identifier="WikipediaPilotAdapter",
            pipeline_version="V8.8",
            acquisition_record_id="run_1",
            is_network_retrieved=True,
        )
        with pytest.raises(ProvenanceVerificationError) as exc:
            auditor.verify_entry(entry)
        assert "valid public HTTPS source_url" in str(exc.value)

    def test_missing_revision_identifier_fails_closed(self):
        """Audit entry missing source revision fails closed."""
        auditor = PilotProvenanceAuditor()
        entry = PilotDocumentAuditEntry(
            document_hash="d" * 64,
            source_id="wikipedia_open_corpus",
            provenance_class=PilotProvenanceClass.REMOTE_SOURCE_DATA,
            canonical_source="wikipedia_open_corpus",
            source_url="https://en.wikipedia.org/wiki/Test",
            source_revision="",  # Missing!
            retrieval_timestamp="2026-09-08T12:00:00Z",
            raw_byte_count=100,
            normalized_byte_count=80,
            token_count=20,
            adapter_identifier="WikipediaPilotAdapter",
            pipeline_version="V8.8",
            acquisition_record_id="run_1",
            is_network_retrieved=True,
        )
        with pytest.raises(ProvenanceVerificationError) as exc:
            auditor.verify_entry(entry)
        assert "requires source_revision" in str(exc.value)

    def test_altered_raw_bytes_checksum_mismatch(self, network_client, tmp_path):
        """Expected checksum mismatch raises NetworkSecurityError and unlinks .part file."""
        dest = tmp_path / "article.json"
        mock_resp = MagicMock()
        mock_resp.headers = {"Content-Type": "application/json"}
        mock_resp.read.side_effect = [b'{"title": "Test"}', b""]
        mock_resp.geturl.return_value = "https://en.wikipedia.org/test"

        with patch("urllib.request.build_opener") as mock_opener:
            mock_inst = MagicMock()
            mock_inst.open.return_value = mock_resp
            mock_opener.return_value = mock_inst

            with pytest.raises(NetworkSecurityError) as exc:
                network_client.fetch_url_to_file(
                    url="https://en.wikipedia.org/test",
                    destination_path=dest,
                    expected_sha256="wrong_hash_0000000000000000000000000000000000000000000000000000000000",
                )
            assert "Checksum mismatch" in str(exc.value)
            assert not dest.exists()
            assert not dest.with_suffix(".part").exists()

    def test_response_exceeds_byte_ceiling_fails_closed(self, network_client, tmp_path):
        """Payload exceeding max_doc_bytes triggers BoundedPayloadError."""
        dest = tmp_path / "oversized.json"
        mock_resp = MagicMock()
        mock_resp.headers = {"Content-Type": "application/json"}
        # Return 2 KB chunk when ceiling is 1 KB
        mock_resp.read.side_effect = [b"A" * 2000, b""]
        mock_resp.geturl.return_value = "https://en.wikipedia.org/big"

        with patch("urllib.request.build_opener") as mock_opener:
            mock_inst = MagicMock()
            mock_inst.open.return_value = mock_resp
            mock_opener.return_value = mock_inst

            with pytest.raises(BoundedPayloadError) as exc:
                network_client.fetch_url_to_file("https://en.wikipedia.org/big", dest)
            assert "byte ceiling breached" in str(exc.value)
            assert not dest.exists()
            assert not dest.with_suffix(".part").exists()

    def test_redirect_loop_detected_and_aborted(self, network_client, tmp_path):
        """Redirect loop is caught and aborted immediately."""
        dest = tmp_path / "loop.json"
        err301 = urllib.error.HTTPError(
            url="https://en.wikipedia.org/a",
            code=301,
            msg="Moved",
            hdrs={"Location": "https://en.wikipedia.org/a"},
            fp=None,
        )

        with patch("urllib.request.build_opener") as mock_opener:
            mock_inst = MagicMock()
            mock_inst.open.side_effect = err301
            mock_opener.return_value = mock_inst

            with pytest.raises(RedirectLoopError) as exc:
                network_client.fetch_url_to_file("https://en.wikipedia.org/a", dest)
            assert "Redirect loop detected" in str(exc.value)

    def test_invalid_content_type_rejected(self, network_client, tmp_path):
        """Disallowed content type (e.g. text/html executable/binary) triggers ContentTypeMismatchError."""
        dest = tmp_path / "file.json"
        mock_resp = MagicMock()
        mock_resp.headers = {"Content-Type": "application/x-msdos-program"}
        mock_resp.geturl.return_value = "https://en.wikipedia.org/exe"

        with patch("urllib.request.build_opener") as mock_opener:
            mock_inst = MagicMock()
            mock_inst.open.return_value = mock_resp
            mock_opener.return_value = mock_inst

            with pytest.raises(ContentTypeMismatchError) as exc:
                network_client.fetch_url_to_file("https://en.wikipedia.org/exe", dest)
            assert "Content-Type" in str(exc.value)
            assert not dest.exists()

    def test_incomplete_empty_response_cleaned_up(self, network_client, tmp_path):
        """Empty response is rejected and .part scratch file is unlinked."""
        dest = tmp_path / "empty.json"
        mock_resp = MagicMock()
        mock_resp.headers = {"Content-Type": "application/json"}
        mock_resp.read.return_value = b""
        mock_resp.geturl.return_value = "https://en.wikipedia.org/empty"

        with patch("urllib.request.build_opener") as mock_opener:
            mock_inst = MagicMock()
            mock_inst.open.return_value = mock_resp
            mock_opener.return_value = mock_inst

            with pytest.raises(NetworkSecurityError) as exc:
                network_client.fetch_url_to_file("https://en.wikipedia.org/empty", dest)
            assert "empty response" in str(exc.value)
            assert not dest.exists()
            assert not dest.with_suffix(".part").exists()
