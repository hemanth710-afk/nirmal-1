"""
Unit tests for split isolation and leakage enforcement (tests/test_split_integrity.py).
Verifies:
1. Hard invariant: TRAIN ∩ VAL = 0, TRAIN ∩ TEST = 0, VAL ∩ TEST = 0
2. Pipeline explicitly raises DataLeakageError upon any overlap
3. CleanCurriculumGenerator satisfies zero-leakage invariant
"""

import pytest
from training.data_pipeline import DataPipeline, DataLeakageError
from training.clean_dataset import CleanCurriculumGenerator


def test_split_isolation_passed():
    pipeline = DataPipeline(seed=42)
    train_ex = [pipeline.create_example("A", f"Train text {i}", "src", split="train") for i in range(10)]
    val_ex = [pipeline.create_example("A", f"Val text {i}", "src", split="val") for i in range(5)]
    test_ex = [pipeline.create_example("A", f"Test text {i}", "src", split="test") for i in range(5)]

    stats = pipeline.verify_split_isolation(train_ex, val_ex, test_ex)
    assert stats.leakage_passed is True
    assert stats.train_val_overlap == 0
    assert stats.train_test_overlap == 0
    assert stats.val_test_overlap == 0


def test_split_isolation_fails_on_train_test_overlap():
    pipeline = DataPipeline(seed=42)
    leaked_text = "Shared leaked sequence between train and test"
    train_ex = [pipeline.create_example("A", leaked_text, "src", split="train")]
    val_ex = [pipeline.create_example("A", "Distinct val text", "src", split="val")]
    test_ex = [pipeline.create_example("A", leaked_text, "src", split="test")]

    with pytest.raises(DataLeakageError) as excinfo:
        pipeline.verify_split_isolation(train_ex, val_ex, test_ex)
    assert "DATA LEAKAGE DETECTED between TRAIN and TEST splits" in str(excinfo.value)


def test_split_isolation_fails_on_internal_train_duplicate():
    pipeline = DataPipeline(seed=42)
    dup_text = "Duplicate training text"
    train_ex = [
        pipeline.create_example("A", dup_text, "src", split="train", example_id="ex1"),
        pipeline.create_example("A", dup_text, "src", split="train", example_id="ex2"),
    ]
    val_ex = [pipeline.create_example("A", "Val text", "src", split="val")]
    test_ex = [pipeline.create_example("A", "Test text", "src", split="test")]

    with pytest.raises(DataLeakageError) as excinfo:
        pipeline.verify_split_isolation(train_ex, val_ex, test_ex)
    assert "contains 1 internal duplicate" in str(excinfo.value)


def test_clean_curriculum_generator_zero_leakage():
    gen = CleanCurriculumGenerator(seed=42)
    train_set, val_set, test_set = gen.generate_full_clean_dataset(
        train_count_per_domain=15,
        val_count_per_domain=5,
        test_count_per_domain=5,
    )
    assert len(train_set) == 15 * 12
    assert len(val_set) == 5 * 12
    assert len(test_set) == 5 * 12
