"""
NIRMAL-1 V8.6: TEST SUITE FOR REVISION VERIFICATION (PHASE 2 & PHASE 7)

Verifies:
1. Exact upstream revision reality audit for all six external sources.
2. In-repo snapshot labels (e.g. revision_v1.0_snapshot) classified as UNVERIFIED.
3. Every source receives exactly one of:
   - VERIFIED_IMMUTABLE
   - VERIFIED_RELEASE_BUT_NOT_IMMUTABLE
   - UNVERIFIED
   - NOT_APPLICABLE
4. Adversarial: Nonexistent fabricated revision fails closed.
5. Adversarial: Floating branch revision (main/latest) fails closed.
6. In-repo synthetic source receives VERIFIED_IMMUTABLE.
7. Rejected sources receive NOT_APPLICABLE.
"""

from pathlib import Path
import pytest

from training.acquisition.source_reconciliation import (
    IndependentSourceReconciler,
    RevisionVerificationStatus,
    INDEPENDENT_SOURCE_OBSERVATIONS,
)
from training.acquisition.evidence import (
    SourceEvidenceManager,
    SourceEvidenceDossier,
    ApprovalStatus,
    EvidenceValidationError,
    ApprovalPolicyEvaluator,
)


@pytest.fixture
def reconciler():
    return IndependentSourceReconciler()


@pytest.fixture
def policy_evaluator():
    return ApprovalPolicyEvaluator()


class TestRevisionVerification:
    """Rigorous audit of revision verifiability and detection of invented revisions."""

    def test_all_six_external_snapshot_labels_are_unverified(self, reconciler):
        """
        Phase 2 Invariant:
        revision_v1.0_snapshot, revision_v2.0_snapshot, revision_arxiv_2026_bulk,
        revision_dolma_v1_7_snapshot, revision_rp2_v2.0_snapshot, dump_snapshot_20260901
        do not exist upstream as immutable git SHAs. Must be classified as UNVERIFIED.
        """
        external_sources = [
            ("fineweb_edu_permissive", "revision_v1.0_snapshot"),
            ("the_stack_v2_permissive", "revision_v2.0_snapshot"),
            ("arxiv_open_access_papers", "revision_arxiv_2026_bulk"),
            ("dolma_v1_7_permissive", "revision_dolma_v1_7_snapshot"),
            ("redpajama_v2_permissive", "revision_rp2_v2.0_snapshot"),
            ("wikipedia_open_corpus", "dump_snapshot_20260901"),
        ]

        for src_id, expected_label in external_sources:
            s = reconciler.reconcile_source(src_id)
            assert s.revision_status == RevisionVerificationStatus.UNVERIFIED, (
                f"Source {src_id} with label '{expected_label}' must be UNVERIFIED!"
            )
            # Ensure blocker is explicitly registered
            has_rev_blocker = any("Revision identifier is UNVERIFIED" in b for b in s.unresolved_blockers)
            assert has_rev_blocker is True

    def test_every_source_receives_exactly_one_valid_status(self, reconciler):
        """Phase 2 Requirement: exactly one valid status enum per source."""
        valid_statuses = {
            RevisionVerificationStatus.VERIFIED_IMMUTABLE,
            RevisionVerificationStatus.VERIFIED_RELEASE_BUT_NOT_IMMUTABLE,
            RevisionVerificationStatus.UNVERIFIED,
            RevisionVerificationStatus.NOT_APPLICABLE,
        }

        summaries = reconciler.reconcile_all()
        for src_id, s in summaries.items():
            assert s.revision_status in valid_statuses, f"Invalid status for {src_id}: {s.revision_status}"

    def test_synthetic_source_is_verified_immutable(self, reconciler):
        s = reconciler.reconcile_source("nirmal_synthetic_v8_2")
        assert s.revision_status == RevisionVerificationStatus.VERIFIED_IMMUTABLE

    def test_rejected_sources_are_not_applicable(self, reconciler):
        s1 = reconciler.reconcile_source("proprietary_forum_scrapes")
        assert s1.revision_status == RevisionVerificationStatus.NOT_APPLICABLE
        s2 = reconciler.reconcile_source("non_commercial_research_corpus")
        assert s2.revision_status == RevisionVerificationStatus.NOT_APPLICABLE

    def test_adversarial_nonexistent_fabricated_revision_fails_validation(self):
        """
        Adversarial: Fabricated 40-char hex string that is nonexistent or placeholder
        cannot bypass validation.
        """
        valid_ev_file = "evidence_files/nirmal_synthetic_v8_2_evidence.txt"
        dossier = SourceEvidenceDossier(
            source_id="fabricated_rev_source",
            canonical_source_name="Fabricated Revision Source",
            canonical_url="https://example.org/data",
            dataset_version_identifier="1.0",
            acquisition_method="HTTPS_DOWNLOAD",
            snapshot_revision_identifier="placeholder_revision_deadbeef",
            retrieval_timestamp="2026-09-08",
            source_checksum="e" * 64,
            license_url="https://example.org/license",
            license_text_hash=None,
            license_evidence_file_path=valid_ev_file,
            terms_policy_evidence_file_path=None,
            dataset_card_evidence_file_path=None,
            declared_license="Apache-2.0",
            per_file_license_policy="TEST",
            provenance_requirements=["commit"],
            attribution_requirements=["Author"],
            security_screening_status="PASSED_NO_CREDENTIALS",
            benchmark_contamination_status="SYNTHETIC_CLEAN",
            approval_status=ApprovalStatus.APPROVED,
        )
        with pytest.raises(EvidenceValidationError) as exc:
            dossier.validate()
        assert "unverified or placeholder revision" in str(exc.value)

    def test_adversarial_floating_branch_revision_fails_validation(self):
        """
        Adversarial: Floating git branch names like 'main' or 'latest'
        cannot satisfy immutable pinning requirement.
        """
        valid_ev_file = "evidence_files/nirmal_synthetic_v8_2_evidence.txt"
        dossier = SourceEvidenceDossier(
            source_id="floating_branch_source",
            canonical_source_name="Floating Branch Source",
            canonical_url="https://example.org/data",
            dataset_version_identifier="1.0",
            acquisition_method="HTTPS_DOWNLOAD",
            snapshot_revision_identifier="unverified_main_head",
            retrieval_timestamp="2026-09-08",
            source_checksum="f" * 64,
            license_url="https://example.org/license",
            license_text_hash=None,
            license_evidence_file_path=valid_ev_file,
            terms_policy_evidence_file_path=None,
            dataset_card_evidence_file_path=None,
            declared_license="Apache-2.0",
            per_file_license_policy="TEST",
            provenance_requirements=["commit"],
            attribution_requirements=["Author"],
            security_screening_status="PASSED_NO_CREDENTIALS",
            benchmark_contamination_status="SYNTHETIC_CLEAN",
            approval_status=ApprovalStatus.APPROVED,
        )
        with pytest.raises(EvidenceValidationError) as exc:
            dossier.validate()
        assert "unverified or placeholder revision" in str(exc.value)
