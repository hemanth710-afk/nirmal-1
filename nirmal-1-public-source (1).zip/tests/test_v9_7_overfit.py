import pytest
from scripts.v9_7_learning_sanity import LearningSanityEvaluator

def test_overfit_detection():
    evaluator = LearningSanityEvaluator()
    state = evaluator.evaluate_model_state(train_acc=0.95, val_acc=0.1, ood_acc=0.05)
    assert state == "OVERFIT"

def test_not_overfit_if_random():
    evaluator = LearningSanityEvaluator()
    state = evaluator.evaluate_model_state(train_acc=0.01, val_acc=0.01, ood_acc=0.01)
    assert state != "OVERFIT"

def test_not_overfit_if_generalizing():
    evaluator = LearningSanityEvaluator()
    state = evaluator.evaluate_model_state(train_acc=0.95, val_acc=0.95, ood_acc=0.9)
    assert state != "OVERFIT"

def test_tiny_dataset_expectation():
    evaluator = LearningSanityEvaluator()
    # It must consider > 0.9 train and < 0.2 val as overfit
    assert evaluator.evaluate_model_state(0.91, 0.19, 0.0) == "OVERFIT"
    
def test_near_overfit_boundary():
    evaluator = LearningSanityEvaluator()
    # Barely missing threshold
    assert evaluator.evaluate_model_state(0.85, 0.1, 0.0) == "PARTIALLY_TRAINED"
