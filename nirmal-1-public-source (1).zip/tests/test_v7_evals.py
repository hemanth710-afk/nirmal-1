"""
Unit Tests for Nirmal-1 V7 Scaling, Tokenizer, Datasets, and Evaluation Benchmarks.
Ensures:
- 100% test passing rate across all V7 components
- Exact byte-level round-trip tokenization
- Strict split isolation without data leakage
- 45-50 GB architecture parameter invariants
- Standalone execution of all evaluation benchmarks
"""

import math
import pytest
import torch

from nirmal.configuration_nirmal import NirmalConfig
from nirmal.model import NirmalForCausalLM
from training.v7_tokenizer import ByteLevelBPETokenizer, run_tokenizer_ab_benchmark
from training.v7_dataset import V7DatasetGenerator
from training.data_pipeline import DataLeakageError
from training.scaling import (
    get_v7_model_spec,
    calculate_nirmal_parameters,
    compute_training_flops,
    fit_power_law,
    plan_45_to_50_gb_architecture,
    get_scale_nirmal_config,
)
from evals.v7_reasoning import evaluate_agi_capability_index, score_loglik
from evals.v7_composition import evaluate_compositional_scaling
from evals.v7_fewshot import evaluate_fewshot_scaling_v7
from evals.v7_long_horizon import evaluate_long_horizon_v7
from evals.v7_world_model import evaluate_world_model_v7
from evals.v7_causal import evaluate_causal_reasoning_v7
from evals.v7_long_context import evaluate_long_context_scaling_v7
from evals.v7_forgetting import evaluate_continual_learning_v7


@pytest.fixture
def tiny_v7_model():
    tok = ByteLevelBPETokenizer(target_vocab_size=300)
    tok.train_from_corpus(["def solve(): return 42", "Alpha implies Beta. Beta implies Gamma."], max_merges=20)
    cfg = get_scale_nirmal_config("tiny", vocab_size=tok.vocab_size)
    model = NirmalForCausalLM(cfg)
    model.eval()
    return model, tok


class TestV7Tokenizer:
    def test_byte_level_reversible(self):
        tok = ByteLevelBPETokenizer(target_vocab_size=350)
        sample = "Nirmal-1 Architecture: λ = 0.05, 14 * 5 = 70, 日本語, emoji 🚀"
        ids = tok.encode(sample, add_special_tokens=False)
        decoded = tok.decode(ids)
        assert decoded == sample
        assert tok.unk_token_id not in ids

    def test_zero_unk_guarantee(self):
        tok = ByteLevelBPETokenizer(target_vocab_size=300)
        test_bytes = bytes([i for i in range(256)]).decode("latin-1")
        ids = tok.encode(test_bytes, add_special_tokens=False)
        assert tok.unk_token_id not in ids

    def test_tokenizer_ab_benchmark(self):
        bench = run_tokenizer_ab_benchmark()
        assert "char_tokenizer" in bench
        assert "byte_bpe_32k" in bench
        assert bench["byte_bpe_32k"]["sequence_compression_ratio"] > 1.5
        assert bench["byte_bpe_32k"]["unknown_token_rate"] == 0.0


class TestV7Dataset:
    def test_11_domains_generated(self):
        gen = V7DatasetGenerator(seed=123)
        split_data = gen.generate_split("val", count_per_domain=2)
        assert len(split_data) == 22  # 11 domains * 2
        domains = {ex.domain for ex in split_data}
        assert len(domains) == 11

    def test_split_isolation_and_leakage_exception(self):
        gen = V7DatasetGenerator(seed=99)
        train_ex, val_ex, test_ex = gen.generate_full_clean_dataset(
            train_count_per_domain=3,
            val_count_per_domain=2,
            test_count_per_domain=2,
        )
        assert len(train_ex) == 33
        assert len(val_ex) == 22
        assert len(test_ex) == 22

        # Intentionally inject overlap to verify guardrail
        with pytest.raises(DataLeakageError):
            gen.pipeline.verify_split_isolation(train_ex, val_ex, list(test_ex) + [train_ex[0]])


class TestV7ScalingLaws:
    def test_model_specs(self):
        spec_tiny = get_v7_model_spec("tiny", vocab_size=32000)
        spec_large = get_v7_model_spec("large", vocab_size=32000)
        assert spec_tiny.total_parameters < spec_large.total_parameters
        assert spec_tiny.fp16_size_mb > 0

    def test_flops_calculation(self):
        flops = compute_training_flops(active_params=10_000_000, total_tokens=1_000_000)
        assert flops == 6.0 * 10_000_000 * 1_000_000

    def test_power_law_fitting(self):
        x = [10.0, 100.0, 1000.0]
        y = [10.0, 1.0, 0.1]
        A, alpha, r2 = fit_power_law(x, y)
        assert math.isclose(alpha, 1.0, rel_tol=0.05)
        assert r2 >= 0.99

    def test_45_to_50_gb_architecture_plan(self):
        spec_fp16 = plan_45_to_50_gb_architecture(target_gb=48.0, precision="FP16")
        spec_bf16 = plan_45_to_50_gb_architecture(target_gb=48.0, precision="BF16")
        spec_int8 = plan_45_to_50_gb_architecture(target_gb=48.0, precision="INT8")
        spec_int4 = plan_45_to_50_gb_architecture(target_gb=48.0, precision="INT4")

        for s in [spec_fp16, spec_bf16, spec_int8, spec_int4]:
            assert 45.0 <= s.artifact_size_gb <= 50.0, f"Failed for {s.precision}: size={s.artifact_size_gb}"
            assert s.active_parameters < s.total_parameters


class TestV7EvaluationBenchmarks:
    def test_agi_index_evaluation(self, tiny_v7_model):
        model, tok = tiny_v7_model
        res = evaluate_agi_capability_index(model, tok)
        assert res.reference_score == 100.0
        assert len(res.category_scores) == 12
        assert isinstance(res.overall_index, float)

    def test_compositional_scaling(self, tiny_v7_model):
        model, tok = tiny_v7_model
        res = evaluate_compositional_scaling(model, tok, hops_to_test=[2, 4])
        assert "2_hop" in res
        assert "4_hop" in res
        assert "mean_composition_acc" in res

    def test_fewshot_scaling(self, tiny_v7_model):
        model, tok = tiny_v7_model
        res = evaluate_fewshot_scaling_v7(model, tok, shots=[0, 1, 2])
        assert "shot_0" in res
        assert "shot_1" in res
        assert "shot_2" in res

    def test_long_horizon_eval(self, tiny_v7_model):
        model, tok = tiny_v7_model
        res = evaluate_long_horizon_v7(model, tok, horizons=[1, 2], num_trials=1)
        assert 1 in res.results_by_horizon
        assert 2 in res.results_by_horizon
        assert hasattr(res, "decay_exponent_neural")

    def test_world_model_eval(self, tiny_v7_model):
        model, tok = tiny_v7_model
        res = evaluate_world_model_v7(model, tok)
        assert hasattr(res, "standard_acc")
        assert hasattr(res, "param_shift_acc")
        assert hasattr(res, "structural_shift_acc")
        assert hasattr(res, "counterfactual_acc")

    def test_causal_reasoning_eval(self, tiny_v7_model):
        model, tok = tiny_v7_model
        res = evaluate_causal_reasoning_v7(model, tok)
        assert hasattr(res, "correlation_vs_causation_acc")
        assert hasattr(res, "intervention_acc")
        assert hasattr(res, "counterfactual_acc")

    def test_long_context_scaling(self, tiny_v7_model):
        model, tok = tiny_v7_model
        res = evaluate_long_context_scaling_v7(model, tok, lengths=[256, 512], max_eval_len=256)
        assert 256 in res.single_needle_accuracy
        assert hasattr(res, "effective_context_window")

    def test_continual_learning_eval(self, tiny_v7_model):
        model, tok = tiny_v7_model
        res = evaluate_continual_learning_v7(model, tok)
        assert "replay_0pct" in res.replay_metrics
        assert "replay_20pct" in res.replay_metrics
