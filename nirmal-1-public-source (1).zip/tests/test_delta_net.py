"""
Unit tests for DeltaNet linear attention and associative recurrence.
"""

import torch
import pytest

from nirmal.configuration_nirmal import NirmalConfig
from nirmal.delta_net import NirmalDeltaNet


def test_delta_net_forward_shapes():
    """Test output shapes of DeltaNet layer in parallel and cached modes."""
    config = NirmalConfig(
        hidden_size=256,
        num_attention_heads=4,
        num_key_value_heads=2,
        head_dim=64,
    )
    delta_layer = NirmalDeltaNet(config)

    batch_size = 2
    seq_len = 8
    x = torch.randn(batch_size, seq_len, config.hidden_size)

    out, state = delta_layer(x, use_cache=True)
    assert out.shape == (batch_size, seq_len, config.hidden_size)
    assert state.shape == (batch_size, config.num_attention_heads, config.head_dim, config.head_dim)


def test_delta_net_recurrent_equivalence():
    """Verify that full sequence scan and step-by-step recurrent state updates yield identical outputs."""
    config = NirmalConfig(
        hidden_size=128,
        num_attention_heads=2,
        num_key_value_heads=2,
        head_dim=64,
    )
    delta_layer = NirmalDeltaNet(config)
    delta_layer.eval()

    batch_size = 2
    seq_len = 6
    x = torch.randn(batch_size, seq_len, config.hidden_size)

    # 1. Full sequence forward
    with torch.no_grad():
        full_out, full_state = delta_layer(x, use_cache=True)

    # 2. Step-by-step incremental forward
    with torch.no_grad():
        step_outputs = []
        state = None
        for t in range(seq_len):
            step_x = x[:, t : t + 1, :]
            step_out, state = delta_layer(step_x, state=state, use_cache=True)
            step_outputs.append(step_out)

        recurrent_out = torch.cat(step_outputs, dim=1)

    assert torch.allclose(full_out, recurrent_out, atol=1e-5)
    assert torch.allclose(full_state, state, atol=1e-5)


def test_delta_net_backward_gradient_flow():
    """Verify gradient backpropagation through DeltaNet recurrence."""
    config = NirmalConfig(hidden_size=128, num_attention_heads=2, head_dim=64)
    delta_layer = NirmalDeltaNet(config)

    x = torch.randn(2, 4, config.hidden_size, requires_grad=True)
    out, _ = delta_layer(x, use_cache=False)
    loss = out.sum()
    loss.backward()

    assert x.grad is not None
    assert not torch.isnan(x.grad).any()
    assert delta_layer.q_proj.weight.grad is not None
    assert delta_layer.beta_proj.weight.grad is not None


def test_delta_net_with_attention_mask():
    """Regression test for Issue 3: DeltaNet accepts attention_mask and masks padding tokens."""
    torch.manual_seed(42)
    config = NirmalConfig(hidden_size=128, num_attention_heads=2, head_dim=64)
    delta_layer = NirmalDeltaNet(config)

    # Sequence with padding on token 2 and 3
    x = torch.randn(1, 4, config.hidden_size)
    mask = torch.tensor([[1, 1, 0, 0]])

    out_masked, state_masked = delta_layer(x, attention_mask=mask, use_cache=True)
    assert out_masked.shape == (1, 4, config.hidden_size)

    # Outputs for padded tokens should be 0
    assert torch.allclose(out_masked[:, 2:], torch.zeros_like(out_masked[:, 2:]))

    # Output for first 2 tokens with mask should match unpadded 2-token sequence
    out_unpadded, state_unpadded = delta_layer(x[:, :2, :], use_cache=True)
    assert torch.allclose(out_masked[:, :2, :], out_unpadded, atol=1e-4)
    assert torch.allclose(state_masked, state_unpadded, atol=1e-4)
