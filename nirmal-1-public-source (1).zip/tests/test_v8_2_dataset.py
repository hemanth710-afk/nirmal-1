"""
Unit and Integration Tests for Nirmal-1 Milestone V8.2:
Production Dataset Acquisition, Cleaning, Deduplication, Sharding & Verification.
"""

from pathlib import Path
import shutil
import pytest
import torch

from training.data_pipeline import DataLeakageError
from training.v7_tokenizer import ByteLevelBPETokenizer
from training.v8_2_data_engine import (
    CleaningPipeline,
    DeduplicationEngine,
    MultiDomainCorpusEngine,
    SplitIsolationAuditor,
    BinaryShardWriter,
    StreamingShardReader,
    ProductionDocument,
    ProvenanceMetadata,
    calculate_physical_storage_accounting,
    evaluate_dataset_completeness_gate,
)
from training.v8_2_mixture_experiments import MixtureExperimentRunner


def test_cleaning_pipeline_filters():
    """Verify that cleaning pipeline removes malformed, empty, and repetitive text."""
    cleaner = CleaningPipeline()

    # 1. Valid clean text
    valid_text = "Standard telemetry reading indicates chamber pressure is within nominal bounds at 1013 hPa."
    c_text, reason = cleaner.inspect_and_clean(valid_text)
    assert c_text is not None
    assert reason is None

    # 2. Too short / empty text
    short_text = "hello"
    c_short, r_short = cleaner.inspect_and_clean(short_text)
    assert c_short is None
    assert r_short == "empty_or_too_short"

    # 3. Excessive character repetition
    rep_text = "Pressure reading: " + "!" * 30
    c_rep, r_rep = cleaner.inspect_and_clean(rep_text)
    assert c_rep is None
    assert r_rep == "excessive_char_repetition"

    # 4. Excessive line repetition
    line_rep_text = "\n".join(["telemetry sensor line"] * 10)
    c_lrep, r_lrep = cleaner.inspect_and_clean(line_rep_text)
    assert c_lrep is None
    assert r_lrep == "excessive_line_repetition"

    # 5. Invalid Unicode replacement character
    bad_unicode = "Corrupt payload \ufffd\ufffd detected in stream"
    c_bad, r_bad = cleaner.inspect_and_clean(bad_unicode)
    assert c_bad is None
    assert r_bad == "invalid_unicode_control_chars"


def test_exact_deduplication_zero_duplicates():
    """Verify that SHA-256 exact deduplication filters identical text."""
    engine = DeduplicationEngine(num_perm=64, jaccard_threshold=0.85)

    doc_1 = "Unique technical specification document detailing composite panel thermal gradients."
    doc_2 = "Unique technical specification document detailing composite panel thermal gradients."  # exact duplicate
    doc_3 = "Completely distinct document on orbital trajectory insertion delta-v requirements."

    is_u1, st1 = engine.process_document("doc_1", doc_1)
    is_u2, st2 = engine.process_document("doc_2", doc_2)
    is_u3, st3 = engine.process_document("doc_3", doc_3)

    assert is_u1 is True and st1 == "unique"
    assert is_u2 is False and st2 == "exact_duplicate"
    assert is_u3 is True and st3 == "unique"
    assert engine.exact_duplicates_count == 1


def test_minhash_near_duplicate_detection():
    """Verify that MinHash detects high Jaccard similarity near-duplicates."""
    engine = DeduplicationEngine(num_perm=64, jaccard_threshold=0.80)

    base_doc = "Standard telemetry reading indicates chamber pressure is within nominal bounds at 1013 hPa across all 4 sensors."
    # Perturb with minor trailing word
    near_dup = base_doc + " Note: telemetry log verified."

    is_u1, _ = engine.process_document("base_1", base_doc)
    is_u2, st2 = engine.process_document("near_2", near_dup)

    assert is_u1 is True
    assert is_u2 is False
    assert "near_duplicate" in st2
    assert engine.near_duplicates_count == 1


def test_three_way_split_isolation():
    """Verify that split isolation passes on disjoint sets and raises DataLeakageError on overlap."""
    auditor = SplitIsolationAuditor()

    p_meta = ProvenanceMetadata(
        source_id="test",
        domain="code",
        license_provenance="MIT",
        acquisition_date="2026-09-06",
        preprocessing_version="v8.2",
        tokenizer_version="bpe-32k",
        sha256_hash="",
    )

    doc_train = ProductionDocument(
        id="tr_1", domain="code", raw_text="train code sample", clean_text="train code sample",
        provenance=ProvenanceMetadata(**{**p_meta.to_dict(), "sha256_hash": "hash_train"}),
        token_ids=[10, 20, 30],
    )
    doc_val = ProductionDocument(
        id="val_1", domain="code", raw_text="val code sample", clean_text="val code sample",
        provenance=ProvenanceMetadata(**{**p_meta.to_dict(), "sha256_hash": "hash_val"}),
        token_ids=[40, 50, 60],
    )
    doc_test = ProductionDocument(
        id="test_1", domain="code", raw_text="test code sample", clean_text="test code sample",
        provenance=ProvenanceMetadata(**{**p_meta.to_dict(), "sha256_hash": "hash_test"}),
        token_ids=[70, 80, 90],
    )

    # Clean disjoint splits
    res = auditor.verify_split_isolation([doc_train], [doc_val], [doc_test])
    assert res["isolation_status"] == "STRICT_ZERO_LEAKAGE_CONFIRMED"

    # Cross-split overlap injection: Train and Val have same hash
    leaked_val = ProductionDocument(
        id="val_leak", domain="code", raw_text="train code sample", clean_text="train code sample",
        provenance=ProvenanceMetadata(**{**p_meta.to_dict(), "sha256_hash": "hash_train"}),
        token_ids=[10, 20, 30],
    )

    with pytest.raises(DataLeakageError, match="TRAIN ∩ VAL LEAKAGE DETECTED"):
        auditor.verify_split_isolation([doc_train], [leaked_val], [doc_test])


def test_capability_benchmark_holdout_isolation():
    """Verify that training documents containing evaluation benchmark entities are rejected."""
    auditor = SplitIsolationAuditor()

    p_meta = ProvenanceMetadata(
        source_id="test", domain="code", license_provenance="MIT", acquisition_date="2026-09-06",
        preprocessing_version="v8.2", tokenizer_version="bpe-32k", sha256_hash="hash_clean",
    )

    contaminated_doc = ProductionDocument(
        id="doc_dirty", domain="code",
        raw_text="import causal_simulator for test_open_world evaluation suite",
        clean_text="import causal_simulator for test_open_world evaluation suite",
        provenance=p_meta,
    )
    clean_val = ProductionDocument(
        id="val_clean", domain="code", raw_text="pure clean validation sample", clean_text="pure clean validation sample",
        provenance=ProvenanceMetadata(**{**p_meta.to_dict(), "sha256_hash": "hash_val"}),
    )
    clean_test = ProductionDocument(
        id="test_clean", domain="code", raw_text="pure clean test sample", clean_text="pure clean test sample",
        provenance=ProvenanceMetadata(**{**p_meta.to_dict(), "sha256_hash": "hash_test"}),
    )

    with pytest.raises(DataLeakageError, match="Benchmark entity overlap detected"):
        auditor.verify_split_isolation([contaminated_doc], [clean_val], [clean_test])


def test_binary_sharding_and_concatenation_parity(tmp_path):
    """Verify that binary shards accurately write uint16 tokens and concatenate without loss."""
    writer = BinaryShardWriter(tmp_path / "shards")

    p_meta = ProvenanceMetadata(
        source_id="test", domain="code", license_provenance="MIT", acquisition_date="2026-09-06",
        preprocessing_version="v8.2", tokenizer_version="bpe-32k", sha256_hash="hash",
    )

    doc_1 = ProductionDocument(id="d1", domain="code", raw_text="t1", clean_text="t1", provenance=p_meta, token_ids=[101, 102, 103, 104])
    doc_2 = ProductionDocument(id="d2", domain="code", raw_text="t2", clean_text="t2", provenance=p_meta, token_ids=[105, 106])

    m1 = writer.write_shard("shard_0001", [doc_1])
    m2 = writer.write_shard("shard_0002", [doc_2])

    assert m1["total_tokens"] == 4
    assert m2["total_tokens"] == 2
    assert (m1["total_tokens"] + m2["total_tokens"]) == 6

    # Verify physical file existence and size (uint16 = 2 bytes/token)
    bin_file_1 = tmp_path / "shards" / "shard_0001.bin"
    assert bin_file_1.exists()
    assert bin_file_1.stat().st_size == 4 * 2


def test_streaming_loader_and_checkpoint_resumption(tmp_path):
    """Verify that streaming loader saves and restores exact data position without drift."""
    writer = BinaryShardWriter(tmp_path / "shards")

    p_meta = ProvenanceMetadata(
        source_id="test", domain="code", license_provenance="MIT", acquisition_date="2026-09-06",
        preprocessing_version="v8.2", tokenizer_version="bpe-32k", sha256_hash="h",
    )

    # 128 tokens total across 2 shards
    tokens_shard1 = list(range(100, 164))
    tokens_shard2 = list(range(200, 264))

    doc1 = ProductionDocument(id="d1", domain="code", raw_text="t1", clean_text="t1", provenance=p_meta, token_ids=tokens_shard1)
    doc2 = ProductionDocument(id="d2", domain="code", raw_text="t2", clean_text="t2", provenance=p_meta, token_ids=tokens_shard2)

    m1 = writer.write_shard("shard_01", [doc1])
    m2 = writer.write_shard("shard_02", [doc2])

    manifests = [m1, m2]

    # Reader with batch_size=2, seq_len=8 -> 16 tokens/step
    reader = StreamingShardReader(manifests, tmp_path / "shards", batch_size=2, seq_len=8)
    gen = reader.stream_batches()

    # Step 1 and 2
    b1, meta1 = next(gen)
    b2, meta2 = next(gen)

    # Save state at step 2
    checkpoint_state = reader.get_state()

    # Step 3 (uninterrupted)
    b3_ref, meta3_ref = next(gen)

    # Resume on fresh reader
    resumed_reader = StreamingShardReader(manifests, tmp_path / "shards", batch_size=2, seq_len=8)
    resumed_reader.load_state(checkpoint_state)
    resumed_gen = resumed_reader.stream_batches()
    b3_resumed, meta3_resumed = next(resumed_gen)

    # Verify exact tensor match
    assert torch.equal(b3_ref, b3_resumed)
    assert meta3_ref["token_offset"] == meta3_resumed["token_offset"]


def test_physical_storage_accounting_calculations():
    """Verify that storage calculations distinguish tokens from bytes."""
    calc_200b = calculate_physical_storage_accounting(200_000_000_000)

    # 200B uint16 tokens = exactly 400 billion bytes = ~372.53 GiB
    assert calc_200b["tokenized_binary_storage_uint16"]["bytes"] == 400_000_000_000
    assert 370.0 <= calc_200b["tokenized_binary_storage_uint16"]["gigabytes"] <= 375.0
    # Total disk required (raw + clean + tokenized + temp) should be between 2.0 and 2.5 TB
    assert 2.0 <= calc_200b["total_production_cluster_disk_required_tb"] <= 2.5


def test_dataset_completeness_gate():
    """Verify that completeness gate yields PARTIALLY READY when volume deficit exists."""
    # Staged volume is less than 200B
    partial_res = evaluate_dataset_completeness_gate(
        actual_verified_tokens=250_000,
        required_tokens=200_000_000_000,
        zero_leakage_passed=True,
        all_shards_verified=True,
        manifest_hashes_match=True,
    )
    assert partial_res["readiness_status"] == "PARTIALLY READY"
    assert partial_res["token_deficit"] > 0
    assert "PARTIALLY READY -- DATASET VOLUME GAP" in partial_res["final_gate_verdict"]

    # Full volume meets 200B
    full_res = evaluate_dataset_completeness_gate(
        actual_verified_tokens=200_000_000_000,
        required_tokens=200_000_000_000,
        zero_leakage_passed=True,
        all_shards_verified=True,
        manifest_hashes_match=True,
    )
    assert full_res["readiness_status"] == "READY"
    assert full_res["token_deficit"] == 0
