import pytest
from scripts.v9_6_controlled_scaling import ResourceGuard

def test_resource_guard_safe():
    # Small ram, small time
    assert ResourceGuard.check_safe_to_run(0, 100, 10) == True

def test_resource_guard_unsafe_ram():
    # 5GB ram (unsafe limit is 4096MB)
    assert ResourceGuard.check_safe_to_run(0, 5000, 10) == False

def test_resource_guard_unsafe_time():
    # > 300 seconds
    assert ResourceGuard.check_safe_to_run(0, 100, 400) == False

def test_no_production_shard_writes():
    # Handled by isolation in experiment harness (outputs to experiments/v9_6/)
    import pathlib
    assert pathlib.Path("experiments/v9_6").exists()
