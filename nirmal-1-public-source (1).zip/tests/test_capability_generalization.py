import pytest
from training.acquisition.capability_curriculum import CapabilityCurriculumPlanner

@pytest.fixture
def planner():
    return CapabilityCurriculumPlanner()

def test_train_split(planner):
    # Deterministic split, we just test it returns one of the valid splits
    split = planner.get_split("Document text 1", {"source_id": "srcA"})
    assert split in ["TRAIN", "VALIDATION", "OOD_TEST"]

def test_validation_split(planner):
    # We test that same text and source gives same split
    split1 = planner.get_split("Document text 1", {"source_id": "srcA"})
    split2 = planner.get_split("Document text 1", {"source_id": "srcA"})
    assert split1 == split2

def test_ood_test_split(planner):
    split = planner.get_split("Document text 1", {"source_id": "srcB"})
    assert split in ["TRAIN", "VALIDATION", "OOD_TEST"]

def test_leakage_prevention_source(planner):
    # Same source, same text -> same split
    assert planner.get_split("doc", {"source_id": "A"}) == planner.get_split("doc", {"source_id": "A"})

def test_leakage_prevention_document(planner):
    # Same doc_id if used as template
    assert planner.get_split("doc", {"template_id": "T1"}) == planner.get_split("doc", {"template_id": "T1"})

def test_leakage_prevention_revision(planner):
    # Revisions of the same doc shouldn't leak (they have same text start or template)
    assert planner.get_split("text is same", {"source_id": "A"}) == planner.get_split("text is same", {"source_id": "A"})

def test_leakage_prevention_near_duplicate(planner):
    # First 50 chars match
    assert planner.get_split("01234567890123456789012345678901234567890123456789 A", {"source_id": "A"}) == \
           planner.get_split("01234567890123456789012345678901234567890123456789 B", {"source_id": "A"})

def test_capability_template(planner):
    # Template ID forces same split
    assert planner.get_split("diff text", {"template_id": "math_proof_1"}) == \
           planner.get_split("other text", {"template_id": "math_proof_1"})

def test_composition_math_planning(planner):
    pass # These are structural tests for the curriculum, actual composition is tested in classifier

def test_composition_science_causal_reasoning(planner):
    pass
