import pytest
from scripts.v9_7_learning_sanity import LearningSanityEvaluator

def test_full_generalization_detection():
    evaluator = LearningSanityEvaluator()
    state = evaluator.evaluate_model_state(0.9, 0.9, 0.9)
    assert state == "GENERALIZING"

def test_partial_generalization_detection():
    evaluator = LearningSanityEvaluator()
    state = evaluator.evaluate_model_state(0.9, 0.85, 0.4)
    assert state == "PARTIALLY_GENERALIZING"

def test_generalization_distinguishes_from_overfit():
    evaluator = LearningSanityEvaluator()
    assert evaluator.evaluate_model_state(0.95, 0.1, 0.1) != "GENERALIZING"

def test_val_vs_ood_gap():
    evaluator = LearningSanityEvaluator()
    # High train, High val, Low OOD -> partial
    assert evaluator.evaluate_model_state(0.9, 0.9, 0.2) == "PARTIALLY_GENERALIZING"

def test_fail_generalization():
    evaluator = LearningSanityEvaluator()
    assert evaluator.evaluate_model_state(0.1, 0.1, 0.1) == "RANDOM"
