"""
Unit tests for NirmalConfig configuration and validation.
"""

import json
from pathlib import Path
import tempfile
import pytest

from nirmal.configuration_nirmal import NirmalConfig


def test_default_config_prototype_values():
    """Verify default config matches required prototype baseline values."""
    config = NirmalConfig()
    assert config.hidden_size == 512
    assert config.num_hidden_layers == 12
    assert config.num_attention_heads == 8
    assert config.num_key_value_heads == 2
    assert config.head_dim == 64
    assert config.vocab_size == 32000
    assert config.context_length == 8192
    assert config.num_experts == 8
    assert config.num_experts_per_tok == 2
    assert config.full_attention_interval == 4

    # Check that layer types resolve to hybrid pattern
    assert len(config.layer_types) == 12
    # Layers at index 3, 7, 11 (1-indexed 4, 8, 12) must be causal_attention
    assert config.layer_types[3] == "causal_attention"
    assert config.layer_types[7] == "causal_attention"
    assert config.layer_types[11] == "causal_attention"
    assert config.layer_types[0] == "delta_net"
    assert config.layer_types[1] == "delta_net"


def test_dimension_validation_mismatch():
    """Test that dimension mismatches raise ValueError."""
    # hidden_size != heads * head_dim
    with pytest.raises(ValueError, match="hidden_size"):
        NirmalConfig(hidden_size=500, num_attention_heads=8, head_dim=64)

    # heads not divisible by kv_heads
    with pytest.raises(ValueError, match="divisible by num_key_value_heads"):
        NirmalConfig(hidden_size=512, num_attention_heads=8, num_key_value_heads=3, head_dim=64)

    # top_k > num_experts
    with pytest.raises(ValueError, match="num_experts_per_tok"):
        NirmalConfig(num_experts=4, num_experts_per_tok=5)


def test_config_serialization_roundtrip():
    """Test dictionary and JSON file serialization/deserialization."""
    config = NirmalConfig(hidden_size=256, num_attention_heads=4, num_key_value_heads=2, head_dim=64, num_hidden_layers=4)
    cfg_dict = config.to_dict()
    restored = NirmalConfig.from_dict(cfg_dict)
    assert restored == config

    with tempfile.TemporaryDirectory() as tmpdir:
        tmp_file = Path(tmpdir) / "test_config.json"
        config.to_json_file(tmp_file)
        loaded = NirmalConfig.from_json_file(tmp_file)
        assert loaded == config
