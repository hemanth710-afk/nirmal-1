"""Unit tests for V10.6 Symbol/Relation Decoupling Harness."""

import json
from pathlib import Path

import pytest
import torch
import torch.nn as nn

from training.evaluation.v10_2_harness import CapacityBuilder, aggregate_results
from training.evaluation.v10_6_harness import (
    ALL_RULES,
    DISJOINT_OOD,
    HOLDOUT_RULES,
    TRAIN_RULES,
    TRAIN_VOCAB,
    DualChannelWrapper,
    PairwiseRelationEncoder,
    PermutationAugmentor,
    RandomRelationEncoder,
    RelativeProjectionEncoder,
    V10_6_DataBuilder,
    apply_rule,
    build_ablation_model,
    permutation_consistency_loss,
    relation_invariance_score,
    scaffold_off_acc,
)

VOCAB = 250
H = 32


# ── Rule correctness ──────────────────────────────────────────────────────────
def test_apply_rule_all_rules():
    b = torch.tensor([[10]])
    assert torch.equal(apply_rule(b, "copy"),               torch.tensor([[10, 10, 10]]))
    assert torch.equal(apply_rule(b, "increment"),           torch.tensor([[10, 11, 12]]))
    assert torch.equal(apply_rule(b, "double_step"),         torch.tensor([[10, 12, 14]]))
    assert torch.equal(apply_rule(b, "reverse"),             torch.tensor([[12, 11, 10]]))
    assert torch.equal(apply_rule(b, "fixed_shift"),         torch.tensor([[10, 13, 16]]))
    assert torch.equal(apply_rule(b, "simple_composition"),  torch.tensor([[10, 11, 13]]))


# ── Channel separation ────────────────────────────────────────────────────────
def test_identity_relation_channel_separation():
    """A0 has no relation encoder; A1 has a trainable one. They must be separate."""
    a0 = build_ablation_model("A0", vocab_size=VOCAB, rel_dim=16)
    a1 = build_ablation_model("A1", vocab_size=VOCAB, rel_dim=16)
    assert a0.relation_encoder is None
    assert a1.relation_encoder is not None
    assert isinstance(a1.relation_encoder, PairwiseRelationEncoder)


def test_random_relation_is_frozen():
    """A2 relation encoder must have no trainable parameters."""
    a2 = build_ablation_model("A2", vocab_size=VOCAB, rel_dim=16)
    trainable = [p for p in a2.relation_encoder.parameters() if p.requires_grad]
    # Only proj layer is trainable, rel_emb is frozen
    frozen = [p for p in a2.relation_encoder.rel_emb.parameters()]
    assert all(not p.requires_grad for p in frozen)


# ── Deterministic remapping ────────────────────────────────────────────────────
def test_permutation_augmentor_deterministic():
    aug = PermutationAugmentor(rng_seed=42)
    g = torch.Generator()
    g.manual_seed(99)
    src = torch.tensor([[10, 11, 12]])
    r1 = aug.remap(src, 130, 200, "increment", g=torch.Generator().manual_seed(7).__class__())
    g1 = torch.Generator(); g1.manual_seed(7)
    g2 = torch.Generator(); g2.manual_seed(7)
    r1 = aug.remap(src, 130, 200, "increment", g=g1)
    r2 = aug.remap(src, 130, 200, "increment", g=g2)
    assert torch.equal(r1, r2)


def test_permutation_augmentor_disjoint_vocab():
    """Remapped sequence must live entirely in the new vocab range."""
    aug = PermutationAugmentor(rng_seed=0)
    src = torch.tensor([[10, 11, 12], [20, 21, 22]])
    g = torch.Generator(); g.manual_seed(42)
    remapped = aug.remap(src, 130, 180, "increment", g=g)
    assert remapped.min().item() >= 130
    assert remapped.max().item() < 186  # max base 180-8=172, +6 offset


# ── Random permutation rule structure ─────────────────────────────────────────
def test_permutation_preserves_rule_structure():
    """After remapping, the rule structure must still hold."""
    aug = PermutationAugmentor(rng_seed=1)
    src = torch.tensor([[10, 11, 12]])
    g = torch.Generator(); g.manual_seed(55)
    remapped = aug.remap(src, 130, 180, "increment", g=g)
    # increment rule: t1-t0=1, t2-t1=1
    diff1 = remapped[0, 1] - remapped[0, 0]
    diff2 = remapped[0, 2] - remapped[0, 1]
    assert diff1.item() == 1
    assert diff2.item() == 1


# ── Relation consistency loss ──────────────────────────────────────────────────
def test_relation_consistency_loss_decreases_with_identical_inputs():
    model = build_ablation_model("A1", vocab_size=VOCAB, rel_dim=16)
    seq = torch.randint(10, 50, (4, 3))
    loss = permutation_consistency_loss(model, seq, seq)
    # Identical sequences → consistency loss must be 0
    assert loss.item() < 1e-6


def test_relation_consistency_loss_nonzero_for_different_seqs():
    model = build_ablation_model("A1", vocab_size=VOCAB, rel_dim=16)
    seq_a = torch.tensor([[10, 11, 12], [20, 21, 22]])
    seq_b = torch.tensor([[140, 141, 142], [150, 151, 152]])
    loss = permutation_consistency_loss(model, seq_a, seq_b)
    # Different sequences → some non-zero loss expected (with random init)
    assert isinstance(loss.item(), float)


# ── Wrong-relation control ─────────────────────────────────────────────────────
def test_wrong_relation_control():
    """A2 (random frozen relation) should not systematically beat A0 on OOD."""
    db = V10_6_DataBuilder(vocab_size=VOCAB)
    a0 = build_ablation_model("A0", vocab_size=VOCAB, rel_dim=16)
    a2 = build_ablation_model("A2", vocab_size=VOCAB, rel_dim=16)
    ood_batch = db.make_batch("increment", DISJOINT_OOD, batch_size=8, seed=42)
    dev = torch.device("cpu")
    acc0 = scaffold_off_acc(a0, ood_batch, ood_batch, dev)
    acc2 = scaffold_off_acc(a2, ood_batch, ood_batch, dev)
    # Both untrained → roughly equal random chance; neither should be dramatically better
    assert abs(acc0 - acc2) < 0.5  # Not a strict bound, just sanity check


# ── Leakage detection ──────────────────────────────────────────────────────────
def test_vocabulary_isolation():
    db = V10_6_DataBuilder(vocab_size=VOCAB)
    train = db.make_batch("increment", TRAIN_VOCAB, batch_size=32, seed=42)
    ood   = db.make_batch("increment", DISJOINT_OOD, batch_size=32, seed=42)
    cert  = db.leakage_certificate(train, ood)
    assert cert["vocab_disjoint"]  is True
    assert cert["no_row_overlap"]  is True
    assert cert["no_subseq_leak"]  is True
    assert cert["valid"]           is True


def test_leakage_detection_fails_on_same_vocab():
    db = V10_6_DataBuilder(vocab_size=VOCAB)
    same = db.make_batch("increment", TRAIN_VOCAB, batch_size=16, seed=1)
    cert = db.leakage_certificate(same, same)
    assert cert["vocab_disjoint"] is False
    assert cert["valid"] is False


# ── Parameter-count correctness ────────────────────────────────────────────────
def test_parameter_count_correctness():
    a0 = build_ablation_model("A0", vocab_size=VOCAB, level="L0", rel_dim=16)
    a1 = build_ablation_model("A1", vocab_size=VOCAB, level="L0", rel_dim=16)
    p0 = sum(p.numel() for p in a0.parameters())
    p1 = sum(p.numel() for p in a1.parameters())
    # A1 must have strictly more parameters (the relation encoder adds parameters)
    assert p1 > p0
    print(f"A0 params: {p0:,}  A1 params: {p1:,}")


# ── Scaffold removal ───────────────────────────────────────────────────────────
def test_scaffold_off_acc_shape():
    db = V10_6_DataBuilder(vocab_size=VOCAB)
    model = build_ablation_model("A1", vocab_size=VOCAB, rel_dim=16)
    batch = db.make_batch("increment", TRAIN_VOCAB, batch_size=4, seed=7)
    acc = scaffold_off_acc(model, batch, batch, torch.device("cpu"))
    assert isinstance(acc, float)
    assert 0.0 <= acc <= 1.0


# ── Held-out rule isolation ────────────────────────────────────────────────────
def test_held_out_rule_isolation():
    assert set(HOLDOUT_RULES) & set(TRAIN_RULES) == set()
    assert "double_step" in HOLDOUT_RULES
    assert "reverse"     in HOLDOUT_RULES


# ── Deterministic seed behavior ───────────────────────────────────────────────
def test_deterministic_seed_behavior():
    db = V10_6_DataBuilder(vocab_size=VOCAB)
    b1 = db.make_batch("increment", TRAIN_VOCAB, batch_size=8, seed=42)
    b2 = db.make_batch("increment", TRAIN_VOCAB, batch_size=8, seed=42)
    assert torch.equal(b1, b2)


# ── Metric correctness ─────────────────────────────────────────────────────────
def test_metric_correctness():
    vals = [0.10, 0.20, 0.30]
    agg = aggregate_results(vals)
    assert abs(agg["mean"] - 0.20) < 1e-5
    assert agg["min"]  == 0.10
    assert agg["max"]  == 0.30
    assert agg["std"]  > 0


# ── Report completeness ────────────────────────────────────────────────────────
def test_report_completeness():
    files = list(Path("experiments/v10_6").glob("v10_6_results_*.json"))
    if not files:
        pytest.skip("V10.6 results not yet generated")
    files.sort()
    data = json.loads(files[-1].read_text())
    for key in ["A0", "A1", "A2", "A3", "A4", "A5", "A6"]:
        assert key in data, f"Missing ablation key: {key}"
    assert "leakage" in data
