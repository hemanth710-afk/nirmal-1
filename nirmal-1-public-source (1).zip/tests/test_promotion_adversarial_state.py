import pytest
import json
from pathlib import Path
from training.acquisition.promotion_gate import RealSourcePromotionGate, PromotionSecurityError

@pytest.fixture
def gate(tmp_path):
    return RealSourcePromotionGate(promotion_dir=tmp_path/"promotion", pilot_dir=tmp_path/"pilot", evidence_dir=tmp_path/"evidence")

def test_illegal_state_transition(gate, tmp_path):
    manifest = {
        "source_id": "test_source",
        # Missing state completely
        "cryptographic_hashes": {
            "final_shard_sha256": "dummyhash"
        },
        "shard_path": str(tmp_path / "pilot" / "shards" / "dummy.bin")
    }
    
    pilot_dir = tmp_path / "pilot"
    manifest_dir = pilot_dir / "manifests"
    manifest_dir.mkdir(parents=True, exist_ok=True)
    
    with open(manifest_dir / "test_source_pilot_manifest.json", "w") as f:
        json.dump(manifest, f)
        
    result = gate.promote_source("test_source")
    assert result.verdict == "REJECTED"

def test_missing_pilot_shard(gate, tmp_path):
    manifest = {
        "source_id": "wikipedia_open_corpus",
        "state": "PILOT_ELIGIBLE",
        "cryptographic_hashes": {
            "final_shard_sha256": "dummyhash"
        },
        "shard_path": str(tmp_path / "pilot" / "shards" / "dummy.bin")
    }
    
    pilot_dir = tmp_path / "pilot"
    manifest_dir = pilot_dir / "manifests"
    manifest_dir.mkdir(parents=True, exist_ok=True)
    
    with open(manifest_dir / "wikipedia_open_corpus_pilot_manifest.json", "w") as f:
        json.dump(manifest, f)
        
    result = gate.promote_source("wikipedia_open_corpus")
    assert result.verdict == "REJECTED"

def test_tampered_state_in_manifest(gate, tmp_path):
    manifest = {
        "source_id": "wikipedia_open_corpus",
        "state": "APPROVED_FOR_PRODUCTION", 
        "cryptographic_hashes": {
            "final_shard_sha256": "dummyhash"
        },
        "shard_path": str(tmp_path / "pilot" / "shards" / "dummy.bin")
    }
    
    pilot_dir = tmp_path / "pilot"
    manifest_dir = pilot_dir / "manifests"
    manifest_dir.mkdir(parents=True, exist_ok=True)
    
    shard_dir = pilot_dir / "shards"
    shard_dir.mkdir(parents=True, exist_ok=True)
    with open(shard_dir / "dummy.bin", "wb") as f:
        f.write(b"00")
    
    with open(manifest_dir / "wikipedia_open_corpus_pilot_manifest.json", "w") as f:
        json.dump(manifest, f)
        
    result = gate.promote_source("wikipedia_open_corpus")
    assert result.verdict == "REJECTED"
