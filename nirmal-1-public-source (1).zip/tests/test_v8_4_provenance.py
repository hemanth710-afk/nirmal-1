"""
Unit tests for SourceProvenanceRecord and DatasetManifestManager in Nirmal-1 V8.4.
"""

from pathlib import Path
import tempfile
import pytest

from training.v8_4_manifest import (
    SourceProvenanceRecord,
    DatasetManifestManager,
    LicenseProvenanceViolationError,
    ALLOWED_LICENSES,
)


def test_license_validation_allowed():
    rec = SourceProvenanceRecord(
        source_name="OpenSourceRepo",
        source_identifier="https://github.com/example/repo",
        license="MIT",
        provenance_details="Verified MIT repository",
        acquisition_timestamp="2026-09-06T12:00:00Z",
        original_size_bytes=1000,
        processed_size_bytes=950,
        measured_token_count=250,
        source_sha256="abc123def456",
        preprocessing_version="v8.4.0",
    )
    assert rec.validate_license() is True


def test_license_validation_rejected():
    rec_nc = SourceProvenanceRecord(
        source_name="RestrictedRepo",
        source_identifier="https://example.com/data",
        license="CC-BY-NC-4.0",
        provenance_details="Non-commercial restricted dataset",
        acquisition_timestamp="2026-09-06T12:00:00Z",
        original_size_bytes=1000,
        processed_size_bytes=950,
        measured_token_count=250,
        source_sha256="abc123def456",
        preprocessing_version="v8.4.0",
    )
    assert rec_nc.validate_license() is False

    with tempfile.TemporaryDirectory() as tmpdir:
        mgr = DatasetManifestManager(manifest_dir=Path(tmpdir))
        with pytest.raises(LicenseProvenanceViolationError):
            mgr.register_source(rec_nc)


def test_manifest_signature_and_verification():
    with tempfile.TemporaryDirectory() as tmpdir:
        tmp_path = Path(tmpdir)
        mgr = DatasetManifestManager(dataset_version="TEST-MANIFEST-001", manifest_dir=tmp_path)

        rec = SourceProvenanceRecord(
            source_name="PermissiveSource",
            source_identifier="https://example.org/source",
            license="Apache-2.0",
            provenance_details="Apache source",
            acquisition_timestamp="2026-09-06T12:00:00Z",
            original_size_bytes=5000,
            processed_size_bytes=4800,
            measured_token_count=1200,
            source_sha256="1234567890abcdef",
            preprocessing_version="v8.4.0",
        )
        mgr.register_source(rec)
        manifest_file = mgr.save_manifest()
        assert manifest_file.exists()

        # Load and verify
        loaded = DatasetManifestManager.load_and_verify_manifest(manifest_file)
        assert loaded["dataset_version"] == "TEST-MANIFEST-001"
        assert len(loaded["sources"]) == 1
        assert "manifest_sha256_signature" in loaded
