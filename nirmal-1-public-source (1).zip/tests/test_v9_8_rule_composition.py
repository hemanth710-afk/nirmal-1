import pytest
from scripts.v9_8_generalization_bridge import GeneralizationEvaluator, GeneralizationTaskGenerator

def test_composition_threshold():
    ev = GeneralizationEvaluator()
    state = ev.evaluate_model_state(train_acc=0.9, val_acc=0.9, comp_acc=0.85, ood_acc=0.1)
    assert state == "COMPOSING"

def test_not_composing_if_ood_high():
    ev = GeneralizationEvaluator()
    state = ev.evaluate_model_state(train_acc=0.9, val_acc=0.9, comp_acc=0.9, ood_acc=0.85)
    assert state == "GENERALIZING"

def test_not_composing_if_comp_low():
    ev = GeneralizationEvaluator()
    state = ev.evaluate_model_state(train_acc=0.9, val_acc=0.9, comp_acc=0.1, ood_acc=0.1)
    assert state == "INTERPOLATING"

def test_composition_task_format():
    gen = GeneralizationTaskGenerator()
    d = gen.generate_task("LEVEL_3_COMPOSITION", 2, 8, 10, 40)
    # Check that a, a, a+1, a+1 rule holds
    assert (d[:, 0] == d[:, 1]).all()
    assert (d[:, 2] == d[:, 0] + 1).all()

def test_composition_vs_interpolating():
    ev = GeneralizationEvaluator()
    state1 = ev.evaluate_model_state(1.0, 1.0, 0.5, 0.0)
    assert state1 == "INTERPOLATING"
