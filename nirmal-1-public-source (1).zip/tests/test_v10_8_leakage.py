"""Leakage audit tests for V10.8 Learning-to-Learn Study."""

import pytest
import torch

from training.evaluation.v10_8_harness import (
    HELD_OUT_TRANSLATE_C,
    P_FIELD,
    Episode,
    EpisodeBuilder,
    LeakageAuditor,
    RuleDefinition,
    RuleSampler,
)


def test_support_query_disjointness():
    g = torch.Generator().manual_seed(999)
    builder = EpisodeBuilder(p=P_FIELD)
    sampler = RuleSampler(p=P_FIELD)

    for _ in range(50):
        rule = sampler.sample_seen_rule(g)
        ep = builder.build_episode(rule, k=4, symbol_regime="V-A", is_unseen_symbol=True, g=g)
        audit = LeakageAuditor.audit_episode(ep)
        assert audit["query_not_in_support"] is True
        assert audit["valid"] is True


def test_injected_leak_fails_closed():
    """Verify that an artificially corrupted episode with query leakage is caught."""
    g = torch.Generator().manual_seed(101)
    builder = EpisodeBuilder(p=P_FIELD)
    rule = RuleDefinition("translate", (3,))
    ep = builder.build_episode(rule, k=3, symbol_regime="V-A", is_unseen_symbol=False, g=g)

    # Artificially inject qx into support_xs
    corrupted_ep = Episode(
        input_ids=ep.input_ids,
        target=ep.target,
        k=ep.k,
        rule=ep.rule,
        symbol_regime=ep.symbol_regime,
        is_unseen_symbol=ep.is_unseen_symbol,
        qx_val=ep.support_xs[0],  # Injected leak!
        qy_val=ep.qy_val,
        support_xs=ep.support_xs,
    )

    audit = LeakageAuditor.audit_episode(corrupted_ep)
    assert audit["query_not_in_support"] is False
    assert audit["valid"] is False


def test_held_out_parameter_isolation():
    sampler = RuleSampler(p=P_FIELD, held_out_c=HELD_OUT_TRANSLATE_C)
    g = torch.Generator().manual_seed(777)

    # Sample 500 seen rules and ensure held_out_c is never chosen
    for _ in range(500):
        rule = sampler.sample_seen_rule(g)
        if rule.family == "translate":
            assert rule.params[0] != HELD_OUT_TRANSLATE_C


def test_benchmark_isolation_audit():
    g = torch.Generator().manual_seed(888)
    sampler = RuleSampler(p=P_FIELD, held_out_c=HELD_OUT_TRANSLATE_C)
    builder = EpisodeBuilder(p=P_FIELD)

    # Valid clean train rules
    train_rules = [sampler.sample_seen_rule(g) for _ in range(50)]
    eval_episodes = [
        builder.build_episode(sampler.sample_seen_rule(g), k=2, symbol_regime="V-A", is_unseen_symbol=False, g=g)
        for _ in range(20)
    ]

    res = LeakageAuditor.audit_benchmark_isolation(train_rules, eval_episodes)
    assert res["valid"] is True
    assert res["held_out_family_excluded"] is True
    assert res["held_out_parameter_excluded"] is True

    # Artificially inject held_out family into train rules
    leaky_train_rules = train_rules + [RuleDefinition("power", ())]
    res_leaky = LeakageAuditor.audit_benchmark_isolation(leaky_train_rules, eval_episodes)
    assert res_leaky["valid"] is False
    assert res_leaky["held_out_family_excluded"] is False
