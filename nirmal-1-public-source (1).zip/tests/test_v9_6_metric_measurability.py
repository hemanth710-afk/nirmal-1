import pytest
from scripts.v9_6_controlled_scaling import ScalingExperiment

def test_floor_detection():
    exp = ScalingExperiment()
    meas = exp.determine_measurability({"t1": 0.0, "t2": 0.0})
    assert meas == "UNMEASURABLE"

def test_ceiling_detection():
    # If it escapes the floor, it's MEASURABLE or WEAKLY_MEASURABLE
    exp = ScalingExperiment()
    meas = exp.determine_measurability({"t1": 0.1, "t2": 0.0})
    assert meas == "MEASURABLE"
    
def test_weak_measurability():
    exp = ScalingExperiment()
    meas = exp.determine_measurability({"t1": 0.02, "t2": 0.03})
    assert meas == "WEAKLY_MEASURABLE"
