"""V10.2 Report completeness tests."""
import json
import pytest
from pathlib import Path

OUT = Path("experiments/v10_2")

def get_latest_results():
    files = list(OUT.glob("v10_2_results_*.json"))
    if not files:
        return None
    files.sort()
    return json.loads(files[-1].read_text())

@pytest.mark.skipif(get_latest_results() is None, reason="Results not yet generated")
def test_results_file_exists():
    assert get_latest_results() is not None

@pytest.mark.skipif(get_latest_results() is None, reason="Results not yet generated")
def test_all_levels_present_for_fully_disjoint():
    data = get_latest_results()
    levels = ["L0", "L1", "L2"]
    for level in levels:
        assert f"{level}_identity_D_FULLY_DISJOINT" in data
        assert f"{level}_value_relative_D_FULLY_DISJOINT" in data

@pytest.mark.skipif(get_latest_results() is None, reason="Results not yet generated")
def test_all_taxonomies_present_for_l2():
    data = get_latest_results()
    taxonomies = [
        "A_SAME_VOCAB", "B_SURFACE_FORM", "C_PARTIAL_DISJOINT", 
        "D_FULLY_DISJOINT", "E_LONGER_CONTEXT", "F_POSITIONAL_SHIFT", 
        "G_ISOMORPHIC_RULE", "H_COMPOSITIONAL"
    ]
    for tax in taxonomies:
        assert f"L2_identity_{tax}" in data
        assert f"L2_value_relative_{tax}" in data

@pytest.mark.skipif(get_latest_results() is None, reason="Results not yet generated")
def test_result_structure():
    data = get_latest_results()
    first_key = list(data.keys())[0]
    result = data[first_key]
    assert "params" in result
    assert "train" in result
    assert "val" in result
    assert "ood" in result
    assert "gap" in result
    assert "primary_failure" in result
    assert "mean" in result["ood"]
    assert "std" in result["ood"]
    assert "ci95" in result["ood"]
