"""
NIRMAL-1 V8.6: TEST SUITE FOR INDEPENDENT SOURCE RECONCILIATION

Verifies:
1. IndependentSourceReconciler audits all candidate sources.
2. Evidence artifact independence tracking (PROJECT_GENERATED vs DIRECT_REMOTE).
3. PROJECT_GENERATED artifacts cannot independently satisfy external source approval.
4. All six external sources are strictly UNDER_REVIEW.
5. Adversarial: Valid hash but false source claim.
6. Adversarial: Project-generated evidence pretending to be authoritative.
7. Adversarial: Missing provenance metadata.
8. Adversarial: Critical mismatch producing APPROVED fails closed.
"""

from pathlib import Path
import pytest

from training.acquisition.source_reconciliation import (
    IndependentSourceReconciler,
    EvidenceOrigin,
    RevisionVerificationStatus,
    ReconciliationResult,
)
from training.acquisition.evidence import (
    SourceEvidenceManager,
    SourceEvidenceDossier,
    ApprovalStatus,
    EvidenceValidationError,
    ApprovalPolicyEvaluator,
)


@pytest.fixture
def reconciler():
    return IndependentSourceReconciler()


@pytest.fixture
def policy_evaluator():
    return ApprovalPolicyEvaluator()


@pytest.fixture
def evidence_mgr():
    return SourceEvidenceManager()


class TestSourceReconciliation:
    """Test suite for independent source reconciliation engine."""

    def test_reconciler_audits_all_sources(self, reconciler):
        summaries = reconciler.reconcile_all()
        assert len(summaries) >= 9
        expected_sources = [
            "fineweb_edu_permissive",
            "the_stack_v2_permissive",
            "arxiv_open_access_papers",
            "dolma_v1_7_permissive",
            "redpajama_v2_permissive",
            "wikipedia_open_corpus",
            "nirmal_synthetic_v8_2",
            "proprietary_forum_scrapes",
            "non_commercial_research_corpus",
        ]
        for s in expected_sources:
            assert s in summaries

    def test_evidence_artifact_independence_audit(self, reconciler):
        """Verifies that existing evidence files in repo are classified as PROJECT_GENERATED."""
        audit = reconciler.audit_evidence_artifact_independence("fineweb_edu_permissive")
        assert len(audit) > 0
        for art_name, (origin, can_support, reason) in audit.items():
            assert origin == EvidenceOrigin.PROJECT_GENERATED
            assert can_support is False
            assert "PROJECT_GENERATED" in reason

    def test_all_six_external_sources_remain_under_review(self, reconciler):
        external_sources = [
            "fineweb_edu_permissive",
            "the_stack_v2_permissive",
            "arxiv_open_access_papers",
            "dolma_v1_7_permissive",
            "redpajama_v2_permissive",
            "wikipedia_open_corpus",
        ]
        summaries = reconciler.reconcile_all()
        for src in external_sources:
            s = summaries[src]
            assert s.overall_status == "UNDER_REVIEW"
            assert len(s.unresolved_blockers) > 0

    def test_synthetic_dataset_is_approved_and_matched(self, reconciler):
        s = reconciler.reconcile_source("nirmal_synthetic_v8_2")
        assert s.overall_status == "APPROVED"
        assert s.revision_status == RevisionVerificationStatus.VERIFIED_IMMUTABLE
        assert s.license_result == ReconciliationResult.MATCH
        assert len(s.unresolved_blockers) == 0

    def test_rejected_sources_remain_rejected(self, reconciler):
        s1 = reconciler.reconcile_source("proprietary_forum_scrapes")
        assert s1.overall_status == "REJECTED"
        s2 = reconciler.reconcile_source("non_commercial_research_corpus")
        assert s2.overall_status == "REJECTED"

    def test_adversarial_valid_hash_but_false_source_claim(self, reconciler):
        """
        Adversarial: An attacker provides a valid SHA-256 of a local file,
        but claims the dataset is Apache-2.0 when it is heterogeneous/GPL.
        The reconciler must flag CLAIM_MISMATCH and record blockers.
        """
        s = reconciler.reconcile_source("the_stack_v2_permissive")
        assert s.license_result == ReconciliationResult.CLAIM_MISMATCH
        # Check that blockers explicitly call out the license claim mismatch
        has_lic_blocker = any("License claim mismatch" in b for b in s.unresolved_blockers)
        assert has_lic_blocker is True

    def test_adversarial_project_generated_evidence_cannot_approve_external_source(self, policy_evaluator, evidence_mgr):
        """
        Adversarial: An external source dossier attempts to use a PROJECT_GENERATED
        evidence artifact under official/ to claim APPROVED status.
        ApprovalPolicyEvaluator must fail closed on req_03.
        """
        dossier = evidence_mgr.load_dossier("fineweb_edu_permissive")
        assert dossier is not None
        # Point to the official evidence artifact which is PROJECT_GENERATED
        dossier.license_evidence_file_path = "official/fineweb_edu_permissive/license_evidence.txt"
        evidence_mgr.save_dossier(dossier)

        try:
            all_passed, results = policy_evaluator.evaluate_source("fineweb_edu_permissive")
            assert all_passed is False
            assert results["req_03_license_evidence_stored"].passed is False
            assert results["req_03_license_evidence_stored"].status == "PROJECT_GENERATED"
        finally:
            # Revert dossier
            dossier.license_evidence_file_path = None
            evidence_mgr.save_dossier(dossier)

    def test_adversarial_missing_provenance_blocks_approval(self, policy_evaluator):
        """
        Adversarial: Source with missing provenance fields cannot be approved.
        """
        valid_ev_file = "evidence_files/nirmal_synthetic_v8_2_evidence.txt"
        dossier = SourceEvidenceDossier(
            source_id="no_prov_source",
            canonical_source_name="No Provenance Source",
            canonical_url="https://example.org/data",
            dataset_version_identifier="1.0",
            acquisition_method="HTTPS_DOWNLOAD",
            snapshot_revision_identifier="git_commit_1234567890abcdef",
            retrieval_timestamp="2026-09-08",
            source_checksum="c" * 64,
            license_url="https://example.org/license",
            license_text_hash=None,
            license_evidence_file_path=valid_ev_file,
            terms_policy_evidence_file_path=None,
            dataset_card_evidence_file_path=None,
            declared_license="Apache-2.0",
            per_file_license_policy="TEST",
            provenance_requirements=[],  # Empty provenance!
            attribution_requirements=["Author"],
            security_screening_status="PASSED_NO_CREDENTIALS",
            benchmark_contamination_status="SYNTHETIC_CLEAN",
            approval_status=ApprovalStatus.APPROVED,
        )
        with pytest.raises(EvidenceValidationError) as exc:
            dossier.validate()
        assert "provenance_requirements" in str(exc.value)

    def test_adversarial_critical_mismatch_blocks_approval(self, policy_evaluator):
        """
        Adversarial: A dossier with critical license mismatches cannot pass req_12.
        """
        class FakeRecord:
            revision_status = "UNVERIFIED_REVISION"
            claimed_vs_observed = {
                "declared_license": {
                    "claimed": "Apache-2.0",
                    "observed": "Heterogeneous per-file licensing",
                    "status": "CLAIM_MISMATCH",
                }
            }

        all_passed, results = policy_evaluator.evaluate_source("the_stack_v2_permissive", official_record=FakeRecord())
        assert all_passed is False
        assert results["req_12_no_critical_mismatch"].passed is False
        assert results["req_12_no_critical_mismatch"].status == "CLAIM_MISMATCH"
