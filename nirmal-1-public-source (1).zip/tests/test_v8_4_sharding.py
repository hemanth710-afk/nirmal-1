"""
Unit tests for DistributedShardWriter and DistributedShardReader in Nirmal-1 V8.4.
"""

from pathlib import Path
import tempfile
import numpy as np
import pytest
import torch

from training.v8_4_sharding import DistributedShardWriter, DistributedShardReader


def test_distributed_shard_writer_and_reader():
    with tempfile.TemporaryDirectory() as tmpdir:
        tmp_path = Path(tmpdir)
        writer = DistributedShardWriter(output_dir=tmp_path, dataset_version="TEST-V8.4")

        # Create dummy documents
        doc1 = {"token_ids": [10, 20, 30, 40, 50], "domain": "code"}
        doc2 = {"token_ids": [100, 200, 300], "domain": "math"}
        doc3 = {"token_ids": [1, 2, 3, 4, 5, 6, 7, 8], "domain": "science"}

        summary = writer.write_shard("test_shard_01", [doc1, doc2, doc3])
        assert summary.total_tokens == 16
        assert summary.total_documents == 3
        assert (tmp_path / "test_shard_01.bin").exists()
        assert (tmp_path / "test_shard_01.idx").exists()
        assert (tmp_path / "test_shard_01.manifest.json").exists()

        # Test reader
        manifest_dicts = [summary.to_dict()]
        reader = DistributedShardReader(
            shard_manifests=manifest_dicts,
            shard_dir=tmp_path,
            batch_size=2,
            seq_len=3,  # step_tokens = 2 * (3 + 1) = 8
        )

        batches = list(reader.stream_batches())
        assert len(batches) == 2  # 16 total tokens / 8 per step = 2 batches
        x, y, meta = batches[0]
        assert x.shape == (2, 3)
        assert y.shape == (2, 3)
        assert meta["global_step"] == 1
