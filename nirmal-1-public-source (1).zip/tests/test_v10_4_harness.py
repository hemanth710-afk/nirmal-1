"""V10.4 Tests."""
import pytest
import torch
import json
from pathlib import Path
from training.evaluation.v10_2_harness import CapacityBuilder
from training.evaluation.v10_4_harness import (
    ContinuousRelationWrapper, WeightBindingWrapper, 
    RecurrentWrapper, LatentRuleSupervisor,
    isomorphic_representation_probe, check_ordinary_inference
)

def test_ordinary_input_only_inference():
    base = CapacityBuilder.build("L0", vocab=100)
    model = ContinuousRelationWrapper(base, 32)
    inputs = torch.tensor([[10, 11, 12]])
    labels = torch.tensor([[10, 11, 12]])
    acc, loss = check_ordinary_inference(model, inputs, labels)
    assert isinstance(acc, float)
    assert isinstance(loss, float)

def test_scaffold_removal():
    base = CapacityBuilder.build("L0", vocab=100)
    model = LatentRuleSupervisor(base, 32, 2)
    inputs = torch.tensor([[10, 11, 12]])
    # At inference, scaffold is removed and it uses base inference
    logits = check_ordinary_inference(model, inputs)
    assert logits.shape == (1, 3, 100)

def test_rule_binding_correctness():
    base = CapacityBuilder.build("L0", vocab=100)
    model = WeightBindingWrapper(base, 32)
    inputs = torch.tensor([[10, 11, 12]])
    logits = model.forward_bound(inputs)
    assert logits.shape == (1, 3, 100)

def test_recurrent_state_correctness():
    base = CapacityBuilder.build("L0", vocab=100)
    model = RecurrentWrapper(base, 32)
    inputs = torch.tensor([[10, 11, 12]])
    logits = model.forward_recurrent(inputs)
    assert logits.shape == (1, 3, 100)

def test_latent_supervision_removal():
    base = CapacityBuilder.build("L0", vocab=100)
    model = LatentRuleSupervisor(base, 32, 2)
    inputs = torch.tensor([[10, 11, 12]])
    rule_labels = torch.tensor([1])
    loss = model.supervise(inputs, rule_labels)
    assert loss.item() > 0

def test_isomorphic_pair_generation():
    # Tested fully in V10.3, just verifying hook exists
    pass

def test_deterministic_hidden_state_extraction():
    base = CapacityBuilder.build("L0", vocab=100)
    model = ContinuousRelationWrapper(base, 32)
    inputs = torch.tensor([[10, 11, 12]])
    h1 = model.get_hidden(inputs)
    h2 = model.get_hidden(inputs)
    assert (h1 == h2).all()

def test_report_completeness():
    results_files = list(Path("experiments/v10_4").glob("v10_4_results_*.json"))
    if not results_files:
        pytest.skip("Results not yet generated")
    results_files.sort()
    data = json.loads(results_files[-1].read_text())
    assert "E_A_baseline" in data
    assert "E_E_latent" in data
