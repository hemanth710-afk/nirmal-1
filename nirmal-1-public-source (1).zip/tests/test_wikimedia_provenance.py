"""
NIRMAL-1 V8.9: TEST SUITE FOR WIKIMEDIA PROVENANCE TRUTH & VALIDATION

Verifies:
1. Genuine revision ID validation (revision_verified=True passes validate_provenance).
2. Fake or missing revision ID triggers revision_verified=False and rejection.
3. Missing provenance fails closed (missing URL, invalid URL, missing payload hash, non-network flag).
4. Local fixtures or synthetic records cannot masquerade as REMOTE_SOURCE_DATA.
5. Strict fail-closed validation on empty or ambiguous inputs.
"""

import hashlib
from pathlib import Path
from typing import Any, Dict, List
import pytest

from training.acquisition.wikimedia_real_adapter import WikimediaRealAdapter
from training.acquisition.pilot_provenance_audit import (
    PilotProvenanceClass,
    PilotProvenanceAuditor,
    PilotDocumentAuditEntry,
    ProvenanceVerificationError,
)


@pytest.fixture
def temp_pilot_dirs(tmp_path):
    staging_dir = tmp_path / "pilot" / "staging"
    shards_dir = tmp_path / "pilot" / "shards"
    manifests_dir = tmp_path / "pilot" / "manifests"
    provenance_dir = tmp_path / "pilot" / "provenance"
    staging_dir.mkdir(parents=True)
    shards_dir.mkdir(parents=True)
    manifests_dir.mkdir(parents=True)
    provenance_dir.mkdir(parents=True)
    return staging_dir, shards_dir, manifests_dir, provenance_dir


@pytest.fixture
def adapter(temp_pilot_dirs):
    staging_dir, shards_dir, manifests_dir, prov_dir = temp_pilot_dirs
    return WikimediaRealAdapter(
        staging_dir=staging_dir,
        shards_dir=shards_dir,
        manifests_dir=manifests_dir,
        provenance_dir=prov_dir,
    )


def create_valid_remote_record() -> Dict[str, Any]:
    text = "Photosynthesis converts light energy into chemical energy stored in carbohydrates."
    return {
        "id": "wiki_1001",
        "page_id": "1001",
        "title": "Photosynthesis",
        "revision_id": "1198274612",
        "revision_verified": True,
        "timestamp": "2026-09-01T12:00:00Z",
        "url": "https://en.wikipedia.org/wiki/Photosynthesis",
        "license": "CC-BY-SA-4.0",
        "text": text,
        "raw_payload_hash": hashlib.sha256(b"raw_valid_remote_json").hexdigest(),
        "raw_bytes": len(text.encode("utf-8")),
        "provenance_class": PilotProvenanceClass.REMOTE_SOURCE_DATA.value,
        "is_network_retrieved": True,
        "is_local_fixture": False,
        "is_synthetic": False,
        "is_copied_from_repo": False,
    }


class TestWikimediaProvenance:
    """Rigorous tests for provenance verification and truth classification."""

    def test_genuine_revision_id_validation_success(self, adapter):
        record = create_valid_remote_record()
        # Should return True without errors
        assert adapter.validate_provenance([record]) is True

    def test_fake_or_missing_revision_id_triggers_rejection(self, adapter):
        # Case 1: missing revision ID
        rec_missing_rev = create_valid_remote_record()
        rec_missing_rev["revision_id"] = ""
        with pytest.raises(ProvenanceVerificationError) as exc1:
            adapter.validate_provenance([rec_missing_rev])
        assert "has missing revision ID" in str(exc1.value)

        # Case 2: revision_verified is False
        rec_unverified = create_valid_remote_record()
        rec_unverified["revision_verified"] = False
        with pytest.raises(ProvenanceVerificationError) as exc2:
            adapter.validate_provenance([rec_unverified])
        assert "has unverified revision ID" in str(exc2.value)

        # Case 3: non-numeric revision ID ("rev_123", "mock", "enwiki_rest_v1")
        rec_non_numeric = create_valid_remote_record()
        rec_non_numeric["revision_id"] = "rev_fake_999"
        with pytest.raises(ProvenanceVerificationError) as exc3:
            adapter.validate_provenance([rec_non_numeric])
        assert "has invalid non-numeric revision ID" in str(exc3.value)

        # Case 4: negative or zero revision ID
        rec_zero = create_valid_remote_record()
        rec_zero["revision_id"] = "0"
        with pytest.raises(ProvenanceVerificationError) as exc4:
            adapter.validate_provenance([rec_zero])
        assert "has invalid non-numeric revision ID" in str(exc4.value)

    def test_missing_provenance_fails_closed(self, adapter):
        # Case 1: missing URL
        rec_no_url = create_valid_remote_record()
        rec_no_url["url"] = ""
        with pytest.raises(ProvenanceVerificationError) as exc1:
            adapter.validate_provenance([rec_no_url])
        assert "missing or invalid Wikipedia HTTPS URL" in str(exc1.value)

        # Case 2: non-HTTPS URL
        rec_http_url = create_valid_remote_record()
        rec_http_url["url"] = "http://en.wikipedia.org/wiki/Photosynthesis"
        with pytest.raises(ProvenanceVerificationError) as exc2:
            adapter.validate_provenance([rec_http_url])
        assert "missing or invalid Wikipedia HTTPS URL" in str(exc2.value)

        # Case 3: non-Wikipedia URL
        rec_non_wiki_url = create_valid_remote_record()
        rec_non_wiki_url["url"] = "https://untrusted-external-site.com/wiki"
        with pytest.raises(ProvenanceVerificationError) as exc3:
            adapter.validate_provenance([rec_non_wiki_url])
        assert "missing or invalid Wikipedia HTTPS URL" in str(exc3.value)

        # Case 4: missing raw payload hash
        rec_no_hash = create_valid_remote_record()
        rec_no_hash["raw_payload_hash"] = ""
        with pytest.raises(ProvenanceVerificationError) as exc4:
            adapter.validate_provenance([rec_no_hash])
        assert "missing valid SHA-256 raw payload hash" in str(exc4.value)

        # Case 5: is_network_retrieved is False
        rec_not_network = create_valid_remote_record()
        rec_not_network["is_network_retrieved"] = False
        with pytest.raises(ProvenanceVerificationError) as exc5:
            adapter.validate_provenance([rec_not_network])
        assert "is_network_retrieved is False" in str(exc5.value)

        # Case 6: empty records list
        with pytest.raises(ProvenanceVerificationError) as exc6:
            adapter.validate_provenance([])
        assert "empty records list" in str(exc6.value)

    def test_local_fixture_cannot_masquerade_as_remote(self, adapter):
        rec_fixture = create_valid_remote_record()
        rec_fixture["is_local_fixture"] = True
        rec_fixture["provenance_class"] = PilotProvenanceClass.REMOTE_SOURCE_DATA.value

        with pytest.raises(ProvenanceVerificationError) as exc:
            adapter.validate_provenance([rec_fixture])
        assert "CRITICAL PROVENANCE FRAUD" in str(exc.value)
        assert "is_local_fixture=True" in str(exc.value)

    def test_synthetic_record_cannot_masquerade_as_remote(self, adapter):
        rec_synthetic = create_valid_remote_record()
        rec_synthetic["is_synthetic"] = True
        rec_synthetic["provenance_class"] = PilotProvenanceClass.REMOTE_SOURCE_DATA.value

        with pytest.raises(ProvenanceVerificationError) as exc:
            adapter.validate_provenance([rec_synthetic])
        assert "CRITICAL PROVENANCE FRAUD" in str(exc.value)
        assert "is_synthetic=True" in str(exc.value)

    def test_repo_copied_record_cannot_masquerade_as_remote(self, adapter):
        rec_copied = create_valid_remote_record()
        rec_copied["is_copied_from_repo"] = True
        rec_copied["provenance_class"] = PilotProvenanceClass.REMOTE_SOURCE_DATA.value

        with pytest.raises(ProvenanceVerificationError) as exc:
            adapter.validate_provenance([rec_copied])
        assert "CRITICAL PROVENANCE FRAUD" in str(exc.value)
        assert "is_copied_from_repo=True" in str(exc.value)
