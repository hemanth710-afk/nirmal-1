"""
Comprehensive regression tests for Nirmal-1 V8.4 data pipeline hardening:
- Source abstraction (file, dir, archive)
- Corrupt record isolation and fail-closed handling
- Shard integrity verification and atomic writes
- Cross-split isolation validation and leakage detection
- Manifest tamper detection and dataset fingerprinting
- Authoritative token accounting report
"""

import gzip
import json
import os
from pathlib import Path
import shutil
import tempfile
import zipfile
import pytest

from training.v8_4_ingestion import (
    StreamingIngestionEngine,
    IngestionCheckpoint,
    SourceDescriptor,
    SourceType,
    CorruptRecordPolicy,
    CorruptedRecordError,
)
from training.v8_4_global_dedup import (
    GlobalExactDeduplicator,
    MinHashLSHDeduplicator,
    ProductionDeduplicationPipeline,
    CrossSplitLeakageError,
    CrossSplitIsolationValidator,
)
from training.v8_4_manifest import (
    SourceProvenanceRecord,
    ShardManifestEntry,
    DatasetManifestManager,
    LicenseProvenanceViolationError,
    ManifestIntegrityError,
)
from training.v8_4_sharding import (
    DistributedShardWriter,
    DistributedShardReader,
    ShardIntegrityError,
)
from training.v8_4_tokenization import (
    ProductionTokenizationPipeline,
    EXPECTED_TOKENIZER_CHECKSUM,
)


def test_source_descriptor_and_directory_streaming():
    with tempfile.TemporaryDirectory() as tmpdir:
        tmp_path = Path(tmpdir)
        data_dir = tmp_path / "raw_data"
        data_dir.mkdir()

        # Create two files in directory
        f1 = data_dir / "part1.jsonl"
        f2 = data_dir / "part2.jsonl"

        with open(f1, "w", encoding="utf-8") as f:
            f.write(json.dumps({"id": "d1", "text": "First valid document with sufficient text length for ingestion."}) + "\n")
        with open(f2, "w", encoding="utf-8") as f:
            f.write(json.dumps({"id": "d2", "text": "Second valid document with sufficient text length for ingestion."}) + "\n")

        desc = SourceDescriptor(
            source_identifier="test_corpus_dir",
            source_type=SourceType.LOCAL_DIR,
            location=str(data_dir),
            license="Apache-2.0",
            provenance_details="Synthetic test directory",
        )

        engine = StreamingIngestionEngine(checkpoint_dir=tmp_path / "ckpts", min_doc_length=20)
        docs = list(engine.stream_records_from_source(desc))
        assert len(docs) == 2
        assert {d.id for d in docs} == {"d1", "d2"}


def test_source_archive_streaming():
    with tempfile.TemporaryDirectory() as tmpdir:
        tmp_path = Path(tmpdir)
        zip_path = tmp_path / "corpus.zip"

        with zipfile.ZipFile(zip_path, "w") as zf:
            zf.writestr("doc_a.txt", "Document A: High quality scientific content with necessary length to pass filters.")
            zf.writestr("doc_b.txt", "Document B: High quality programming explanations with adequate details.")

        desc = SourceDescriptor(
            source_identifier="test_corpus_zip",
            source_type=SourceType.ARCHIVE,
            location=str(zip_path),
            license="MIT",
            provenance_details="Synthetic test archive",
        )

        engine = StreamingIngestionEngine(checkpoint_dir=tmp_path / "ckpts", min_doc_length=20)
        docs = list(engine.stream_records_from_source(desc))
        assert len(docs) == 2


def test_corrupt_record_policy_isolate_vs_fail_closed():
    with tempfile.TemporaryDirectory() as tmpdir:
        tmp_path = Path(tmpdir)
        bad_json_file = tmp_path / "bad.jsonl"
        with open(bad_json_file, "w", encoding="utf-8") as f:
            f.write('{"id": "ok1", "text": "Valid document with long enough text to pass filters."}\n')
            f.write('{corrupted_json_line_missing_quotes\n')
            f.write('{"id": "ok2", "text": "Another valid document with long enough text to pass filters."}\n')

        prov = SourceProvenanceRecord(
            source_name="CorruptStream",
            source_identifier=str(bad_json_file),
            license="MIT",
            provenance_details="Test corrupt",
            acquisition_timestamp="2026-09-06T00:00:00Z",
            original_size_bytes=100,
            processed_size_bytes=0,
            measured_token_count=0,
            source_sha256="",
            preprocessing_version="v8.4.0",
        )

        # Policy 1: ISOLATE_AND_LOG (default) -> skips corrupted line, finishes cleanly
        engine_iso = StreamingIngestionEngine(
            checkpoint_dir=tmp_path / "ckpts1",
            min_doc_length=20,
            corrupt_policy=CorruptRecordPolicy.ISOLATE_AND_LOG,
        )
        docs_iso = list(engine_iso.stream_records_from_file(bad_json_file, source_record=prov))
        assert len(docs_iso) == 2
        assert engine_iso.total_corrupted == 1

        # Policy 2: FAIL_CLOSED -> raises CorruptedRecordError
        engine_fail = StreamingIngestionEngine(
            checkpoint_dir=tmp_path / "ckpts2",
            min_doc_length=20,
            corrupt_policy=CorruptRecordPolicy.FAIL_CLOSED,
        )
        with pytest.raises(CorruptedRecordError):
            list(engine_fail.stream_records_from_file(bad_json_file, source_record=prov))


def test_shard_atomic_writes_and_corruption_detection():
    with tempfile.TemporaryDirectory() as tmpdir:
        tmp_path = Path(tmpdir)
        writer = DistributedShardWriter(output_dir=tmp_path, dataset_version="TEST-V8.4")

        docs = [
            {"token_ids": [101, 102, 103, 104], "domain": "domain_1"},
            {"token_ids": [201, 202, 203], "domain": "domain_2"},
        ]
        summary = writer.write_shard("shard_alpha", docs)
        assert (tmp_path / "shard_alpha.bin").exists()
        assert (tmp_path / "shard_alpha.idx").exists()

        reader = DistributedShardReader(
            shard_manifests=[summary.to_dict()],
            shard_dir=tmp_path,
        )
        # Integrity check passes initially
        assert reader.verify_shard_integrity(0)["integrity_passed"] is True

        # Tamper binary file
        with open(tmp_path / "shard_alpha.bin", "r+b") as f:
            f.seek(0)
            f.write(b"\x00")

        # Now integrity check must fail
        with pytest.raises(ShardIntegrityError):
            reader.verify_shard_integrity(0)


def test_cross_split_isolation_and_leakage_detection():
    validator = CrossSplitIsolationValidator(jaccard_threshold=0.85)

    base_tokens = ["attention", "transformer", "scaling", "loss", "optimizer", "gradient", "activation", "residual"] * 8
    t_text = " ".join(base_tokens)
    v_text = "Distinct validation benchmark text covering symbolic reasoning logic."
    ts_text = "Distinct held-out test theorem proof verification."

    train = [("t1", t_text)]
    val = [("v1", v_text)]
    test = [("ts1", ts_text)]

    # Clean splits pass
    res = validator.validate_isolation(train, val, test)
    assert res["isolation_status"] == "STRICT_ZERO_LEAKAGE_CONFIRMED"

    # Exact leakage into val fails
    with pytest.raises(CrossSplitLeakageError):
        validator.validate_isolation(train, [("v_leak", t_text)], test)

    # Near-duplicate leakage into test fails
    near_t_text = " ".join(base_tokens[:-1] + ["telemetry"])
    with pytest.raises(CrossSplitLeakageError):
        validator.validate_isolation(train, val, [("ts_leak", near_t_text)])


def test_manifest_tamper_detection_and_dataset_fingerprint():
    with tempfile.TemporaryDirectory() as tmpdir:
        tmp_path = Path(tmpdir)
        mgr = DatasetManifestManager(dataset_version="FP-TEST-001", manifest_dir=tmp_path)

        fp1 = mgr.compute_dataset_fingerprint()
        assert isinstance(fp1, str) and len(fp1) == 64

        manifest_file = mgr.save_manifest()
        loaded = DatasetManifestManager.load_and_verify_manifest(manifest_file)
        assert loaded["dataset_version"] == "FP-TEST-001"

        # Tampering with file content
        with open(manifest_file, "r", encoding="utf-8") as f:
            data = json.load(f)
        data["dataset_version"] = "TAMPERED-VERSION"
        with open(manifest_file, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)

        with pytest.raises(ManifestIntegrityError):
            DatasetManifestManager.load_and_verify_manifest(manifest_file)
