"""Unit tests for V10.9 Foundation Harness."""

import numpy as np
import pytest
import torch

from training.evaluation.v10_9_foundation_harness import (
    ANS_TOKEN,
    DEFAULT_VOCAB_SIZE,
    EP_TOKEN,
    MAP_TOKEN,
    MIN_DATA_TOKEN,
    PAD_TOKEN,
    PLACEHOLDER_TOKEN,
    QRY_TOKEN,
    SUP_TOKEN,
    FoundationEpisode,
    Stage1AGenerator,
    Stage1BGenerator,
    collate_foundation_episodes,
    paired_bootstrap_ci,
    wilson_ci,
)


def test_dedicated_token_ordering():
    assert PAD_TOKEN == 0
    assert EP_TOKEN == 1
    assert SUP_TOKEN == 2
    assert MAP_TOKEN == 3
    assert QRY_TOKEN == 4
    assert ANS_TOKEN == 5
    assert PLACEHOLDER_TOKEN == 6
    assert MIN_DATA_TOKEN >= 10


def test_wilson_ci():
    low, high = wilson_ci(50, 100, confidence=0.95)
    assert 0.40 < low < 0.50
    assert 0.50 < high < 0.60
    assert wilson_ci(0, 100)[0] == 0.0
    assert wilson_ci(100, 100)[1] == 1.0


def test_paired_bootstrap_ci():
    # Distinct positive shift
    a = np.array([1.0] * 80 + [0.0] * 20)
    b = np.array([1.0] * 40 + [0.0] * 60)
    low, high = paired_bootstrap_ci(a, b, n_resamples=500, seed=42)
    assert low > 0.0, f"Expected positive lower bound, got {low}"
    assert high > low


def test_collate_episodes_padding():
    ep1 = FoundationEpisode(
        input_ids=torch.tensor([1, 2, 3], dtype=torch.long),
        target=10,
        task_type="test",
        control_type="correct",
        keys=[2], values=[3], query_key=2,
    )
    ep2 = FoundationEpisode(
        input_ids=torch.tensor([1, 2, 3, 4, 5], dtype=torch.long),
        target=20,
        task_type="test",
        control_type="correct",
        keys=[4], values=[5], query_key=4,
    )

    padded, targets = collate_foundation_episodes([ep1, ep2])
    assert padded.shape == (2, 5)
    # Left padding
    assert padded[0, :2].tolist() == [0, 0]
    assert padded[0, 2:].tolist() == [1, 2, 3]
    assert padded[1].tolist() == [1, 2, 3, 4, 5]
    assert targets.tolist() == [10, 20]


def test_benchmark_manifest_hashing():
    """Verify deterministic benchmark manifest hashing."""
    import hashlib
    g = torch.Generator().manual_seed(999)
    gen = Stage1BGenerator()
    episodes = [gen.generate_quartet(g)["correct"] for _ in range(10)]

    # Compute manifest hash from episode fingerprints
    hasher1 = hashlib.sha256()
    for ep in episodes:
        hasher1.update(ep.fingerprint.encode("utf-8"))
    digest1 = hasher1.hexdigest()

    # Recompute with identical seed
    g_replay = torch.Generator().manual_seed(999)
    episodes_replay = [gen.generate_quartet(g_replay)["correct"] for _ in range(10)]
    hasher2 = hashlib.sha256()
    for ep in episodes_replay:
        hasher2.update(ep.fingerprint.encode("utf-8"))
    digest2 = hasher2.hexdigest()

    assert digest1 == digest2, "Benchmark manifest hash is non-deterministic!"
    assert len(digest1) == 64
