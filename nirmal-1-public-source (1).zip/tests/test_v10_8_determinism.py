"""Determinism tests for V10.8 Episode Generation."""

import pytest
import torch

from training.evaluation.v10_8_harness import (
    P_FIELD,
    EpisodeBuilder,
    RuleDefinition,
    RuleSampler,
    Symbolizer,
)


def test_episode_generation_determinism():
    builder = EpisodeBuilder(p=P_FIELD)
    rule = RuleDefinition("scale", (7,))

    g1 = torch.Generator().manual_seed(42)
    ep1 = builder.build_episode(rule, k=4, symbol_regime="V-A", is_unseen_symbol=True, g=g1)

    g2 = torch.Generator().manual_seed(42)
    ep2 = builder.build_episode(rule, k=4, symbol_regime="V-A", is_unseen_symbol=True, g=g2)

    assert torch.equal(ep1.input_ids, ep2.input_ids)
    assert ep1.target == ep2.target
    assert ep1.qx_val == ep2.qx_val
    assert ep1.qy_val == ep2.qy_val
    assert ep1.support_xs == ep2.support_xs


def test_rule_sampling_determinism():
    sampler = RuleSampler(p=P_FIELD)

    g1 = torch.Generator().manual_seed(108)
    rules1 = [sampler.sample_seen_rule(g1) for _ in range(20)]

    g2 = torch.Generator().manual_seed(108)
    rules2 = [sampler.sample_seen_rule(g2) for _ in range(20)]

    assert rules1 == rules2


def test_symbolizer_determinism():
    g1 = torch.Generator().manual_seed(99)
    pi1 = Symbolizer.sample_symbolization("V-B", is_unseen=True, g=g1)

    g2 = torch.Generator().manual_seed(99)
    pi2 = Symbolizer.sample_symbolization("V-B", is_unseen=True, g=g2)

    for x in range(P_FIELD):
        assert pi1(x) == pi2(x)
