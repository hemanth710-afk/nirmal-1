import pytest
from training.acquisition.capability_experiment_analysis import ExperimentAnalyzer

@pytest.fixture
def analyzer():
    return ExperimentAnalyzer()

def test_split_isolation(analyzer):
    assert not analyzer.check_leakage("training text", "eval text", "labels")

def test_leakage_detection_exact_match(analyzer):
    assert analyzer.check_leakage("same text", "same text", "labels")

def test_leakage_detection_label_leakage(analyzer):
    assert analyzer.check_leakage("the label is mathematical reasoning", "eval text", "mathematical reasoning")

def test_synthetic_control_isolation(analyzer):
    assert not analyzer.check_leakage("synthetic control A", "synthetic eval B", "")

def test_no_leakage_empty(analyzer):
    assert not analyzer.check_leakage("", "", "")
