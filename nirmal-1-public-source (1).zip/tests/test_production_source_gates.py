"""
Test Suite for Production Source Hard Gates G1 through G14 (Nirmal-1 V8.4).

Verifies:
1. All 14 hard gates (G1-G14) evaluated by ProductionDataGateSystem.
2. GATE_13_CREDENTIAL_SAFETY and GATE_14_SOURCE_APPROVAL are properly registered.
3. Execution mode (--execute) strictly blocks all 6 unapproved external sources.
4. Dry-run mode (--dry-run) safely inspects all 6 external sources without writing files.
5. Non-existent sources fail closed.
6. Overall production gate correctly remains NO-GO due to 200B token requirement deficit.
7. Synthetic adversarial runner passes all fail-closed conditions.
"""

from pathlib import Path
import pytest
import subprocess
import sys

from scripts.production_data_acquisition import (
    SourceRegistry,
    ProductionDataGateSystem,
    run_synthetic_adversarial_test,
)
from training.acquisition.evidence import (
    SourceEvidenceManager,
    ApprovalStatus,
)


@pytest.fixture
def gate_system():
    registry = SourceRegistry()
    return ProductionDataGateSystem(registry)


class TestProductionSourceGates:
    """Rigorous gate testing for production data acquisition."""

    def test_all_14_gates_evaluated(self, gate_system):
        overall_status, gates = gate_system.evaluate_gates()

        expected_gates = [
            "GATE_1_TOKEN_COUNT",
            "GATE_2_EXACT_DEDUP",
            "GATE_3_NEAR_DEDUP",
            "GATE_4_SPLIT_ISOLATION",
            "GATE_5_TOKENIZER",
            "GATE_6_SHARD_INTEGRITY",
            "GATE_7_MANIFEST_INTEGRITY",
            "GATE_8_PROVENANCE",
            "GATE_9_LICENSE_POLICY",
            "GATE_10_RESUMABILITY",
            "GATE_11_DATA_ACCOUNTING",
            "GATE_12_CONTAMINATION_LEAKAGE",
            "GATE_13_CREDENTIAL_SAFETY",
            "GATE_14_SOURCE_APPROVAL",
        ]

        for g in expected_gates:
            assert g in gates, f"Missing hard gate: {g}"
            assert "status" in gates[g]
            assert "passed" in gates[g]

        assert len(gates) == 14

        # Invariants:
        # G1 must FAIL because current physical tokens (233,997) < 200B
        assert gates["GATE_1_TOKEN_COUNT"]["passed"] is False
        assert gates["GATE_1_TOKEN_COUNT"]["status"] == "FAIL"

        # Gate 13 & 14
        assert gates["GATE_13_CREDENTIAL_SAFETY"]["passed"] is True
        assert gates["GATE_13_CREDENTIAL_SAFETY"]["status"] == "PASS"

        assert gates["GATE_14_SOURCE_APPROVAL"]["passed"] is True
        assert gates["GATE_14_SOURCE_APPROVAL"]["status"] == "PASS"

        # Overall verdict must be NO-GO
        assert overall_status == "NO-GO"

    def test_execute_mode_blocks_all_six_external_sources(self):
        external_sources = [
            "fineweb_edu_permissive",
            "the_stack_v2_permissive",
            "arxiv_open_access_papers",
            "dolma_v1_7_permissive",
            "redpajama_v2_permissive",
            "wikipedia_open_corpus",
        ]

        script_path = Path(__file__).resolve().parent.parent / "scripts" / "acquire_external_source.py"

        for src in external_sources:
            cmd = [sys.executable, str(script_path), "--execute", "--source", src]
            res = subprocess.run(cmd, capture_output=True, text=True)
            # Exit code 2 indicates GATE G14 failed closed
            assert res.returncode == 2, f"Expected exit code 2 for unapproved source {src}, got {res.returncode}"
            assert "GATE G14 FAILED" in res.stdout
            assert "is NOT APPROVED" in res.stdout

    def test_dry_run_mode_succeeds_for_all_sources(self):
        all_sources = [
            "fineweb_edu_permissive",
            "the_stack_v2_permissive",
            "arxiv_open_access_papers",
            "dolma_v1_7_permissive",
            "redpajama_v2_permissive",
            "wikipedia_open_corpus",
            "nirmal_synthetic_v8_2",
        ]

        script_path = Path(__file__).resolve().parent.parent / "scripts" / "acquire_external_source.py"

        for src in all_sources:
            cmd = [sys.executable, str(script_path), "--dry-run", "--source", src]
            res = subprocess.run(cmd, capture_output=True, text=True)
            assert res.returncode == 0, f"Dry run failed for {src}: {res.stderr}\n{res.stdout}"
            assert "DRY RUN COMPLETED SUCCESSFULLY" in res.stdout

    def test_execute_unknown_source_fails_closed(self):
        script_path = Path(__file__).resolve().parent.parent / "scripts" / "acquire_external_source.py"
        cmd = [sys.executable, str(script_path), "--execute", "--source", "non_existent_source_999"]
        res = subprocess.run(cmd, capture_output=True, text=True)
        assert res.returncode == 1
        assert "No source evidence dossier found" in res.stdout

    def test_synthetic_adversarial_suite_passes(self):
        results = run_synthetic_adversarial_test()
        assert len(results) >= 10
        for test_name, status in results.items():
            assert status == "PASS", f"Adversarial test {test_name} failed: {status}"
