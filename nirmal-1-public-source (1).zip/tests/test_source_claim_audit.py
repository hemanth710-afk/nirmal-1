"""
Test Suite for Automated Source Claim Auditing (Nirmal-1 V8.5).

Verifies:
1. SourceClaimsAuditor accurately audits all 9 registered dossiers.
2. Adversarial 5: Missing evidence artifact is detected and classified as MISSING_EVIDENCE.
3. Adversarial 6: Modified evidence after hashing is detected as an integrity failure.
4. Adversarial 7: Dossier claiming APPROVED with missing evidence fails closed.
5. Adversarial 8: Dossier claiming a license that conflicts with observed evidence is flagged as CLAIM_MISMATCH.
6. Fail-closed: External candidate sources are strictly maintained as UNDER_REVIEW.
7. Audit record generation in data/acquisition_records/.
"""

import json
from pathlib import Path
import pytest

from scripts.audit_source_claims import SourceClaimsAuditor, SourceAuditReport
from training.acquisition.evidence import (
    SourceEvidenceManager,
    SourceEvidenceDossier,
    ApprovalStatus,
)
from training.acquisition.official_evidence import OfficialEvidenceManager, ClaimStatus


@pytest.fixture
def auditor():
    return SourceClaimsAuditor()


class TestSourceClaimAudit:
    """Rigorous testing for claim auditing and fail-closed policies."""

    def test_auditor_evaluates_all_sources(self, auditor):
        all_ok, reports = auditor.run_all_audits()
        assert len(reports) == 9

        # Invariant: only synthetic is APPROVED
        assert reports["nirmal_synthetic_v8_2"].effective_approval_status == "APPROVED"
        assert reports["nirmal_synthetic_v8_2"].dossier_approval_status == "APPROVED"

        # Invariant: all 6 external sources must be UNDER_REVIEW
        external_sources = [
            "fineweb_edu_permissive",
            "the_stack_v2_permissive",
            "arxiv_open_access_papers",
            "dolma_v1_7_permissive",
            "redpajama_v2_permissive",
            "wikipedia_open_corpus",
        ]
        for src in external_sources:
            assert reports[src].effective_approval_status == "UNDER_REVIEW"
            assert reports[src].dossier_approval_status == "UNDER_REVIEW"

        # Invariant: prohibited sources are REJECTED
        assert reports["non_commercial_research_corpus"].effective_approval_status == "REJECTED"
        assert reports["proprietary_forum_scrapes"].effective_approval_status == "REJECTED"

        assert all_ok is True

    def test_adversarial_5_missing_evidence_artifact_detected(self, auditor, monkeypatch, tmp_path):
        # Point to a temporary official directory without evidence files
        empty_official = tmp_path / "empty_official"
        empty_official.mkdir()
        fake_official_mgr = OfficialEvidenceManager(official_dir=empty_official)
        monkeypatch.setattr(auditor, "official_mgr", fake_official_mgr)

        report = auditor.audit_source("fineweb_edu_permissive")
        assert report.field_audits["license_evidence"].status == ClaimStatus.MISSING_EVIDENCE.value
        assert "Missing official evidence record" in report.fail_closed_violations[0]

    def test_adversarial_6_modified_evidence_after_hashing_detected(self, auditor, monkeypatch, tmp_path):
        fake_official = tmp_path / "modified_official"
        fake_official_mgr = OfficialEvidenceManager(official_dir=fake_official)
        fake_official_mgr.generate_source_evidence("the_stack_v2_permissive")

        # Modify the evidence file after it was hashed
        lic_file = fake_official_mgr.get_source_dir("the_stack_v2_permissive") / "license_evidence.txt"
        lic_file.write_text("Modified unauthorized license contents", encoding="utf-8")

        monkeypatch.setattr(auditor, "official_mgr", fake_official_mgr)
        report = auditor.audit_source("the_stack_v2_permissive")

        assert report.field_audits["license_evidence"].status == ClaimStatus.MISSING_EVIDENCE.value
        assert any("Evidence integrity failure" in v for v in report.fail_closed_violations)

    def test_adversarial_7_dossier_claims_approved_without_evidence_fails_closed(self, auditor, monkeypatch):
        # Simulate an illegitimate dossier attempting to claim APPROVED
        tampered_dossier = SourceEvidenceDossier(
            source_id="fake_external_source",
            canonical_source_name="Fake Source",
            canonical_url="https://valid.org/data",
            dataset_version_identifier="1.0",
            acquisition_method="TEST",
            snapshot_revision_identifier="rev1",
            retrieval_timestamp="2026-09-07",
            source_checksum="a" * 64,
            license_url="https://valid.org/license",
            license_text_hash=None,
            license_evidence_file_path=None,
            terms_policy_evidence_file_path=None,
            dataset_card_evidence_file_path=None,
            declared_license="Apache-2.0",
            per_file_license_policy="TEST",
            approval_status=ApprovalStatus.APPROVED,
        )
        monkeypatch.setattr(auditor.evidence_mgr, "load_dossier", lambda sid: tampered_dossier)
        monkeypatch.setattr(auditor.official_mgr, "load_verification_record", lambda sid: None)

        report = auditor.audit_source("fake_external_source")
        assert report.effective_approval_status == "UNDER_REVIEW"
        assert report.all_requirements_passed is False
        assert any("CRITICAL: Dossier declares APPROVED" in v for v in report.fail_closed_violations)

    def test_adversarial_8_license_conflict_detected_as_claim_mismatch(self, auditor):
        # arXiv claims CC-BY-4.0, but observed is mixed repository licensing
        report_arxiv = auditor.audit_source("arxiv_open_access_papers")
        assert report_arxiv.field_audits["declared_license"].status == ClaimStatus.CLAIM_MISMATCH.value

        # The Stack v2 claims Apache-2.0, but observed is heterogeneous per-file
        report_stack = auditor.audit_source("the_stack_v2_permissive")
        assert report_stack.field_audits["declared_license"].status == ClaimStatus.CLAIM_MISMATCH.value

        # Dolma claims Apache-2.0, but observed is ODC-By with mixed subcollections
        report_dolma = auditor.audit_source("dolma_v1_7_permissive")
        assert report_dolma.field_audits["declared_license"].status == ClaimStatus.CLAIM_MISMATCH.value

        # RedPajama claims Apache-2.0, but observed is Common Crawl web data
        report_rp2 = auditor.audit_source("redpajama_v2_permissive")
        assert report_rp2.field_audits["declared_license"].status == ClaimStatus.CLAIM_MISMATCH.value

    def test_audit_record_saving(self, auditor):
        all_ok, reports = auditor.run_all_audits()
        record_path = auditor.save_audit_record(reports)
        assert record_path.exists()

        data = json.loads(record_path.read_text(encoding="utf-8"))
        assert data["total_sources_audited"] == 9
        assert "fineweb_edu_permissive" in data["sources"]
        assert data["sources"]["fineweb_edu_permissive"]["effective_approval_status"] == "UNDER_REVIEW"
