"""
Unit tests for Sparse Mixture of Experts (MoE), SwiGLU experts, and Top-K routing.
"""

import torch
import pytest

from nirmal.configuration_nirmal import NirmalConfig
from nirmal.moe import NirmalSwiGLU, NirmalTopKRouter, NirmalSparseMoE


def test_swiglu_shape_and_forward():
    """Verify SwiGLU expert feed-forward network maintains hidden dimension."""
    hidden_size = 128
    intermediate_size = 256
    swiglu = NirmalSwiGLU(hidden_size, intermediate_size)

    x = torch.randn(2, 4, hidden_size)
    out = swiglu(x)
    assert out.shape == (2, 4, hidden_size)


def test_topk_router_probabilities_and_losses():
    """Verify Top-K router outputs, probability normalization, and auxiliary losses."""
    hidden_size = 128
    num_experts = 8
    top_k = 2
    router = NirmalTopKRouter(
        hidden_size=hidden_size,
        num_experts=num_experts,
        top_k=top_k,
        aux_loss_coef=0.01,
        z_loss_coef=0.001,
    )

    batch_size = 2
    seq_len = 8
    x = torch.randn(batch_size, seq_len, hidden_size)

    weights, indices, router_loss = router(x)

    assert weights.shape == (batch_size, seq_len, top_k)
    assert indices.shape == (batch_size, seq_len, top_k)

    # Weights for each token must sum to 1.0
    weight_sums = weights.sum(dim=-1)
    assert torch.allclose(weight_sums, torch.ones_like(weight_sums), atol=1e-5)

    # Indices must be valid expert IDs in [0, num_experts - 1]
    assert (indices >= 0).all() and (indices < num_experts).all()

    # Router loss must be positive and scalar
    assert router_loss.dim() == 0
    assert router_loss.item() > 0.0


def test_sparse_moe_forward_and_backward():
    """Verify SparseMoE end-to-end dispatch and backpropagation."""
    config = NirmalConfig(
        hidden_size=128,
        num_attention_heads=2,
        num_key_value_heads=2,
        head_dim=64,
        intermediate_size=256,
        num_experts=4,
        num_experts_per_tok=2,
    )
    moe = NirmalSparseMoE(config)

    x = torch.randn(2, 6, config.hidden_size, requires_grad=True)
    out, router_loss = moe(x)

    assert out.shape == x.shape
    total_loss = out.sum() + router_loss
    total_loss.backward()

    assert x.grad is not None
    assert moe.router.weight.grad is not None
