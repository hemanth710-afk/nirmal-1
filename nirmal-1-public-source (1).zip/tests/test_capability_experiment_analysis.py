import pytest
from training.acquisition.capability_experiment_analysis import ExperimentAnalyzer

@pytest.fixture
def analyzer():
    return ExperimentAnalyzer()

def test_compute_statistics_empty(analyzer):
    stats = analyzer.compute_statistics([])
    assert stats["mean"] == 0.0
    assert stats["variance"] == 0.0

def test_compute_statistics_values(analyzer):
    stats = analyzer.compute_statistics([1.0, 2.0, 3.0])
    assert stats["mean"] == 2.0
    assert stats["floor"] == 1.0
    assert stats["ceiling"] == 3.0
    assert stats["variance"] > 0.0

def test_mde_calculation(analyzer):
    mde = analyzer.compute_mde([1.0, 2.0, 3.0])
    assert mde > 0.0
    assert mde != float('inf')

def test_mde_zero_variance(analyzer):
    mde = analyzer.compute_mde([0.0, 0.0, 0.0])
    assert mde == float('inf')

def test_sensitivity_classification_unmeasurable(analyzer):
    sens = analyzer.classify_sensitivity([0.0, 0.0], [0.0, 0.0])
    assert sens == "UNMEASURABLE"

def test_sensitivity_classification_sensitive(analyzer):
    sens = analyzer.classify_sensitivity([1.0, 2.0], [5.0, 6.0], known_difference=True)
    assert sens == "SENSITIVE"
