"""Tests for run-level reproducibility — V10.0."""
import pytest
from training.acquisition.v10_0_intervention_engine import (
    TaskConfig, RunConfig, run_intervention
)
from pathlib import Path
import tempfile


@pytest.fixture
def task():
    return TaskConfig("copy", 3, (10, 30), (10, 30), (60, 80), 4, 99)


@pytest.fixture
def tmpdir():
    with tempfile.TemporaryDirectory() as d:
        yield Path(d)


def test_same_seed_same_result(task, tmpdir):
    rc = RunConfig("repro_test", 42, 16)
    r1 = run_intervention(rc, task, tmpdir)
    r2 = run_intervention(rc, task, tmpdir)
    assert r1.train_acc == r2.train_acc
    assert r1.ood_acc   == r2.ood_acc


def test_different_seeds_may_differ(task, tmpdir):
    r1 = run_intervention(RunConfig("repro_diff", 42, 16), task, tmpdir)
    r2 = run_intervention(RunConfig("repro_diff", 43, 16), task, tmpdir)
    # Logically the seeds may produce same exact acc on this tiny task,
    # but they must at least produce valid results
    assert 0.0 <= r1.ood_acc <= 1.0
    assert 0.0 <= r2.ood_acc <= 1.0


def test_manifest_written(task, tmpdir):
    run_intervention(RunConfig("manifest_test", 42, 8), task, tmpdir)
    manifests = list(tmpdir.glob("manifest_*.json"))
    assert len(manifests) >= 1


def test_manifest_contains_config_hash(task, tmpdir):
    import json
    run_intervention(RunConfig("hash_test", 42, 8), task, tmpdir)
    manifests = list(tmpdir.glob("manifest_*.json"))
    data = json.loads(manifests[0].read_text())
    assert "config_hash" in data
    assert len(data["config_hash"]) == 32  # MD5 hex
