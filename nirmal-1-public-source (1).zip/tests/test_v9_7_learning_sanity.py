import pytest
from scripts.v9_7_learning_sanity import LearningSanityEvaluator, SanityTaskGenerator

def test_sanity_task_generation():
    gen = SanityTaskGenerator()
    data = gen.generate_sequence_copy(batch_size=2, seq_len=10)
    assert data.shape == (2, 10)
    # Check copying behavior
    assert (data[:, :5] == data[:, 5:]).all()

def test_task_existence():
    evaluator = LearningSanityEvaluator()
    assert "TASK_A_SEQUENCE_COPY" in evaluator.tasks

def test_evaluator_init():
    evaluator = LearningSanityEvaluator()
    assert evaluator.config.vocab_size == 100

def test_learning_curve_steps():
    # Only tests if it creates valid metric output
    evaluator = LearningSanityEvaluator()
    state = evaluator.evaluate_model_state(0.05, 0.0, 0.0)
    assert state == "RANDOM"

def test_learning_curve_state_partial():
    evaluator = LearningSanityEvaluator()
    state = evaluator.evaluate_model_state(0.5, 0.5, 0.5)
    assert state == "PARTIALLY_TRAINED"
