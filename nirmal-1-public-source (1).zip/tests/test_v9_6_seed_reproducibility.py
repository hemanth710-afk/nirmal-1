import pytest
from scripts.v9_6_controlled_scaling import ScalingExperiment, ExperimentManifest

def test_seed_reproducibility():
    exp = ScalingExperiment()
    res1 = exp.mock_eval_run("SCALE_0", "BUDGET_1", "BASELINE", 42)
    res2 = exp.mock_eval_run("SCALE_0", "BUDGET_1", "BASELINE", 42)
    assert res1 == res2

def test_manifest_integrity():
    m1 = ExperimentManifest.create("test", "SCALE_0", {"seed": 1}, 10, 2, {"a": 0.0})
    m2 = ExperimentManifest.create("test", "SCALE_0", {"seed": 1}, 10, 2, {"a": 0.0})
    # Hashes should match for config, data, results
    assert m1["model_config_hash"] == m2["model_config_hash"]
    assert m1["result_hash"] == m2["result_hash"]
