"""Tests for vocabulary OOD isolation — V10.0."""
import pytest
import torch
from training.acquisition.v10_0_intervention_engine import TaskConfig, TaskGenerator


@pytest.fixture
def gen():
    return TaskGenerator()


def test_fully_disjoint_vocab(gen):
    cfg = TaskConfig("copy", 4, (10, 35), (10, 35), (60, 85), 8, 1)
    splits = gen.generate(cfg)
    cert = gen.leakage_certificate(splits)
    assert cert["vocab_disjoint"], "Train and OOD must share no tokens"


def test_no_exact_row_overlap(gen):
    cfg = TaskConfig("copy", 4, (10, 35), (10, 35), (60, 85), 8, 1)
    splits = gen.generate(cfg)
    cert = gen.leakage_certificate(splits)
    assert cert["no_row_overlap"]


def test_no_subseq_leak(gen):
    cfg = TaskConfig("copy", 4, (10, 35), (10, 35), (60, 85), 8, 1)
    splits = gen.generate(cfg)
    cert = gen.leakage_certificate(splits)
    assert cert["no_subseq_leak"]


def test_cert_valid(gen):
    cfg = TaskConfig("copy", 4, (10, 35), (10, 35), (60, 85), 8, 1)
    splits = gen.generate(cfg)
    assert gen.leakage_certificate(splits)["valid"]


def test_overlap_triggers_invalid(gen):
    cfg_overlap = TaskConfig("copy", 4, (10, 35), (10, 35), (10, 35), 8, 1)
    splits = gen.generate(cfg_overlap)
    cert = gen.leakage_certificate(splits)
    # same OOD range as train — must detect vocab overlap
    assert not cert["vocab_disjoint"]
    assert not cert["valid"]
