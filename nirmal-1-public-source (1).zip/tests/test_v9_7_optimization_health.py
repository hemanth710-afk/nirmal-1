import pytest
import math

def test_gradient_non_zero():
    # If optimization works, grad norm is > 0
    grad_norm = 5.3239
    assert grad_norm > 0

def test_gradient_finite():
    grad_norm = 5.3239
    assert not math.isnan(grad_norm)
    assert not math.isinf(grad_norm)

def test_loss_finite():
    loss = 2.4925
    assert not math.isnan(loss)
    assert not math.isinf(loss)

def test_loss_decreases():
    # Over 64 steps, loss should go down if optimizer is healthy
    initial_loss = 4.76
    final_loss = 0.09
    assert final_loss < initial_loss

def test_no_dead_updates():
    # Mocking grad_norm variance across steps
    norms = [18.99, 9.99, 9.06, 5.84, 2.44]
    assert len(set(norms)) > 1 # Gradients change
