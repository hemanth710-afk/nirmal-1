"""
NIRMAL-1 V8.9: TEST SUITE FOR WIKIMEDIA RESUME & REPLAY PROTECTION

Verifies:
1. Interrupted run simulation and checkpoint save:
   Simulates crash/interruption after N documents and verifies that
   data/pilot/staging/ckpt_{run_id}.json is saved with consistent state.
2. Resume without duplicate accepted records:
   Resuming from checkpoint processes remaining documents without duplicating
   already accepted records, keeping accounting exactly balanced.
3. Run -> interrupt -> resume produces identical final artifact:
   Verifies that an uninterrupted run and an interrupted+resumed run on the same
   inputs produce the exact same binary shard byte-for-byte and identical checksum.
4. Replay protection:
   Deterministic identity f'{source_id}:{page_id}:{revision_id}'.
   - Same document + same revision -> rejected as duplicate replay.
   - Same document + new revision -> accepted as distinct version.
"""

import hashlib
import json
from pathlib import Path
from typing import Any, Dict, List, Optional
import pytest

from training.acquisition.wikimedia_real_adapter import WikimediaRealAdapter
from training.acquisition.pilot_provenance_audit import PilotProvenanceClass


@pytest.fixture
def temp_pilot_dirs(tmp_path):
    staging_dir = tmp_path / "pilot" / "staging"
    shards_dir = tmp_path / "pilot" / "shards"
    manifests_dir = tmp_path / "pilot" / "manifests"
    provenance_dir = tmp_path / "pilot" / "provenance"
    staging_dir.mkdir(parents=True)
    shards_dir.mkdir(parents=True)
    manifests_dir.mkdir(parents=True)
    provenance_dir.mkdir(parents=True)
    return staging_dir, shards_dir, manifests_dir, provenance_dir


def create_sample_docs() -> List[Dict[str, Any]]:
    docs = [
        {
            "id": "wiki_1001",
            "page_id": "1001",
            "title": "Quantum Computing",
            "revision_id": "2001",
            "revision_verified": True,
            "timestamp": "2026-09-01T12:00:00Z",
            "url": "https://en.wikipedia.org/wiki/Quantum_Computing",
            "license": "CC-BY-SA-4.0",
            "text": (
                "Quantum computing is a multidisciplinary field comprising computer science, physics, "
                "and mathematics that utilizes quantum mechanics to solve complex problems faster than classical computers."
            ),
            "raw_payload_hash": hashlib.sha256(b"quantum_sample_payload").hexdigest(),
            "raw_bytes": 220,
            "provenance_class": PilotProvenanceClass.REMOTE_SOURCE_DATA.value,
            "is_network_retrieved": True,
            "is_local_fixture": False,
            "is_synthetic": False,
            "is_copied_from_repo": False,
            "metadata": {"page_id": 1001},
        },
        {
            "id": "wiki_1002",
            "page_id": "1002",
            "title": "Differential Geometry",
            "revision_id": "2002",
            "revision_verified": True,
            "timestamp": "2026-09-01T12:05:00Z",
            "url": "https://en.wikipedia.org/wiki/Differential_Geometry",
            "license": "CC-BY-SA-4.0",
            "text": (
                "Differential geometry is a mathematical discipline that studies the geometry of smooth manifolds "
                "using techniques from differential calculus, integral calculus, and linear algebra."
            ),
            "raw_payload_hash": hashlib.sha256(b"diffgeo_sample_payload").hexdigest(),
            "raw_bytes": 210,
            "provenance_class": PilotProvenanceClass.REMOTE_SOURCE_DATA.value,
            "is_network_retrieved": True,
            "is_local_fixture": False,
            "is_synthetic": False,
            "is_copied_from_repo": False,
            "metadata": {"page_id": 1002},
        },
        {
            "id": "wiki_1003",
            "page_id": "1003",
            "title": "Photosynthesis",
            "revision_id": "2003",
            "revision_verified": True,
            "timestamp": "2026-09-01T12:10:00Z",
            "url": "https://en.wikipedia.org/wiki/Photosynthesis",
            "license": "CC-BY-SA-4.0",
            "text": (
                "Photosynthesis is a biological process used by plants, algae, and certain bacteria to convert light energy "
                "into chemical energy stored in carbohydrate molecules such as glucose."
            ),
            "raw_payload_hash": hashlib.sha256(b"photosynth_sample_payload").hexdigest(),
            "raw_bytes": 215,
            "provenance_class": PilotProvenanceClass.REMOTE_SOURCE_DATA.value,
            "is_network_retrieved": True,
            "is_local_fixture": False,
            "is_synthetic": False,
            "is_copied_from_repo": False,
            "metadata": {"page_id": 1003},
        },
    ]
    return docs


class TestWikimediaResume:
    """Test suite for checkpoint resume and replay protection."""

    def test_interrupted_run_simulation_and_checkpoint_save(self, temp_pilot_dirs):
        staging_dir, shards_dir, manifests_dir, prov_dir = temp_pilot_dirs
        adapter = WikimediaRealAdapter(
            run_id="test_run_interrupted_save",
            staging_dir=staging_dir,
            shards_dir=shards_dir,
            manifests_dir=manifests_dir,
            provenance_dir=prov_dir,
        )

        docs = create_sample_docs()

        # Simulate interruption after 1st document
        with pytest.raises(RuntimeError) as exc:
            adapter.run_pipeline(records=docs, simulate_interrupt_after=1)
        assert "Simulated interruption after document 1" in str(exc.value)

        # Verify checkpoint was written to staging
        ckpt_path = staging_dir / f"ckpt_{adapter.run_id}.json"
        assert ckpt_path.exists()

        # Checkpoint contents inspection
        with open(ckpt_path, "r", encoding="utf-8") as f:
            ckpt_data = json.load(f)

        assert ckpt_data["run_id"] == adapter.run_id
        assert len(ckpt_data["accepted_records"]) == 1
        assert ckpt_data["accepted_records"][0]["doc_id"] == "wiki_1001"
        assert len(ckpt_data["remaining_records"]) == 2
        assert len(ckpt_data["all_token_ids"]) > 0
        assert ckpt_data["accounting"]["document_accounting"]["documents_accepted"] == 1
        assert "wikipedia_open_corpus:1001:2001" in ckpt_data["processed_identities"]

    def test_resume_without_duplicate_accepted_records(self, temp_pilot_dirs):
        staging_dir, shards_dir, manifests_dir, prov_dir = temp_pilot_dirs
        run_id = "test_run_resume_no_dups"
        adapter = WikimediaRealAdapter(
            run_id=run_id,
            staging_dir=staging_dir,
            shards_dir=shards_dir,
            manifests_dir=manifests_dir,
            provenance_dir=prov_dir,
        )

        docs = create_sample_docs()

        # 1. Run with interruption after document 1
        with pytest.raises(RuntimeError):
            adapter.run_pipeline(records=docs, simulate_interrupt_after=1)

        # 2. Resume the run
        resume_adapter = WikimediaRealAdapter(
            run_id=run_id,
            staging_dir=staging_dir,
            shards_dir=shards_dir,
            manifests_dir=manifests_dir,
            provenance_dir=prov_dir,
        )
        result = resume_adapter.resume(run_id=run_id)

        assert result.status == "SUCCESS"
        assert result.documents_accepted == 3
        assert result.documents_discovered == 3
        assert result.documents_rejected == 0

        # Verify no duplicate doc_ids in provenance entries
        prov_doc_ids = [e.doc_id for e in resume_adapter.doc_provenance]
        assert len(prov_doc_ids) == 3
        assert len(set(prov_doc_ids)) == 3
        assert sorted(prov_doc_ids) == ["wiki_1001", "wiki_1002", "wiki_1003"]

        # Verify token counts reconcile exactly
        assert result.tokens_after_filter == len(resume_adapter.all_token_ids)
        assert resume_adapter.accounting.final_shard_tokens == result.tokens_after_filter

    def test_run_interrupt_resume_produces_identical_final_artifact(self, temp_pilot_dirs):
        staging_dir, shards_dir, manifests_dir, prov_dir = temp_pilot_dirs
        docs = create_sample_docs()

        # Run 1: Complete uninterrupted execution
        adapter_uninterrupted = WikimediaRealAdapter(
            run_id="run_complete_baseline",
            staging_dir=staging_dir,
            shards_dir=shards_dir,
            manifests_dir=manifests_dir,
            provenance_dir=prov_dir,
        )
        result1 = adapter_uninterrupted.run_pipeline(records=docs)
        shard1_path = shards_dir / f"{adapter_uninterrupted.run_id}_tokens.bin"
        shard1_bytes = shard1_path.read_bytes()
        tokens1 = list(adapter_uninterrupted.all_token_ids)

        # Run 2: Interrupted after document 1, then resumed
        adapter_interrupted = WikimediaRealAdapter(
            run_id="run_interrupted_resume",
            staging_dir=staging_dir,
            shards_dir=shards_dir,
            manifests_dir=manifests_dir,
            provenance_dir=prov_dir,
        )
        with pytest.raises(RuntimeError):
            adapter_interrupted.run_pipeline(records=docs, simulate_interrupt_after=1)

        resumed_adapter = WikimediaRealAdapter(
            run_id="run_interrupted_resume",
            staging_dir=staging_dir,
            shards_dir=shards_dir,
            manifests_dir=manifests_dir,
            provenance_dir=prov_dir,
        )
        result2 = resumed_adapter.resume(run_id="run_interrupted_resume")
        shard2_path = shards_dir / f"{resumed_adapter.run_id}_tokens.bin"
        shard2_bytes = shard2_path.read_bytes()
        tokens2 = list(resumed_adapter.all_token_ids)

        # Verify that interrupted-and-resumed pipeline produces the IDENTICAL final artifact
        assert tokens1 == tokens2
        assert shard1_bytes == shard2_bytes
        assert result1.checksum == result2.checksum
        assert result1.documents_accepted == result2.documents_accepted == 3
        assert result1.tokens_after_filter == result2.tokens_after_filter

    def test_replay_protection_same_revision_rejected(self, temp_pilot_dirs):
        staging_dir, shards_dir, manifests_dir, prov_dir = temp_pilot_dirs
        adapter = WikimediaRealAdapter(
            run_id="test_replay_protection",
            staging_dir=staging_dir,
            shards_dir=shards_dir,
            manifests_dir=manifests_dir,
            provenance_dir=prov_dir,
        )

        doc = create_sample_docs()[0]  # page_id 1001, rev 2001
        replay_duplicate = dict(doc)

        # Batch containing doc and an exact replay of the same revision
        batch = [doc, replay_duplicate]

        result = adapter.run_pipeline(records=batch)
        assert result.status == "SUCCESS"
        assert result.documents_discovered == 2
        assert result.documents_accepted == 1
        assert result.documents_rejected == 1
        assert result.dedup_removed == 1

        # Replay rejection audit check
        rejections = adapter.accounting.rejection_audit_trail
        assert len(rejections) == 1
        assert "replay_duplicate_same_revision" in rejections[0].reason
        assert "wikipedia_open_corpus:1001:2001" in rejections[0].reason

    def test_replay_protection_new_revision_accepted(self, temp_pilot_dirs):
        staging_dir, shards_dir, manifests_dir, prov_dir = temp_pilot_dirs
        adapter = WikimediaRealAdapter(
            run_id="test_new_revision_accepted",
            staging_dir=staging_dir,
            shards_dir=shards_dir,
            manifests_dir=manifests_dir,
            provenance_dir=prov_dir,
        )

        # Version A: revision 2001
        doc_v1 = create_sample_docs()[0]

        # Version B: same page 1001, NEW revision 2002, updated content
        doc_v2 = dict(doc_v1)
        doc_v2["revision_id"] = "2002"
        doc_v2["text"] = (
            "Quantum computing algorithms utilize fault-tolerant logical qubits and quantum error correction "
            "codes to achieve reliable, large-scale computational speedups over classical supercomputers."
        )
        doc_v2["raw_payload_hash"] = hashlib.sha256(b"quantum_updated_revision").hexdigest()

        batch = [doc_v1, doc_v2]

        result = adapter.run_pipeline(records=batch)
        assert result.status == "SUCCESS"
        assert result.documents_discovered == 2
        assert result.documents_accepted == 2
        assert result.documents_rejected == 0

        # Verify both distinct revisions were recorded
        identities = list(adapter.processed_identities.keys())
        assert "wikipedia_open_corpus:1001:2001" in identities
        assert "wikipedia_open_corpus:1001:2002" in identities
