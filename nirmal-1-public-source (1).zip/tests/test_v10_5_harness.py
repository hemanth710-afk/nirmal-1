"""Tests for V10.5 Few-Shot Rule Induction Harness."""

import json
from pathlib import Path
import pytest
import torch

from training.evaluation.v10_5_harness import (
    FewShotRuleFamily,
    FewShotTaskGenerator,
    evaluate_few_shot_acc,
    TRAIN_RULES,
    HELD_OUT_RULES,
    TRAIN_VOCAB,
    DISJOINT_OOD_VOCAB,
    SEP_TOKEN,
)
from training.evaluation.v10_2_harness import CapacityBuilder, aggregate_results


def test_rule_correctness():
    base = torch.tensor([[10]])
    assert (FewShotRuleFamily.apply(base, "copy") == torch.tensor([[10, 10, 10]])).all()
    assert (FewShotRuleFamily.apply(base, "increment") == torch.tensor([[10, 11, 12]])).all()
    assert (FewShotRuleFamily.apply(base, "double_step") == torch.tensor([[10, 12, 14]])).all()
    assert (FewShotRuleFamily.apply(base, "reverse") == torch.tensor([[12, 11, 10]])).all()
    assert (FewShotRuleFamily.apply(base, "fixed_shift") == torch.tensor([[10, 13, 16]])).all()
    assert (FewShotRuleFamily.apply(base, "simple_composition") == torch.tensor([[10, 11, 13]])).all()


def test_deterministic_demonstration_generation():
    gen = FewShotTaskGenerator(vocab_size=250)
    b1 = gen.build_batch("increment", TRAIN_VOCAB, num_demos=4, batch_size=8, seed=42)
    b2 = gen.build_batch("increment", TRAIN_VOCAB, num_demos=4, batch_size=8, seed=42)
    assert torch.equal(b1["input_ids"], b2["input_ids"])
    assert torch.equal(b1["target"], b2["target"])


def test_held_out_rule_isolation():
    # Verify train rules and held out rules are strictly disjoint sets
    train_set = set(TRAIN_RULES)
    held_out_set = set(HELD_OUT_RULES)
    assert len(train_set & held_out_set) == 0
    assert "double_step" in held_out_set
    assert "reverse" in held_out_set
    assert "increment" in train_set


def test_vocabulary_disjointness():
    gen = FewShotTaskGenerator(vocab_size=250)
    train_b = gen.build_batch("increment", TRAIN_VOCAB, num_demos=2, batch_size=16, seed=42)
    ood_b = gen.build_batch("increment", DISJOINT_OOD_VOCAB, num_demos=2, batch_size=16, seed=42)

    cert = gen.leakage_certificate(train_b["input_ids"], ood_b["input_ids"])
    assert cert["vocab_disjoint"] is True
    assert cert["no_row_overlap"] is True
    assert cert["no_subseq_leak"] is True
    assert cert["valid"] is True


def test_demonstration_permutation():
    gen = FewShotTaskGenerator(vocab_size=250)
    b_orig = gen.build_batch("increment", TRAIN_VOCAB, num_demos=4, batch_size=4, seed=42, order="original")
    b_rev = gen.build_batch("increment", TRAIN_VOCAB, num_demos=4, batch_size=4, seed=42, order="reversed")
    b_perm = gen.build_batch("increment", TRAIN_VOCAB, num_demos=4, batch_size=4, seed=42, order="permuted")

    # Shapes must be identical
    assert b_orig["input_ids"].shape == b_rev["input_ids"].shape
    assert b_orig["input_ids"].shape == b_perm["input_ids"].shape

    # Last 3 tokens (the query) must be identical
    assert torch.equal(b_orig["input_ids"][:, -3:], b_rev["input_ids"][:, -3:])
    assert torch.equal(b_orig["input_ids"][:, -3:], b_perm["input_ids"][:, -3:])

    # But preceding demonstration orders should differ
    assert not torch.equal(b_orig["input_ids"], b_rev["input_ids"])


def test_distractor_correctness():
    gen = FewShotTaskGenerator(vocab_size=250)
    b_clean = gen.build_batch("increment", TRAIN_VOCAB, num_demos=2, batch_size=2, seed=42, distractor=False)
    b_dist = gen.build_batch("increment", TRAIN_VOCAB, num_demos=2, batch_size=2, seed=42, distractor=True)

    # Distractor sequence must be longer by exactly num_demos tokens
    assert b_dist["input_ids"].shape[1] == b_clean["input_ids"].shape[1] + 2
    # Distractor token 2 must be present in distractor batch
    assert (b_dist["input_ids"] == 2).any()
    assert not (b_clean["input_ids"] == 2).any()


def test_metric_correctness():
    # Build a tiny mock model or L0 model and verify evaluate_few_shot_acc returns a valid float in [0, 1]
    model = CapacityBuilder.build("L0", vocab=250)
    gen = FewShotTaskGenerator(vocab_size=250)
    batch = gen.build_batch("increment", TRAIN_VOCAB, num_demos=2, batch_size=4, seed=42)
    device = torch.device("cpu")
    acc = evaluate_few_shot_acc(model, batch, device)
    assert isinstance(acc, float)
    assert 0.0 <= acc <= 1.0


def test_immutable_evaluation_hashes():
    gen = FewShotTaskGenerator(vocab_size=250)
    b1 = gen.build_batch("increment", DISJOINT_OOD_VOCAB, num_demos=4, batch_size=8, seed=99)
    b2 = gen.build_batch("increment", DISJOINT_OOD_VOCAB, num_demos=4, batch_size=8, seed=99)
    h1 = gen.hash_dataset(b1["input_ids"])
    h2 = gen.hash_dataset(b2["input_ids"])
    assert h1 == h2
    assert len(h1) == 64  # SHA-256 hex string


def test_multi_seed_aggregation():
    vals = [0.10, 0.12, 0.14]
    agg = aggregate_results(vals)
    assert agg["mean"] == 0.12
    assert agg["min"] == 0.10
    assert agg["max"] == 0.14
    assert agg["std"] > 0


def test_report_completeness():
    results_files = list(Path("experiments/v10_5").glob("v10_5_results_*.json"))
    if not results_files:
        pytest.skip("V10.5 results not yet generated")
    results_files.sort()
    data = json.loads(results_files[-1].read_text())
    assert "exp_a_demo_counts" in data
    assert "exp_c_held_out" in data
    assert "exp_d_quality" in data
    assert "exp_e_order" in data
