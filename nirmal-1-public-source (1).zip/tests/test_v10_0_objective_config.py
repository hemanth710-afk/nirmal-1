"""Tests for objective configuration correctness — V10.0."""
import pytest
import torch
from training.acquisition.v10_0_intervention_engine import ObjectiveWrapper


def _dummy_logits(B=2, T=6, V=100):
    return torch.randn(B, T, V)


def test_causal_lm_loss_finite():
    logits = _dummy_logits()
    targets = torch.randint(0, 100, (2, 6))
    loss = ObjectiveWrapper.causal_lm_loss(logits, targets)
    assert torch.isfinite(loss)


def test_relation_consistency_loss_finite():
    logits = _dummy_logits()
    targets = torch.randint(0, 100, (2, 6))
    loss = ObjectiveWrapper.relation_consistency_loss(logits, targets)
    assert torch.isfinite(loss)


def test_relation_consistency_ge_causal():
    logits = _dummy_logits()
    targets = torch.randint(0, 100, (2, 6))
    base = ObjectiveWrapper.causal_lm_loss(logits, targets)
    rc   = ObjectiveWrapper.relation_consistency_loss(logits, targets)
    # RC adds a penalty so should be >= base (or very close)
    assert rc >= base - 1e-5


def test_contrastive_iso_loss_finite():
    logits     = _dummy_logits()
    iso_logits = _dummy_logits()
    targets     = torch.randint(0, 100, (2, 6))
    iso_targets = torch.randint(0, 100, (2, 6))
    loss = ObjectiveWrapper.contrastive_iso_loss(logits, targets, iso_logits, iso_targets)
    assert torch.isfinite(loss)


def test_different_objectives_differ():
    torch.manual_seed(1)
    logits  = _dummy_logits()
    targets = torch.randint(0, 100, (2, 6))
    l1 = ObjectiveWrapper.causal_lm_loss(logits, targets).item()
    l2 = ObjectiveWrapper.relation_consistency_loss(logits, targets).item()
    assert abs(l1 - l2) > 1e-8  # they should be different values
