import pytest
import torch
from scripts.run_capability_eval import CapabilityEvaluator

def test_seed_reproducibility():
    evaluator = CapabilityEvaluator()
    data = evaluator.generate_dummy_dataset(200)
    
    # Run twice with same seed
    res1 = evaluator.train_and_eval(data, steps=2, seed=42)
    res2 = evaluator.train_and_eval(data, steps=2, seed=42)
    
    for k in res1:
        assert res1[k] == res2[k]

def test_manifest_reproducibility():
    # If parameters and seed are same, dataset is same
    evaluator1 = CapabilityEvaluator()
    evaluator2 = CapabilityEvaluator()
    import torch
    torch.manual_seed(10)
    d1 = evaluator1.generate_dummy_dataset(100)
    torch.manual_seed(10)
    d2 = evaluator2.generate_dummy_dataset(100)
    assert torch.all(d1 == d2)

def test_seed_differences():
    # Ensure different seeds don't accidentally produce exact same evaluation dict object
    # (Though accuracy might be identically 0.0, the objects are distinct)
    evaluator = CapabilityEvaluator()
    data = evaluator.generate_dummy_dataset(200)
    res1 = evaluator.train_and_eval(data, steps=1, seed=42)
    res2 = evaluator.train_and_eval(data, steps=1, seed=43)
    assert isinstance(res1, dict)
    assert isinstance(res2, dict)
    assert res1 is not res2

def test_eval_suite_reproducibility():
    evaluator = CapabilityEvaluator()
    s1 = evaluator.get_eval_suite()
    s2 = evaluator.get_eval_suite()
    for k in s1:
        assert torch.all(s1[k] == s2[k])
