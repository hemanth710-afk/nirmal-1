"""Tests for V10.9 Stage 1A and Stage 1B Episode Generators and Controls."""

import pytest
import torch

from training.evaluation.v10_9_foundation_harness import (
    ANS_TOKEN,
    EP_TOKEN,
    MAP_TOKEN,
    MIN_DATA_TOKEN,
    PLACEHOLDER_TOKEN,
    QRY_TOKEN,
    SUP_TOKEN,
    Stage1AGenerator,
    Stage1BGenerator,
)


def test_stage1a_episode_structure():
    gen = Stage1AGenerator(vocab_start=10, domain_size=8)
    g = torch.Generator().manual_seed(42)

    for _ in range(20):
        ep = gen.generate_episode(g)
        tokens = ep.input_ids.tolist()

        # Format: [EP, SUP, s1, MAP, s1, SUP, s2, MAP, s2, SUP, s3, MAP, s3, QRY, qx, MAP, ANS]
        assert len(tokens) == 17
        assert tokens[0] == EP_TOKEN
        assert tokens[1] == SUP_TOKEN
        assert tokens[13] == QRY_TOKEN
        assert tokens[15] == MAP_TOKEN
        assert tokens[16] == ANS_TOKEN

        # Answer token isolation: sequence ends at ANS_TOKEN
        assert ep.target not in tokens[16:]
        assert ep.target == ep.query_key

        # Query symbol not in support symbols
        assert ep.query_key not in ep.keys


def test_stage1b_quartet_equality_and_controls():
    gen = Stage1BGenerator(vocab_start=10, vocab_size=64)
    g = torch.Generator().manual_seed(999)

    for _ in range(30):
        quartet = gen.generate_quartet(g)
        ep_c = quartet["correct"]
        ep_r = quartet["random"]
        ep_w = quartet["wrong"]
        ep_a = quartet["absent"]

        # All 4 controls must have equal length
        assert len(ep_c.input_ids) == 21
        assert len(ep_r.input_ids) == 21
        assert len(ep_w.input_ids) == 21
        assert len(ep_a.input_ids) == 21

        # All 4 must have identical target and query key
        assert ep_c.target == ep_r.target == ep_w.target == ep_a.target
        assert ep_c.query_key == ep_r.query_key == ep_w.query_key == ep_a.query_key

        # All 4 have identical delimiter positions: QRY at index 17, ANS at index 20
        for ep in [ep_c, ep_r, ep_w, ep_a]:
            toks = ep.input_ids.tolist()
            assert toks[0] == EP_TOKEN
            assert toks[17] == QRY_TOKEN
            assert toks[19] == MAP_TOKEN
            assert toks[20] == ANS_TOKEN

        # Absent support tokens must be PLACEHOLDER_TOKEN
        a_toks = ep_a.input_ids.tolist()
        for sup_slot in [2, 4, 6, 8, 10, 12, 14, 16]:
            assert a_toks[sup_slot] == PLACEHOLDER_TOKEN

        # Accidental match rejection in random support:
        # In ep_r, the query key must NOT map to ep_c.target!
        r_toks = ep_r.input_ids.tolist()
        qx = ep_r.query_key
        # Check every support pair (index 2-4, 6-8, 10-12, 14-16)
        for k_idx, v_idx in [(2, 4), (6, 8), (10, 12), (14, 16)]:
            if r_toks[k_idx] == qx:
                assert r_toks[v_idx] != ep_r.target, "Accidental match was not rejected in random control!"


def test_stage1b_target_distribution_balance():
    gen = Stage1BGenerator(vocab_start=10, vocab_size=64)
    g = torch.Generator().manual_seed(123)
    targets = [gen.generate_quartet(g)["correct"].target for _ in range(100)]
    unique_targets = set(targets)
    assert len(unique_targets) >= 15, "Targets are not reasonably distributed across vocabulary!"


def test_stage1b_wrong_support_validity():
    """Verify wrong support is internally valid but deliberately implies a wrong target."""
    gen = Stage1BGenerator(vocab_start=10, vocab_size=64)
    g = torch.Generator().manual_seed(456)

    for _ in range(50):
        quartet = gen.generate_quartet(g)
        ep_w = quartet["wrong"]
        toks = ep_w.input_ids.tolist()
        qx = ep_w.query_key
        target = ep_w.target

        # Find where qx is in wrong support
        qx_found = False
        for k_idx, v_idx in [(2, 4), (6, 8), (10, 12), (14, 16)]:
            if toks[k_idx] == qx:
                qx_found = True
                assert toks[v_idx] != target, "Wrong support accidentally matched true target!"
        assert qx_found, "Query key not found in wrong support pairs!"


def test_stage1b_absent_support_neutrality():
    """Verify absent support has identical placeholder tokens and no target correlation."""
    gen = Stage1BGenerator(vocab_start=10, vocab_size=64)
    g = torch.Generator().manual_seed(789)

    for _ in range(30):
        ep_a = gen.generate_quartet(g)["absent"]
        toks = ep_a.input_ids.tolist()
        for slot in [2, 4, 6, 8, 10, 12, 14, 16]:
            assert toks[slot] == PLACEHOLDER_TOKEN
            assert toks[slot] != ep_a.target
