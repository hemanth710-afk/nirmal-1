import pytest
from training.acquisition.capability_classifier import CapabilityClassifier
from pathlib import Path

@pytest.fixture
def classifier():
    return CapabilityClassifier(Path("data/capability_taxonomy.json"))

def test_unknown_explicit_state(classifier):
    labels, conf = classifier.classify_document("Random unstructured noise with no keywords", {})
    assert "UNKNOWN" in labels
    assert conf == "UNKNOWN"

def test_unknown_not_agi(classifier):
    labels, conf = classifier.classify_document("Something else", {})
    assert "mathematical reasoning" not in labels
    assert "UNKNOWN" in labels

def test_unknown_not_disappear(classifier):
    # Even if it has a low-confidence hint, if it doesn't cross threshold it might remain unknown,
    # or the low-confidence label is attached but UNKNOWN is handled appropriately.
    # In our deterministic classifier, it just outputs labels and confidence.
    labels, conf = classifier.classify_document("Unknown text", {})
    assert len(labels) == 1
    assert labels == ["UNKNOWN"]

def test_unknown_percentages_reported():
    # Tested in report tests, but here we just ensure the taxonomy defines it
    import json
    with open("data/capability_taxonomy.json") as f:
        tax = json.load(f)
    assert tax["categories"]["UNKNOWN"]["type"] == "UNKNOWN"

def test_low_confidence_visible(classifier):
    # A single keyword like "proof" or "theorem" alone doesn't trigger HIGH
    labels, conf = classifier.classify_document("theorem", {})
    assert conf != "HIGH"
