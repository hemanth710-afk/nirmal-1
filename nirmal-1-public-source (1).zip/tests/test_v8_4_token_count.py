"""
Unit tests for physical token counting and categorization logic in Nirmal-1 V8.4.
"""

from pathlib import Path
import pytest

from scripts.count_verified_production_tokens import find_and_count_shards, TARGET_PRODUCTION_TOKENS
from training.v8_4_manifest import TokenAccountingCategories


def test_token_accounting_category_separation():
    cats = TokenAccountingCategories(
        local_verified_tokens=233_997,
        remote_verified_tokens=0,
        planned_tokens=200_000_000_000,
        estimated_tokens=0,
    )
    d = cats.to_dict()
    assert d["LOCAL_VERIFIED"] == 233_997
    assert d["REMOTE_VERIFIED"] == 0
    assert d["PLANNED"] == 200_000_000_000
    assert d["ESTIMATED"] == 0
    assert "Never combined" in d["category_policy"]


def test_physical_token_count_on_disk():
    local_tokens, total_docs, shards = find_and_count_shards()
    assert local_tokens >= 233_997
    assert len(shards) >= 4

    deficit = TARGET_PRODUCTION_TOKENS - local_tokens
    assert deficit > 0
    assert deficit == TARGET_PRODUCTION_TOKENS - local_tokens
