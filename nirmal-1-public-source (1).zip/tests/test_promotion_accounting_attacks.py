import pytest
import json
from pathlib import Path
from training.acquisition.promotion_gate import RealSourcePromotionGate, PromotionSecurityError
from training.acquisition.promotion_accounting import PromotionAccountingTracker, PromotionAccountingError

@pytest.fixture
def setup_gate(tmp_path):
    gate = RealSourcePromotionGate(promotion_dir=tmp_path/"promotion", pilot_dir=tmp_path/"pilot", evidence_dir=tmp_path/"evidence")
    
    pilot_dir = tmp_path / "pilot"
    manifest_dir = pilot_dir / "manifests"
    manifest_dir.mkdir(parents=True, exist_ok=True)
    shard_dir = pilot_dir / "shards"
    shard_dir.mkdir(parents=True, exist_ok=True)
    prov_dir = pilot_dir / "provenance"
    prov_dir.mkdir(parents=True, exist_ok=True)
    
    with open(shard_dir / "test.bin", "wb") as f:
        f.write(b"00")
        
    manifest = {
        "source_id": "test_source",
        "state": "PILOT_ELIGIBLE",
        "cryptographic_hashes": {
            "final_shard_sha256": "81143896dfa1c3e1db6f52e259b15e2193556c4d7e98d5c9071c713b194fb847"
        },
        "shard_path": str(shard_dir / "test.bin")
    }
    with open(manifest_dir / "test_source_pilot_manifest.json", "w") as f:
        json.dump(manifest, f)
        
    return gate, tmp_path, prov_dir

def test_negative_tokens(setup_gate):
    gate, tmp_path, prov_dir = setup_gate
    
    # Valid 64-char hashes
    doc_hash = "a" * 64
    manifest_hash = "b" * 64
    promo_hash = "c" * 64
    
    tracker = PromotionAccountingTracker(source_id="test_source", promotion_id="test_promo")
    with pytest.raises(PromotionAccountingError): # Or whatever exception is thrown for negative tokens
        tracker.record_promotion(
            doc_id="doc1",
            page_id="page1",
            revision_id="1",
            doc_hash=doc_hash,
            source_manifest_hash=manifest_hash,
            promotion_manifest_hash=promo_hash,
            tokens=-50
        )
