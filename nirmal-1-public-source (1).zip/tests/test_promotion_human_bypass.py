import pytest
import json
from pathlib import Path
from training.acquisition.promotion_gate import RealSourcePromotionGate, PromotionSecurityError

@pytest.fixture
def setup_pilot(tmp_path):
    gate = RealSourcePromotionGate(promotion_dir=tmp_path/"promotion", pilot_dir=tmp_path/"pilot", evidence_dir=tmp_path/"evidence")
    
    pilot_dir = tmp_path / "pilot"
    manifest_dir = pilot_dir / "manifests"
    manifest_dir.mkdir(parents=True, exist_ok=True)
    shard_dir = pilot_dir / "shards"
    shard_dir.mkdir(parents=True, exist_ok=True)
    prov_dir = pilot_dir / "provenance"
    prov_dir.mkdir(parents=True, exist_ok=True)
    
    evidence_dir = tmp_path / "evidence"
    evidence_dir.mkdir(parents=True, exist_ok=True)
    
    # Needs to be in eligibility matrix to pass Check 1
    matrix = {
        "sources": {
            "test_source": {
                "version": "2026.09"
            }
        }
    }
    with open(evidence_dir / "source_eligibility_matrix.json", "w") as f:
        json.dump(matrix, f)
        
    evidence = {
        "canonical_url": "http://example.com"
    }
    with open(evidence_dir / "test_source.json", "w") as f:
        json.dump(evidence, f)
    
    manifest = {
        "source_id": "test_source",
        "state": "PILOT_ELIGIBLE",
        "cryptographic_hashes": {
            "final_shard_sha256": "81143896dfa1c3e1db6f52e259b15e2193556c4d7e98d5c9071c713b194fb847"
        },
        "shard_path": str(shard_dir / "test.bin")
    }
    with open(manifest_dir / "test_source_pilot_manifest.json", "w") as f:
        json.dump(manifest, f)
        
    with open(shard_dir / "test.bin", "wb") as f:
        f.write(b"00")
        
    with open(prov_dir / "prov_test_source.jsonl", "w") as f:
        json.dump({"doc_id": "doc1", "source_revision": "1", "license": "CC-BY-SA 4.0", "origin_type": "REMOTE_SOURCE_DATA", "token_count": 2}, f)
        f.write("\n")
        
    return gate, tmp_path

def test_human_review_missing(setup_pilot):
    gate, tmp_path = setup_pilot
    result = gate.promote_source("test_source")
    # Even if it passes step 1, it might fail some other step, but it should fail AT LEAST at human review or some other checklist item.
    # The requirement is that it fails or goes to PROMOTION_PENDING, but we assert it doesn't bypass human review.
    assert result.state == "PROMOTION_PENDING" or result.verdict == "NEEDS_HUMAN_REVIEW" or result.verdict == "REJECTED"

def test_human_review_forged_license(setup_pilot):
    gate, tmp_path = setup_pilot
    
    evidence_dir = tmp_path / "evidence"
    evidence = {
        "canonical_url": "http://example.com",
        "declared_license": "CC-BY-NC 4.0" 
    }
    with open(evidence_dir / "test_source.json", "w") as f:
        json.dump(evidence, f)
        
    result = gate.promote_source("test_source")
    assert result.verdict != "APPROVED"
