"""
NIRMAL-1 V8.8: TEST SUITE FOR ADAPTER CLASSIFICATION & TOKEN ISOLATION (SCENARIOS 12, 13, 15)

Verifies:
12. Attempted write to production directory (data/shards/) fails closed.
13. Token accounting conservation reconciles exactly (discovered = accepted + rejected).
15. Authoritative production token counter (233,997) is strictly unchanged after pilot execution.
16. Adapters are accurately classified into capability categories.
"""

from pathlib import Path
import pytest

from training.acquisition.pilot_adapter import (
    WikipediaPilotAdapter,
    PilotSecurityError,
)
from training.acquisition.pilot_provenance_audit import (
    PilotProvenanceAuditor,
    AdapterCapability,
)

REPO_ROOT = Path(__file__).resolve().parent.parent


class TestPilotOriginClassification:
    """Tests adapter capabilities, token accounting, and production isolation."""

    def test_adapter_capability_audit_classifications(self):
        """Audits all adapters and verifies capability labels."""
        auditor = PilotProvenanceAuditor()
        adapters = auditor.audit_all_adapters()

        # Check all 4 adapters
        assert "wikimedia_dump_parser" in adapters
        assert "hf_snapshot_sync" in adapters
        assert "s3_bulk_sync" in adapters
        assert "wikipedia_pilot_adapter" in adapters

        # The mock snapshot syncers are SYNTHETIC_ONLY
        assert adapters["wikimedia_dump_parser"]["capability"] == AdapterCapability.SYNTHETIC_ONLY.value
        assert adapters["hf_snapshot_sync"]["capability"] == AdapterCapability.SYNTHETIC_ONLY.value
        assert adapters["s3_bulk_sync"]["capability"] == AdapterCapability.SYNTHETIC_ONLY.value

        # The updated pilot adapter has real network client
        assert adapters["wikipedia_pilot_adapter"]["capability"] == AdapterCapability.REAL_REMOTE_RETRIEVAL.value

    def test_attempted_production_shard_write_blocked(self, tmp_path):
        """Pilot cannot configure output directory within data/shards/."""
        prod_shards = REPO_ROOT / "data" / "shards"
        adapter = WikipediaPilotAdapter(
            use_remote_source=False,
            staging_dir=tmp_path / "staging",
            shards_dir=prod_shards,  # Illegal!
            manifests_dir=tmp_path / "manifests",
        )
        with pytest.raises(PilotSecurityError) as exc:
            adapter.prepare_pilot()
        assert "Attempted to write pilot output to production directory" in str(exc.value)

    def test_token_accounting_exact_conservation(self, tmp_path):
        """Token accounting balances discovered = accepted + rejected and reconciles tokens."""
        adapter = WikipediaPilotAdapter(
            use_remote_source=False,
            staging_dir=tmp_path / "staging",
            shards_dir=tmp_path / "shards",
            manifests_dir=tmp_path / "manifests",
            provenance_dir=tmp_path / "provenance",
        )
        result = adapter.finalize_pilot()

        assert result.documents_discovered == result.documents_accepted + result.documents_rejected
        assert result.tokens_after_filter > 0

        # Verify tracker internals
        acc = adapter.accounting
        is_conserved, msg = acc.verify_conservation()
        assert is_conserved is True
        assert acc.accepted_tokens == acc.final_shard_tokens

    def test_authoritative_production_token_count_unaffected(self, tmp_path):
        """Pilot execution does NOT alter the 233,997 verified production tokens on disk."""
        prod_shards_dir = REPO_ROOT / "data" / "shards"
        files_before = set(prod_shards_dir.glob("*"))

        adapter = WikipediaPilotAdapter(
            use_remote_source=False,
            staging_dir=tmp_path / "staging",
            shards_dir=tmp_path / "shards",
            manifests_dir=tmp_path / "manifests",
            provenance_dir=tmp_path / "provenance",
        )
        adapter.finalize_pilot()

        files_after = set(prod_shards_dir.glob("*"))
        assert files_before == files_after, "Files in data/shards/ were modified by pilot run!"
        assert len(files_after) == 18, f"Expected 18 authoritative production shard files, got {len(files_after)}"
