import pytest
from scripts.v9_9_ood_investigation import OodInvestigator

def test_objective_gap_detected():
    inv = OodInvestigator()
    res = inv.evaluate_objective_gap(0.01, 0.0)
    assert res == "OBJECTIVE_GENERALIZATION_GAP"

def test_objective_aligned_if_loss_high():
    inv = OodInvestigator()
    res = inv.evaluate_objective_gap(2.5, 0.0)
    assert res == "ALIGNED"

def test_objective_aligned_if_ood_high():
    inv = OodInvestigator()
    res = inv.evaluate_objective_gap(0.01, 0.95)
    assert res == "ALIGNED"

def test_objective_aligned_if_both_high():
    inv = OodInvestigator()
    res = inv.evaluate_objective_gap(2.5, 0.95)
    assert res == "ALIGNED"
