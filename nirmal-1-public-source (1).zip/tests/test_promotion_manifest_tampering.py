import pytest
import json
from pathlib import Path
from training.acquisition.promotion_gate import RealSourcePromotionGate, PromotionSecurityError

@pytest.fixture
def setup_gate(tmp_path):
    gate = RealSourcePromotionGate(promotion_dir=tmp_path/"promotion", pilot_dir=tmp_path/"pilot", evidence_dir=tmp_path/"evidence")
    
    pilot_dir = tmp_path / "pilot"
    manifest_dir = pilot_dir / "manifests"
    manifest_dir.mkdir(parents=True, exist_ok=True)
    shard_dir = pilot_dir / "shards"
    shard_dir.mkdir(parents=True, exist_ok=True)
    prov_dir = pilot_dir / "provenance"
    prov_dir.mkdir(parents=True, exist_ok=True)
    
    with open(shard_dir / "test.bin", "wb") as f:
        f.write(b"00")
        
    manifest = {
        "source_id": "test_source",
        "state": "PILOT_ELIGIBLE",
        "cryptographic_hashes": {
            "final_shard_sha256": "81143896dfa1c3e1db6f52e259b15e2193556c4d7e98d5c9071c713b194fb847"
        },
        "shard_path": str(shard_dir / "test.bin")
    }
    with open(manifest_dir / "test_source_pilot_manifest.json", "w") as f:
        json.dump(manifest, f)
        
    return gate, tmp_path, manifest_dir

def test_tampered_shard_hash(setup_gate):
    gate, tmp_path, manifest_dir = setup_gate
    
    manifest = {
        "source_id": "test_source",
        "state": "PILOT_ELIGIBLE",
        "cryptographic_hashes": {
            "final_shard_sha256": "wronghash12345"
        },
        "shard_path": str(tmp_path / "pilot" / "shards" / "test.bin")
    }
    with open(manifest_dir / "test_source_pilot_manifest.json", "w") as f:
        json.dump(manifest, f)
        
    result = gate.promote_source("test_source")
    assert result.verdict == "REJECTED"

def test_missing_crypto_chain(setup_gate):
    gate, tmp_path, manifest_dir = setup_gate
    
    manifest = {
        "source_id": "test_source",
        "state": "PILOT_ELIGIBLE",
        "shard_path": str(tmp_path / "pilot" / "shards" / "test.bin")
    }
    with open(manifest_dir / "test_source_pilot_manifest.json", "w") as f:
        json.dump(manifest, f)
        
    result = gate.promote_source("test_source")
    assert result.verdict == "REJECTED"
