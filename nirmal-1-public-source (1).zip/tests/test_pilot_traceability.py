"""
NIRMAL-1 V8.8: TEST SUITE FOR PILOT TRACEABILITY & REPRODUCIBILITY (SCENARIOS 11-13)

Verifies:
11. End-to-end machine trace exists and chains deterministically from raw to final shard.
12. Recomputation of document and payload hashes matches trace records exactly.
13. Provenance mutation or tampering after ingestion is detected and rejected.
"""

import hashlib
import json
from pathlib import Path
import pytest

from training.acquisition.pilot_adapter import (
    WikipediaPilotAdapter,
)
from training.acquisition.pilot_provenance_audit import (
    PilotProvenanceAuditor,
    PilotProvenanceClass,
    ProvenanceVerificationError,
)


@pytest.fixture
def pilot_adapter(tmp_path):
    staging_dir = tmp_path / "staging"
    shards_dir = tmp_path / "shards"
    manifests_dir = tmp_path / "manifests"
    provenance_dir = tmp_path / "provenance"
    return WikipediaPilotAdapter(
        use_remote_source=False,  # Use deterministic synthetic records for test isolation
        staging_dir=staging_dir,
        shards_dir=shards_dir,
        manifests_dir=manifests_dir,
        provenance_dir=provenance_dir,
    )


class TestPilotTraceability:
    """Tests machine-readable stage-by-stage traceability."""

    def test_complete_end_to_end_trace_generation(self, pilot_adapter):
        """Finalizing pilot emits a valid, complete machine-readable trace."""
        result = pilot_adapter.finalize_pilot()
        assert result.status == "SUCCESS"
        assert result.trace_path != ""

        trace_path = Path(result.trace_path)
        assert trace_path.exists()

        with open(trace_path, "r", encoding="utf-8") as f:
            trace_data = json.load(f)

        assert trace_data["source_id"] == "wikipedia_open_corpus"
        assert trace_data["final_shard_hash"] == result.checksum
        assert len(trace_data["trace_chain"]) == result.documents_accepted

        for step in trace_data["trace_chain"]:
            assert "doc_id" in step
            assert step["raw_source_bytes"] > 0
            assert len(step["raw_payload_hash"]) == 64
            assert len(step["document_hash"]) == 64
            assert step["quality_decision"] == "PASS"
            assert step["security_decision"] == "PASS"
            assert step["dedup_decision"] == "PASS"
            assert step["contamination_decision"] == "PASS"
            assert step["token_count"] > 0
            assert step["shard_hash"] == result.checksum

    def test_deterministic_hash_recomputation(self, pilot_adapter):
        """Document hashes in trace match exact sha256 of normalized text."""
        result = pilot_adapter.finalize_pilot()
        trace_path = Path(result.trace_path)
        with open(trace_path, "r", encoding="utf-8") as f:
            trace_data = json.load(f)

        prov_path = Path(result.provenance_path)
        with open(prov_path, "r", encoding="utf-8") as f:
            prov_data = json.load(f)

        assert len(trace_data["trace_chain"]) == len(prov_data["documents"])
        for step, doc_meta in zip(trace_data["trace_chain"], prov_data["documents"]):
            assert step["document_hash"] == doc_meta["document_hash"]
            assert step["token_count"] == doc_meta["token_count"]

    def test_provenance_tampering_detected(self, tmp_path):
        """Modifying provenance metadata post-creation causes verification failure."""
        auditor = PilotProvenanceAuditor(provenance_dir=tmp_path / "provenance")
        from training.acquisition.pilot_provenance_audit import PilotDocumentAuditEntry

        # Create valid entry
        entry = PilotDocumentAuditEntry(
            document_hash="e" * 64,
            source_id="wikipedia_open_corpus",
            provenance_class=PilotProvenanceClass.LOCAL_FIXTURE,
            canonical_source="wikipedia_open_corpus",
            source_url="https://en.wikipedia.org/wiki/Test",
            source_revision="rev_1",
            retrieval_timestamp="2026-09-08T12:00:00Z",
            raw_byte_count=100,
            normalized_byte_count=80,
            token_count=20,
            adapter_identifier="WikipediaPilotAdapter",
            pipeline_version="V8.8",
            acquisition_record_id="run_1",
            is_local_fixture=True,
        )
        assert auditor.verify_entry(entry) is True

        # Tamper entry to falsely claim REMOTE_SOURCE_DATA while retaining is_local_fixture=True
        entry.provenance_class = PilotProvenanceClass.REMOTE_SOURCE_DATA
        with pytest.raises(ProvenanceVerificationError) as exc:
            auditor.verify_entry(entry)
        assert "REMOTE_SOURCE_DATA claimed without network retrieval flag" in str(exc.value)
