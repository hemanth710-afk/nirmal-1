"""
NIRMAL-1 V8.9: TEST SUITE FOR WIKIMEDIA EXACT ACCOUNTING & STAGE-BY-STAGE CONSERVATION

Verifies:
1. Exact document conservation equation:
   discovered == accepted + rejected_quality + rejected_security + rejected_dedup + rejected_contamination
2. Token reconciliation:
   accepted_tokens == final_shard_tokens (tampering raises AccountingConservationError).
3. Stage-by-stage rejection tracking with exact attribution.
4. Zero sensitive data leakage in rejection audit logs.
"""

import hashlib
from pathlib import Path
from typing import Any, Dict, List
import pytest

from training.acquisition.wikimedia_real_adapter import WikimediaRealAdapter
from training.acquisition.pilot_accounting import (
    PilotAccountingTracker,
    AccountingConservationError,
)
from training.acquisition.pilot_provenance_audit import PilotProvenanceClass


@pytest.fixture
def temp_pilot_dirs(tmp_path):
    staging_dir = tmp_path / "pilot" / "staging"
    shards_dir = tmp_path / "pilot" / "shards"
    manifests_dir = tmp_path / "pilot" / "manifests"
    provenance_dir = tmp_path / "pilot" / "provenance"
    staging_dir.mkdir(parents=True)
    shards_dir.mkdir(parents=True)
    manifests_dir.mkdir(parents=True)
    provenance_dir.mkdir(parents=True)
    return staging_dir, shards_dir, manifests_dir, provenance_dir


def make_remote_record(
    doc_id: str,
    page_id: str,
    revision_id: str,
    title: str,
    text: str,
) -> Dict[str, Any]:
    return {
        "id": doc_id,
        "page_id": page_id,
        "title": title,
        "revision_id": revision_id,
        "revision_verified": True,
        "timestamp": "2026-09-01T12:00:00Z",
        "url": f"https://en.wikipedia.org/wiki/{title.replace(' ', '_')}",
        "license": "CC-BY-SA-4.0",
        "text": text,
        "raw_payload_hash": hashlib.sha256(text.encode("utf-8")).hexdigest(),
        "raw_bytes": len(text.encode("utf-8")),
        "provenance_class": PilotProvenanceClass.REMOTE_SOURCE_DATA.value,
        "is_network_retrieved": True,
        "is_local_fixture": False,
        "is_synthetic": False,
        "is_copied_from_repo": False,
        "metadata": {"page_id": page_id},
    }


class TestWikimediaAccounting:
    """Rigorous accounting and conservation test suite."""

    def test_stage_by_stage_rejection_and_exact_conservation(self, temp_pilot_dirs):
        staging_dir, shards_dir, manifests_dir, prov_dir = temp_pilot_dirs
        adapter = WikimediaRealAdapter(
            run_id="run_accounting_conservation",
            staging_dir=staging_dir,
            shards_dir=shards_dir,
            manifests_dir=manifests_dir,
            provenance_dir=prov_dir,
        )

        valid_text_1 = (
            "Quantum computing is a multidisciplinary field comprising aspects of computer science, "
            "physics, and mathematics that utilizes quantum mechanics to solve complex problems faster."
        )
        valid_text_2 = (
            "Differential geometry is a mathematical discipline that studies the geometry of smooth curves, "
            "surfaces, and manifolds in Euclidean and non-Euclidean space."
        )
        # Quality reject: too short (< 50 chars / < 20 tokens)
        quality_reject_text = "Too short."
        # Security reject: contains private key header
        secret_reject_text = (
            "Configuration file with private credential key: "
            "-----BEGIN RSA PRIVATE KEY-----\nMIIEowIBAAKCAQEA0Y3...\n-----END RSA PRIVATE KEY-----"
        )
        # Dedup reject: exact duplicate of doc 1
        dedup_reject_text = valid_text_1
        # Contamination reject: contains 13-gram benchmark probe from CAUSAL_SIMULATOR_IN_REPO
        contamination_reject_text = (
            "Research documentation on causal inference: calculate average treatment effect under "
            "do intervention on variable A with confounding Z to estimate unbiased effects."
        )

        records = [
            make_remote_record("wiki_101", "101", "1001", "Quantum Computing", valid_text_1),
            make_remote_record("wiki_102", "102", "1002", "Differential Geometry", valid_text_2),
            make_remote_record("wiki_103", "103", "1003", "Short Doc", quality_reject_text),
            make_remote_record("wiki_104", "104", "1004", "Secret Doc", secret_reject_text),
            make_remote_record("wiki_105", "105", "1005", "Duplicate Doc", dedup_reject_text),
            make_remote_record("wiki_106", "106", "1006", "Contaminated Doc", contamination_reject_text),
        ]

        result = adapter.run_pipeline(records=records)

        # 1. Verify exact document conservation
        assert result.status == "SUCCESS"
        assert result.documents_discovered == 6
        assert result.documents_accepted == 2
        assert result.documents_rejected == 4

        # 2. Verify stage-by-stage breakdown
        assert result.quality_removed == 1
        assert result.security_removed == 1
        assert result.dedup_removed == 1
        assert result.contamination_removed == 1

        # Equation: discovered == accepted + quality + security + dedup + contamination
        assert result.documents_discovered == (
            result.documents_accepted
            + result.quality_removed
            + result.security_removed
            + result.dedup_removed
            + result.contamination_removed
        )

        # 3. Verify accounting conservation status
        is_conserved, msg = adapter.accounting.verify_conservation()
        assert is_conserved is True
        assert "Accounting conservation fully verified" in msg

        # 4. Verify token reconciliation
        assert result.tokens_after_filter == adapter.accounting.accepted_tokens
        assert adapter.accounting.final_shard_tokens == adapter.accounting.accepted_tokens
        assert result.tokens_after_filter == len(adapter.all_token_ids)

    def test_token_reconciliation_violation_fails_closed(self, temp_pilot_dirs):
        staging_dir, shards_dir, manifests_dir, prov_dir = temp_pilot_dirs
        adapter = WikimediaRealAdapter(
            run_id="run_token_mismatch",
            staging_dir=staging_dir,
            shards_dir=shards_dir,
            manifests_dir=manifests_dir,
            provenance_dir=prov_dir,
        )

        valid_text = (
            "Photosynthesis is a biological process used by plants and algae to convert light energy "
            "into chemical energy stored in carbohydrates."
        )
        record = make_remote_record("wiki_201", "201", "2001", "Photosynthesis", valid_text)

        # Artificially corrupt token accounting right before finalization
        def tamper_hook():
            adapter.accounting.final_shard_tokens += 10  # Tampering!

        # Process record
        adapter.prepare_pilot()
        norm_records = adapter.normalize([record])
        adapter.validate_provenance([record])

        # Step through pipeline
        tok_ids, _ = adapter.tokenization_pipeline.encode_document(norm_records[0]["text"])
        adapter.accounting.record_discovery(raw_bytes=len(valid_text), estimated_tokens=len(valid_text.split()))
        adapter.accounting.record_acceptance(norm_tokens=len(tok_ids), shard_tokens=len(tok_ids))
        adapter.all_token_ids.extend(tok_ids)

        # Introduce token mismatch
        tamper_hook()

        with pytest.raises(AccountingConservationError) as exc:
            adapter.finalize()
        assert "Token accounting violation" in str(exc.value)

    def test_rejection_audit_trail_zero_sensitive_leakage(self, temp_pilot_dirs):
        staging_dir, shards_dir, manifests_dir, prov_dir = temp_pilot_dirs
        adapter = WikimediaRealAdapter(
            run_id="run_audit_safety",
            staging_dir=staging_dir,
            shards_dir=shards_dir,
            manifests_dir=manifests_dir,
            provenance_dir=prov_dir,
        )

        secret_str = "-----BEGIN RSA PRIVATE KEY-----"
        secret_payload = f"Sensitive cloud configuration: {secret_str}\nMIIEowIBAAKCAQEA0Y3...\n-----END RSA PRIVATE KEY-----"
        rec_secret = make_remote_record("wiki_301", "301", "3001", "Secret Leak", secret_payload)

        result = adapter.run_pipeline(records=[rec_secret])
        assert result.documents_rejected == 1
        assert result.security_removed == 1

        # Check rejection audit trail
        rejections = adapter.accounting.rejection_audit_trail
        assert len(rejections) == 1
        rej_audit = rejections[0].to_dict()

        # Ensure no raw secret text is leaked in rejection audit
        assert secret_str not in str(rej_audit)
        assert secret_payload not in str(rej_audit)
        assert rej_audit["rejection_stage"] == "security"
        assert rej_audit["doc_id"] == "wiki_301"

    def test_document_conservation_violation_fails_closed(self, temp_pilot_dirs):
        staging_dir, shards_dir, manifests_dir, prov_dir = temp_pilot_dirs
        adapter = WikimediaRealAdapter(
            run_id="run_doc_conservation_fail",
            staging_dir=staging_dir,
            shards_dir=shards_dir,
            manifests_dir=manifests_dir,
            provenance_dir=prov_dir,
        )

        # Directly tamper with accounting tracker discovery count
        adapter.accounting.record_discovery(raw_bytes=100, estimated_tokens=25)
        adapter.accounting.record_discovery(raw_bytes=100, estimated_tokens=25)
        # Accepted only 1 without recording rejection for 2nd
        adapter.accounting.record_acceptance(norm_tokens=25, shard_tokens=25)

        is_conserved, msg = adapter.accounting.verify_conservation()
        assert is_conserved is False
        assert "Document conservation violation" in msg

        with pytest.raises(AccountingConservationError) as exc:
            adapter.finalize()
        assert "Exact document conservation violated" in str(exc.value)
