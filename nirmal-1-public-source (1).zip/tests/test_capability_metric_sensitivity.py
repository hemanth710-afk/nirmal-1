import pytest
from training.acquisition.capability_experiment_analysis import ExperimentAnalyzer

@pytest.fixture
def analyzer():
    return ExperimentAnalyzer()

def mock_accuracy_metric(inputs, labels):
    return sum(1 for i, l in zip(inputs, labels) if i == l) / max(1, len(inputs))

def test_metric_ablation_reacts_to_inputs(analyzer):
    inputs = [1, 0, 1, 0]
    labels = [1, 0, 1, 0]
    res = analyzer.run_metric_ablation(mock_accuracy_metric, inputs, labels)
    assert res["reacts_to_inputs"] == True

def test_metric_ablation_reacts_to_labels(analyzer):
    inputs = [1, 2, 3, 4, 5, 6, 7, 8]
    labels = [1, 2, 3, 4, 5, 6, 7, 8]
    res = analyzer.run_metric_ablation(mock_accuracy_metric, inputs, labels)
    assert res["reacts_to_labels"] == True

def test_detectable_synthetic_improvement(analyzer):
    sens = analyzer.classify_sensitivity([0.1, 0.1, 0.2], [0.8, 0.9, 0.85], known_difference=True)
    assert sens == "SENSITIVE"

def test_detectable_synthetic_regression(analyzer):
    sens = analyzer.classify_sensitivity([0.8, 0.9, 0.85], [0.1, 0.1, 0.2], known_difference=True)
    assert sens == "SENSITIVE"

def test_floor_ceiling_detection(analyzer):
    # Tests that flat lines near 0 are unmeasurable
    sens = analyzer.classify_sensitivity([0.0, 0.0], [0.0, 0.0])
    assert sens == "UNMEASURABLE"
