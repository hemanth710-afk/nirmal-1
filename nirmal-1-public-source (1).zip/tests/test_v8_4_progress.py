"""
Unit tests for data expansion progress tracking and token threshold gating in Nirmal-1 V8.4.
"""

import pytest

from training.cost_model import TrainingCostModel, H100_BF16_PEAK_TFLOPS


def test_progress_accounting_against_200b():
    target = 200_000_000_000
    staged = 233_997
    deficit = target - staged
    pct = (staged / target) * 100.0

    assert deficit == 199_999_766_003
    assert round(pct, 6) == 0.000117


def test_cost_model_projections():
    model = TrainingCostModel()
    projections = model.evaluate_all_topologies(target_tokens=200_000_000_000)
    assert len(projections) == 5

    # Recommended 64x H100
    rec = [p for p in projections if p["num_gpus"] == 64][0]
    assert rec["total_training_days"] < 5.0  # Around 2.64 days
    assert rec["throughput_tokens_per_sec"] > 700_000
    assert rec["provenance_labels"]["h100_peak_flops"].startswith("ASSUMED")
    assert rec["provenance_labels"]["mfu"].startswith("ESTIMATED")
