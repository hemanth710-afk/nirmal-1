"""Tests for V10.9 Report Completeness and Integrity."""

import json
from pathlib import Path
import pytest

REPORT_PATH = Path("docs/V10_9_FOUNDATIONAL_EPISODIC_LEARNING.md")
STAGE0_JSON = Path("experiments/v10_9/stage0/stage0_results.json")
STAGE1_JSON = Path("experiments/v10_9/stage1/stage1_results.json")


def test_report_exists_and_not_empty():
    assert REPORT_PATH.exists(), "Report markdown file is missing!"
    content = REPORT_PATH.read_text(encoding="utf-8")
    assert len(content) > 1000, "Report markdown file is unexpectedly short!"


def test_report_contains_all_14_required_sections():
    content = REPORT_PATH.read_text(encoding="utf-8")
    required_sections = [
        "## 1. Stage 0 — Instrumentation & Null Calibration",
        "## 2. Stage 1A — Identity Copy with Unseen Query Symbol",
        "## 3. Stage 1B — Copy from Support / Associative Retrieval",
        "## 4. Optimization Matrix (Foundational Factorial)",
        "## 5. Learning Curves and Training Dynamics",
        "## 6. Support-Control Results",
        "## 7. Readiness Gates (Gates 1–5)",
        "## 8. Per-Seed Results",
        "## 9. Gradient Health & Diagnostic Monitoring",
        "## 10. Measured Throughput Pilot",
        "## 11. Failure Classifications",
        "## 12. Exact Stopping Point",
        "## 13. Limits of Inference",
        "## 14. Stage 2 Progression Verdict",
    ]
    for section in required_sections:
        assert section in content, f"Missing required report section: {section}"


def test_report_scientific_failure_and_stopping_classification():
    content = REPORT_PATH.read_text(encoding="utf-8")
    assert "FOUNDATIONAL_EPISODIC_LEARNING_FAILURE" in content
    assert "STRICT NO-GO" in content
    assert "Stage 2 Authorized:" in content


def test_report_has_no_unresolved_placeholders():
    content = REPORT_PATH.read_text(encoding="utf-8")
    import re
    # Check for unrendered template tags like {SOMETHING_TABLE}
    matches = re.findall(r"\{[A-Z0-9_]+\}", content)
    assert len(matches) == 0, f"Found unrendered template tags in report: {matches}"


def test_results_json_manifests_exist_and_match():
    assert STAGE0_JSON.exists(), "stage0_results.json missing!"
    assert STAGE1_JSON.exists(), "stage1_results.json missing!"

    s0 = json.loads(STAGE0_JSON.read_text(encoding="utf-8"))
    s1 = json.loads(STAGE1_JSON.read_text(encoding="utf-8"))

    assert "throughput_pilot" in s0
    assert "stage0_sanitizers" in s0
    assert "factorial_results" in s1
    assert "confirmation_results" in s1
    assert len(s1["factorial_results"]) == 10
    assert len(s1["confirmation_results"]) == 2
