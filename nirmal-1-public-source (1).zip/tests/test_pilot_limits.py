"""
NIRMAL-1 V8.7: TEST SUITE FOR HARD PILOT RESOURCE CEILINGS (PHASE 3, 6, 10)

Verifies:
1. Normal execution passes within limits (<=100 docs, <=1 MB, <=100k tokens).
2. Byte limit overflow (> 1 MB) raises PilotLimitExceededError.
3. Document limit overflow (> 100 docs) raises PilotLimitExceededError.
4. Token limit overflow (> 100,000 tokens) raises PilotLimitExceededError.
5. Disk limit overflow raises PilotLimitExceededError.
"""

from pathlib import Path
import pytest

from training.acquisition.pilot_adapter import (
    WikipediaPilotAdapter,
    PilotLimitExceededError,
)


@pytest.fixture
def pilot_adapter(tmp_path):
    # Use isolated test dirs to avoid side effects
    staging_dir = tmp_path / "staging"
    shards_dir = tmp_path / "shards"
    manifests_dir = tmp_path / "manifests"
    return WikipediaPilotAdapter(
        staging_dir=staging_dir,
        shards_dir=shards_dir,
        manifests_dir=manifests_dir,
    )


class TestPilotLimits:
    """Test suite for pilot resource ceiling enforcement."""

    def test_normal_execution_within_limits(self, pilot_adapter):
        result = pilot_adapter.finalize_pilot()
        assert result.status == "SUCCESS"
        assert result.documents_accepted <= 100
        assert result.bytes_downloaded <= 1048576
        assert result.tokens_after_filter <= 100000

    def test_byte_limit_overflow_fails_closed(self, pilot_adapter):
        """Byte ceiling exceeded (> 1 MB) must trigger PilotLimitExceededError."""
        # Create a single huge record > 1 MB
        huge_text = "Quantum computing " * 70000  # ~1.2 MB
        huge_records = [{
            "id": "huge_doc_1",
            "title": "Huge Document",
            "revision_id": "rev_huge_1",
            "timestamp": "2026-09-08T12:00:00Z",
            "contributor": "Tester",
            "url": "https://en.wikipedia.org/wiki/Huge",
            "license": "CC-BY-SA-4.0",
            "text": huge_text,
        }]

        with pytest.raises(PilotLimitExceededError) as exc:
            pilot_adapter.finalize_pilot(records_override=huge_records)
        assert "Downloaded bytes exceed max limit" in str(exc.value) or "ceiling breached" in str(exc.value)

    def test_document_limit_overflow_fails_closed(self, pilot_adapter):
        """Document ceiling exceeded (> 100 docs) must trigger PilotLimitExceededError."""
        too_many_records = [
            {
                "id": f"doc_{i}",
                "title": f"Doc {i}",
                "revision_id": f"rev_{i}",
                "timestamp": "2026-09-08T12:00:00Z",
                "contributor": "Tester",
                "url": f"https://en.wikipedia.org/wiki/Doc_{i}",
                "license": "CC-BY-SA-4.0",
                "text": "This is a valid short scientific document text describing fundamental principles.",
            }
            for i in range(105)  # 105 > 100 max
        ]

        with pytest.raises(PilotLimitExceededError) as exc:
            pilot_adapter.finalize_pilot(records_override=too_many_records)
        assert "Discovered documents exceed max limit" in str(exc.value) or "Document ceiling breached" in str(exc.value)

    def test_token_limit_overflow_fails_closed(self, pilot_adapter):
        """Token ceiling exceeded (> 100,000 tokens) must trigger PilotLimitExceededError."""
        # Lower the max_tokens limit on adapter to test ceiling enforcement
        pilot_adapter.max_tokens = 500  # Strict 500 token ceiling

        with pytest.raises(PilotLimitExceededError) as exc:
            pilot_adapter.finalize_pilot()
        assert "Token ceiling breached" in str(exc.value)

    def test_disk_limit_overflow_fails_closed(self, pilot_adapter):
        """Simulated disk limit overflow fails closed."""
        # Set max_disk to an impossible requirement (e.g. 100 Petabytes)
        pilot_adapter.max_disk = 100 * 1024 * 1024 * 1024 * 1024 * 1024  # 100 PB

        with pytest.raises(PilotLimitExceededError) as exc:
            pilot_adapter.prepare_pilot()
        assert "Insufficient disk space" in str(exc.value)
