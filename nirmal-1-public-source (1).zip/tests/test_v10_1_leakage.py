"""V10.1 — leakage detection tests (integration with engine)."""
import pytest
from training.acquisition.v10_1_ood_amplification import (
    TaskConfig, TaskGenerator, VOCAB_CONDITIONS
)


@pytest.fixture
def gen():
    return TaskGenerator()


def test_leakage_cert_before_eval(gen):
    task = TaskConfig("copy", 4, (10, 35), (10, 35), (60, 85), 4, 1000)
    splits = gen.generate(task)
    cert = gen.leakage_certificate(splits)
    assert cert["valid"], "Canonical task must be leakage-free"


def test_partial_disjoint_subseq_safety(gen):
    task = VOCAB_CONDITIONS["PARTIAL_DISJOINT"]
    splits = gen.generate(task)
    cert = gen.leakage_certificate(splits)
    # Even partial overlap: row and subsequence checks must run
    assert "no_row_overlap" in cert
    assert "no_subseq_leak" in cert


def test_leakage_fails_on_identical_ranges(gen):
    task = TaskConfig("copy", 4, (10, 35), (10, 35), (10, 35), 4, 1000)
    splits = gen.generate(task)
    cert = gen.leakage_certificate(splits)
    assert not cert["vocab_disjoint"]
    assert not cert["valid"]


def test_leakage_cert_keys_complete(gen):
    task = VOCAB_CONDITIONS["FULL_DISJOINT"]
    splits = gen.generate(task)
    cert = gen.leakage_certificate(splits)
    for key in ("vocab_disjoint", "no_row_overlap", "no_subseq_leak", "valid"):
        assert key in cert
