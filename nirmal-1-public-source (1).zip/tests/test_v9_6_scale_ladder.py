import pytest
from scripts.v9_6_controlled_scaling import ScalingExperiment

def test_scale_ladder_progression():
    exp = ScalingExperiment()
    assert "SCALE_0" in exp.scales
    assert "SCALE_3" in exp.scales
    # Check monotonicity
    p0 = exp.scales["SCALE_0"]["params"]
    p1 = exp.scales["SCALE_1"]["params"]
    p2 = exp.scales["SCALE_2"]["params"]
    p3 = exp.scales["SCALE_3"]["params"]
    assert p0 < p1 < p2 < p3

def test_scale_config_validity():
    exp = ScalingExperiment()
    for k, v in exp.scales.items():
        assert "layers" in v
        assert "dim" in v
        assert "params" in v
        assert "est_ram" in v
        assert "est_time" in v
