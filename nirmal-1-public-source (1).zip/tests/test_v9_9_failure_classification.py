import pytest
from scripts.v9_9_ood_investigation import OodInvestigator

def test_failure_signal():
    inv = OodInvestigator()
    # Signal failure overwrites other failures if train < 0.8
    assert inv.classify_failure(0.5, 0.0, "VOCAB_DISJOINT") == "TRAINING_SIGNAL_FAILURE"

def test_failure_success():
    inv = OodInvestigator()
    # Success overwrites other failures if OOD >= 0.8
    assert inv.classify_failure(0.9, 0.9, "VOCAB_DISJOINT") == "SUCCESS"

def test_failure_vocab():
    inv = OodInvestigator()
    assert inv.classify_failure(0.9, 0.0, "VOCAB_DISJOINT") == "VOCABULARY_FAILURE"

def test_failure_position():
    inv = OodInvestigator()
    assert inv.classify_failure(0.9, 0.0, "POSITION_PERMUTED") == "POSITION_FAILURE"

def test_failure_context():
    inv = OodInvestigator()
    assert inv.classify_failure(0.9, 0.0, "CONTEXT_CHANGED") == "CONTEXT_FAILURE"
