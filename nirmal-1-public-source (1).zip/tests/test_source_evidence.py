"""
Test Suite for Source Evidence Dossiers and Approval Invariants (Nirmal-1 V8.4).

Verifies:
1. All 9 source dossiers in data/source_evidence/ load and validate successfully.
2. Invariant: Source cannot be APPROVED with a missing physical evidence file.
3. Invariant: Source cannot be APPROVED with a placeholder checksum.
4. Invariant: Source cannot be APPROVED with a placeholder URL.
5. Invariant: Source cannot be APPROVED with unresolved restrictions.
6. Tampered license text hash is detected and rejected.
7. External 6 sources are properly kept in UNDER_REVIEW status.
8. Only in-repo synthetic corpus is APPROVED with verified on-disk evidence.
"""

from pathlib import Path
import pytest

from training.acquisition.evidence import (
    SourceEvidenceDossier,
    SourceEvidenceManager,
    ApprovalStatus,
    EvidenceValidationError,
)

REPO_ROOT = Path(__file__).resolve().parent.parent


@pytest.fixture
def evidence_mgr():
    return SourceEvidenceManager()


class TestSourceEvidenceDossiers:
    """Rigorous tests enforcing fail-closed source approval invariants."""

    def test_all_registered_dossiers_exist_and_validate(self, evidence_mgr):
        dossiers = evidence_mgr.load_all_dossiers()
        assert len(dossiers) == 9

        # Target 6 external sources
        target_6 = [
            "fineweb_edu_permissive",
            "the_stack_v2_permissive",
            "arxiv_open_access_papers",
            "dolma_v1_7_permissive",
            "redpajama_v2_permissive",
            "wikipedia_open_corpus",
        ]
        for src_id in target_6:
            assert src_id in dossiers
            d = dossiers[src_id]
            assert d.approval_status == ApprovalStatus.UNDER_REVIEW
            # Must pass validate() because it is UNDER_REVIEW
            d.validate(base_dir=evidence_mgr.evidence_dir)

    def test_only_synthetic_corpus_is_approved(self, evidence_mgr):
        dossiers = evidence_mgr.load_all_dossiers()
        approved = [s for s, d in dossiers.items() if d.approval_status == ApprovalStatus.APPROVED]
        assert approved == ["nirmal_synthetic_v8_2"], f"Only synthetic corpus should be approved, got: {approved}"

        synth = dossiers["nirmal_synthetic_v8_2"]
        synth.validate(base_dir=evidence_mgr.evidence_dir)
        is_app, reason = evidence_mgr.check_source_approval("nirmal_synthetic_v8_2")
        assert is_app is True
        assert "officially APPROVED" in reason

    def test_approved_with_missing_evidence_file_fails(self, evidence_mgr):
        """Cannot be APPROVED without a real physical evidence file on disk."""
        fake_dossier = SourceEvidenceDossier(
            source_id="fake_source",
            canonical_source_name="Fake Source",
            canonical_url="https://valid.org/dataset",
            dataset_version_identifier="1.0",
            acquisition_method="TEST",
            snapshot_revision_identifier="rev1",
            retrieval_timestamp="2026-09-06",
            source_checksum="a" * 64,
            license_url="https://valid.org/license",
            license_text_hash=None,
            license_evidence_file_path="non_existent_file_path_12345.txt",
            terms_policy_evidence_file_path=None,
            dataset_card_evidence_file_path=None,
            declared_license="Apache-2.0",
            per_file_license_policy="TEST",
            known_restrictions=[],
            approval_status=ApprovalStatus.APPROVED,
            benchmark_contamination_status="SYNTHETIC_CLEAN",
        )
        with pytest.raises(EvidenceValidationError) as exc:
            fake_dossier.validate(base_dir=evidence_mgr.evidence_dir)
        assert "physical evidence file does not exist" in str(exc.value)

    def test_approved_with_placeholder_checksum_fails(self, evidence_mgr):
        """Cannot be APPROVED with placeholder checksum (e.g. PENDING, TODO)."""
        valid_evidence_file = Path("evidence_files/nirmal_synthetic_v8_2_evidence.txt")
        dossier = SourceEvidenceDossier(
            source_id="fake_source_2",
            canonical_source_name="Fake Source 2",
            canonical_url="https://valid.org/dataset",
            dataset_version_identifier="1.0",
            acquisition_method="TEST",
            snapshot_revision_identifier="rev1",
            retrieval_timestamp="2026-09-06",
            source_checksum="PENDING_REMOTE_SYNC",  # Placeholder!
            license_url="https://valid.org/license",
            license_text_hash=None,
            license_evidence_file_path=str(valid_evidence_file),
            terms_policy_evidence_file_path=None,
            dataset_card_evidence_file_path=None,
            declared_license="Apache-2.0",
            per_file_license_policy="TEST",
            known_restrictions=[],
            approval_status=ApprovalStatus.APPROVED,
            benchmark_contamination_status="SYNTHETIC_CLEAN",
        )
        with pytest.raises(EvidenceValidationError) as exc:
            dossier.validate(base_dir=evidence_mgr.evidence_dir)
        assert "placeholder checksum" in str(exc.value)

    def test_approved_with_placeholder_url_fails(self, evidence_mgr):
        """Cannot be APPROVED with placeholder URL (e.g. example.com)."""
        valid_evidence_file = Path("evidence_files/nirmal_synthetic_v8_2_evidence.txt")
        dossier = SourceEvidenceDossier(
            source_id="fake_source_3",
            canonical_source_name="Fake Source 3",
            canonical_url="https://example.com/placeholder_repo",  # Placeholder URL
            dataset_version_identifier="1.0",
            acquisition_method="TEST",
            snapshot_revision_identifier="rev1",
            retrieval_timestamp="2026-09-06",
            source_checksum="b" * 64,
            license_url="https://valid.org/license",
            license_text_hash=None,
            license_evidence_file_path=str(valid_evidence_file),
            terms_policy_evidence_file_path=None,
            dataset_card_evidence_file_path=None,
            declared_license="Apache-2.0",
            per_file_license_policy="TEST",
            known_restrictions=[],
            approval_status=ApprovalStatus.APPROVED,
            benchmark_contamination_status="SYNTHETIC_CLEAN",
        )
        with pytest.raises(EvidenceValidationError) as exc:
            dossier.validate(base_dir=evidence_mgr.evidence_dir)
        assert "placeholder URL" in str(exc.value)

    def test_approved_with_unresolved_restrictions_fails(self, evidence_mgr):
        """Cannot be APPROVED if unresolved restrictions exist."""
        valid_evidence_file = Path("evidence_files/nirmal_synthetic_v8_2_evidence.txt")
        dossier = SourceEvidenceDossier(
            source_id="fake_source_4",
            canonical_source_name="Fake Source 4",
            canonical_url="https://valid.org/dataset",
            dataset_version_identifier="1.0",
            acquisition_method="TEST",
            snapshot_revision_identifier="rev1",
            retrieval_timestamp="2026-09-06",
            source_checksum="c" * 64,
            license_url="https://valid.org/license",
            license_text_hash=None,
            license_evidence_file_path=str(valid_evidence_file),
            terms_policy_evidence_file_path=None,
            dataset_card_evidence_file_path=None,
            declared_license="Apache-2.0",
            per_file_license_policy="TEST",
            known_restrictions=["Unresolved copyright issue in subset B"],
            approval_status=ApprovalStatus.APPROVED,
            benchmark_contamination_status="SYNTHETIC_CLEAN",
        )
        with pytest.raises(EvidenceValidationError) as exc:
            dossier.validate(base_dir=evidence_mgr.evidence_dir)
        assert "unresolved restrictions" in str(exc.value)

    def test_license_text_hash_mismatch_fails(self, evidence_mgr):
        """Hash mismatch between declared license_text_hash and on-disk file fails."""
        valid_evidence_file = Path("evidence_files/nirmal_synthetic_v8_2_evidence.txt")
        dossier = SourceEvidenceDossier(
            source_id="fake_source_5",
            canonical_source_name="Fake Source 5",
            canonical_url="https://valid.org/dataset",
            dataset_version_identifier="1.0",
            acquisition_method="TEST",
            snapshot_revision_identifier="rev1",
            retrieval_timestamp="2026-09-06",
            source_checksum="d" * 64,
            license_url="https://valid.org/license",
            license_text_hash="tampered_hash_value_12345",
            license_evidence_file_path=str(valid_evidence_file),
            terms_policy_evidence_file_path=None,
            dataset_card_evidence_file_path=None,
            declared_license="Apache-2.0",
            per_file_license_policy="TEST",
            known_restrictions=[],
            approval_status=ApprovalStatus.APPROVED,
            benchmark_contamination_status="SYNTHETIC_CLEAN",
        )
        with pytest.raises(EvidenceValidationError) as exc:
            dossier.validate(base_dir=evidence_mgr.evidence_dir)
        assert "hash mismatch" in str(exc.value)
