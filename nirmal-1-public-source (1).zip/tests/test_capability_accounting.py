import pytest
from pathlib import Path
from training.acquisition.capability_mixture import CapabilityMixturePlanner
from training.acquisition.wikimedia_real_adapter import WikimediaRealAdapter

def test_hard_data_limits():
    adapter = WikimediaRealAdapter()
    assert adapter.max_docs <= 100
    assert adapter.max_bytes <= 10485760
    assert adapter.max_tokens <= 100000
    assert adapter.max_disk <= 104857600

def test_rejection_rates(tmp_path):
    planner = CapabilityMixturePlanner(Path("data/capability_taxonomy.json"))
    
    planner.record_rejection("duplicate")
    planner.record_rejection("duplicate")
    planner.record_rejection("contaminated")
    planner.record_rejection("security")
    
    planner.add_document({"token_count": 100, "source_id": "src1", "capability_labels": ["UNKNOWN"]})
    
    report = planner.get_report()
    # duplicates = 2/4 total? Wait, the planner records rate independently.
    assert planner.duplicate_rate["duplicates"] == 2
    assert planner.contamination_rate["contaminated"] == 1
    assert planner.security_rejection_rate["rejected"] == 1
