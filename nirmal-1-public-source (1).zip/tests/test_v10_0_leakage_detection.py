"""Tests for leakage detection correctness — V10.0."""
import pytest
import torch
from training.acquisition.v10_0_intervention_engine import TaskGenerator


gen = TaskGenerator()


def test_cert_catches_vocab_overlap():
    train = torch.tensor([[10, 20, 30]])
    ood   = torch.tensor([[25, 35, 45]])  # 25 appears in train range, but not exact token
    # 25 not in {10,20,30} so vocab overlap = False
    cert = gen.leakage_certificate({"train": train, "val": train, "ood": ood})
    assert cert["vocab_disjoint"]  # 25/35/45 not in {10,20,30}


def test_cert_catches_explicit_overlap():
    train = torch.tensor([[10, 20, 30]])
    ood   = torch.tensor([[10, 50, 60]])  # 10 is shared
    cert = gen.leakage_certificate({"train": train, "val": train, "ood": ood})
    assert not cert["vocab_disjoint"]
    assert not cert["valid"]


def test_cert_catches_exact_row_dup():
    train = torch.tensor([[10, 20, 30]])
    ood   = torch.tensor([[10, 20, 30]])  # exact dup
    cert = gen.leakage_certificate({"train": train, "val": train, "ood": ood})
    assert not cert["no_row_overlap"]
    assert not cert["valid"]


def test_cert_catches_subseq_leak():
    train = torch.tensor([[10, 20, 30, 40]])
    ood   = torch.tensor([[10, 20, 30, 99]])  # first three match
    cert = gen.leakage_certificate({"train": train, "val": train, "ood": ood})
    assert not cert["no_subseq_leak"]
    assert not cert["valid"]


def test_cert_clean_data():
    train = torch.tensor([[10, 11, 12]])
    ood   = torch.tensor([[60, 61, 62]])
    cert = gen.leakage_certificate({"train": train, "val": train, "ood": ood})
    assert cert["valid"]
